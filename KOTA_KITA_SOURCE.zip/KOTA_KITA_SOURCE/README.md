# KOTA KITA – Dunia Malaysia · Complete Source Export

This is the complete game as published on the Claude Artifact
(version `1795400989-95fd`), exported **unchanged**. No feature was removed or redesigned.

The game is an HTML5 canvas game written in plain JavaScript. It has **no libraries or
frameworks** and needs **no internet connection**. Everything is drawn and played by code:
characters, the isometric map, buildings, animals, food and the music and sound effects.

---

## 1. Quick start

| I want to… | Use this file |
|---|---|
| Play the game now (offline, any browser) | `index.html` |
| Make an APK with an HTML-to-APK converter app/website | `index.html` (one single file, everything embedded) |
| Make an APK with an Android IDE app on the phone | the `android/` folder |
| Edit the game code | `src/`, then run `tools/build.py` |
| Host it on a website | `web/` folder |

**Mula cepat (BM):** Buka `index.html` dalam Chrome untuk bermain. Untuk APK, gunakan
`index.html` (satu fail lengkap) dalam aplikasi penukar HTML-ke-APK, atau buka folder
`android/` dalam aplikasi IDE Android dan tekan *Build*. Lihat bahagian 4.

---

## 2. What is in this ZIP

```
KOTA_KITA_SOURCE/
├── index.html                  ← THE GAME. Single self-contained offline file (1.3 MB):
│                                 HTML + CSS + all JavaScript + fonts + images embedded.
├── original_artifact/
│   └── index.html              ← Byte-for-byte copy of the published Artifact
│                                 (SHA-256 2b4781e3…ec82). Loads fonts from Google Fonts.
├── src/                        ← Complete editable source code
│   ├── shell.html                HTML structure (title, creator, game HUD, panels, dialogs)
│   ├── style.css                 All CSS
│   └── *.js (29 files)           All game JavaScript (see section 3)
├── fonts/                      ← Fredoka + Nunito (woff2) + fonts.css + OFL licences
├── assets/images/              ← Image files (see docs/ASSETS.md)
├── web/                        ← Multi-file web build: web/index.html + web/fonts/
├── android/                    ← Ready Android WebView project (Gradle, Java, no libraries)
├── tools/build.py              ← Rebuilds index.html, web/ and android assets from src/
└── docs/
    ├── ASSETS.md               ← Where every character/map/sound asset lives in the code
    ├── SAVE_DATA.md            ← Save system and full player-data structure
    ├── sample_save.json        ← A real save file from a new game
    ├── FILE_CHECKSUMS.txt      ← SHA-256 of every file in this ZIP
    └── screenshots/            ← Screenshots taken from this exported build, offline
```

The **only** change from the Artifact is how fonts load: the Artifact downloads Fredoka and
Nunito from Google Fonts, while this `index.html` has the same two fonts embedded so that it
works with no internet inside an APK. All game code, CSS and images are identical.

---

## 3. Source files (`src/`)

`tools/build.py` joins the JS files **in this exact order** (later files extend earlier
ones, so the order matters) and inserts them plus `style.css` into `shell.html`.

| # | File | Contents |
|---|---|---|
| 1 | `data.js` | Character options (skin, faces, eyes, hair, hijab, accessories), outfits incl. traditional wear, items and game data |
| 2 | `assets.js` | Embedded photo avatar artwork (2 base64 JPEGs, also in `assets/images/`) |
| 3 | `chibi.js` | Chibi character renderer (body, skin, hair, eyes, clothes, hijab, accessories) |
| 4 | `anime.js` | Anime-style portraits and character art |
| 5 | `world.js` | 72×72 tile world grid, collision tiles, base world data and tile drawing |
| 6 | `engine.js` | Runtime state, player, townsfolk NPCs, movement, collision, interactions, update loop |
| 7 | `core.js` | Game state `S`, new save, save/load (`localStorage`), calendar & time, daily tick, bills, money |
| 8 | `ui.js` | Icons, navigation, screen scaling, HUD, panel & dialog framework, new game / continue |
| 9 | `games.js` | Mini-games: fishing (with sea creatures), rush, quiz |
| 10 | `panels1.js` | Panels: travel, home rooms & furniture, part-time/full-time jobs, education institutions |
| 11 | `panels2.js` | Panels: wardrobe, shops, food, books, gadgets, fishing, farm, market |
| 12 | `loc.js` | Location activities, building scenes and action cards, NPC dialogue |
| 13 | `features.js` | Mission panel (Misi Harian), skills, location locks, gem shop, aquarium, certificates |
| 14 | `life.js` | Age groups, Malaysian states, education background, adult careers, employers |
| 15 | `creator.js` | Character creator |
| 16 | `update.js` | New-player welcome bonus and "Balik ke Rumah" |
| 17 | `iso_gen.js` | Isometric 2.5D city map generator (districts, roads, sea, river, rail, airport) |
| 18 | `iso_art.js` | Drawing code for every building, tree and prop |
| 19 | `iso_render.js` | Isometric renderer, camera, zoom, pathfinding, minimap |
| 20 | `iso_hud.js` | Reference-style HUD (gold/purple panels, bottom nav, event card) |
| 21 | `career2.js` | Careers, sponsorships, phone calls, **audio engine (music + sound effects)** |
| 22 | `x_base.js` | Expansion hooks, surau and prayer times, pet clinic building |
| 23 | `x_cook.js` | 13 signature recipes, step-by-step cooking mini-game, kitchen, groceries |
| 24 | `x_tapau.js` | TapauGo food delivery |
| 25 | `x_fest.js` | Festivals (CNY, Raya, Ramadan bazaar, Deepavali, Christmas, Gawai…) |
| 26 | `x_home.js` | Free home design mode, 10 rooms, furniture |
| 27 | `x_shop.js` | BorongKu & KedaiKlik marketplaces |
| 28 | `x_pet.js` | Pet adoption, strays, pet care |
| 29 | `x_farm.js` | Farming expansion: crops, animals, buildings, farm missions |

Rebuild after editing (needs Python 3, works on a PC or in Termux on Android):

```
python3 tools/build.py
```

---

## 4. Making the Android APK using only your phone

### Option A – HTML-to-APK converter app or website (easiest)
1. Unzip this file on your phone (Files app → tap the ZIP → Extract).
2. In the converter, choose "HTML / local file" and select **`index.html`** from the root
   folder. It is one complete file, so no other files are needed.
3. Set these options if the converter has them:
   - JavaScript: **ON**
   - DOM storage / localStorage: **ON** (required, otherwise the game cannot save)
   - Orientation: **Landscape**
   - Full screen: ON
   - App icon: `assets/images/app_icon_512.png`
4. Build, download and install the APK.

### Option B – Android IDE on the phone (full control)
The `android/` folder is a complete, minimal Android Studio–format project:
- One Java file, no external libraries.
- Package `com.kotakita.game`; minSdk 21 (Android 5.0), targetSdk 34.
- Landscape, full screen, keeps the screen on.
- localStorage saving enabled; the Back button closes panels like the game's Esc key.

It builds with any Gradle-based on-phone IDE, e.g. **Code on the Go** (free, open source)
or **AndroidIDE**:
1. Unzip, then open the `android` folder as a project in the IDE.
2. The first build downloads Gradle 8.4 and Android Gradle Plugin 8.2.2, so it needs
   internet once.
3. Run the `assembleDebug` build (or tap *Build/Run*). The APK appears in
   `android/app/build/outputs/apk/debug/app-debug.apk`.
4. Install it. If you change the game, run `tools/build.py` again (or copy the new
   `index.html` into `android/app/src/main/assets/`).

Note: `MainActivity.java` was compile-checked against the Android API here, but the full
Gradle/APK build was not run in this export environment, which has no Android SDK.

### Option C – Play in the phone browser
Open `index.html` in Chrome on the phone. Saves are stored in that browser.

---

## 5. Saves

- Saves are stored in the browser/WebView **localStorage** under the key
  `kotakita_dunia_malaysia_v1`. The game saves automatically as you play, and with the
  **Simpan** button on the HUD.
- A save made in the Claude Artifact is stored by your browser for that website, so it
  does **not** move into the APK by itself. The APK starts with a new game.
- Older saves are upgraded automatically when loaded, and no items are lost.
- Full data structure: `docs/SAVE_DATA.md`.

---

## 6. Requirements and dependencies

| Need | Status |
|---|---|
| Libraries / frameworks | **None**: plain JavaScript, Canvas 2D, Web Audio |
| Internet | Not needed (the original Artifact file only needs it for fonts) |
| Fonts | Fredoka & Nunito, included (SIL Open Font License, see `fonts/`) |
| Browser / WebView | Any modern Chromium (Android System WebView 70+), Firefox, Safari |
| Screen | Landscape. Scales from 640×360 phones to 4K, with touch, mouse and keyboard |
