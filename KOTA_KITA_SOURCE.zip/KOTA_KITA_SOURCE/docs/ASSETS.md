# Game assets – where everything lives

KOTA KITA was built **code-first**: almost all graphics are drawn at runtime on an HTML5
`<canvas>` with vector paths, and all music and sound effects are synthesised with the
**Web Audio API**. So there are very few separate image files and **no audio files**. The
assets *are* the source code below, and all of it is in `src/` and in `index.html`.

That makes the game small (about 1.3 MB in total), sharp at any screen resolution, and
fully offline.

## Image files (`assets/images/`)

| File | Used for |
|---|---|
| `photo_avatar_gadis_full.jpg` (298×624) | Special "Gadis Penampang" photo avatar, full body. Embedded in `src/assets.js` |
| `photo_avatar_gadis_head.jpg` (200×200) | Same avatar, head portrait. Embedded in `src/assets.js` |
| `app_icon_512.png`, `app_icon_192.png` | App icon for the APK / converter (new, not part of the game) |

The two JPEGs are copies for convenience. The game itself uses the embedded versions, so
nothing needs to be copied.

## Characters (drawn by code)

| What | Code |
|---|---|
| Chibi player & NPC renderer: skin, face shapes, eyes, brows, noses, mouths, expressions, 18 hairstyles, hijab (4 styles), 12 hats, 7 glasses, 8 accessories, 15 shoes, bags, earrings, necklaces, beards, poses | `src/chibi.js` + option lists in `src/data.js` |
| Anime-style portraits | `src/anime.js` |
| Outfits: daily, school, college, work/uniform, sport, modern, formal, and traditional Malaysian wear (Melayu, Cina, India, Sabah, Sarawak, Warisan Lain), plus festive outfits | `src/data.js`, `src/x_fest.js` (festive outfits) |
| Character creator previews | `src/creator.js` |
| Townsfolk NPC looks | `src/engine.js` (`npcLook`, `FOLK`) |
| Pets: 16 breeds with animated vector art | `src/x_pet.js` (`drawPet`) |
| Farm animals | `src/iso_art.js` (props), `src/x_farm.js` |
| Delivery rider, courier van, Santa, lion/dragon dance, parade | `src/x_tapau.js`, `src/x_shop.js`, `src/x_fest.js` |

## Map and locations (drawn by code)

| What | Code |
|---|---|
| Isometric 2.5D city layout: districts, roads, sea, river, pond, rail, runway, island, coast, trees, props, vehicles | `src/iso_gen.js` |
| Building art (36 kinds): airport, apartment, fire station, city hall, bank, barn, bus terminal, beach hut, cinema, factory, gazebo, government office, hospital, houses, jetty hut, kampung house, train station, career centre, clinic, library, lighthouse, LRT, mall, food court, market, night market, pet clinic, police, port, ranger post, resort, school, stadium, surau, university | `src/iso_art.js` (`BART`), `src/x_base.js` (surau, pet clinic) |
| Trees, lamps, stalls, umbrellas, boats, containers, cranes, tanks, planes, towers, flags, benches, waterfall, fountain | `src/iso_art.js` (`treeArt`, `propArt`) |
| Ground textures, labels, district names, minimap, full map | `src/iso_render.js` |
| 32 enterable locations and their interior scenes | `src/loc.js` (`drawScene`), `src/iso_render.js` (`drawBldPortrait`) |
| Rooms and 71 furniture items for home design | `src/panels1.js` (`drawRoom`, `drawFurn`), `src/x_home.js` |
| Festival decorations: lanterns, ketupat, pelita, kolam, flags, Christmas tree, snow, fireworks | `src/x_fest.js` |
| Fish and sea creatures | `src/games.js` (`drawCreature`) |
| Food and dishes (cooking mini-game) | `src/x_cook.js` |
| Farm view (18 crops, growth stages) | `src/x_farm.js` (`drawFarm`), `src/panels2.js` |
| HUD icons (SVG) | `src/ui.js` (`ICON`), `src/iso_hud.js` |

## Sound effects and music (synthesised with Web Audio)

All audio is in `src/career2.js` (`AU` audio engine):

- **Mixer:** master, music, sound-effect and ringtone volume channels with mute, saved in
  `localStorage` key `kotakita_audio_v1`.
- **Sound effects** (`SFX`): click, notify, coin, cash, sponsor, success, fanfare, offer,
  reject, decline, mission, assign, pickup, hangup.
- **Phone ringtone** for incoming job/sponsor calls.
- **Background music:** a procedural chord-and-melody sequencer (`PROG` chords, `PENT`
  melody scale). `src/x_fest.js` swaps these for festival-themed music.
- Audio pauses automatically when the app goes to the background.

## Fonts (`fonts/`)

Fredoka (500, 600, 700) for titles and Nunito (600–900) for text, in woff2 with Latin and
Latin-Extended character sets. Licensed under the SIL Open Font License (see the
`LICENSE-*.txt` files). They are embedded in `index.html` and linked from `web/fonts/`.
