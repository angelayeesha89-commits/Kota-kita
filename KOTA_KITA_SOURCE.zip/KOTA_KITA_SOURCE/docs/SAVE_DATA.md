# Save system and player data structure

## Storage

The game stores everything in the browser/WebView `localStorage` as JSON text:

| Key | Contents | Code |
|---|---|---|
| `kotakita_dunia_malaysia_v1` | The whole game state object `S` (below) | `src/core.js` (`save`, `loadSave`, `wipeSave`) |
| `kotakita_audio_v1` | Volume settings `{master, music, sfx, ring, mute}` | `src/career2.js` (`auSave`) |
| `kotakita_bonus_claims_v1` | Player IDs that already received the welcome bonus (stops it being given twice) | `src/update.js` |

- **Saving:** `save()` writes `S` (plus the player position) automatically during play
  and when **Simpan** is pressed.
- **Loading:** "Sambung" (Continue) runs `loadSave()`, then the upgrade steps below, then
  `startGame()`.
- **Upgrading old saves:** `migrate()` (`src/ui.js`), `migrateLife()` (`src/life.js`) and the
  `XDEF` / `XMIG` hooks (`src/x_base.js` and each `x_*.js`) add any missing fields with
  default values. They never delete data. `mapV` marks the map version (2 = isometric map),
  and older positions are moved to the new map.
- **In an APK:** the Android WebView keeps localStorage in the app's private storage. It
  is kept across restarts and app updates (if signed with the same key), and removed only
  by "Clear data" or uninstalling.

A complete real example is in `docs/sample_save.json` (a new game, 108 fields).

## Fields of `S` (`kotakita_dunia_malaysia_v1`)

### Profile and character
| Field | Type | Meaning |
|---|---|---|
| `v` | number | Save format version |
| `pid` | string | Unique player ID (`KK-…`) |
| `name` | string | Player name |
| `age`, `bday` | number, [day, month] | Age and birthday |
| `stage` | string | Life stage (school, college, adult…) |
| `state`, `town`, `resState` | string | Home state, town and state of residence |
| `look` | object | Full appearance: pose, skin, face, eye, eyeCol, brow, nose, mouth, hair, hairCol, hijab, hijabSt, hijabCol, glasses, hat, acc, bag, ear, neck, beard, body, style, expr, shoes, g (gender), outfit |
| `photo` | string/null | Selected photo avatar |
| `profileSet`, `bgTop`, `mqSet` | | Profile setup flags |
| `agama` | string | Optional religion setting ('' = not set; prayer features only when chosen) |

### Progress and money
| Field | Type | Meaning |
|---|---|---|
| `money`, `bank`, `debt`, `mortgage` | number / object | Wallet, bank balance, loans, house loan |
| `gems` | number | Premium gems |
| `xp`, `lvl`, `energy` | number | Experience, level, energy |
| `stats` | `{akademik, karisma, cergas, gembira}` | Academic, charisma, fitness, happiness |
| `sk`, `skSnap` | object | Skill points and snapshot |
| `time` | number | Game clock in minutes since the start date (14 Feb) |
| `weather` | string | Current weather |
| `pos` | [x, y] | Player position on the map |
| `mapV`, `zoomI` | number | Map version, camera zoom level (added when zoom is changed) |
| `tx` | array | Transaction history |
| `cnt` | object | Counters (shifts, fish, harvests, cooking, festivals…) used by achievements |
| `ach` | object | Unlocked achievements |
| `visited` | object | Locations visited |

### Missions, calendar and messages
`mq` (main quest step), `dq` (daily missions `{d, list}`), `wq` (weekly missions),
`daily`, `events`, `festDone`, `notifs`, `msgs`, `journal`.

### Education and career
`school {classes}`, `spm`, `edu`, `apps`, `degrees`, `certs`, `clubs`, `job`, `ptSkill`,
`workLog`, `biz` (businesses), `japps` (job applications), `exp` (work experience),
`ptHired`, `resume {obj, langs, done}`, `vac`/`vacW`/`vacN`/`ptVac` (job vacancies),
`pracRec` (internships), `spon` (sponsorship `{id, name, start, end, paid, total}`),
`bonusClaimed`, `bonusAt`, `bonusAmt` (welcome bonus).

### Clothing and items
`owned` (outfits), `ownedShoes`, `ownedHijab`, `ownedGlasses`, `ownedHats`, `ownedAccs`,
`ownedBags`, `ownedEars`, `ownedNecks`, `styles` (saved looks), `inv` (inventory
`{itemId: quantity}`), `vehicles`, `ride`.

### Home and furniture
`home {type, owned, rooms}`. The 10 rooms are `bilik`, `tamu`, `dapur`, `mandi`, `belajar`,
`balkoni`, `laman`, `bilik2`, `makan`, `luar`. Each room is `{wall, floor, items, lay}` (plus
`cur` once curtains are chosen), where `lay` is a list of
`{id, x, y, r, s, c}` (furniture id, position, mirror flip, size, colour).
`furn` = furniture in storage, `homeSaved` = saved layouts.

### Fishing and farming
`rod`, `rodsOwned`, `baits`, `bait`, `fishInv`, `fishdex`, `aqua` (aquarium),
`farm {plots, size, animals, barn}`, `farmx {xp, bld, clean, breed, fm}` (farm level,
buildings, cleanliness, breeding, farm missions).

### Social
`friends`, `talked`, `msgd`, `gifted`, `invited`.

### Expansion systems
| Field | Meaning |
|---|---|
| `cook {xp, cooked, best, n, kitGiven}` | Cooking skill, dishes cooked, best results |
| `tg {cart, rest, orders, n, q, cat}` | TapauGo cart and orders |
| `mk {cart, orders, n, shop, cat}`, `mkDefs` | BorongKu/KedaiKlik cart, orders, delivered furniture definitions |
| `evr {eventKey: {...}}` | Festival records: angpao/duit raya claimed, visits, outfits |
| `solat`, `prayNotif` | Prayer log and notification setting |
| `pets`, `petMeta {n, stray, centre, walk}` | Adopted pets (stats, breed, accessories) and adoption-centre state |
| `audio` | Copy of the volume settings |

## Backing up / moving a save (advanced)

In a desktop browser console on the page where the game runs:
```js
copy(localStorage.getItem('kotakita_dunia_malaysia_v1'))          // copy save text
localStorage.setItem('kotakita_dunia_malaysia_v1', '<pasted text>') // restore, then reload
```
