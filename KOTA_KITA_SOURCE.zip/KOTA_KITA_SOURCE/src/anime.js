// ===================== ANIME 2.5D RENDERER (young-adult proportions) =====================
// Design units ("D"): feet at y=0, ~6 heads tall (≈264 D). Drawn at A_K world units per D.
const A_K=.5;
function aGeom(C){const BP=BODIES[C.body||0]||BODIES[0],CS=CSTYLES[C.style||0]||CSTYLES[0];const f=C.g==='f';
  const bw=BP[1]*1.04*(CS[3]||1),bh=BP[2]*.96*(CS[2]||1),hs=CS[1]*1.3;
  return{f,bw,bh,hs,sh:(f?21.5:26.5)*bw,chest:(f?19:22.5)*bw,waist:(f?13.6:17.5)*bw,hip:(f?21.5:19.5)*bw,
    neckY:-214*bh,shY:-199*bh,chestY:-182*bh,waistY:-150*bh,hipY:-126*bh,crotchY:-115*bh,kneeY:-62*bh,ankleY:-11,
    headY:-214*bh-21*hs,chibi:(CS[2]||1)<.8}}
function animeHeadCentre(C,fy){const g=aGeom(C);return{hs:.6*g.hs,cy:(g.headY+(fy||0)*.95*g.hs)*A_K}}
function animeHeight(C){const g=aGeom(C);return-(g.headY-30*g.hs)*A_K}
// body half-width at y (D units)
function bodyW(g,y){const T=[[g.neckY,5.6],[g.shY-4,12],[g.shY,g.sh-1.5],[g.chestY,g.chest],[g.waistY,g.waist],[g.hipY,g.hip],[g.crotchY,g.hip-.6]];
  if(y<=T[0][0])return T[0][1];for(let i=1;i<T.length;i++){if(y<=T[i][0]){const [y0,w0]=T[i-1],[y1,w1]=T[i];const t=(y-y0)/(y1-y0);return w0+(w1-w0)*(t*t*(3-2*t))}}return T[T.length-1][1]}
// garment silhouette from y0 to hem with ease (and optional flare below waist)
function garmentPath(g,y0,hem,ease,flare,neck){const p=new Path2D(),L=[],Rr=[];const step=3;
  for(let y=y0;y<=hem;y+=step){let w=bodyW(g,Math.min(y,g.crotchY))+ease;if(y>g.waistY&&flare)w+=flare*Math.pow((y-g.waistY)/Math.max(1,hem-g.waistY),1.2);if(y>g.crotchY&&!flare)w+=0;L.push([-w,y]);Rr.push([w,y])}
  const wl=bodyW(g,Math.min(hem,g.crotchY))+ease+(flare&&hem>g.waistY?flare:0);L.push([-wl,hem]);Rr.push([wl,hem]);
  p.moveTo(-(neck||6.5),y0-1);p.quadraticCurveTo(0,y0+(neck?5:3),(neck||6.5),y0-1);
  for(const [x,y] of Rr)p.lineTo(x,y);
  p.quadraticCurveTo(0,hem+2.2,L[L.length-1][0],hem);
  for(let i=L.length-1;i>=0;i--)p.lineTo(L[i][0],L[i][1]);p.closePath();return p}
function legPath(g,s,lift,ease,kind){// s=-1 left, 1 right
  const hx=s*(g.f?9.6:9.8)*g.bw,kx=s*(g.f?7.2:8.6)*g.bw,ax=s*(g.f?6.4:7.6)*g.bw,ky=g.kneeY-lift*.5,ay=g.ankleY-lift;
  let tW=(g.f?11.4:11.8)*g.bw+ease,kW=7.4+ease*.8,cW=7.8+ease*.7,aW=4.8+ease*.6;
  if(kind==='cargo'){kW+=2.4;cW+=2.6;aW+=1}
  if(kind==='wide'){kW+=3.5;cW+=6;aW+=8}
  if(kind==='jogger'){tW+=6;kW+=11;cW+=13;aW+=2.2}
  const p=new Path2D();
  p.moveTo(s*.6,g.crotchY-6);p.lineTo(hx+s*tW*.55,g.hipY-2);
  p.quadraticCurveTo(hx+s*tW*.62,(g.hipY+ky)/2,kx+s*kW*.62,ky);
  p.quadraticCurveTo(kx+s*cW*.75,(ky+ay)/2-6,ax+s*aW*.6,ay);
  p.lineTo(ax-s*aW*.6,ay);
  p.quadraticCurveTo(kx-s*cW*.55,(ky+ay)/2-6,kx-s*kW*.5,ky);
  p.quadraticCurveTo(hx-s*tW*.5,(g.crotchY+ky)/2,s*.6,g.crotchY);p.closePath();
  return{p,ax,ay,kx,ky,aW}}
function armGeo(g,s,sw){const x0=s*(g.sh-3.2),y0=g.shY+2,ex=s*(g.sh+3.4),ey=-152*g.bh+sw*.3,wx=s*(g.sh+1.6)+sw*.15*s,wy=-113*g.bh-Math.abs(sw)*.2;return{x0,y0,ex,ey,wx,wy}}
function limb(ctx,pts,w0,w1,col,oc){// tapered polyline
  const p=new Path2D(),n=pts.length,L=[],R=[];
  for(let i=0;i<n;i++){const a=pts[Math.max(0,i-1)],b=pts[Math.min(n-1,i+1)];let dx=b[0]-a[0],dy=b[1]-a[1];const d=Math.hypot(dx,dy)||1;dx/=d;dy/=d;const w=(w0+(w1-w0)*i/(n-1))/2;L.push([pts[i][0]-dy*w,pts[i][1]+dx*w]);R.push([pts[i][0]+dy*w,pts[i][1]-dx*w])}
  p.moveTo(L[0][0],L[0][1]);for(let i=1;i<n;i++)p.lineTo(L[i][0],L[i][1]);
  const e=pts[n-1];p.quadraticCurveTo(e[0]+(e[0]-pts[n-2][0])*.4,e[1]+(e[1]-pts[n-2][1])*.4,R[n-1][0],R[n-1][1]);
  for(let i=n-1;i>=0;i--)p.lineTo(R[i][0],R[i][1]);p.closePath();
  ctx.fillStyle=col;ctx.fill(p);ctx.strokeStyle=oc||shade(col,-.45);ctx.lineWidth=.8;ctx.stroke(p);return p}
function armPts(a,t){// points along arm up to fraction t (0..1 of shoulder→wrist)
  const P=[[a.x0,a.y0],[a.ex,a.ey],[a.wx,a.wy]];const out=[P[0]];const segs=[[P[0],P[1]],[P[1],P[2]]];const tot=2;let rem=t*tot;
  for(const [p,q] of segs){if(rem<=0)break;const k=Math.min(1,rem);out.push([p[0]+(q[0]-p[0])*k,p[1]+(q[1]-p[1])*k]);rem-=1}return out}
function aShade(ctx,p,x0,x1,y0,y1,k){clothShade(ctx,p,x0,x1,y0,y1,k)}

const isChibi=C=>((CSTYLES[C.style|0]||CSTYLES[0])[2]||1)<.8;
// ---------- garment spec from outfit
function garmentSpec(o,C){
  const f=C.g==='f',hij=!!C.hijab,st=o.style,S=STYLE[st]||STYLE.casual;
  let bot=o.bot||S.bot;if((st==='uniform'||st==='borneo'||st==='office')&&f)bot='skirt';
  if(bot==='shorts'&&(hij||o.id==='sp4'||o.id==='sp5'))bot='pants';
  if(bot==='pina')bot='skirt';
  let sleeve='long';
  if(['sport','nurse','cheongsam','sari'].includes(st)||(st==='casual'&&!['hoodie','jacket','cardigan','varsity','check','blouse','denim','track','lace','hoodjacket','bomber'].includes(o.pat))||(st==='uniform'&&o.id==='s1')||(st==='dress'&&o.cat==='moden')||(st==='borneo'&&!f&&o.id!=='t19'))sleeve='short';
  if(hij)sleeve='long';
  let one=!!S.one,hem=-122,ease=1.6,flare=0,skHem=-8,neck=6.5;
  if(o.te)hem=-147;
  if(['kurung','tunic','kurta','punjabi','bodo'].includes(st)){hem=-88;flare=6}
  if(st==='kedah'||st==='kebaya'||st==='bajumelayu'||st==='samfu')hem=-112;
  if(st==='robe'){hem=-22;flare=14;ease=5}
  if(st==='labcoat')hem=-122;
  if(o.pat==='hoodie'){ease=3.4;hem=-118}
  if(['jacket','varsity','denim','track'].includes(o.pat)){ease=3;hem=-124}
  if(o.pat==='hoodjacket'||o.pat==='bomber'){ease=4.6;hem=-114}
  if(st==='blazer'||st==='suit')ease=2.4;
  if(one){hem=st==='gown'?-3:st==='sari'?-4:st==='cheongsam'?-36:o.cat==='moden'?-50:-14;flare=st==='gown'?26:st==='dress'?14:st==='sari'?8:6}
  if(bot==='skirt'){skHem=o.skEnd?-84:st==='skirt'&&o.cat==='kolej'?-50:st==='pinafore'?-56:-6;if(st==='lehenga')skHem=-3}
  return{bot,sleeve,one,hem,ease,flare,skHem,neck,cargo:o.bp==='cargo',wide:o.bp==='wide',jogger:o.bp==='jogger'}}

// ---------- hair
function hairLock(p,x0,y0,x1,y1,w,bend){const dx=x1-x0,dy=y1-y0,d=Math.hypot(dx,dy)||1,nx=-dy/d,ny=dx/d,mx=(x0+x1)/2+nx*(bend||0),my=(y0+y1)/2+ny*(bend||0);
  p.moveTo(x0-nx*w/2,y0-ny*w/2);p.quadraticCurveTo(mx-nx*w*.55,my-ny*w*.55,x1,y1);p.quadraticCurveTo(mx+nx*w*.55,my+ny*w*.55,x0+nx*w/2,y0+ny*w/2);p.closePath()}
const SWEPT=[[5,-24,-11,-4.5,11,-3],[1,-23,-16,-1,9,-3],[8,-24,-3,-6,10,-2],[11,-23,6,-6,9,1],[15,-21,14,-4,8,2],[18.5,-16,19.5,1,6,1]];
const SHORTSW=[[4,-24,-10,-8,10,-3],[8,-24,-1,-9,9,-2],[11,-23,8,-9,8,1],[15,-20,16,-6,7,2],[-1,-23,-15,-6,8,-3]];
const FULL=[[-15,-19,-16,-4,9,-1],[-9,-22.5,-9.5,-3.5,9,-.5],[-3,-24,-3,-3,9,0],[3,-24,3,-3,9,0],[9,-22.5,9.5,-3.5,9,.5],[15,-19,16,-4,9,1]];
function aHair(C){
  const f=C.g==='f',st=C.hair|0,gg=aGeom(C),lcap=(gg.kneeY+6-gg.headY)/gg.hs;const cap=new Path2D(),fr=new Path2D(),back=new Path2D(),side=new Path2D(),extra=[];let backKind=null;
  const capArc=(rx,top,lo)=>{cap.moveTo(-rx,lo);cap.bezierCurveTo(-rx-1,top*.55,-rx*.6,top,0,top);cap.bezierCurveTo(rx*.6,top,rx+1,top*.55,rx,lo);cap.quadraticCurveTo(rx-3,-10,12,-14.5);cap.quadraticCurveTo(0,-17,-12,-14.5);cap.quadraticCurveTo(-rx+3,-10,-rx,lo);cap.closePath()};
  const fringe=(arr)=>{for(const l of arr)hairLock(fr,...l)};
  const longBack=(len,wid,wavy)=>{len=Math.min(len,lcap);if(gg.chibi)wid=Math.min(wid,wavy?36:29);back.moveTo(-19,-14);back.bezierCurveTo(-25,-2,-wid,len*.4,-wid,len*.75);
    if(wavy){let x=-wid;for(let i=0;i<6;i++){const nx=-wid+(i+1)*wid*2/6;back.quadraticCurveTo((x+nx)/2,len+(i%2?4:9),nx,len-(i%2?0:3));x=nx}}
    else back.quadraticCurveTo(0,len+6,wid,len*.75+(0));
    back.bezierCurveTo(wid,len*.4,25,-2,19,-14);back.closePath();backKind='long'};
  const sideLocks=(len,wavy,s)=>{len=Math.min(len,lcap*.72);for(const sd of (s||[-1,1])){const x=sd*17.5;side.moveTo(sd*19,-6);if(wavy){side.bezierCurveTo(sd*25,len*.3,sd*15,len*.55,sd*22,len);side.quadraticCurveTo(sd*16,len*.8,sd*14.5,len*.55);side.bezierCurveTo(sd*18,len*.3,sd*13.5,10,x-sd*2,-2)}else{side.quadraticCurveTo(sd*22,len*.5,sd*20.5,len);side.lineTo(sd*15.5,len-3);side.quadraticCurveTo(sd*16,len*.5,x-sd*2.5,-2)}side.closePath()}};
  if(f){
    switch(st){
    case 0:capArc(21,-27,4);longBack(118,27);sideLocks(58);fringe(SWEPT);break;
    case 1:capArc(22.5,-28,5);longBack(114,40,1);sideLocks(74,1);fringe(SWEPT.concat([[-18,-15,-23,6,7,-3],[19,-14,24,7,7,3]]));break;
    case 2:capArc(21,-26.5,2);backKind='pony';fringe(SHORTSW);sideLocks(14,0);break;
    case 3:capArc(21,-26.5,2);backKind='bun';fringe(SHORTSW);sideLocks(10,0);break;
    case 4:capArc(22,-27,6);back.moveTo(-21,-12);back.bezierCurveTo(-27,0,-27,16,-24,22);back.quadraticCurveTo(0,27,24,22);back.bezierCurveTo(27,16,27,0,21,-12);back.closePath();backKind='bob';
      fringe(FULL);sideLocks(20,0);break;
    case 5:capArc(21,-27,3);backKind='twin';fringe(FULL);sideLocks(14,0);break;
    case 6:capArc(21,-26,1);fringe(SWEPT.concat([[-16,-14,-20,4,6,-2]]));break;
    case 7:capArc(21,-26.5,4);back.moveTo(-19,-14);back.bezierCurveTo(-25,0,-24,26,-20,34);back.quadraticCurveTo(0,38,20,34);back.bezierCurveTo(24,26,25,0,19,-14);back.closePath();backKind='braid';
      fringe(SHORTSW);sideLocks(26,1,[-1]);break;
    case 8:capArc(21.5,-27,4);longBack(104,32,1);backKind='halfbun';sideLocks(58,1);fringe(SWEPT);break;
    case 9:capArc(21,-27,4);longBack(120,26);sideLocks(22,0);
      fringe([[-16,-17,-16,-3,7,0],[-10.5,-21,-10.5,-3,7,0],[-5,-23,-5,-3,7,0],[.5,-23.5,.5,-3,7,0],[6,-23,6,-3,7,0],[11.5,-21,11.5,-3,7,0],[16.5,-17,16.5,-2,6,0]]);break;
    }
  } else {
    switch(st){
    case 0:capArc(21.5,-28,2);fringe([[-10,-22,-15,-5,8,-2],[-4,-24,-7,-6,8,-1],[2,-24,1,-5,8,1],[8,-23,9,-6,8,2],[13,-21,16,-5,7,2],[-16,-17,-20,0,6,-2],[18,-15,20,1,6,2],[-6,-26,-10,-31,5,-1],[3,-27,6,-32,5,1],[11,-24,15,-29,5,2]]);break;
    case 1:capArc(21.2,-27,1);fringe([[-10,-23,-6,-8,9,-3],[-5,-24,4,-8,9,-3],[0,-25,11,-8,9,-3],[5,-24,16,-5,8,-2],[11,-22,19,-2,7,-1],[-16,-17,-19,0,6,-2]]);break;
    case 2:capArc(21,-26,0);fringe([[-12,-21,-13,-11,8,-1],[-6,-23,-6,-11,8,0],[0,-23.5,0,-11,8,0],[6,-23,7,-11,8,1],[12,-21,14,-10,7,1],[-17,-16,-19,-2,5,-1],[17,-16,19,-2,5,1]]);break;
    case 3:capArc(21.5,-27,2);fringe([[-1,-24,-11,-4,9,3],[-4,-23,-16,-2,8,3],[1,-24,11,-4,9,-3],[4,-23,16,-2,8,-3],[-9,-20,-19,2,6,2],[9,-20,19,2,6,-2]]);break;
    case 4:cap.moveTo(-19,-8);cap.bezierCurveTo(-21,-26,-10,-30,0,-30);cap.bezierCurveTo(10,-30,21,-26,19,-8);cap.quadraticCurveTo(0,-20,-19,-8);cap.closePath();backKind='undercut';
      fringe([[-10,-24,6,-33,9,-3],[-3,-26,10,-34,9,-3],[4,-26,13,-31,8,-2],[-14,-20,-2,-29,7,-3]]);break;
    case 5:capArc(20.2,-24.5,-6);backKind='buzz';break;
    case 6:capArc(22.5,-29,3);fringe([[-14,-21,-15,-5,9,-2],[-8.5,-24,-9.5,-4,9,-1],[-3,-25,-3.5,-4,9,0],[2.5,-25,3,-4,9,1],[8,-24,9.5,-4,9,1],[13.5,-21,15.5,-5,8,2],[-19,-14,-21,2,6,-2],[19,-14,21,2,6,2]]);break;
    case 7:capArc(22,-28,0);backKind='curly';break;
    default:capArc(21,-26,-2);
    }
  }
  return{cap,fr,back,side,backKind}}
function aHairFill(ctx,p,hc,y0,y1,lw,soft){const g=ctx.createLinearGradient(0,y0,0,y1);g.addColorStop(0,shade(hc,.26));g.addColorStop(.4,shade(hc,.06));g.addColorStop(1,shade(hc,-.26));ctx.fillStyle=g;ctx.fill(p);ctx.strokeStyle=shade(hc,-.45);ctx.lineWidth=lw||.6;if(soft){ctx.globalAlpha=.35;ctx.lineWidth=.45}ctx.stroke(p);ctx.globalAlpha=1}
function aHairShine(ctx,clip,hc){ctx.save();ctx.clip(clip);ctx.strokeStyle='rgba(255,255,255,.2)';ctx.lineWidth=2.2;ctx.lineCap='round';for(const [a,b] of [[1.24,1.36],[1.58,1.7]]){ctx.beginPath();ctx.ellipse(0,-6,17.5,14,0,Math.PI*a,Math.PI*b);ctx.stroke()}
  ctx.strokeStyle=shade(hc,-.4);ctx.globalAlpha=.45;ctx.lineWidth=.55;for(const x of [-14,-8,-2,4,10,15]){ctx.beginPath();ctx.moveTo(x*.35,-27);ctx.quadraticCurveTo(x*.8,-20,x,-10);ctx.stroke()}ctx.restore()}
function aCurly(ctx,hc,top){const p=new Path2D();for(let i=0;i<14;i++){const a=Math.PI*(1.0+i/13),x=Math.cos(a)*19,y=-6+Math.sin(a)*21;p.moveTo(x+4.6,y);p.arc(x,y,4.6,0,TAU)}for(let i=0;i<6;i++){const x=-12+i*4.8;p.moveTo(x+3.6,-15);p.arc(x,-15+(i%2)*1.5,3.6,0,TAU)}aHairFill(ctx,p,hc,-30,-6,.6);aHairShine(ctx,p,hc)}

// ---------- face
function aFacePath(C){const f=C.g==='f';let cw=f?18.6:19.2,jy=15,jw=f?12.6:14,chin=f?21.6:22.6;
  switch(C.face|0){case 0:cw+=.8;chin-=1.2;jw+=1.6;break;case 1:cw-=.6;chin+=1.4;break;case 2:jw-=1.8;chin+=.8;break;case 3:jw+=3;chin-=.6;jy=18;break}
  if(isChibi(C)){cw+=1.2;jw+=3.4;chin-=2.2;jy-=1}
  const p=new Path2D();p.moveTo(-cw,-14);p.bezierCurveTo(-cw-.6,-4,-cw,6,-cw+.6,9);p.bezierCurveTo(-cw+1.4,jy-1,-jw-2,jy+2,-jw*.42,chin-1.6);p.quadraticCurveTo(0,chin+.6,jw*.42,chin-1.6);p.bezierCurveTo(jw+2,jy+2,cw-1.4,jy-1,cw-.6,9);p.bezierCurveTo(cw,6,cw+.6,-4,cw,-14);p.quadraticCurveTo(0,-26,-cw,-14);p.closePath();return p}
function aEye(ctx,x,y,C,s,mode,far){
  const f=C.g==='f',col=EYECOL[C.eyeCol]||EYECOL[0];let w=f?6.5:6.2,h=f?8.8:7.6,tilt=f?.05:.02,ir=f?4.9:4.4;
  switch(C.eye|0){case 0:h+=.8;ir+=.2;break;case 1:h-=1.1;tilt+=.14;ir-=.2;break;case 2:tilt-=.12;h+=.3;break;case 3:h+=1.2;w+=.4;ir+=.5;break;case 4:tilt+=.22;h-=.3;break;case 5:h-=1.6;break}
  if(isChibi(C)){w*=1.14;h*=1.2;ir*=1.15}
  if(far)w*=.7;
  ctx.save();ctx.translate(x,y);ctx.rotate(-tilt*s);const X=v=>v*s;const lash='#24161c';ctx.lineCap='round';ctx.lineJoin='round';
  if(mode==='happy'||mode==='wink'){ctx.strokeStyle=lash;ctx.lineWidth=1.6;ctx.beginPath();ctx.moveTo(X(-w),.6);ctx.quadraticCurveTo(0,-h*(mode==='happy'?1.1:.7),X(w),.2);ctx.stroke();if(f){ctx.lineWidth=.9;ctx.beginPath();ctx.moveTo(X(w),.2);ctx.lineTo(X(w+2.2),-1.4);ctx.stroke()}ctx.restore();return}
  const top=-h*.62,bot=h*.5;
  const eye=new Path2D();eye.moveTo(X(-w),0);eye.bezierCurveTo(X(-w*.7),top*1.15,X(w*.45),top*1.25,X(w),top*.35);eye.bezierCurveTo(X(w*.8),bot*.9,X(-w*.4),bot*1.15,X(-w),0);eye.closePath();
  ctx.fillStyle='#fffaf6';ctx.fill(eye);
  ctx.save();ctx.clip(eye);const iy=mode==='down'?1.2:.3;
  const g=ctx.createLinearGradient(0,iy-ir*1.2,0,iy+ir*1.2);g.addColorStop(0,vivid(col,.16,.45));g.addColorStop(.5,vivid(col,.34,.55));g.addColorStop(1,vivid(col,.68,.62));
  const irx=w*.84,iry=h*.68;ctx.fillStyle=g;ctx.beginPath();ctx.ellipse(X(-.2),iy,irx,iry,0,0,TAU);ctx.fill();
  ctx.fillStyle=vivid(col,.05,.3);ctx.beginPath();ctx.ellipse(X(-.2),iy+.2,irx*.4,iry*.46,0,0,TAU);ctx.fill();
  ctx.fillStyle='rgba(255,255,255,.3)';ctx.beginPath();ctx.ellipse(X(-.2),iy+ir*.75,ir*.6,ir*.3,0,0,TAU);ctx.fill();
  const ls=ctx.createLinearGradient(0,top,0,top+3.5);ls.addColorStop(0,'rgba(40,10,30,.35)');ls.addColorStop(1,'rgba(40,10,30,0)');ctx.fillStyle=ls;ctx.fillRect(-w-2,top-1,w*2+4,5);
  ctx.restore();
  // lashes
  ctx.fillStyle=lash;ctx.beginPath();ctx.moveTo(X(-w-.4),.4);ctx.bezierCurveTo(X(-w*.7),top*1.3,X(w*.45),top*1.42,X(w+.7),top*.4-.3);ctx.lineTo(X(w+.1),top*.35+.6);ctx.bezierCurveTo(X(w*.45),top*1.08,X(-w*.7),top*1.02,X(-w+.3),.8);ctx.closePath();ctx.fill();
  if(f){ctx.strokeStyle=lash;ctx.lineWidth=.7;for(const [a,b,c,d] of [[w*.82,top*.95,w*1.02,top*.95-1.9],[w*.5,top*1.22,w*.62,top*1.22-1.6]]){ctx.beginPath();ctx.moveTo(X(a),b);ctx.lineTo(X(c),d);ctx.stroke()}}
  ctx.strokeStyle='rgba(90,40,50,.35)';ctx.lineWidth=.45;ctx.beginPath();ctx.moveTo(X(w*.35),bot*1.02);ctx.quadraticCurveTo(X(w*.7),bot*.95,X(w*.95),bot*.3);ctx.stroke();
  ctx.strokeStyle='rgba(120,60,60,.22)';ctx.lineWidth=.4;ctx.beginPath();ctx.moveTo(X(-w*.6),top*1.45);ctx.quadraticCurveTo(X(w*.2),top*1.75,X(w*.9),top*1.05);ctx.stroke();
  if(C.eye===5){ctx.fillStyle=shade(SKIN[C.skin]||SKIN[1],-.05);ctx.beginPath();ctx.moveTo(X(-w-.5),.2);ctx.bezierCurveTo(X(-w*.6),top*1.5,X(w*.5),top*1.5,X(w+.5),top*.4);ctx.lineTo(X(w+.5),top*.1+.6);ctx.quadraticCurveTo(0,top*.25,X(-w-.5),.6);ctx.fill();ctx.strokeStyle=lash;ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(X(-w-.5),.6);ctx.quadraticCurveTo(0,top*.25,X(w+.5),top*.1+.6);ctx.stroke()}
  ctx.fillStyle='#fff';ctx.beginPath();ctx.ellipse(-ir*.35,iy-ir*.45,ir*.36,ir*.3,-.4,0,TAU);ctx.fill();ctx.beginPath();ctx.arc(ir*.35,iy+ir*.45,ir*.14,0,TAU);ctx.fill();
  ctx.globalAlpha=.85;ctx.beginPath();ctx.arc(-ir*.05,iy-ir*.78,ir*.12,0,TAU);ctx.fill();ctx.globalAlpha=1;
  if(C.eye===3||mode==='star'){const r=mode==='star'?ir*.55:ir*.3,sx=ir*.2,sy=iy-ir*.1;ctx.beginPath();ctx.moveTo(sx,sy-r);ctx.quadraticCurveTo(sx,sy,sx+r,sy);ctx.quadraticCurveTo(sx,sy,sx,sy+r);ctx.quadraticCurveTo(sx,sy,sx-r,sy);ctx.quadraticCurveTo(sx,sy,sx,sy-r);ctx.fill()}
  ctx.restore()}
function aFace(ctx,C,side){
  const f=C.g==='f',sk=SKIN[C.skin]||SKIN[1],hc=HAIRCOL[C.hairCol]||'#222',ex=C.expr||0,dx=side?3.2:0;
  // blush
  for(const sd of (side?[1]:[-1,1])){const bx=sd*10.8+dx,by=10.4;const g=ctx.createRadialGradient(bx,by,.3,bx,by,4.8);g.addColorStop(0,`rgba(255,110,140,${ex===3?.6:.42})`);g.addColorStop(1,'rgba(255,110,130,0)');ctx.fillStyle=g;ctx.beginPath();ctx.ellipse(bx,by,5,3,0,0,TAU);ctx.fill();
    if(ex===3){ctx.strokeStyle='rgba(220,70,100,.55)';ctx.lineWidth=.5;for(let k=-1;k<=1;k++){ctx.beginPath();ctx.moveTo(bx+k*1.6-.7,by+1);ctx.lineTo(bx+k*1.6+.7,by-1);ctx.stroke()}}}
  const mL=ex===1?'happy':ex===4?'star':ex===3?'down':null,mR=ex===1?'happy':ex===2?'wink':ex===4?'star':ex===3?'down':null;
  const chb=isChibi(C),ey=chb?7:5.2,exx=chb?(f?9.6:9.8):(f?8.9:9.1);
  if(side){aEye(ctx,-5+dx,ey,C,-1,mL,1);aEye(ctx,9.8+dx,ey,C,1,mR)}else{aEye(ctx,-exx,ey,C,-1,mL);aEye(ctx,exx,ey,C,1,mR)}
  // brows
  const bc=shade(hc,hc==='#1f1a24'?.1:-.2);ctx.fillStyle=bc;const bwid=[1.2,1.15,1.9,.8,1.2,1.4][C.brow|0]||1.2,bt=f?bwid*.85:bwid*1.25;
  for(const sd of (side?[-1,1]:[-1,1])){const bx=sd*(f?8.6:9)+dx*(sd>0?1.1:.5);let yi=-5.6,yo=-6,cy=-7.6;if(C.brow===1)cy=-8.8;if(C.brow===4){yi=-7.2;yo=-5}if(C.brow===5||ex===5){yi=-4.6;yo=-7}if(ex===6){yi-=1.4;yo-=1.4;cy-=1.6}
    const xi=bx-sd*4.4,xo=bx+sd*4.8;ctx.beginPath();ctx.moveTo(xi,yi);ctx.quadraticCurveTo(bx,cy-bt*.4,xo,yo);ctx.quadraticCurveTo(bx,cy+bt*.8,xi,yi+bt);ctx.closePath();ctx.fill()}
  // nose
  ctx.strokeStyle=shade(sk,-.32);ctx.lineWidth=.6;ctx.lineCap='round';
  if(isChibi(C)){ctx.fillStyle=shade(sk,-.18);ctx.beginPath();ctx.ellipse(dx+.2,11.6,.9,.6,0,0,TAU);ctx.fill()}else{
  if(C.nose===2){ctx.beginPath();ctx.moveTo(dx+.6,4);ctx.quadraticCurveTo(dx+1.6,9,dx+.4,11.2);ctx.stroke()}
  ctx.beginPath();ctx.moveTo(dx-1.2,11.4);ctx.quadraticCurveTo(dx,12.2,dx+1.2,11.4);ctx.stroke();ctx.fillStyle='rgba(255,255,255,.5)';ctx.beginPath();ctx.arc(dx-.3,9.6,.55,0,TAU);ctx.fill();}
  // beard
  if(!f&&C.beard){const bcol=shade(hc,-.05);ctx.fillStyle=bcol;if(C.beard===1){ctx.beginPath();ctx.moveTo(dx-4.4,14.2);ctx.quadraticCurveTo(dx,12.6,dx+4.4,14.2);ctx.quadraticCurveTo(dx,13.9,dx-4.4,14.2);ctx.fill()}
    else if(C.beard===2){ctx.beginPath();ctx.moveTo(dx-2.4,20.6);ctx.lineTo(dx+2.4,20.6);ctx.lineTo(dx,24.6);ctx.closePath();ctx.fill()}
    else{ctx.globalAlpha=.3;ctx.strokeStyle=bcol;ctx.lineWidth=2.6;ctx.beginPath();ctx.moveTo(-17,6);ctx.quadraticCurveTo(-14,19,dx,23);ctx.quadraticCurveTo(14,19,17,6);ctx.stroke();ctx.globalAlpha=1}}
  // mouth
  const mx=dx,my=isChibi(C)?16.6:16.4,m=ex===1||ex===4?1:ex===2?4:ex===3?2:ex===5?5:ex===6?6:(C.mouth|0);
  const lip=f?'#d9667e':'#b8606a';ctx.strokeStyle='#8a3442';ctx.lineWidth=.8;
  switch(m){
  case 1:{ctx.fillStyle='#8a2a3c';ctx.beginPath();ctx.moveTo(mx-4.2,my-.6);ctx.quadraticCurveTo(mx,my+.2,mx+4.2,my-.6);ctx.quadraticCurveTo(mx+2.6,my+4.6,mx,my+4.8);ctx.quadraticCurveTo(mx-2.6,my+4.6,mx-4.2,my-.6);ctx.fill();ctx.fillStyle='#fff';ctx.fillRect(mx-3,my-.4,6,1.1);ctx.fillStyle='#ff8fa3';ctx.beginPath();ctx.ellipse(mx,my+3.4,2.2,1.2,0,0,TAU);ctx.fill();break}
  case 2:ctx.beginPath();ctx.moveTo(mx-2.8,my);ctx.quadraticCurveTo(mx-1.4,my+1.4,mx,my+.3);ctx.quadraticCurveTo(mx+1.4,my+1.4,mx+2.8,my);ctx.stroke();break;
  case 3:ctx.beginPath();ctx.moveTo(mx-2.4,my+.6);ctx.quadraticCurveTo(mx,my+1.2,mx+2.4,my+.6);ctx.stroke();break;
  case 4:ctx.fillStyle='#fff';ctx.beginPath();ctx.moveTo(mx-4,my-.4);ctx.quadraticCurveTo(mx,my+3.6,mx+4,my-.4);ctx.closePath();ctx.fill();ctx.stroke();break;
  case 5:ctx.beginPath();ctx.moveTo(mx-3,my+.8);ctx.quadraticCurveTo(mx+.6,my+1.8,mx+3.2,my-.4);ctx.stroke();break;
  case 6:ctx.fillStyle='#8a2a3c';ctx.beginPath();ctx.ellipse(mx,my+1.2,1.7,2.2,0,0,TAU);ctx.fill();break;
  default:ctx.beginPath();ctx.moveTo(mx-3.4,my);ctx.quadraticCurveTo(mx,my+2.4,mx+3.4,my);ctx.stroke();
  }
  if(f&&m!==1&&m!==6){ctx.fillStyle=lip;ctx.globalAlpha=.55;ctx.beginPath();ctx.ellipse(mx,my+1.7,2.2,.9,0,0,TAU);ctx.fill();ctx.globalAlpha=1}
}

// ---------- main
function drawAnime(ctx,x,y,s,C,dir,frame){
  dir=dir||0;frame=frame||0;C=C||{};
  const o=OUT[C.outfit]||OUT.h2,sh=SHOE[C.shoes]||SHOE.sh1,sk=SKIN[C.skin]||SKIN[1],hc=HAIRCOL[C.hairCol]||'#222',hij=!!C.hijab;
  const g=aGeom(C),G=garmentSpec(o,C),f=g.f;G.hem*=g.bh;G.skHem*=g.bh;
  ctx.save();ctx.translate(x,y);ctx.scale(s*A_K,s*A_K);ctx.lineJoin='round';ctx.lineCap='round';
  if(dir===1){ctx.scale(-1,1);dir=2}
  const back=dir===3,side=dir===2;
  if(side)ctx.scale(.8,1);
  const bob=(frame%2)?-1.6:0,lA=frame===1?6:0,lB=frame===3?6:0,sw=frame===1?6:frame===3?-6:0;
  // shadow
  ctx.fillStyle='rgba(30,20,60,.22)';ctx.beginPath();ctx.ellipse(0,0,24,6,0,0,TAU);ctx.fill();
  const hp=hij?null:aHair(C);
  const line=(c,w,pts)=>{ctx.strokeStyle=c;ctx.lineWidth=w;ctx.beginPath();pts.forEach(([a,b],i)=>i?ctx.lineTo(a,b):ctx.moveTo(a,b));ctx.stroke()};
  const dot=(c,xx,yy,r)=>{ctx.fillStyle=c;ctx.beginPath();ctx.arc(xx,yy,r,0,TAU);ctx.fill()};
  const headX=side?2:0,hY=g.headY+bob;
  const headT=()=>{ctx.translate(headX,hY);ctx.scale(g.hs,g.hs)};
  // ===== back hair layer (front/side views)
  if(!back&&hp){ctx.save();headT();
    if(hp.backKind==='long'||hp.backKind==='bob'||hp.backKind==='braid'||hp.backKind==='halfbun')aHairFill(ctx,hp.back,shade(hc,-.12),-20,110);
    const tl=Math.min(1,((g.kneeY-g.headY)/g.hs)/80);ctx.save();ctx.scale(1,tl);
    if(hp.backKind==='pony'){const t=new Path2D();t.moveTo(8,-20);t.bezierCurveTo(30,-14,30,30,22,72);t.quadraticCurveTo(16,40,12,20);t.quadraticCurveTo(14,0,4,-14);t.closePath();aHairFill(ctx,t,shade(hc,-.1),-20,72)}
    if(hp.backKind==='twin'){for(const sd of [-1,1]){const t=new Path2D();t.moveTo(sd*16,-16);t.bezierCurveTo(sd*36,-6,sd*34,40,sd*28,78);t.quadraticCurveTo(sd*22,44,sd*20,20);t.quadraticCurveTo(sd*20,0,sd*12,-12);t.closePath();aHairFill(ctx,t,shade(hc,-.1),-16,78)}}
    ctx.restore();
    ctx.restore()}
  const BPC={1:'#3a3f52',6:'#f49ac0',7:'#26262c'},bpc=BPC[C.bag|0]||(C.acc===1?'#3a3f52':null);
  if(bpc&&!back&&!side){const px=-(g.sh+17),pw=19,py=g.shY+6,ph=(g.waistY-g.shY)+16;const bp=new Path2D();rrp(bp,px,py,pw,ph,6);fillP(ctx,bp,bpc,.8);aShade(ctx,bp,px,px+pw,py,py+ph,1);
    const pk=new Path2D();rrp(pk,px+1.6,py+ph*.52,pw-4,ph*.36,4);fillP(ctx,pk,shade(bpc,.08),.6);ctx.fillStyle=shade(bpc,-.3);ctx.fillRect(px+5,py+ph*.52-2,3,6);ctx.fillStyle='#e8e0d0';ctx.fillRect(px+5.4,py+ph*.52+2,2.2,1.6)}
  // ===== legs, trousers, skirt, shoes
  ctx.save();ctx.translate(0,bob*.3);
  const legs=[];
  for(const s2 of [-1,1]){const lift=s2<0?lA:lB;legs.push(Object.assign({s:s2,lift},legPath(g,s2,lift,0)))}
  const pants=G.bot==='pants'||G.bot==='shorts';
  for(const L of legs){const sx=side?L.s*(L.lift?-5:4)+(frame===1?L.s*-4:frame===3?L.s*4:0):0;ctx.save();ctx.translate(sx,0);
    const lp=L.p;ctx.fillStyle=sk;ctx.fill(lp);ctx.strokeStyle=shade(sk,-.35);ctx.lineWidth=.7;ctx.stroke(lp);aShade(ctx,lp,L.s*-2-14,L.s*-2+14,g.hipY,0,.7);
    if(pants&&!G.one){const pk=G.bot==='shorts'?'':G.cargo?'cargo':G.wide?'wide':G.jogger?'jogger':'';const pl=legPath(g,L.s,L.lift,G.cargo||G.jogger?2.6:1.6,pk);let pp=pl.p;
      if(G.bot==='shorts'){ctx.save();ctx.beginPath();ctx.rect(-60,-200,120,200+g.kneeY-6);ctx.clip()}
      fillP(ctx,pp,o.bottom,.8);aShade(ctx,pp,L.s*10-16,L.s*10+16,g.hipY,0,1);
      if(!back&&G.jogger){const px=L.s*(g.hip+3.4)-(L.s>0?10:0),py=-96*g.bh;const q=new Path2D();rrp(q,px,py,10,14,2);fillP(ctx,q,shade(o.bottom,-.04),.6);const fl=new Path2D();rrp(fl,px-.5,py-1,11,4.6,1.4);fillP(ctx,fl,shade(o.bottom,.04),.6);dot(shade(o.bottom,-.45),px+5,py+2.4,.8);
        line(shade(o.bottom,-.3),.6,[[L.s*8,g.hipY+8],[L.s*9,-90],[L.s*7.4,-50]]);const cf=new Path2D();rrp(cf,pl.ax-(pl.aW+1.4)/2-L.s*.2,pl.ay-7,pl.aW+1.4,7.4,2.4);fillP(ctx,cf,shade(o.bottom,-.12),.7);ctx.strokeStyle=shade(o.bottom,-.35);ctx.lineWidth=.45;for(let k=1;k<4;k++){ctx.beginPath();ctx.moveTo(pl.ax-pl.aW/2+k*pl.aW/4,pl.ay-6.6);ctx.lineTo(pl.ax-pl.aW/2+k*pl.aW/4,pl.ay-.4);ctx.stroke()}}
      if(!back&&G.cargo){const px=L.s*(g.hip+1.4)-(L.s>0?7:0),py=-100*g.bh;const q=new Path2D();rrp(q,px,py,7,10,1.5);fillP(ctx,q,shade(o.bottom,-.05),.6);line(shade(o.bottom,-.4),.6,[[px,py+3],[px+7,py+3]]);ctx.fillStyle=shade(o.bottom,-.2);ctx.fillRect(pl.ax-L.s*5.6-(L.s>0?0:0)-3,pl.ay-4,8.6,2.2)}
      if(!back&&!G.cargo&&!G.jogger){line(shade(o.bottom,-.25),.5,[[L.s*10,g.hipY+4],[pl.ax+L.s*.6,pl.ay-1]])}
      if(G.bot==='shorts'){ctx.restore()}}
    {ctx.save();ctx.translate(L.ax+L.s*(side?2:.6),-L.lift*.8);ctx.scale(1.45,1.45);drawShoe(ctx,0,0,sh,side,sk);ctx.restore()}
    ctx.restore()}
  if(pants&&!G.one){const wb=garmentPath(g,g.waistY+2,g.crotchY-2,2.2,0,g.waist+2.2);fillP(ctx,wb,o.bottom,.8);aShade(ctx,wb,-24,24,g.waistY,g.crotchY,1);if(!back){line(shade(o.bottom,-.35),.6,[[0,g.waistY+4],[0,g.crotchY-2]])}}
  ctx.restore();
  // skirt
  if(G.bot==='skirt'&&!G.one){const fl=(o.style==='lehenga'?16:o.skEnd?6:10);const p=garmentPath(g,g.waistY+1,G.skHem,2.4,fl,g.waist+2.4);fillP(ctx,p,o.bottom);
    const bp=(['batik','songket','zari','beads','motif','sequin','silver'].includes(o.pat))&&o.style!=='casual';if(bp)withClip(ctx,p,()=>drawPattern(ctx,o.pat==='silver'?'beads':o.pat,o.bottom,o.accent,-50,g.waistY,50,0));
    if(o.bpat==='pleat'){withClip(ctx,p,()=>{ctx.strokeStyle=shade(o.bottom,-.2);ctx.lineWidth=.8;const w0=g.waist+2.4,w1=bodyW(g,g.crotchY)+2.4+fl;for(let k=-6;k<=6;k++){ctx.beginPath();ctx.moveTo(k/6*w0,g.waistY+3);ctx.lineTo(k/6*w1*1.06,G.skHem);ctx.stroke()}ctx.fillStyle=o.accent;ctx.fillRect(-w1-6,G.skHem-4.4,w1*2+12,4.6)})}
    else if(o.bpat)withClip(ctx,p,()=>{drawPattern(ctx,o.bpat==='plaid'?'check':'floral',o.bottom,o.accent,-50,g.waistY,50,0);if(o.bpat==='plaid'){ctx.fillStyle='rgba(230,200,120,.35)';for(let xx=-40;xx<40;xx+=5)ctx.fillRect(xx+1.2,g.waistY,.6,200);for(let yy=g.waistY;yy<0;yy+=5)ctx.fillRect(-40,yy+1.2,80,.6)}});
    if(!back){ctx.strokeStyle=shade(o.bottom,-.22);ctx.lineWidth=.6;for(const k of [-.55,-.2,.2,.55]){ctx.beginPath();ctx.moveTo(k*g.waist,g.waistY+6);ctx.lineTo(k*(g.hip+fl+4),G.skHem-2);ctx.stroke()}}
    if(o.style==='borneo'||o.style==='lehenga'){ctx.fillStyle=o.accent;const w=bodyW(g,g.crotchY)+2.4+fl;ctx.fillRect(-w-2,G.skHem-14,w*2+4,3.4);ctx.fillRect(-w-2,G.skHem-8,w*2+4,1.6);if(o.gold){ctx.fillStyle='#e23b3b';ctx.fillRect(-w-2,G.skHem-10.6,w*2+4,1.4)}}
    if(o.style==='kurung'&&!back){line(shade(o.bottom,-.3),.6,[[g.hip*.6,g.crotchY],[g.hip*.75,G.skHem]])}
    aShade(ctx,p,-g.hip-fl-4,g.hip+fl+4,g.waistY,G.skHem,1)}
  // ===== torso garment
  const topCol=(o.style==='labcoat')?'#cfe3f7':(o.style==='blazer'||o.style==='suit')?'#ffffff':(o.style==='sari'||o.style==='lehenga')?shade(o.top,-.12):o.pat==='silver'?'#3a2a2a':o.top;
  const y0=g.neckY+4,hem=G.one?G.hem:G.hem;
  const tp=garmentPath(g,y0,hem,G.ease,G.flare,o.pat==='hoodie'?8:6.5);
  // neck (skin)
  {const n=new Path2D();rrp(n,-5.4,g.neckY-6+bob,10.8,14,4);ctx.fillStyle=shade(sk,-.06);ctx.fill(n);ctx.strokeStyle=shade(sk,-.35);ctx.lineWidth=.6;ctx.stroke(n)}
  if((o.pat==='hoodie'||o.pat==='hoodjacket'||o.pat==='bomber')&&!back){const hd=new Path2D();hd.moveTo(-15,y0+2);hd.quadraticCurveTo(-14,y0-9,0,y0-8);hd.quadraticCurveTo(14,y0-9,15,y0+2);hd.quadraticCurveTo(0,y0+8,-15,y0+2);fillP(ctx,hd,o.pat==='bomber'?o.accent:shade(o.top,-.12),.7)}
  fillP(ctx,tp,topCol,.8);
  const tpat=(['batik','floral','check'].includes(o.pat)&&['casual','tunic'].includes(o.style))||['cloud','zari'].includes(o.pat)||(o.pat==='songket'&&['kurung','bodo'].includes(o.style))||(['beads','motif','sequin'].includes(o.pat)&&o.style!=='casual')||(['floral','batik'].includes(o.pat)&&['dress','kurung','kebaya','samfu','tunic','kedah'].includes(o.style));
  if(tpat)withClip(ctx,tp,()=>drawPattern(ctx,o.pat,topCol,o.accent,-50,y0,50,hem+2));
  if(o.pat==='batikshirt')withClip(ctx,tp,()=>{drawPattern(ctx,'batik',topCol,o.accent,-50,y0,50,hem+2);ctx.strokeStyle=o.accent;ctx.globalAlpha=.55;ctx.lineWidth=.6;for(let yy=y0+4;yy<hem;yy+=7){ctx.beginPath();ctx.moveTo(-30,yy);ctx.bezierCurveTo(-15,yy-4,-6,yy+4,6,yy);ctx.bezierCurveTo(15,yy-4,22,yy+3,32,yy);ctx.stroke()}ctx.globalAlpha=1});
  if(o.pat==='hawaii')withClip(ctx,tp,()=>{for(const [fx,fy,r] of [[-14,-190,5.4],[10,-178,6.2],[-8,-162,5],[16,-150,4.6],[2,-196,4],[-20,-172,4],[0,-140,5],[-16,-136,4.4],[18,-130,4]]){const yy=fy*g.bh;ctx.fillStyle='#2f8a4a';ctx.beginPath();ctx.ellipse(fx+r*.9,yy+r*.7,r*.6,r*.22,.6,0,TAU);ctx.fill();ctx.fillStyle=o.accent;for(let k=0;k<5;k++){const a=k/5*TAU;ctx.beginPath();ctx.ellipse(fx+Math.cos(a)*r*.55,yy+Math.sin(a)*r*.55,r*.52,r*.34,a,0,TAU);ctx.fill()}ctx.fillStyle='#fff3c4';ctx.beginPath();ctx.arc(fx,yy,r*.26,0,TAU);ctx.fill()}});
  if(o.pat==='silver')withClip(ctx,tp,()=>{for(let yy=y0+6;yy<hem;yy+=4){ctx.fillStyle=(yy|0)%8<4?'#d4d8e0':'#aab0ba';ctx.fillRect(-40,yy,80,2.2)}});
  aShade(ctx,tp,-34,34,y0,hem,1);
  {ctx.save();ctx.clip(tp);ctx.fillStyle='rgba(40,15,60,.15)';ctx.beginPath();ctx.ellipse(0,y0+1,12,4,0,0,TAU);ctx.fill();ctx.restore()}
  const tw=(yy)=>bodyW(g,Math.min(yy,g.crotchY))+G.ease+(G.flare&&yy>g.waistY?G.flare*Math.pow((yy-g.waistY)/Math.max(1,hem-g.waistY),1.2):0);
  // belt
  if(o.belt&&!G.one){const by=G.hem<-140?G.hem-2:g.waistY+2;const bw2=tw(by)+.4;ctx.fillStyle=o.style==='borneo'?o.accent:'#4a3222';ctx.fillRect(-bw2,by-2.2,bw2*2,4.4);ctx.fillStyle=o.style==='borneo'?shade(o.accent,.3):'#e2c06a';ctx.fillRect(-3,by-3,6,6);ctx.fillStyle=o.style==='borneo'?o.accent:'#4a3222';ctx.fillRect(-1.4,by-1.4,2.8,2.8)}
  // bajumelayu samping
  if(o.style==='bajumelayu'){const sm=garmentPath(g,g.waistY+2,-98*g.bh,G.ease+1.6,4,g.waist+G.ease+1.6);const smc=o.id==='t2'?'#7a1f2b':o.id==='f5'?'#e8d6a8':o.id==='t1'?'#3a1f6e':shade(o.top,o.top==='#1d1d24'||o.top==='#17171c'?.3:-.3);
    fillP(ctx,sm,smc,.8);withClip(ctx,sm,()=>drawPattern(ctx,o.pat==='goldtrim'?'zari':'songket',smc,o.accent,-40,g.waistY,40,-90));ctx.fillStyle=o.accent;ctx.fillRect(-tw(g.waistY)-2,g.waistY+1,tw(g.waistY)*2+4,2.2);aShade(ctx,sm,-30,30,g.waistY,-98,1)}
  // ===== garment details (front)
  if(!back){
   const dk=shade(o.top,-.38),cy0=y0+1;
   const collar=(c,oc,big)=>{const b=big||1;ctx.fillStyle=c;ctx.strokeStyle=oc;ctx.lineWidth=.6;for(const sd of [-1,1]){ctx.beginPath();ctx.moveTo(sd*7.5*b,cy0-1.4);ctx.lineTo(sd*1,cy0+5.5);ctx.lineTo(sd*7.4*b,cy0+9.5);ctx.lineTo(sd*10.4*b,cy0+1.4);ctx.closePath();ctx.fill();ctx.stroke()}};
   const placket=(c,n)=>{line(c,.6,[[0,cy0+5],[0,hem-1]]);for(let yy=cy0+10;yy<hem-2;yy+=n||8)dot(shade(c,-.1),1.4,yy,.8)};
   const inner=(c,wTop,wBot)=>{ctx.fillStyle=c;ctx.beginPath();ctx.moveTo(-wTop,cy0-1);ctx.lineTo(wTop,cy0-1);ctx.lineTo(wBot,hem);ctx.lineTo(-wBot,hem);ctx.closePath();ctx.fill()};
   switch(o.style){
   case 'casual':case 'skirt':case 'tunic':case 'kedah':
    if(o.pat==='hoodie'){line(shade(o.top,-.28),3.4,[[-8,cy0],[0,cy0+5],[8,cy0]]);line('#fff',.9,[[-3,cy0+4],[-3.4,cy0+20]]);line('#fff',.9,[[3,cy0+4],[3.4,cy0+20]]);dot('#e8e8e8',-3.4,cy0+21,1);dot('#e8e8e8',3.4,cy0+21,1);const k=new Path2D();k.moveTo(-12,hem-22);k.lineTo(12,hem-22);k.lineTo(14,hem-6);k.lineTo(-14,hem-6);k.closePath();fillP(ctx,k,shade(o.top,-.06),.6);ctx.fillStyle=shade(o.top,-.12);ctx.fillRect(-tw(hem-2),hem-4,tw(hem-2)*2,4)}
    else if(o.pat==='bomber'){inner(o.accent,8.4,7.4);line('#ffffff',.9,[[-3,cy0+3],[-3.4,cy0+18]]);line('#ffffff',.9,[[3,cy0+3],[3.4,cy0+18]]);dot('#e8e8e8',-3.4,cy0+19,1);dot('#e8e8e8',3.4,cy0+19,1);
      line(dk,1,[[-8.4,cy0],[-7.4,hem]]);line(dk,1,[[8.4,cy0],[7.4,hem]]);line(shade(o.top,-.2),.6,[[-8,cy0+2],[-7,hem]]);
      ctx.fillStyle=shade(o.top,-.1);for(const sd of [-1,1])ctx.fillRect(sd>0?7.4:-tw(hem-2),hem-5,tw(hem-2)-7.4,5);ctx.strokeStyle=shade(o.top,-.28);ctx.lineWidth=.4;for(let xx=-tw(hem);xx<tw(hem);xx+=1.6){if(Math.abs(xx)<7.6)continue;ctx.beginPath();ctx.moveTo(xx,hem-5);ctx.lineTo(xx,hem);ctx.stroke()}
      line(shade(o.top,-.4),.9,[[-tw(cy0+18)+3,cy0+16],[-10.5,cy0+16]]);dot('#9a9aa4',-10.5,cy0+16,.9)}
    else if(o.pat==='hoodjacket'){inner(o.accent,7.4,6.6);ctx.fillStyle='rgba(0,0,0,.06)';ctx.fillRect(-6.6,cy0+6,13.2,2);line(dk,1,[[-7.4,cy0],[-6.6,hem]]);line(dk,1,[[7.4,cy0],[6.6,hem]]);line('#d9c9b0',.6,[[-7,cy0+2],[-6.3,hem]]);line('#d9c9b0',.6,[[7,cy0+2],[6.3,hem]]);
      line(shade(o.top,-.25),3,[[-10,cy0],[-7,cy0+3]]);line(shade(o.top,-.25),3,[[10,cy0],[7,cy0+3]]);line('#fff',.9,[[-8.6,cy0+3],[-9.2,cy0+19]]);line('#fff',.9,[[8.6,cy0+3],[9.2,cy0+19]]);dot('#e8e8e8',-9.2,cy0+20,1);dot('#e8e8e8',9.2,cy0+20,1);
      for(const sd of [-1,1]){const k=new Path2D();k.moveTo(sd*9,hem-22);k.lineTo(sd*(tw(hem-10)-2),hem-20);k.lineTo(sd*(tw(hem-4)-1),hem-6);k.lineTo(sd*9.5,hem-6);k.closePath();fillP(ctx,k,shade(o.top,-.05),.5)}ctx.fillStyle=shade(o.top,-.12);for(const sd of [-1,1])ctx.fillRect(sd>0?6.6:-tw(hem-2),hem-4,tw(hem-2)-6.6,4)}
    else if(['jacket','varsity','denim','track'].includes(o.pat)){const ic=o.pat==='denim'?o.accent:'#ffffff';inner(ic,6,5.4);line(dk,.9,[[-6,cy0],[-5.4,hem]]);line(dk,.9,[[6,cy0],[5.4,hem]]);
      if(o.pat==='track'){line('#fff',1.4,[[-6.6,cy0+2],[-6,hem]]);line('#fff',1.4,[[6.6,cy0+2],[6,hem]]);const k=new Path2D();rrp(k,-11,cy0-4,22,5,2.4);fillP(ctx,k,shade(o.top,.08),.6);dot('#fff',-14,cy0+16,1.6)}
      else{collar(shade(o.top,-.08),dk,o.pat==='denim'?1.25:1.1)}
      if(o.pat==='denim'){for(const sd of [-1,1]){const k=new Path2D();rrp(k,sd>0?8:-17,cy0+16,9,8,1.4);fillP(ctx,k,shade(o.top,-.04),.6);line(dk,.5,[[sd>0?8:-17,cy0+19],[sd>0?17:-8,cy0+19]]);dot('#d9b44a',sd*12.5,cy0+20,.8)}ctx.fillStyle=shade(o.top,-.15);ctx.fillRect(-tw(hem),hem-4,tw(hem)*2,4)}
      if(o.pat==='varsity'){ctx.fillStyle=o.accent;ctx.fillRect(-tw(hem),hem-4,tw(hem)*2,4);ctx.font='bold 9px Fredoka,sans-serif';ctx.fillStyle=o.accent;ctx.fillText('K',-17,cy0+20)}}
    else if(o.pat==='cardigan'){inner(o.accent,6,1);ctx.fillStyle=o.accent;ctx.beginPath();ctx.moveTo(-6,cy0-1);ctx.lineTo(0,cy0+22);ctx.lineTo(6,cy0-1);ctx.fill();line(dk,.7,[[0,cy0+22],[0,hem]]);for(let yy=cy0+25;yy<hem;yy+=6)dot(shade(o.top,-.45),2.2,yy,.9)}
    else if(o.pat==='blouse'){collar('#ffffff','#b9b2c8');placket('#d9d3e6',6)}
    else if(o.pat==='lace'){ctx.strokeStyle='#e8dccb';ctx.lineWidth=.6;for(let xx=-8;xx<=8;xx+=2.6){ctx.beginPath();ctx.arc(xx,cy0,1.2,0,Math.PI);ctx.stroke()}for(let xx=-tw(hem)+1;xx<tw(hem);xx+=3){ctx.beginPath();ctx.arc(xx,hem-1,1.4,0,Math.PI);ctx.stroke()}ctx.globalAlpha=.4;for(const xx of [-10,-5,5,10]){ctx.beginPath();ctx.moveTo(xx,cy0+4);ctx.lineTo(xx,hem-2);ctx.stroke()}ctx.globalAlpha=1}
    else if(o.pat==='batikshirt'||o.pat==='hawaii'||o.pat==='collar'||o.pat==='check'){if(o.pat==='hawaii'){ctx.fillStyle=sk;ctx.beginPath();ctx.moveTo(-5,cy0-1);ctx.lineTo(0,cy0+8);ctx.lineTo(5,cy0-1);ctx.fill()}collar(o.pat==='collar'?'#ffffff':shade(o.top,o.pat==='hawaii'?.06:-.06),shade(o.top,-.45),1.15);placket(shade(o.top,-.35),7)}
    else{line(shade(o.top,-.3),.9,[[-6,cy0-.6],[0,cy0+3.6],[6,cy0-.6]])}
    break;
   case 'uniform':collar(shade(o.top,-.1),dk);placket(dk,8);if(o.pat==='tie'){ctx.fillStyle=o.accent;ctx.beginPath();ctx.moveTo(-1.6,cy0+5);ctx.lineTo(1.6,cy0+5);ctx.lineTo(2.6,cy0+26);ctx.lineTo(0,cy0+29);ctx.lineTo(-2.6,cy0+26);ctx.fill()}
     if(o.pat==='badge'){dot(o.accent,-10,cy0+12,2.6);ctx.fillStyle=o.accent;ctx.fillRect(-g.sh,cy0-1,8,2);ctx.fillRect(g.sh-8,cy0-1,8,2)}
     if(o.pat==='reflect'){const yy=g.waistY-6;ctx.fillStyle=o.accent;ctx.fillRect(-tw(yy),yy,tw(yy)*2,3.4);ctx.fillRect(-tw(yy+8),yy+8,tw(yy+8)*2,2.2)}break;
   case 'office':collar('#ffffff','#b9b2c8');placket('#d9d3e6',7);if(!f){ctx.fillStyle=o.accent;ctx.beginPath();ctx.moveTo(-1.8,cy0+5);ctx.lineTo(1.8,cy0+5);ctx.lineTo(2.8,cy0+30);ctx.lineTo(0,cy0+33);ctx.lineTo(-2.8,cy0+30);ctx.fill()}break;
   case 'blazer':case 'suit':{collar('#ffffff','#b9b2c8',.9);ctx.fillStyle=o.accent;if(o.style==='suit'||!f){ctx.beginPath();ctx.moveTo(-1.8,cy0+5);ctx.lineTo(1.8,cy0+5);ctx.lineTo(2.8,cy0+30);ctx.lineTo(0,cy0+33);ctx.lineTo(-2.8,cy0+30);ctx.fill()}
     for(const sd of [-1,1]){const c=new Path2D();c.moveTo(sd*7,cy0-2);c.lineTo(sd*(g.sh-1),cy0+1);c.lineTo(sd*(tw(-130*g.bh)),hem);c.lineTo(sd*2,hem);c.lineTo(sd*2.2,cy0+32);c.lineTo(sd*11,cy0+16);c.closePath();fillP(ctx,c,o.top,.7);aShade(ctx,c,-30,30,cy0,hem,.8);line(shade(o.top,-.45),.7,[[sd*7,cy0-2],[sd*11,cy0+16],[sd*2.2,cy0+32]])}
     dot(shade(o.top,-.5),-3.6,cy0+40,1.1);if(o.style==='blazer'){dot(o.accent,-12,cy0+16,2.4)}const k=new Path2D();rrp(k,9,cy0+14,7,1.6,.6);fillP(ctx,k,'#ffffff',.3);break}
   case 'labcoat':{const c=new Path2D();for(const sd of [-1,1]){c.moveTo(sd*6,cy0-2);c.lineTo(sd*(g.sh+1),cy0+1);c.lineTo(sd*(g.hip+6),-70*g.bh);c.lineTo(sd*3,-70*g.bh);c.lineTo(sd*3,cy0+26);c.closePath()}fillP(ctx,c,'#ffffff',.7);aShade(ctx,c,-30,30,cy0,-70,.7);dot('#9aa',-14,cy0+20,1.6);ctx.fillStyle=o.accent;ctx.fillRect(9,cy0+14,7,2);ctx.strokeStyle='#3a3f4a';ctx.lineWidth=1.3;ctx.beginPath();ctx.moveTo(-8,cy0);ctx.quadraticCurveTo(-10,cy0+20,-2,cy0+22);ctx.quadraticCurveTo(7,cy0+20,8,cy0);ctx.stroke();break}
   case 'chef':for(let yy=cy0+8;yy<hem-4;yy+=8){dot('#2b2b33',-5,yy,1.2);dot('#2b2b33',5,yy,1.2)}ctx.fillStyle='#e63946';ctx.fillRect(-8,cy0-3,16,3);break;
   case 'nurse':line(o.accent,1.6,[[-8,cy0-1],[0,cy0+10],[8,cy0-1]]);{const k=new Path2D();rrp(k,6,cy0+14,8,7,1);fillP(ctx,k,o.top,.6)}break;
   case 'apron':{const a=new Path2D();rrp(a,-14,cy0+10,28,hem-cy0-8,4);fillP(ctx,a,o.accent);line(o.accent,1.6,[[-11,cy0+10],[-8,cy0-1]]);line(o.accent,1.6,[[11,cy0+10],[8,cy0-1]])}break;
   case 'sport':ctx.fillStyle=o.accent;ctx.fillRect(-tw(cy0+20)+1.4,cy0+4,2.6,hem-cy0-6);ctx.fillRect(tw(cy0+20)-4,cy0+4,2.6,hem-cy0-6);line(shade(o.top,-.3),1.6,[[-6,cy0-1],[0,cy0+5],[6,cy0-1]]);break;
   case 'pinafore':{const p=new Path2D();rrp(p,-12,cy0+10,24,g.waistY-cy0-6,3);fillP(ctx,p,o.bottom);line(o.bottom,2.6,[[-10,cy0+10],[-11,cy0-1]]);line(o.bottom,2.6,[[10,cy0+10],[11,cy0-1]])}break;
   case 'kurung':line(shade(o.top,-.35),.9,[[-5,cy0-1],[0,cy0+3],[5,cy0-1]]);line(shade(o.top,-.35),.7,[[0,cy0+3],[0,cy0+11]]);if(o.pat==='goldtrim'){ctx.fillStyle=o.accent;ctx.fillRect(-tw(hem-3),hem-4,tw(hem-3)*2,2.4);line(o.accent,1.3,[[-6,cy0-1],[0,cy0+4],[6,cy0-1]]);ctx.fillStyle=o.accent;for(let i=0;i<6;i++){const a=i/6*TAU;ctx.beginPath();ctx.ellipse(-10+Math.cos(a)*2.4,cy0+20+Math.sin(a)*2.4,1.6,1,a,0,TAU);ctx.fill()}}break;
   case 'kebaya':{ctx.fillStyle=shade(o.top,.4);ctx.beginPath();ctx.moveTo(-6,cy0-1);ctx.lineTo(0,cy0+26);ctx.lineTo(6,cy0-1);ctx.fill();line(shade(o.top,-.35),.8,[[-6,cy0-1],[0,cy0+26],[6,cy0-1]]);line(shade(o.top,-.35),.8,[[0,cy0+26],[-4,hem]]);for(const yy of [8,15,22])dot('#f2c230',0,cy0+yy+2,2)}break;
   case 'cheongsam':case 'samfu':case 'robe':{const k=new Path2D();rrp(k,-6,cy0-5,12,5,2);fillP(ctx,k,shade(o.top,-.08),.6);if(o.style==='cheongsam'){line(shade(o.top,-.45),.8,[[0,cy0],[10,cy0+8],[14,cy0+14]]);for(const [xx,yy] of [[5,cy0+4],[11,cy0+10]])line(o.accent,1.6,[[xx-2,yy],[xx+2,yy]]);line(shade(o.top,-.4),.8,[[16,-70],[17,G.hem]])}
     else{for(let yy=cy0+6;yy<(o.style==='robe'?-100*g.bh:hem-4);yy+=7)line(o.accent,1.8,[[-3,yy],[3,yy]]);line(shade(o.top,-.45),.8,[[0,cy0],[0,hem]])}
     if(o.style==='robe'){for(const sd of [-1,1]){const st2=new Path2D();rrp(st2,sd>0?2:-10,cy0,8,90*g.bh,2);fillP(ctx,st2,o.accent,.6)}}break}
   case 'sari':{const d=new Path2D();d.moveTo(-g.sh,cy0+1);d.lineTo(-10,cy0-3);d.lineTo(g.hip+6,-112*g.bh);d.lineTo(g.hip+6,-96*g.bh);d.lineTo(8,-96*g.bh);d.closePath();fillP(ctx,d,o.top);withClip(ctx,d,()=>drawPattern(ctx,'zari',o.top,o.accent,-40,-210,40,-90));line(o.accent,2,[[-g.sh,cy0+1],[g.hip+6,-112*g.bh]])}break;
   case 'kurta':case 'punjabi':{const k=new Path2D();rrp(k,-5,cy0-5,10,5,2);fillP(ctx,k,shade(o.top,-.06),.6);line(shade(o.top,-.4),.8,[[0,cy0],[0,cy0+22]]);for(const yy of [6,12,18])dot(o.accent,0,cy0+yy,1.2);if(o.style==='punjabi'){ctx.globalAlpha=.85;line(o.accent,8,[[-tw(-110*g.bh),-104*g.bh],[-g.sh+2,cy0+2],[0,cy0+6],[g.sh-2,cy0+2],[tw(-110*g.bh),-104*g.bh]]);ctx.globalAlpha=1}}break;
   case 'lehenga':{ctx.globalAlpha=.75;const d=new Path2D();d.moveTo(-g.sh,cy0+1);d.lineTo(-10,cy0-3);d.lineTo(g.hip+8,-100*g.bh);d.lineTo(g.hip,-90*g.bh);d.closePath();fillP(ctx,d,o.accent,0);ctx.globalAlpha=1}break;
   case 'bodo':ctx.globalAlpha=.3;ctx.fillStyle='#fff';ctx.fill(tp);ctx.globalAlpha=1;line(o.accent,1.2,[[-6,cy0-1],[0,cy0+4],[6,cy0-1]]);break;
   case 'bajumelayu':if(o.pat==='kelim'){line(o.accent,1.3,[[-6,cy0-1],[0,cy0+4],[6,cy0-1]]);line(o.accent,1,[[0,cy0+4],[0,cy0+14]])}else{const k=new Path2D();rrp(k,-6.5,cy0-5,13,5,2);fillP(ctx,k,shade(o.top,-.1),.6)}for(const yy of [6,12,18])dot(o.accent,0,cy0+yy,1.4);if(o.pat==='goldtrim'){line(o.accent,1.2,[[-6,cy0-1],[0,cy0+8],[6,cy0-1]])}break;
   case 'borneo':{const yy=hem-6;ctx.fillStyle=o.accent;ctx.fillRect(-tw(yy),yy,tw(yy)*2,3);ctx.fillRect(-tw(yy-4),yy-4,tw(yy-4)*2,1.2);line(o.accent,2,[[-8,cy0-1],[0,cy0+9],[8,cy0-1]]);
     if(o.pat==='goldtrim'||o.pat==='coinbelt'){line(o.accent,1.4,[[0,cy0+9],[0,hem]]);for(let k=cy0+14;k<hem-8;k+=6)dot(o.accent,0,k,1.2)}
     if(o.pat==='coinbelt'){const by=g.waistY+2;for(let xx=-tw(by)+1;xx<=tw(by);xx+=4)dot(o.gold?'#f2c84a':'#d8dce4',xx,by,2.2);for(let xx=-tw(by+5)+2;xx<=tw(by+5);xx+=4)dot(o.gold?'#d9a520':'#b8bcc4',xx,by+4.6,1.8)}
     if(o.pat==='cross'){ctx.lineWidth=4;for(const [a,b] of [[[-g.sh+2,cy0],[g.waist+2,g.waistY]],[[g.sh-2,cy0],[-g.waist-2,g.waistY]]]){ctx.strokeStyle='#c8102e';ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);ctx.stroke()}}
     if(o.top==='#6b4a2b'){ctx.strokeStyle=shade(o.top,-.3);ctx.lineWidth=.6;for(let xx=-16;xx<17;xx+=4){ctx.beginPath();ctx.moveTo(xx,cy0+2);ctx.lineTo(xx+1,hem);ctx.stroke()}}break}
   case 'gown':ctx.fillStyle=o.accent;ctx.fillRect(-tw(g.waistY),g.waistY-1,tw(g.waistY)*2,3);line(shade(o.top,-.3),1,[[-9,cy0-1],[0,cy0+8],[9,cy0-1]]);break;
   case 'dress':line(shade(o.top,-.3),1,[[-6,cy0-1],[0,cy0+5],[6,cy0-1]]);if(o.pat==='goldtrim'){line(o.accent,1.4,[[0,cy0+5],[0,G.hem]]);ctx.fillStyle=o.accent;ctx.fillRect(-tw(G.hem-4),G.hem-5,tw(G.hem-4)*2,2)}else{ctx.fillStyle=shade(o.top,-.15);ctx.fillRect(-tw(g.waistY),g.waistY-1,tw(g.waistY)*2,2.2)}break;
   }
   if(o.pat==='lanyard'){ctx.strokeStyle='#2c56b8';ctx.lineWidth=1.6;ctx.beginPath();ctx.moveTo(-8,cy0-1);ctx.lineTo(-2,cy0+30);ctx.moveTo(8,cy0-1);ctx.lineTo(2,cy0+30);ctx.stroke();const k=new Path2D();rrp(k,-5,cy0+29,10,12,1.4);fillP(ctx,k,'#ffffff',.6);ctx.fillStyle='#2c56b8';ctx.fillRect(-5,cy0+29,10,3);ctx.fillStyle='#c9c2da';ctx.fillRect(-3.4,cy0+34,3.2,4);ctx.fillRect(1,cy0+34.5,3,1);ctx.fillRect(1,cy0+36.5,3,1)}
  }
  // ===== arms
  const sleeveCol=o.pat==='varsity'?o.accent:o.style==='labcoat'?'#ffffff':(o.style==='blazer'||o.style==='suit')?o.top:o.style==='sari'||o.style==='lehenga'?shade(o.top,-.12):o.pat==='silver'?'#3a2a2a':o.top;
  const armW=f?8.4:10.2,foreW=f?6:7.2;
  const hands=[];
  const holdCup=C.acc===7&&!back&&!side,still=frame%2===0,peace=(C.pose|0)===1&&!back&&!side&&still&&!holdCup,pockets=(C.pose|0)===2&&!back&&still&&!holdCup;
  for(const sd of (side?[1]:[-1,1])){if(peace&&sd===1)continue;let a=armGeo(g,sd,sd<0?sw:-sw);if(pockets)a={x0:a.x0,y0:a.y0,ex:sd*(g.sh+3),ey:(a.y0+g.hipY)/2-4,wx:sd*(g.hip-4),wy:g.hipY+2};const all=holdCup?armPts(a,.5):armPts(a,1);
    limb(ctx,all,armW,foreW-1,sk,shade(sk,-.35));
    const sl=holdCup?.5:G.sleeve==='long'?.93:o.style==='kebaya'||o.style==='kedah'?.8:.42;const sp=armPts(a,sl);
    const sp2=limb(ctx,sp,armW+2.6,(sl>.6?foreW+2.4:armW+1.4),sleeveCol);aShade(ctx,sp2,a.x0-8,a.x0+8,a.y0,a.wy,.9);
    if(o.pat==='track'){line('#ffffff',1.4,sp.map(([px,py])=>[px+sd*2.6,py]))}
    if(o.pat==='varsity'&&false){}
    const cuffT=sl-.05;const c0=armPts(a,cuffT),c1=sp[sp.length-1],c0e=c0[c0.length-1];
    if(o.pat==='hoodie'||o.pat==='denim'||o.pat==='track'||o.pat==='cardigan'||o.pat==='hoodjacket'||o.pat==='bomber'){ctx.strokeStyle=shade(sleeveCol,-.12);ctx.lineWidth=foreW+2.6;ctx.lineCap='butt';ctx.beginPath();ctx.moveTo(c0e[0],c0e[1]);ctx.lineTo(c1[0],c1[1]);ctx.stroke();ctx.lineCap='round'}
    if(o.style==='borneo'||(o.style==='bajumelayu'&&o.pat==='goldtrim')||o.pat==='lace'||o.pat==='blouse'){ctx.strokeStyle=o.pat==='blouse'||o.pat==='lace'?'#f3eee6':o.accent;ctx.lineWidth=(sl>.6?foreW:armW)+2.6;ctx.lineCap='butt';ctx.beginPath();ctx.moveTo(c0e[0],c0e[1]);ctx.lineTo(c1[0],c1[1]);ctx.stroke();ctx.lineCap='round'}
    // hand
    const hx=a.wx+sd*.3,hy=a.wy+5;if(holdCup){hands.push({sd,hx,hy});continue}
    if(pockets){hands.push({sd,hx:a.wx,hy:a.wy});line(shade(o.bottom||'#333',-.45),.9,[[sd*(g.hip-9),g.hipY-1],[sd*(g.hip+.5),g.hipY+6]]);continue}const hp2=new Path2D();hp2.ellipse(hx,hy,foreW*.6,6.6,sd*.1,0,TAU);ctx.fillStyle=sk;ctx.fill(hp2);ctx.strokeStyle=shade(sk,-.35);ctx.lineWidth=.7;ctx.stroke(hp2);
    ctx.strokeStyle=shade(sk,-.25);ctx.lineWidth=.5;ctx.beginPath();ctx.moveTo(hx-sd*1.2,hy+1);ctx.lineTo(hx-sd*1.6,hy+5);ctx.stroke();
    if(C.acc===4&&sd===-1){ctx.fillStyle='#2b2b33';ctx.fillRect(a.wx-3.4,a.wy-2.6,6.8,3.2);ctx.fillStyle='#f2c230';ctx.fillRect(a.wx-1.8,a.wy-2.2,3.6,2.4)}
    hands.push({sd,hx,hy})}
  // ===== bags / straps / neckwear (body)
  const bg=C.bag|0;
  if(bpc){if(back){const b=new Path2D();rrp(b,-16,g.shY+4,32,(g.waistY-g.shY)+18,7);fillP(ctx,b,bpc);aShade(ctx,b,-16,16,g.shY,g.waistY+20,1)}else{for(const sd of [-1,1]){line(shade(bpc,-.3),3.2,[[sd*(g.sh-8),y0-1],[sd*(g.sh-6),g.chestY+20],[sd*(g.sh-3),g.waistY+2]])}}}
  if((C.bag|0)===6&&!back&&!side){const kx=-(g.sh+7),ky=g.waistY+22;line('#d9b44a',.7,[[kx+2,g.waistY+8],[kx,ky-6]]);ctx.fillStyle='#ffffff';ctx.strokeStyle='#cfc4d6';ctx.lineWidth=.6;for(const sd of [-1,1]){ctx.beginPath();ctx.arc(kx+sd*4,ky-4.4,2.2,0,TAU);ctx.fill();ctx.stroke()}ctx.beginPath();ctx.arc(kx,ky,5.6,0,TAU);ctx.fill();ctx.stroke();ctx.beginPath();ctx.ellipse(kx,ky+8,4.6,4,0,0,TAU);ctx.fill();ctx.stroke();ctx.fillStyle='#2a1a20';ctx.beginPath();ctx.arc(kx-2,ky-.6,.8,0,TAU);ctx.arc(kx+2,ky-.6,.8,0,TAU);ctx.fill();ctx.beginPath();ctx.ellipse(kx,ky+1.6,1,.7,0,0,TAU);ctx.fill();ctx.fillStyle='rgba(255,130,160,.5)';ctx.beginPath();ctx.arc(kx-3.4,ky+1.2,1,0,TAU);ctx.arc(kx+3.4,ky+1.2,1,0,TAU);ctx.fill()}
  if(C.acc===3||bg===2){line('#6b4426',2,[[-g.sh+5,y0],[g.hip-2,g.hipY+2]]);if(!back){const b=new Path2D();rrp(b,g.hip-8,g.hipY-2,15,12,3.4);fillP(ctx,b,C.acc===3?'#c8603a':'#8a5a3a',.8);line('#6e4529',.7,[[g.hip-8,g.hipY+2],[g.hip+7,g.hipY+2]]);dot('#e2c06a',g.hip-.5,g.hipY+3.6,1.2)}}
  const hb=hands.find(q=>q.sd===1)||hands[0];if(bg>=3&&bg<=5&&!back&&hb){const h=hb;const hx=h.hx,hy=h.hy;
    if(bg===5){ctx.strokeStyle='#2a1a10';ctx.lineWidth=1.8;ctx.beginPath();ctx.arc(hx+2,hy+3.6,3.6,Math.PI,TAU);ctx.stroke();const b=new Path2D();rrp(b,hx-7,hy+3.6,20,15,2.4);fillP(ctx,b,'#4a2f1e',.8);ctx.fillStyle='#6a4630';ctx.fillRect(hx-7,hy+8,20,1.4);dot('#e2c06a',hx+3,hy+8.8,1.4);aShade(ctx,b,hx-7,hx+13,hy,hy+19,1)}
    else{const col=bg===3?'#efe1c6':'#d6ad6c';ctx.strokeStyle=shade(col,-.4);ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(hx-3.6,hy+7);ctx.quadraticCurveTo(hx,hy-4,hx+4.8,hy+7);ctx.stroke();const b=new Path2D();b.moveTo(hx-7,hy+6.6);b.lineTo(hx+8,hy+6.6);b.lineTo(hx+10,hy+24);b.lineTo(hx-9,hy+24);b.closePath();fillP(ctx,b,col,.8);aShade(ctx,b,hx-9,hx+10,hy+6,hy+24,.9);
      if(bg===4)withClip(ctx,b,()=>{ctx.strokeStyle=shade(col,-.25);ctx.lineWidth=.55;for(let yy=hy+8;yy<hy+24;yy+=2.4){ctx.beginPath();ctx.moveTo(hx-10,yy);ctx.lineTo(hx+11,yy);ctx.stroke()}for(let xx=hx-9;xx<hx+11;xx+=2.6){ctx.beginPath();ctx.moveTo(xx,hy+6);ctx.lineTo(xx+1,hy+24);ctx.stroke()}});
      else{ctx.fillStyle='#d9c6a2';ctx.fillRect(hx-7,hy+6.6,15,2.2)}}}
  if(C.acc===7&&!back&&!side){const cx=0,cy=g.waistY-6;ctx.fillStyle='rgba(60,30,20,.18)';ctx.beginPath();ctx.ellipse(cx+1,cy+9,7,2,0,0,TAU);ctx.fill();
    const cp=new Path2D();cp.moveTo(cx-6.4,cy-9);cp.lineTo(cx+6.4,cy-9);cp.lineTo(cx+5,cy+9);cp.lineTo(cx-5,cy+9);cp.closePath();const cg=ctx.createLinearGradient(cx-6,0,cx+6,0);cg.addColorStop(0,'#ffffff');cg.addColorStop(1,'#e6e0ee');ctx.fillStyle=cg;ctx.fill(cp);ctx.strokeStyle='#bdb3cc';ctx.lineWidth=.7;ctx.stroke(cp);
    ctx.fillStyle='#a8743e';ctx.beginPath();ctx.moveTo(cx-6,cy-3);ctx.lineTo(cx+6,cy-3);ctx.lineTo(cx+5.4,cy+4);ctx.lineTo(cx-5.4,cy+4);ctx.closePath();ctx.fill();ctx.strokeStyle='#8a5a2a';ctx.lineWidth=.5;for(let k=-4;k<=4;k+=2){ctx.beginPath();ctx.moveTo(cx+k,cy-3);ctx.lineTo(cx+k*.9,cy+4);ctx.stroke()}
    const lid=new Path2D();rrp(lid,cx-7.4,cy-12.4,14.8,4,1.6);ctx.fillStyle='#f6f2fa';ctx.fill(lid);ctx.strokeStyle='#bdb3cc';ctx.stroke(lid);ctx.fillStyle='#e6e0ee';ctx.fillRect(cx-5.6,cy-14.2,11.2,2);
    for(const sd of [-1,1]){const hp3=new Path2D();hp3.ellipse(cx+sd*6.2,cy+1.6,3.6,4.6,sd*.3,0,TAU);ctx.fillStyle=sk;ctx.fill(hp3);ctx.strokeStyle=shade(sk,-.35);ctx.lineWidth=.6;ctx.stroke(hp3)}
    for(const sd of [-1,1]){const a=armGeo(g,sd,0);limb(ctx,[[a.ex,a.ey],[cx+sd*8,cy+3]],(f?6:7.2)+2.4,(f?6:7.2)+1.6,G.sleeve==='long'?sleeveCol:sk)}
    for(const sd of [-1,1]){const hp3=new Path2D();hp3.ellipse(cx+sd*6.2,cy+1.6,3.6,4.6,sd*.3,0,TAU);ctx.fillStyle=sk;ctx.fill(hp3);ctx.strokeStyle=shade(sk,-.35);ctx.lineWidth=.6;ctx.stroke(hp3)}}
  if(C.neck===2){line('#c8102e',6,[[-10,y0-1],[0,y0+2],[10,y0-1]]);if(!back)line('#c8102e',5,[[5,y0+2],[8,y0+16]])}
  if(C.neck===1&&!back&&!hij){ctx.strokeStyle='#f2c230';ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(-5.2,y0-4);ctx.quadraticCurveTo(0,y0+7,5.2,y0-4);ctx.stroke();dot('#f2c230',0,y0+4.4,1.4)}
  if(C.neck===3&&!back&&!hij){const bc=['#e63946','#f2c230','#fff','#2ec4b6'];for(let i=0;i<11;i++){const a=Math.PI*(.1+i*.08);dot(bc[i%4],Math.cos(a)*8.5,y0-4+Math.sin(a)*9,1.3)}}
  if(C.acc===6&&!back){ctx.strokeStyle='#1d1d24';ctx.lineWidth=2.6;ctx.beginPath();ctx.moveTo(-11,y0-2);ctx.quadraticCurveTo(0,y0+8,11,y0-2);ctx.stroke();for(const sd of [-1,1]){const p=new Path2D();p.ellipse(sd*11.5,y0-1,4,5.4,sd*.45,0,TAU);fillP(ctx,p,'#26262e',.7);ctx.fillStyle='#f4f4f6';ctx.beginPath();ctx.ellipse(sd*11.5,y0-1,2.8,3.6,sd*.45,0,TAU);ctx.fill();ctx.fillStyle='#1d1d24';ctx.beginPath();for(let k=0;k<10;k++){const an=-Math.PI/2+k*Math.PI/5,r=k%2?.8:2;ctx.lineTo(sd*11.5+Math.cos(an)*r,y0-1+Math.sin(an)*r)}ctx.fill()}}
  // ===== head
  ctx.save();headT();
  if(hij){
    const hcol=HIJAB_COL[C.hijabCol]||'#ddd',hs2=C.hijabSt|0,P=()=>new Path2D();
    if(hs2!==3){const d=P();const dcap=(g.hipY-g.headY)/g.hs*.8;const long=Math.min(hs2===2?84:hs2===1?56:66,dcap);const hw=g.chibi?.72:1;d.moveTo(-23,2);d.bezierCurveTo(-30*hw,20,-34*hw,40,-32*hw,long*.75);d.quadraticCurveTo(0,long+(hs2===0?10:4),32*hw,long*.75);d.bezierCurveTo(34*hw,40,30*hw,20,23,2);d.closePath();fillP(ctx,d,hcol);aShade(ctx,d,-34,34,0,long+8,1);
      if(!back){ctx.strokeStyle=shade(hcol,-.18);ctx.lineWidth=.7;for(const k of [-14,-6,6,14]){ctx.beginPath();ctx.moveTo(k*.6,30);ctx.quadraticCurveTo(k,long*.6,k*1.3,long-2);ctx.stroke()}}
      if(hs2===2&&!back){const e=P();const el=long;e.moveTo(14,18);e.bezierCurveTo(30,14,40,40,34,el+2);e.lineTo(24,el-2);e.bezierCurveTo(28,48,22,30,10,26);e.closePath();fillP(ctx,e,shade(hcol,-.06))}}
    const hd=P();hd.ellipse(0,-1,hs2===3?21.5:23.5,hs2===3?25:27.5,0,0,TAU);fillP(ctx,hd,hcol);aShade(ctx,hd,-24,24,-28,26,.9);
    if(hs2===3){const tw2=P();tw2.ellipse(0,-17,22,12,0,0,TAU);fillP(ctx,tw2,shade(hcol,-.05));line(shade(hcol,-.3),.8,[[-14,-24],[0,-12],[14,-24]])}
    if(!back){const fp=aFacePath(C);ctx.save();ctx.translate(side?2.4:0,1.5);ctx.scale(.86,.88);ctx.fillStyle=sk;ctx.fill(fp);skinShade(ctx,fp,sk);aFace(ctx,C,side);ctx.restore();
      ctx.strokeStyle=shade(hcol,-.22);ctx.lineWidth=2.2;ctx.beginPath();ctx.ellipse(side?2.4:0,-1,17.4,22.2,0,Math.PI*1.08,Math.PI*1.92);ctx.stroke();
      if(hs2!==3){dot('#f2c230',0,23.6,1.8);dot('#fff8d8',-.5,23.1,.6)}}
  } else {
    if(!back){ // ears
      for(const sd of (side?[-1]:[-1,1])){const ex=sd*17.8;ctx.fillStyle=sk;ctx.beginPath();ctx.ellipse(ex,3,3.2,5.4,sd*.15,0,TAU);ctx.fill();ctx.strokeStyle=shade(sk,-.35);ctx.lineWidth=.6;ctx.stroke()}}
    const fp=aFacePath(C);ctx.save();if(side)ctx.translate(2.4,0);fillP(ctx,fp,sk,.6);if(!back){skinShade(ctx,fp,sk);ctx.save();ctx.clip(fp);const fg=ctx.createRadialGradient(0,4,6,0,4,26);fg.addColorStop(0,'rgba(255,255,255,.18)');fg.addColorStop(.7,'rgba(255,255,255,0)');fg.addColorStop(1,'rgba(160,80,90,.16)');ctx.fillStyle=fg;ctx.fillRect(-30,-30,60,60);ctx.restore()}
    // chin shadow onto neck
    if(back){ctx.restore();
      if(hp.backKind==='long'||hp.backKind==='bob'||hp.backKind==='braid'||hp.backKind==='halfbun')aHairFill(ctx,hp.back,shade(hc,-.08),-20,110);
      if(hp.backKind==='pony'){const t=new Path2D();t.moveTo(-6,-16);t.bezierCurveTo(-8,20,6,40,0,70);t.quadraticCurveTo(10,40,8,-16);t.closePath();aHairFill(ctx,t,shade(hc,-.08),-16,70)}
      if(hp.backKind==='twin'){for(const sd of [-1,1]){const t=new Path2D();t.moveTo(sd*16,-16);t.bezierCurveTo(sd*36,-6,sd*34,40,sd*28,78);t.quadraticCurveTo(sd*22,44,sd*20,20);t.closePath();aHairFill(ctx,t,shade(hc,-.1),-16,78)}}
      const bh=new Path2D();bh.ellipse(0,-4,21.5,24,0,0,TAU);aHairFill(ctx,bh,hc,-28,20);if(hp.backKind==='curly')aCurly(ctx,hc);aHairShine(ctx,bh,hc);
      if(hp.backKind==='bun'||hp.backKind==='halfbun'){const b=new Path2D();b.arc(0,-24,8.5,0,TAU);aHairFill(ctx,b,hc,-32,-16)}
    } else {
      aFace(ctx,C,side);ctx.restore();
      // hair shadow on forehead
      ctx.save();ctx.clip(fp);ctx.translate(0,2.4);ctx.globalAlpha=.4;ctx.fillStyle=shade(sk,-.25);ctx.fill(hp.cap);ctx.fill(hp.fr);ctx.restore();
      if(hp.backKind==='undercut'){const u=new Path2D();u.moveTo(-19.5,4);u.bezierCurveTo(-21,-14,-14,-22,0,-23);u.bezierCurveTo(14,-22,21,-14,19.5,4);u.quadraticCurveTo(18,-6,14,-10);u.quadraticCurveTo(0,-14,-14,-10);u.quadraticCurveTo(-18,-6,-19.5,4);ctx.fillStyle=shade(hc,.35);ctx.globalAlpha=.55;ctx.fill(u);ctx.globalAlpha=1}
      if(hp.backKind==='bun'||hp.backKind==='halfbun'){const b=new Path2D();b.arc(0,-26,hp.backKind==='bun'?9.5:7.5,0,TAU);aHairFill(ctx,b,hc,-36,-17);ctx.strokeStyle='rgba(255,255,255,.3)';ctx.lineWidth=1.4;ctx.beginPath();ctx.arc(0,-26,5.4,Math.PI*1.1,Math.PI*1.5);ctx.stroke()}
      if(hp.backKind==='curly')aCurly(ctx,hc);
      else{aHairFill(ctx,hp.cap,hc,-28,6);aHairShine(ctx,hp.cap,hc)}
      aHairFill(ctx,hp.side,hc,-6,70);
      aHairFill(ctx,hp.fr,hc,-28,6,.6,1);
      if(hp.backKind==='braid'){const bl=Math.min(1,((g.kneeY-g.headY)/g.hs)/90);for(let i=0;i<8;i++){const b=new Path2D();b.ellipse(-19+i*.6,18+i*8*bl,5.4-i*.35,5,.25,0,TAU);aHairFill(ctx,b,hc,14+i*8*bl,24+i*8*bl)}ctx.fillStyle='#ff7aa8';ctx.beginPath();ctx.arc(-15,18+66*bl,2.6,0,TAU);ctx.fill()}
      if(hp.backKind==='twin'){ctx.fillStyle='#e63946';for(const sd of [-1,1]){ctx.beginPath();ctx.arc(sd*18,-14,2.8,0,TAU);ctx.fill()}}
      if(hp.backKind==='pony'){ctx.fillStyle=shade(hc,-.4);ctx.beginPath();ctx.ellipse(12,-18,2.4,3.2,.6,0,TAU);ctx.fill()}
      if(C.ear){for(const sd of (side?[-1]:[-1,1])){const ex=sd*18.2;if(C.ear===2){ctx.strokeStyle='#e2b44a';ctx.lineWidth=.9;ctx.beginPath();ctx.arc(ex,10.4,2.6,0,TAU);ctx.stroke()}else dot(C.ear===3?'#fffaf0':'#f2c230',ex,8,C.ear===3?1.5:1.1)}}
    }
  }
  // headwear / hats / glasses / headphones (reuse chibi headwear, fitted to adult head)
  if(!hij||o.head==='veil'||o.head==='mortar'){ctx.save();ctx.translate(0,-3);ctx.scale(.86,.92);if(o.head&&o.head!=='veil')drawHeadwear(ctx,o.head,o,C);else if(C.hat&&!hij)drawHat(ctx,C.hat);ctx.restore()}
  if(!back&&C.glasses){const gx=f?8.2:8.6;if(C.glasses===5||C.glasses===6){const fr=C.glasses===6?'#fbf7f9':'#121218',flw=C.glasses===6?2.2:1;for(const xx of [-8.6,8.6]){const p=new Path2D();rrp(p,xx-7,-24,14,8,3.4);const gr=ctx.createLinearGradient(0,-24,0,-16);gr.addColorStop(0,'#1e1e2a');gr.addColorStop(1,'#5a4a7a');ctx.fillStyle=gr;ctx.fill(p);if(C.glasses===6){ctx.strokeStyle='#d8cfd8';ctx.lineWidth=3;ctx.stroke(p)}ctx.strokeStyle=fr;ctx.lineWidth=flw;ctx.stroke(p);ctx.fillStyle='rgba(255,255,255,.4)';ctx.fillRect(xx-4.4,-22.6,2.4,2.4)}line(fr,flw+.4,[[-1.6,-21],[1.6,-21]])}
    else{ctx.strokeStyle=C.glasses===4?'#5a3b22':'#2b2b33';ctx.lineWidth=.9;for(const xx of (side?[gx+2.4]:[-gx,gx])){if(C.glasses===1){ctx.beginPath();ctx.arc(xx,4.4,6.4,0,TAU);ctx.stroke()}else if(C.glasses===4){ctx.lineWidth=1.6;ctx.beginPath();ctx.moveTo(xx-6.4,.6);ctx.quadraticCurveTo(xx,-.8,xx+6.4,.6);ctx.stroke()}else{const p=new Path2D();rrp(p,xx-6.8,-.6,13.6,10,2.6);if(C.glasses===3){const gr=ctx.createLinearGradient(0,0,0,10);gr.addColorStop(0,'#2a2a40');gr.addColorStop(1,'#6a5a9a');ctx.fillStyle=gr;ctx.fill(p);ctx.fillStyle='rgba(255,255,255,.4)';ctx.fillRect(xx-4,1,2.4,3)}ctx.stroke(p)}}
      if(!side)line(ctx.strokeStyle,.9,[[-gx+6,3.4],[gx-6,3.4]])}}
  if((C.acc===2||C.acc===5)&&!hij){const cat=C.acc===5,bc=cat?'#f3a9c8':'#f0a6c6';if(cat){for(const sd of [-1,1]){const e=new Path2D();e.moveTo(sd*8,-23);e.lineTo(sd*16,-35);e.lineTo(sd*20,-18);e.closePath();fillP(ctx,e,'#f6b8d1',.8);ctx.fillStyle='#ffdce9';ctx.beginPath();ctx.moveTo(sd*11,-22.4);ctx.lineTo(sd*15.6,-30);ctx.lineTo(sd*17.6,-20.4);ctx.fill()}}
    ctx.strokeStyle=shade(bc,-.35);ctx.lineWidth=4;ctx.beginPath();ctx.arc(0,-2,23.5,Math.PI*1.08,Math.PI*1.92);ctx.stroke();ctx.strokeStyle=bc;ctx.lineWidth=2.6;ctx.stroke();
    for(const sx of (side?[-1]:[-1,1])){const p=new Path2D();rrp(p,sx*22.5-4.4,-4,8.8,14,4.4);fillP(ctx,p,bc);ctx.fillStyle='#fff0f6';ctx.beginPath();ctx.ellipse(sx*22.5,3,2,4,0,0,TAU);ctx.fill()}}
  ctx.restore();
  if(peace){const a0=armGeo(g,1,0),x0=a0.x0,y0a=a0.y0,ex=x0+g.sh*.8,ey=y0a+(g.waistY-g.shY)*.45,wx=x0+g.sh*1.05,wy=y0a-(g.shY-g.headY)*.32;const ag={x0,y0:y0a,ex,ey,wx,wy};
    limb(ctx,armPts(ag,1),armW,foreW-1,sk,shade(sk,-.35));const sl=G.sleeve==='long'?.9:.45;const sp=limb(ctx,armPts(ag,sl),armW+2.6,sl>.6?foreW+2.4:armW+1.4,sleeveCol);aShade(ctx,sp,x0-6,wx+8,wy,ey,.9);
    const hx=wx,hy=wy-3;for(const [fx,rot] of [[-1.6,-.22],[1.8,.2]]){ctx.save();ctx.translate(hx+fx,hy-3);ctx.rotate(rot);const fp=new Path2D();rrp(fp,-1.5,-9,3,10,1.5);ctx.fillStyle=sk;ctx.fill(fp);ctx.strokeStyle=shade(sk,-.35);ctx.lineWidth=.6;ctx.stroke(fp);ctx.restore()}
    const hp4=new Path2D();hp4.ellipse(hx,hy,foreW*.62,5.6,0,0,TAU);ctx.fillStyle=sk;ctx.fill(hp4);ctx.strokeStyle=shade(sk,-.35);ctx.lineWidth=.7;ctx.stroke(hp4);ctx.beginPath();ctx.moveTo(hx-2.6,hy+1);ctx.quadraticCurveTo(hx,hy+2.4,hx+2.6,hy+1);ctx.stroke()}
  ctx.restore();
}
// make the whole game use the 2.5D renderer
drawChibi=drawAnime;
