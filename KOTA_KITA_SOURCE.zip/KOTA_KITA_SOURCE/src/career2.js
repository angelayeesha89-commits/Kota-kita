// ===================== SPONSORSHIP · WALLET LEDGER · STUDENT RULE · PRACTICAL · JOB CALLS · SOUND =====================

// ---------------- AUDIO (Web Audio, procedurally generated — no files)
const AU_KEY='kotakita_audio_v1';
const AU={ctx:null,master:null,music:null,sfx:null,ring:null,set:{master:.8,music:.35,sfx:.8,ring:.9,mute:false},ringing:null,next:0,step:0,ringOsc:[]};
try{Object.assign(AU.set,JSON.parse(localStorage.getItem(AU_KEY)||'{}'))}catch(e){}
function auSave(){try{localStorage.setItem(AU_KEY,JSON.stringify(AU.set))}catch(e){}if(S){S.audio=Object.assign({},AU.set)}}
function auApply(){if(!AU.ctx)return;const t=AU.ctx.currentTime,s=AU.set;AU.master.gain.setTargetAtTime(s.mute?0:s.master,t,.04);AU.music.gain.setTargetAtTime(s.music*(AU.duck?.15:1),t,.2);AU.sfx.gain.setTargetAtTime(s.sfx,t,.04);AU.ring.gain.setTargetAtTime(s.ring,t,.04)}
function auInit(){
  if(AU.ctx){if(AU.ctx.state==='suspended')AU.ctx.resume();return}
  const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
  try{AU.ctx=new C()}catch(e){return}
  const c=AU.ctx;AU.master=c.createGain();AU.master.connect(c.destination);
  const comp=c.createDynamicsCompressor();comp.threshold.value=-14;comp.ratio.value=4;comp.connect(AU.master);
  AU.music=c.createGain();AU.sfx=c.createGain();AU.ring=c.createGain();
  const lp=c.createBiquadFilter();lp.type='lowpass';lp.frequency.value=2600;AU.music.connect(lp);lp.connect(comp);AU.sfx.connect(comp);AU.ring.connect(comp);
  auApply();AU.next=c.currentTime+.3;AU.step=0;
}
const mtof=m=>440*Math.pow(2,(m-69)/12);
function note(f,t,d,type,v,bus,f2,att){const c=AU.ctx,o=c.createOscillator(),g=c.createGain();o.type=type||'sine';o.frequency.setValueAtTime(f,t);if(f2)o.frequency.exponentialRampToValueAtTime(f2,t+d);
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+(att||.008));g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(bus||AU.sfx);o.start(t);o.stop(t+d+.05)}
const SFX={
  click:t=>note(1250,t,.045,'triangle',.08),
  notify:t=>{note(1047,t,.25,'sine',.09);note(1568,t+.1,.4,'sine',.07)},
  coin:t=>{note(988,t,.08,'square',.05);note(1319,t+.07,.28,'square',.05)},
  cash:t=>{note(196,t,.14,'triangle',.08);note(1568,t+.02,.06,'square',.045);note(2093,t+.08,.24,'square',.045)},
  sponsor:t=>{for(let i=0;i<7;i++){note(988+i*70,t+i*.07,.08,'square',.04);note(1319+i*90,t+i*.07+.04,.2,'square',.035)}[523,659,784,1047].forEach((f,i)=>note(f,t+.6+i*.09,.7,'triangle',.11));note(2093,t+.95,.8,'sine',.05)},
  success:t=>[523,659,784,1047].forEach((f,i)=>note(f,t+i*.08,.4,'triangle',.12)),
  fanfare:t=>{[392,523,659,784].forEach((f,i)=>note(f,t+i*.11,.24,'sawtooth',.045));[523,659,784].forEach(f=>note(f,t+.48,1,'triangle',.09));note(1047,t+.48,1,'sine',.07)},
  offer:t=>{SFX.fanfare(t);for(let i=0;i<5;i++)note(1568+i*200,t+.6+i*.06,.25,'sine',.04)},
  reject:t=>{note(392,t,.22,'triangle',.11);note(330,t+.2,.22,'triangle',.11);note(262,t+.4,.55,'triangle',.11)},
  decline:t=>{note(523,t,.15,'sine',.1);note(392,t+.15,.35,'sine',.1)},
  mission:t=>[784,988,1175,1568].forEach((f,i)=>note(f,t+i*.07,.5,'sine',.1)),
  assign:t=>{note(660,t,.08,'triangle',.1);note(880,t+.08,.08,'triangle',.1);note(1320,t+.16,.32,'triangle',.1)},
  pickup:t=>{note(880,t,.06,'sine',.08);note(1175,t+.07,.12,'sine',.08)},
  hangup:t=>{note(480,t,.12,'sine',.08);note(380,t+.12,.18,'sine',.08)}};
function sfx(n){if(!AU.ctx||AU.ctx.state!=='running')return;const f=SFX[n];if(f)try{f(AU.ctx.currentTime+.01)}catch(e){}}
// realistic telephone ring: 400 + 450 Hz dual tone, double ring cadence (0.4s on, 0.2s off, 0.4s on, 2s off)
function ringBurst(){if(!AU.ctx)return;const c=AU.ctx,t=c.currentTime+.02;const g=c.createGain();g.gain.value=0;g.connect(AU.ring);
  for(const [a,b] of [[0,.4],[.6,1]]){g.gain.setValueAtTime(0,t+a);g.gain.linearRampToValueAtTime(.16,t+a+.02);g.gain.setValueAtTime(.16,t+b-.02);g.gain.linearRampToValueAtTime(0,t+b)}
  for(const f of [400,450]){const o=c.createOscillator();o.type='sine';o.frequency.value=f;o.connect(g);o.start(t);o.stop(t+1.05)}
  const am=c.createOscillator(),ag=c.createGain();am.frequency.value=20;ag.gain.value=.05;am.connect(ag);ag.connect(g.gain);am.start(t);am.stop(t+1.05);
  try{navigator.vibrate&&navigator.vibrate([400,200,400])}catch(e){}}
function ringStart(){ringStop();ringBurst();AU.ringing=setInterval(ringBurst,3000);AU.duck=true;auApply()}
function ringStop(){if(AU.ringing){clearInterval(AU.ringing);AU.ringing=null}AU.duck=false;auApply();try{navigator.vibrate&&navigator.vibrate(0)}catch(e){}}
// background music: soft looping I–V–vi–IV with plucked arpeggio, bass and occasional melody
const PROG=[[60,64,67],[55,59,62],[57,60,64],[53,57,60]],PENT=[72,74,76,79,81,84];
function musTick(){if(!AU.ctx||AU.ctx.state!=='running')return;const c=AU.ctx,spb=60/86/2;if(AU.next<c.currentTime)AU.next=c.currentTime+.05;
  while(AU.next<c.currentTime+.5){const bar=Math.floor(AU.step/8)%4,ch=PROG[bar],s=AU.step%8,t=AU.next;
    if(AU.set.music>0&&!AU.set.mute){if(s===0)for(const n of ch){note(mtof(n-12),t,spb*8,'triangle',.022,AU.music,null,.3);note(mtof(n-12)*1.004,t,spb*8,'sine',.018,AU.music,null,.3)}
      note(mtof(ch[[0,1,2,1,2,0,1,2][s]]+12),t,spb*1.6,'sine',.04,AU.music);
      if(s%4===0)note(mtof(ch[0]-24),t,spb*3.4,'sine',.07,AU.music);
      if(s%2===1&&Math.random()<.32)note(mtof(PENT[(AU.step*7+bar*3)%PENT.length]),t,spb*2.4,'triangle',.03,AU.music)}
    AU.next+=spb;AU.step++}}
setInterval(musTick,150);
const auGesture=()=>{auInit()};['pointerdown','keydown','touchstart'].forEach(ev=>addEventListener(ev,auGesture,{passive:true}));
addEventListener('pointerdown',e=>{const b=e.target.closest&&e.target.closest('button,.nb,.ib,.chip[data-a]');if(b&&!b.disabled){auInit();sfx('click')}},true);
document.addEventListener('visibilitychange',()=>{if(!AU.ctx)return;if(document.hidden)AU.ctx.suspend();else AU.ctx.resume()});
// settings UI
{const st=ACT.settings;ACT.settings=()=>{st();const l=$('#dlg .list');if(!l)return;
  l.insertAdjacentHTML('afterbegin',`<div class="li"><div class="t"><b>🔊 Bunyi & Muzik</b><span>Disimpan bersama permainan anda.</span></div>${B(AU.set.mute?'🔇 Dimatikan':'🔊 Dihidupkan','auMute','',AU.set.mute?'r':'g')}</div>
  <div class="vols">${[['master','Kelantangan Utama'],['music','Muzik Latar'],['sfx','Kesan Bunyi'],['ring','Nada Dering Telefon']].map(([k,lb])=>`<label><span>${lb}</span><input type="range" min="0" max="100" step="5" value="${Math.round(AU.set[k]*100)}" data-vol="${k}" aria-label="${lb}"><b id="vv_${k}">${Math.round(AU.set[k]*100)}%</b></label>`).join('')}
  <div class="row">${B('▶ Uji Kesan Bunyi','auTest','sfx','w')}${B('▶ Uji Nada Dering','auTest','ring','w')}</div></div>`)}}
ACT.auMute=()=>{auInit();AU.set.mute=!AU.set.mute;auApply();auSave();save();closeDlg();ACT.settings();toast(AU.set.mute?'Bunyi dimatikan':'Bunyi dihidupkan')};
ACT.auTest=v=>{auInit();setTimeout(()=>{if(v==='ring'){ringBurst()}else{sfx('coin');setTimeout(()=>sfx('success'),450)}},60)};
document.addEventListener('input',e=>{const k=e.target&&e.target.dataset&&e.target.dataset.vol;if(!k)return;AU.set[k]=(+e.target.value)/100;const b=$('#vv_'+k);if(b)b.textContent=e.target.value+'%';auInit();auApply();auSave();if(S)save()});

// ---------------- WALLET LEDGER
const TXK={tajaan:['Tajaan Mingguan','🎁'],praktikal:['Elaun Praktikal','🎓'],sambilan:['Gaji Sambilan','⏱️'],sepenuh:['Gaji Sepenuh Masa','💼'],beli:['Pembelian & Bil','🛍️'],ganjaran:['Ganjaran Lain','⭐']};
function tx(k,amt,desc){if(!S||!amt)return;(S.tx=S.tx||[]).unshift({k,amt:Math.round(amt*100)/100,desc:desc||TXK[k][0],d:dayIdx(),tm:timeStr()});if(S.tx.length>400)S.tx.length=400}
{const sp=spend;spend=function(n,why){const ok=sp(n,why);if(ok&&n>0)tx('beli',-n,why||'Pembelian');return ok}}
{const am=addMoney;addMoney=function(n,why){am(n,why);if(n>0)tx('ganjaran',n,why||'Ganjaran')}}
{const pb=payBill;payBill=function(amt,why){const b=S.money+S.bank;pb(amt,why);const paid=b-(S.money+S.bank);if(paid>0)tx('beli',-paid,why||'Bil')}}
{const ti=trackInc;trackInc=function(k,n){ti(k,n);if(k==='pt'){tx('sambilan',n,'Gaji kerja sambilan');sfx('cash')}else if(k==='ft'){tx('sepenuh',n,'Gaji kerja sepenuh masa'+(S.job&&S.job.emp?' · '+S.job.emp:''));sfx('cash')}else if(k==='biz')tx('ganjaran',n,'Pendapatan perniagaan')}}
{const cm=checkMissions;checkMissions=function(){if(!S)return cm();const m0=S.money,q0=S.mq;cm();const g=S.money-m0;if(g>0){tx('ganjaran',g,S.mq!==q0?'Ganjaran misi utama':'Ganjaran misi');sfx('mission')}}}
{const gw=grantWelcomeBonus;grantWelcomeBonus=function(){const r=gw();if(r){tx('ganjaran',WELCOME_BONUS,'Bonus pemain baharu');setTimeout(()=>sfx('sponsor'),200)}return r}}

// generic reward pop-up (queued so pop-ups never overlap)
const RQ=[];
function rewardPop(o){RQ.push(o);pumpRewards()}
function pumpRewards(){if(!RQ.length||$('#reward')||$('#call')||$('#game').classList.contains('hide'))return;const o=RQ.shift();const st=$('#stage');const el=document.createElement('div');el.id='reward';el.setAttribute('role','dialog');
  const coins=Array.from({length:16},(_,i)=>`<i class="rc" style="left:${5+i*6}%;animation-delay:${(i%5)*.2}s;animation-duration:${1.8+(i%4)*.3}s"></i>`).join('');
  el.innerHTML=`<div class="rcoins">${coins}</div><div class="rbox"><div class="rrays"></div><div class="rbag" style="font-size:72px;line-height:110px;text-align:center">${o.emo||'💰'}</div>
    <h2>${esc(o.title)}</h2><p>${o.msg}</p><div class="ramt">+RM <span id="rCount">0</span></div>${o.sub?`<small>${o.sub}</small>`:''}<button class="btn g" data-a="rewardOk">${o.btn||'Terima'}</button></div>`;
  st.appendChild(el);RT.paused=true;sfx(o.sound||'sponsor');const t0=performance.now();const tick=t=>{const k=Math.min(1,(t-t0)/1200),c=$('#rCount');if(!c)return;c.textContent=Math.round(o.amt*(1-Math.pow(1-k,3))).toLocaleString('en-MY');if(k<1)requestAnimationFrame(tick)};requestAnimationFrame(tick)}

// ---------------- WEEKLY SPONSORSHIP (RM1,000 every Friday for 5 months)
const SPON_AMT=1000,SPON_MONTHS=5,FRI=4;
function sponEnd(start){const t=dateOf(start);let d=start;for(let i=0;i<SPON_MONTHS;i++)d+=MDAYS[(t.m-1+i)%12];return d}
function sponFridays(sp){const out=[];for(let d=sp.start;d<sp.end;d++)if(d%7===FRI)out.push(d);return out}
function sponActivate(){if(!S||S.spon)return;const d=dayIdx();S.spon={id:'TAJ-'+(S.pid||'KK'),name:'Program Tajaan Belia Kota Kita',start:d,end:sponEnd(d),paid:[],total:0};
  addMsg('Yayasan Belia Kota Kita','Tajaan Mingguan Diluluskan!',`Tahniah! Anda layak menerima Tajaan Belia Kota Kita: ${fmt(SPON_AMT)} setiap hari Jumaat selama ${SPON_MONTHS} bulan (${dateStr(d)} – ${dateStr(S.spon.end-1)}). Bayaran dimasukkan terus ke dompet anda.`);
  notify(`Tajaan mingguan diaktifkan: ${fmt(SPON_AMT)} setiap Jumaat selama ${SPON_MONTHS} bulan`);save()}
function sponNext(sp){const today=dayIdx();return sponFridays(sp).find(d=>d>=today&&!sp.paid.some(p=>p.d===d))}
function sponCheck(){if(!S||!S.spon)return 0;const sp=S.spon,today=dayIdx();let n=0;
  for(const d of sponFridays(sp)){if(d>today)break;if(sp.paid.some(p=>p.d===d))continue;sp.paid.push({d,amt:SPON_AMT});sp.total+=SPON_AMT;S.money+=SPON_AMT;tx('tajaan',SPON_AMT,`Tajaan mingguan #${sp.paid.length} · ${dateStr(d)}`);n++}
  if(n){save();hud();const tot=fmt(SPON_AMT*n);notify(`TAHNIAH! Anda telah menerima tajaan mingguan sebanyak ${tot}!`);
    addMsg('Yayasan Belia Kota Kita','Tajaan mingguan diterima',`TAHNIAH! Anda telah menerima tajaan mingguan sebanyak ${tot}! Jumlah diterima setakat ini: ${fmt(sp.total)} (${sp.paid.length}/${sponFridays(sp).length} bayaran).`);
    rewardPop({emo:'🎁',title:'TAJAAN MINGGUAN!',msg:`TAHNIAH! Anda telah menerima tajaan mingguan sebanyak <b>${tot}</b>!`,amt:SPON_AMT*n,sub:`Bayaran ${sp.paid.length} daripada ${sponFridays(sp).length} · ${sponNext(sp)!=null?'Bayaran seterusnya: '+dateStr(sponNext(sp)):'Ini bayaran terakhir program'}`,sound:'sponsor'})}
  if(!sp.ended&&today>=sp.end){sp.ended=true;addMsg('Yayasan Belia Kota Kita','Program tajaan tamat',`Program tajaan ${SPON_MONTHS} bulan anda telah tamat. Jumlah diterima: ${fmt(sp.total)}. Terima kasih!`);notify('Program tajaan mingguan telah tamat.');save()}
  return n}

// ---------------- STUDENT RULE: no full-time employment while enrolled
const STUDENT_MSG='Anda masih berstatus pelajar. Anda hanya boleh bekerja secara part-time sehingga tamat pengajian.';
const fullStudent=()=>!!(S&&S.edu);
function studentBlock(){sfx('decline');showDlg({title:'Status Pelajar',body:`<p>${STUDENT_MSG}</p><div class="note">Anda masih boleh bekerja sambilan, menghadiri kelas, menyiapkan tugasan, menduduki peperiksaan, menyertai aktiviti kampus dan menjalani latihan praktikal.</div>`,buttons:[{label:'Kerja Sambilan',cls:'g',a:'goPanel',v:'kerjaya:pt'},{label:'Okey',cls:'w',a:'closeDlg'}]})}
for(const k of ['vApply','jSubmit','applyFT']){const f=ACT[k];if(f)ACT[k]=v=>{if(fullStudent())return studentBlock();return f(v)}}
{const r=PANELS.kerjaya.render;PANELS.kerjaya.render=t=>{let h=r(t);if(fullStudent()&&(t==='vac'||t==='ft'))h=`<div class="note y" style="margin-bottom:10px"><b>🎓 ${STUDENT_MSG}</b></div>`+h.replace(/data-a="vApply"/g,'data-a="vApply" disabled').replace(/data-a="applyFT"/g,'data-a="applyFT" disabled');
  if(t==='pt'&&fullStudent())h=`<div class="note g" style="margin-bottom:10px">🎓 Pelajar dibenarkan bekerja sambilan dan memperoleh pendapatan part-time.</div>`+h;return h}}
// enrolling while employed: full-time job goes on unpaid study leave (never deleted)
{const ao=ACT.acceptOffer;ACT.acceptOffer=v=>{if(S.job&&!S.job.leave){confirmDlg('Cuti belajar?',`<p>Pelajar sepenuh masa tidak boleh bekerja sepenuh masa. Jawatan anda akan digantung (cuti belajar tanpa gaji) sehingga anda tamat pengajian.</p>`,'Teruskan Mendaftar',()=>{S.job.leave=true;ao(v);eduUid()});return}ao(v);eduUid()}}
{const gr=graduate;graduate=function(){gr();if(S.job&&S.job.leave){delete S.job.leave;addMsg(S.job.emp||'Majikan','Selamat kembali bekerja',`Cuti belajar anda tamat. Anda boleh kembali bekerja sebagai ${occupation()}.`)}
  addMsg('Pusat Kerjaya','Status: Graduan','Tahniah! Status anda kini Graduan. Permohonan kerja sepenuh masa, resume dan temu duga kini dibuka di Pusat Kerjaya.');notify('Status kini Graduan — kerja sepenuh masa dibuka');sfx('fanfare')}}
{const fw=ACT.ftWork;ACT.ftWork=()=>{if(!S.job)return fw();if(S.job.leave||fullStudent())return studentBlock();if(S.job.startDay!=null&&dayIdx()<S.job.startDay){toast(`Hari pertama kerja anda: ${dateStr(S.job.startDay)}.`,'y');return}fw()}}
{const fs=ftSalary;ftSalary=function(){const b=fs();if(!(S.job&&S.job.offer))return b;return S.job.lvl===0?S.job.offer:Math.max(b,S.job.offer)}}
function eduUid(){if(S.edu&&!S.edu.uid)S.edu.uid='E'+dayIdx().toString(36)+Math.random().toString(36).slice(2,6)}

// ---------------- SEMESTER PRACTICAL TRAINING (1 month, RM500 once per semester)
const PRAC_DAYS=30,PRAC_NEED=8,PRAC_PAY=500;
const PLACEMENTS=[['hosp','Hospital Kota Kita','hospital',['med','nurse','sport']],['klinik','Klinik Kesihatan','klinik',['med','nurse']],
 ['jkr','Jabatan Kerajaan (Pejabat Kerajaan)','pejabat',['eng','arch','env','law','com','acc','bus','edu']],['bank','Bank Kota Kita','bandar',['acc','bus','ai']],
 ['itco','Syarikat IT TechNusa','bandar',['it','cs','ai','art','com']],['engco','Syarikat Kejuruteraan Jaya','pelabuhan',['eng','arch']],
 ['corp','Syarikat Swasta (Asia Mall)','mall',['bus','acc','com','art','tour']],['school','Sekolah Menengah Kota Kita','sekolah',['edu','sport']],
 ['hotel','Hotel & Resort Pulau','pulau',['hosp','tour','culi']],['resto','Dapur Medan Selera','medan',['culi','hosp']],
 ['farm','Ladang Agro Kota Kita','ladang',['agri','env']],['fishery','Jabatan Perikanan (Jeti)','jeti',['fish','env']],
 ['police','Balai Polis — Unit Perundangan','polis',['law']],['stadium','Kompleks Sukan','stadium',['sport']],['library','Perpustakaan Awam','perpustakaan',['edu','com','art']]];
const PLACE=Object.fromEntries(PLACEMENTS.map(p=>[p[0],{id:p[0],name:p[1],loc:p[2],courses:p[3]}]));
const pracKey=e=>(e.uid||'E')+'-S'+e.sem;
function pracOf(){const e=S.edu;if(!e)return null;eduUid();if(e.prac&&e.prac.sem!==e.sem)e.prac=null;return e.prac}
const pracPaid=e=>(S.pracRec||[]).some(r=>r.key===pracKey(e));
function pracDone(){const e=S.edu;if(!e)return true;const p=pracOf();return !!(p&&p.done)||pracPaid(e)}
ACT.pracPick=id=>{const e=S.edu,P=PLACE[id];if(!e||!P||pracOf())return;if(!P.courses.includes(e.course)){toast('Penempatan ini tidak sesuai dengan bidang anda.','r');return}
  confirmDlg('Sahkan penempatan praktikal',`<p><b>${esc(P.name)}</b> · ${esc(LOC[P.loc].name)}</p><p>Tempoh: ${dateStr(dayIdx())} – ${dateStr(dayIdx()+PRAC_DAYS-1)} (1 bulan). Hadir sekurang-kurangnya ${PRAC_NEED} hari (6 jam sehari) di lokasi penempatan.</p><div class="note g">Elaun praktikal ${fmt(PRAC_PAY)} dibayar SEKALI apabila latihan semester ini selesai.</div>`,'Mula Praktikal',()=>{
    e.prac={sem:e.sem,place:id,start:dayIdx(),end:dayIdx()+PRAC_DAYS,sessions:0,need:PRAC_NEED,log:[],done:false};addMsg(P.name,'Surat Penempatan Latihan Praktikal',`Anda ditempatkan di ${P.name} untuk latihan praktikal Semester ${e.sem} dari ${dateStr(e.prac.start)} hingga ${dateStr(e.prac.end-1)}. Sila lapor diri di ${LOC[P.loc].name}.`);sfx('success');rerender()})};
ACT.pracGo=()=>{const p=pracOf();if(!p||p.done)return;const P=PLACE[p.place],d=dayIdx();if(p.log.includes(d)){toast('Anda sudah hadir latihan praktikal hari ini.','y');return}const h=hourNow();if(h<7||h>=18){toast('Latihan praktikal antara 7:00 pg – 6:00 ptg.','y');return}
  needAt(P.loc,()=>{if(!useEnergy(20))return;advance(360);p.sessions++;p.log.push(d);stat('akademik',1);stat('karisma',1);addXP(30);S.cnt.prac=(S.cnt.prac||0)+1;sfx('assign');toast(`Latihan praktikal hari ke-${p.sessions} selesai (${p.sessions}/${p.need})`,'g');pracCheck();rerender()},'Pergi latihan praktikal di')};
function pracCheck(){const e=S&&S.edu;if(!e)return;const p=pracOf();if(!p||p.done)return;if(p.sessions<p.need||dayIdx()<p.end)return;
  p.done=true;p.doneDay=dayIdx();const key=pracKey(e);S.pracRec=S.pracRec||[];const P=PLACE[p.place];
  if(S.pracRec.some(r=>r.key===key))return;
  S.pracRec.push({key,inst:e.inst,level:e.level,course:e.course,sem:e.sem,place:p.place,start:p.start,end:p.end,days:p.sessions,done:dayIdx(),allowance:PRAC_PAY});
  S.money+=PRAC_PAY;tx('praktikal',PRAC_PAY,`Elaun praktikal Semester ${e.sem} · ${P.name}`);save();hud();addXP(80);
  const m='TAHNIAH! Anda telah menerima elaun praktikal sebanyak RM500 kerana berjaya menyelesaikan latihan praktikal semester ini.';
  notify(m);addMsg(P.name,'Latihan praktikal selesai',m);sfx('fanfare');
  rewardPop({emo:'🎓',title:'LATIHAN PRAKTIKAL SELESAI!',msg:m,amt:PRAC_PAY,sub:`${esc(P.name)} · Semester ${e.sem} · ${p.sessions} hari hadir`,sound:'coin'})}
{const ue=ACT.uniExam;ACT.uniExam=()=>{const e=S.edu;if(e&&!pracDone()){sfx('decline');const p=pracOf();showDlg({title:'Latihan Praktikal Wajib',body:`<p>Setiap semester termasuk latihan praktikal wajib selama 1 bulan. Selesaikan latihan praktikal Semester ${e.sem} sebelum menduduki peperiksaan akhir.</p>${p?`<div class="note">Kemajuan: ${p.sessions}/${p.need} hari hadir · tamat ${dateStr(p.end-1)}</div>`:''}`,buttons:[{label:'Latihan Praktikal',cls:'g',a:'goPanel',v:'pendidikan:praktikal'},{label:'Okey',cls:'w',a:'closeDlg'}]});return}ue()}}
{const i=PANELS.pendidikan.tabs.findIndex(t=>t[0]==='kuliah');PANELS.pendidikan.tabs.splice(i+1,0,['praktikal','Latihan Praktikal'])}
{const r=PANELS.pendidikan.render;PANELS.pendidikan.render=t=>{
  if(t==='praktikal')return pracRender();let h=r(t);
  if(t==='kuliah'&&S.edu&&!pracDone())h=h.replace('data-a="uniExam"','data-a="uniExam" title="Selesaikan latihan praktikal dahulu"')+`<div class="note y" style="margin-top:10px">🏥 Latihan praktikal Semester ${S.edu.sem} belum selesai — wajib sebelum peperiksaan akhir. ${B('Latihan Praktikal','goPanel','pendidikan:praktikal','y')}</div>`;
  if(t==='kuliah'&&S.edu&&pracDone())h+=`<div class="note g" style="margin-top:10px">✓ Latihan praktikal Semester ${S.edu.sem} selesai.</div>`;
  return h}}
function pracRender(){const e=S.edu,rec=(S.pracRec||[]).slice().reverse();
  const hist=rec.length?`<div class="sec">Rekod latihan praktikal</div><div class="list">${rec.map(r=>`<div class="li"><span class="emo">🎓</span><div class="t"><b>Semester ${r.sem} · ${esc((PLACE[r.place]||{}).name||r.place)}</b><span>${COURSE[r.course]||''} · ${dateStr(r.start)} – ${dateStr(r.end-1)} · ${r.days} hari hadir · selesai ${dateStr(r.done)}</span></div><b style="color:var(--grn2)">+${fmt(r.allowance)}</b></div>`).join('')}</div>`:'';
  if(!e)return`<div class="note">Latihan praktikal dibuka apabila anda mendaftar sebagai pelajar di universiti atau kolej.</div>${hist}`;
  const p=pracOf(),d=dayIdx();let cur;
  if(pracPaid(e))cur=`<div class="card on"><h4>✓ Latihan praktikal Semester ${e.sem} selesai</h4><p>Elaun ${fmt(PRAC_PAY)} telah diterima untuk semester ini. Semester seterusnya mempunyai kelayakan elaun yang baharu.</p></div>`;
  else if(!p){const opts=PLACEMENTS.filter(x=>x[3].includes(e.course));
    cur=`<div class="note" style="margin-bottom:10px">Setiap semester mempunyai <b>latihan praktikal wajib selama 1 bulan</b>. Pilih penempatan yang sesuai dengan bidang <b>${COURSE[e.course]}</b>. Hadir sekurang-kurangnya ${PRAC_NEED} hari dalam tempoh tersebut. Elaun <b>${fmt(PRAC_PAY)}</b> dibayar <b>sekali</b> apabila selesai.</div>
    <div class="grid w">${opts.map(x=>`<div class="card"><h4>${esc(x[1])}</h4><p>📍 ${esc(LOC[x[2]].name)}</p><div class="kv"><span>Tempoh</span><b>1 bulan (${PRAC_DAYS} hari)</b><span>Kehadiran</span><b>${PRAC_NEED} hari × 6 jam</b><span>Elaun</span><b>${fmt(PRAC_PAY)} (sekali)</b></div>${B('Pilih Penempatan','pracPick',x[0],'g')}</div>`).join('')}</div>`}
  else{const P=PLACE[p.place],left=Math.max(0,p.end-d),att=p.log.includes(d);
    cur=`<div class="card on"><h4>Latihan Praktikal Semester ${e.sem}</h4><p>${esc(P.name)} · 📍 ${esc(LOC[P.loc].name)}</p>
    <div class="kv"><span>Tempoh</span><b>${dateStr(p.start)} – ${dateStr(p.end-1)}</b><span>Baki hari</span><b>${left} hari</b><span>Kehadiran</span><b>${p.sessions}/${p.need} hari</b><span>Elaun</span><b>${fmt(PRAC_PAY)} apabila selesai</b></div>
    <div class="stat">Kehadiran<div class="bar"><i style="width:${pct(p.sessions,p.need)}%"></i></div></div><div class="stat">Tempoh<div class="bar"><i style="width:${pct(d-p.start,PRAC_DAYS)}%"></i></div></div>
    <div class="row">${B(att?'✓ Sudah hadir hari ini':'Hadir Latihan (6 jam)','pracGo','','g',att||p.sessions>=p.need)}</div>
    ${p.sessions>=p.need&&left>0?`<div class="note g">Kehadiran mencukupi! Latihan tamat pada ${dateStr(p.end)} dan elaun akan dikreditkan.</div>`:''}</div>`}
  return cur+hist}

// ---------------- JOB OFFER BY PHONE CALL
JSTAT.penilaian=['Penilaian Majikan','y'];
ACT.jInterview=id=>{const a=S.japps.find(x=>x.id===id),d=dayIdx(),h=hourNow();if(!a||a.status!=='temuduga')return;if(fullStudent())return studentBlock();
  if(d<a.iday){toast(`Temu duga pada ${dateStr(a.iday)}.`,'y');return}if(h<9||h>=17){toast('Temu duga antara 9:00 pg – 5:00 ptg.','y');return}
  needAt(a.loc,()=>{startQuiz(`Temu Duga: ${a.title} (${a.emp})`,4,sc=>{advance(90);S.cnt.interview=(S.cnt.interview||0)+1;const formal=['formal','kerja'].includes(OUT[S.look.outfit].cat);
    const p=clamp(.2+sc*.5+(a.score||.4)*.35+(formal?.07:0),.05,.95);a.iscore=Math.round(sc*100);a.status='penilaian';a.result=Math.random()<p?'lulus':'gagal';a.callAt=S.time+150;
    sfx('notify');showDlg({title:'Temu duga selesai',body:`<p>Skor temu duga: <b>${a.iscore}%</b>${formal?' · berpakaian kemas ✓':''}</p><p>Panel ${esc(a.emp)} sedang menilai prestasi anda. Majikan akan <b>menghubungi anda melalui telefon</b> dalam beberapa jam.</p>`,buttons:[{label:'Okey',cls:'g',a:'closeDlg'}]});rerender()},INTERVIEW)},'Pergi temu duga di')};
function offerSalary(a){const v=a.v,k=clamp((a.score||.4)*.6+(a.iscore||50)/100*.4,0,1);return Math.round((v.smin+(v.smax-v.smin)*k*.7)/50)*50}
function startMonday(){let d=dayIdx()+2;while(d%7!==0)d++;return d}
function callResolve(a){if(a.result==='lulus'){a.status='tawaran';a.until=dayIdx()+3;a.offer=offerSalary(a);a.startDay=startMonday();notify(`Panggilan masuk daripada ${a.emp}`);incomingCall(a)}
  else{a.status='ditolak';a.note=`Skor temu duga ${a.iscore}% — calon lain dipilih`;addMsg(a.emp,'Keputusan Temu Duga',`Terima kasih kerana menghadiri temu duga jawatan ${a.title}. Dukacita dimaklumkan permohonan anda tidak berjaya. Anda boleh memohon jawatan kosong lain di Pusat Kerjaya.`);notify(`Permohonan ${a.title} tidak berjaya`);toast(`${a.emp}: permohonan tidak berjaya. Cuba jawatan lain!`,'r');sfx('reject');rerender()}save()}
const PHONE_SVG='<svg viewBox="0 0 24 24"><path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1C10.6 21 3 13.4 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1z" fill="#fff"/></svg>';
function incomingCall(a){const old=$('#call');if(old)old.remove();if(SH&&SH.id)closeSheet();
  const ini=a.emp.split(/\s+/).filter(w=>/^[A-Z]/.test(w)).slice(0,2).map(w=>w[0]).join('')||'HR';const el=document.createElement('div');el.id='call';el.dataset.id=a.id;el.setAttribute('role','dialog');el.setAttribute('aria-label','Panggilan masuk');
  el.innerHTML=`<div class="cph"><div class="cst">📞 INCOMING CALL · PANGGILAN MASUK</div><div class="cav"><span>${esc(ini)}</span><i></i><i class="r2"></i></div><h3>${esc(a.emp)}</h3><p class="sub">Jabatan Sumber Manusia · +60 3-${(7000+(a.id.charCodeAt(1)*37)%2999)}-${(1000+(a.id.length*911)%8999)}</p>
    <div class="cbody" id="callBody"><p class="ctime">Memanggil…</p></div><div class="cbtns" id="callBtns"><button class="cb red" data-a="callDecline" aria-label="Tolak panggilan"><i class="hang">${PHONE_SVG}</i>Tolak</button><button class="cb grn" data-a="callAnswer" aria-label="Jawab panggilan"><i>${PHONE_SVG}</i>Answer Call</button></div></div>`;
  $('#stage').appendChild(el);RT.paused=true;auInit();ringStart()}
function callEnd(){ringStop();const el=$('#call');if(el){clearInterval(+el.dataset.tm||0);el.classList.add('out');setTimeout(()=>el.remove(),250)}RT.paused=!!(DLG||(SH&&SH.id));setTimeout(pumpRewards,400)}
const callApp=()=>{const el=$('#call');return el&&S.japps.find(x=>x.id===el.dataset.id)};
ACT.callAnswer=()=>{const a=callApp();if(!a)return callEnd();ringStop();sfx('pickup');setTimeout(()=>sfx('offer'),350);const J=FT_JOBS.find(j=>j[0]===a.job),el=$('#call');el.classList.add('live');let s=0;
  el.dataset.tm=setInterval(()=>{s++;const t=$('#call .ctime');if(t)t.textContent=`Dalam panggilan · ${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`},1000);
  $('#callBody').innerHTML=`<p class="ctime">Dalam panggilan · 00:00</p><p class="ok">Congratulations! Your job application has been successful.</p><p style="margin:0 0 8px;opacity:.9">"Tahniah! Kami ingin menawarkan anda jawatan ini."</p>
    <div class="ckv"><span>Syarikat</span><b>${esc(a.emp)}</b><span>Jawatan</span><b>${esc(J[8][0])} (${esc(a.title)})</b><span>Gaji bulanan</span><b>${fmt(a.offer)}</b><span>Waktu kerja</span><b>${esc(J[6])}</b><span>Lokasi</span><b>${esc(LOC[a.loc].name)}</b><span>Tarikh mula</span><b>${dateStr(a.startDay)}</b></div>`;
  $('#callBtns').outerHTML=`<div class="cacts"><button class="btn g" data-a="callAccept">✓ Accept Job Offer · Terima</button><button class="btn r" data-a="callReject">✕ Reject Offer · Tolak</button><button class="btn w" data-a="callLater">Fikir dahulu<span class="lt"> (jawab sebelum ${dateStr(a.until)})</span></button></div>`};
ACT.callDecline=()=>{const a=callApp();callEnd();sfx('hangup');if(a){a.missed=true;notify(`Panggilan tidak dijawab daripada ${a.emp}`);addMsg(a.emp,'Panggilan tidak dijawab',`Kami cuba menghubungi anda berkenaan jawatan ${a.title}. Sila jawab tawaran sebelum ${dateStr(a.until)} melalui Pusat Kerjaya → Permohonan Saya.`);toast('Panggilan tidak dijawab. Tawaran disimpan di Permohonan Saya.','y')}save();rerender()};
ACT.callLater=()=>{const a=callApp();callEnd();sfx('hangup');if(a)toast(`Jawab tawaran sebelum ${dateStr(a.until)} di Permohonan Saya.`,'y');rerender()};
ACT.callReject=()=>{const a=callApp();callEnd();if(a){a.status='ditarik';a.note='Tawaran ditolak';sfx('decline');addMsg(a.emp,'Tawaran ditolak',`Anda telah menolak tawaran jawatan ${a.title}. Semoga berjaya!`);toast('Tawaran kerja ditolak.')}save();rerender()};
ACT.callAccept=()=>{const a=callApp();callEnd();if(a)acceptJob(a)};
function acceptJob(a){if(!a||a.status!=='tawaran')return;if(fullStudent()){a.note='Masih pelajar';return studentBlock()}
  const J=FT_JOBS.find(j=>j[0]===a.job);
  const go=()=>{if(S.job){const OJ=FT_JOBS.find(j=>j[0]===S.job.id);S.exp.push({title:OJ[8][S.job.lvl]+' ('+OJ[1]+')',emp:S.job.emp||'—',years:Math.round(S.job.shifts/250*10)/10,type:'Sepenuh masa'})}
    const sd=a.startDay!=null?a.startDay:dayIdx();a.offer=a.offer||offerSalary(a);
    S.job={id:a.job,lvl:0,shifts:0,perfSum:0,start:sd,startDay:sd,inc:0,emp:a.emp,offer:a.offer,loc:a.loc};a.status='diterima';S.workLoc=a.loc;addXP(100);S.stage=S.stage==='graduan'||!S.stage?'bekerja':S.stage;
    addMsg(a.emp,'Surat Lantikan Rasmi',`Tahniah! Anda dilantik sebagai ${J[8][0]} di ${a.emp}. Gaji bulanan ${fmt(a.offer)}. Waktu kerja: ${J[6]}. Hari pertama bekerja: ${dateStr(sd)} di ${LOC[a.loc].name}.`);
    notify(`Status: Bekerja — ${J[8][0]}, ${a.emp}`);sfx('fanfare');checkAch();save();
    showDlg({title:'Selamat datang ke pasukan! 🎉',body:`<div class="kv"><span>Status</span><b>Bekerja sepenuh masa</b><span>Jawatan</span><b>${esc(J[8][0])}</b><span>Majikan</span><b>${esc(a.emp)}</b><span>Gaji bulanan</span><b>${fmt(a.offer)}</b><span>Waktu kerja</span><b>${esc(J[6])}</b><span>Hari pertama</span><b>${dateStr(sd)}</b><span>Tempat kerja</span><b>${esc(LOC[a.loc].name)}</b></div><div class="note g">Tempat kerja anda kini ditanda 💼 di peta. Gaji harian dibayar ke bank selepas setiap syif.</div>`,buttons:[{label:'Status Kerja',cls:'w',a:'goPanel',v:'kerjaya:status'},{label:'Hebat!',cls:'g',a:'closeDlg'}]});rerender()};
  if(S.job&&!S.job.leave)confirmDlg('Tukar kerja?','<p>Anda akan meletak jawatan semasa. Pengalaman akan direkodkan dalam resume.</p>','Terima',go);else go()}
ACT.jAccept=id=>{if(fullStudent())return studentBlock();acceptJob(S.japps.find(x=>x.id===id))};
{const jd=ACT.jDecline;ACT.jDecline=id=>{jd(id);sfx('decline')}}
// sounds for application progress
{const jn=jappNewDay;jappNewDay=function(d){const before=Object.fromEntries((S.japps||[]).map(a=>[a.id,a.status]));jn(d);for(const a of S.japps||[]){const b=before[a.id];if(b===a.status)continue;if(a.status==='temuduga'){sfx('success');toast(`${a.emp}: anda disenarai pendek untuk temu duga!`,'g')}else if(a.status==='ditolak'){sfx('reject');toast(`${a.emp}: permohonan tidak berjaya.`,'r')}}}}

// ---------------- workplace pin on the world map
{const dw=render;render=function(){dw();if(!S||!S.job||S.job.leave)return;const jl=S.job.loc||(FT_JOBS.find(j=>j[0]===S.job.id)||[])[7];const b=BLDS.find(x=>x.loc===jl);if(!b)return;
  const k=RT.k,cx=RT.cam.x,cy=RT.cam.y;
  const tm=performance.now()/1000,a0=tw(b.x+b.w/2,b.y+b.h/2),wx=a0[0],wy=a0[1]-bldTop(b)*.62+Math.sin(tm*3)*3/RT.zoom;const x=(wx-cx)*k,y=(wy-cy)*k;if(x<-200||y<-80||x>cv.width+200||y>cv.height+80)return;
  ctx.save();ctx.setTransform(RT.dpr,0,0,RT.dpr,0,0);const X=x/RT.dpr,Y=y/RT.dpr-34;ctx.font='900 11px Nunito,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';const t='💼 TEMPAT KERJA ANDA',w=ctx.measureText(t).width+20;
  const p=new Path2D();rrp(p,X-w/2,Y-11,w,22,11);const g=ctx.createLinearGradient(X-w/2,0,X+w/2,0);g.addColorStop(0,'#9a5cf5');g.addColorStop(1,'#e0457b');ctx.fillStyle=g;ctx.shadowColor='rgba(80,30,140,.4)';ctx.shadowBlur=8;ctx.fill(p);ctx.shadowBlur=0;ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.stroke(p);
  ctx.fillStyle='#e0457b';ctx.beginPath();ctx.moveTo(X-6,Y+10);ctx.lineTo(X+6,Y+10);ctx.lineTo(X,Y+18);ctx.fill();ctx.fillStyle='#fff';ctx.fillText(t,X,Y+.5);ctx.restore()}}

// ---------------- WALLET PANEL
ICON.dompet='<svg viewBox="0 0 48 48"><defs><linearGradient id="dpG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff8cc6"/><stop offset="1" stop-color="#9a5cf5"/></linearGradient></defs><rect x="6" y="13" width="36" height="26" rx="6" fill="url(#dpG)"/><path d="M10 13l20-6 3 6" fill="#ffd23f"/><rect x="28" y="21" width="14" height="10" rx="4" fill="#fff"/><circle cx="34" cy="26" r="2.4" fill="#9a5cf5"/></svg>';
MORE.unshift(['dompet','Dompet & Tajaan']);
PANELS.dompet={title:'Dompet & Rekod Kewangan',tabs:[['ringkasan','Ringkasan'],['tajaan','Tajaan Mingguan'],['praktikal','Elaun Praktikal'],['transaksi','Transaksi']],render(t,arg){
  const T=S.tx||[];const sum=k=>T.filter(x=>x.k===k).reduce((a,b)=>a+b.amt,0);
  if(t==='ringkasan')return`<div class="grid w"><div class="card on"><h4>Baki</h4><div class="kv"><span>Dompet</span><b>${fmt(S.money)}</b><span>Bank</span><b>${fmt(S.bank)}</b><span>Jumlah</span><b>${fmt(S.money+S.bank)}</b></div></div>
    <div class="card"><h4>Jumlah mengikut kategori</h4><div class="kv">${Object.entries(TXK).map(([k,v])=>`<span>${v[1]} ${v[0]}</span><b style="color:${sum(k)<0?'var(--red)':'var(--grn2)'}">${sum(k)<0?'−':'+'}${fmt(Math.abs(sum(k)))}</b>`).join('')}</div></div></div>
    <p style="font-size:12px;color:var(--mut)">Semua jumlah ialah mata wang maya dalam permainan.</p>`;
  if(t==='tajaan'){const sp=S.spon;if(!sp)return'<div class="note">Tiada program tajaan aktif.</div>';const F=sponFridays(sp),nx=sponNext(sp),d=dayIdx(),active=d<sp.end;
    return`<div class="card on"><h4>🎁 ${esc(sp.name)}</h4><div class="kv"><span>Status</span><b style="color:${active?'var(--grn2)':'var(--mut)'}">${active?'Aktif':'Tamat'}</b><span>Amaun</span><b>${fmt(SPON_AMT)} setiap Jumaat</b><span>Tempoh</span><b>${dateStr(sp.start)} – ${dateStr(sp.end-1)} (${SPON_MONTHS} bulan)</b><span>Diterima</span><b>${fmt(sp.total)} (${sp.paid.length}/${F.length} bayaran)</b><span>Bayaran seterusnya</span><b>${nx!=null?dateStr(nx):'—'}</b><span>Baki tempoh</span><b>${active?`${sp.end-d} hari · ${F.length-sp.paid.length} bayaran lagi`:'Program tamat'}</b></div>
      <div class="stat">Kemajuan<div class="bar"><i style="width:${pct(sp.paid.length,F.length)}%"></i></div></div></div>
      <div class="sec">Sejarah bayaran</div>${sp.paid.length?`<div class="list">${sp.paid.slice().reverse().map((p,i)=>`<div class="li"><span class="emo">🎁</span><div class="t"><b>Bayaran #${sp.paid.length-i}</b><span>${dateStr(p.d)}</span></div><b style="color:var(--grn2)">+${fmt(p.amt)}</b></div>`).join('')}</div>`:'<div class="note">Bayaran pertama pada hari Jumaat.</div>'}`}
  if(t==='praktikal')return pracRender();
  const f=arg||'semua';const L=T.filter(x=>f==='semua'||x.k===f);
  return`<div class="tabs" style="margin-bottom:10px;flex-wrap:wrap">${[['semua','Semua']].concat(Object.entries(TXK).map(([k,v])=>[k,v[0]])).map(([k,l])=>`<button class="${f===k?'on':''}" data-a="txF" data-v="${k}">${l}</button>`).join('')}</div>
    ${L.length?`<div class="list">${L.slice(0,150).map(x=>`<div class="li"><span class="emo">${TXK[x.k][1]}</span><div class="t"><b>${esc(x.desc)}</b><span>${TXK[x.k][0]} · ${dateStr(x.d)} · ${x.tm}</span></div><b style="color:${x.amt<0?'var(--red)':'var(--grn2)'}">${x.amt<0?'−':'+'}${fmt2(Math.abs(x.amt))}</b></div>`).join('')}</div>`:'<div class="note">Tiada transaksi.</div>'}`}};
ACT.txF=v=>openPanel('dompet','transaksi',v);
{const ch=$('#hMoney')&&$('#hMoney').closest('.chip');if(ch){ch.dataset.a='nav';ch.dataset.v='dompet';ch.style.cursor='pointer';ch.title='Dompet & Tajaan'}}

// ---------------- lifecycle hooks
{const nd=newDay;newDay=function(){nd();sponCheck();pracCheck()}}
{const mg=migrate;migrate=function(...a){const r=mg.apply(this,a);if(S){S.tx=S.tx||[];S.pracRec=S.pracRec||[];if(S.audio){Object.assign(AU.set,S.audio)}if(S.edu){eduUid();if(S.job&&!S.job.leave){S.job.leave=true;addMsg('Pusat Kerjaya','Cuti belajar',`${STUDENT_MSG} Jawatan sepenuh masa anda digantung sehingga tamat pengajian.`)}}}return r}}
{const ns=newSave;newSave=function(...a){const r=ns.apply(this,a);S.tx=[];S.pracRec=[];S.audio=Object.assign({},AU.set);return r}}
{const sg=startGame;startGame=function(fresh){sg(fresh);setTimeout(()=>{if(!S)return;if(!S.spon)sponActivate();sponCheck();if(S.edu)eduUid()},fresh?900:600)}}
// watcher: interview call-backs, queued pop-ups, assignment sound
let _lastAssign=null;
setInterval(()=>{if(!S||$('#game').classList.contains('hide'))return;
  if(!$('#call')&&!$('#reward')&&!DLG&&!(SH&&SH.id)&&!RT.homing){const a=(S.japps||[]).find(x=>x.status==='penilaian'&&S.time>=x.callAt);if(a)callResolve(a)}
  pumpRewards();
  const as=S.edu&&S.edu.assign!=null?S.edu.sem+':'+S.edu.assign:null;if(as&&as!==_lastAssign&&_lastAssign!==undefined)sfx('assign');_lastAssign=as},700);
