// ===================== CHIBI RENDERER =====================
const TAU=Math.PI*2;
function shade(hex,a){
  if(!hex||hex[0]!=='#')return hex;
  let n=parseInt(hex.slice(1),16),r=n>>16,g=(n>>8)&255,b=n&255;
  if(a<0){r*=1+a;g*=1+a;b*=1+a}else{r+=(255-r)*a;g+=(255-g)*a;b+=(255-b)*a}
  const h=v=>Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,'0');
  return '#'+h(r)+h(g)+h(b);
}
function rrp(p,x,y,w,h,r){r=Math.min(r,w/2,h/2);p.moveTo(x+r,y);p.arcTo(x+w,y,x+w,y+h,r);p.arcTo(x+w,y+h,x,y+h,r);p.arcTo(x,y+h,x,y,r);p.arcTo(x,y,x+w,y,r);p.closePath();return p}
function fillP(ctx,p,c,lw){ctx.fillStyle=c;ctx.fill(p);if(lw!==0){ctx.strokeStyle=shade(c,-.42);ctx.lineWidth=lw||1.1;ctx.stroke(p)}}
function seeded(n){let s=n*9301+49297;return()=>{s=(s*9301+49297)%233280;return s/233280}}

const STYLE={
 casual:{top:-20,bot:'pants'},skirt:{top:-22,bot:'skirt'},dress:{one:1,end:-3},uniform:{top:-21,bot:'pants'},
 kurung:{top:-11,bot:'skirt'},pinafore:{top:-22,bot:'pina'},sport:{top:-21,bot:'shorts'},nurse:{top:-16,bot:'pants'},
 labcoat:{top:-22,bot:'pants',coat:-9},chef:{top:-20,bot:'pants'},office:{top:-23,bot:'pants'},apron:{top:-21,bot:'pants'},
 blazer:{top:-20,bot:'pants'},suit:{top:-20,bot:'pants'},gown:{one:1,end:-1,flare:8},bajumelayu:{top:-18,bot:'pants'},
 kebaya:{top:-18,bot:'skirt'},kedah:{top:-21,bot:'skirt'},cheongsam:{one:1,end:-4},samfu:{top:-20,bot:'pants'},
 robe:{top:-5,bot:'pants'},sari:{one:1,end:-2},kurta:{top:-10,bot:'pants'},punjabi:{top:-10,bot:'pants'},
 lehenga:{top:-25,bot:'skirt',flare:9},bodo:{top:-18,bot:'skirt'},borneo:{top:-20,bot:'pants'},tunic:{top:-11,bot:'pants'},
};

function drawPattern(ctx,pat,base,acc,x0,y0,x1,y1){
  const R=seeded(7);
  switch(pat){
  case 'songket':
    ctx.fillStyle=acc;
    for(let y=y0;y<y1;y+=5)for(let x=x0+((y/5)%2?2.5:0);x<x1;x+=5){ctx.beginPath();ctx.moveTo(x,y-1.6);ctx.lineTo(x+1.3,y);ctx.lineTo(x,y+1.6);ctx.lineTo(x-1.3,y);ctx.fill()}
    ctx.globalAlpha=.6;ctx.fillRect(x0,y1-3.5,x1-x0,1.4);ctx.globalAlpha=1;break;
  case 'batik':
    for(let y=y0;y<y1;y+=8)for(let x=x0+((y/8)%2?4:0);x<x1;x+=8){
      ctx.fillStyle=shade(base,.35);ctx.beginPath();for(let k=0;k<5;k++){const a=k/5*TAU;ctx.moveTo(x,y);ctx.ellipse(x+Math.cos(a)*2,y+Math.sin(a)*2,1.6,1,a,0,TAU)}ctx.fill();
      ctx.fillStyle=acc;ctx.beginPath();ctx.arc(x,y,.9,0,TAU);ctx.fill()}
    break;
  case 'floral':
    for(let y=y0;y<y1;y+=7)for(let x=x0+((y/7)%2?3.5:0);x<x1;x+=7){ctx.fillStyle=acc;for(let k=0;k<5;k++){const a=k/5*TAU;ctx.beginPath();ctx.arc(x+Math.cos(a)*1.3,y+Math.sin(a)*1.3,.9,0,TAU);ctx.fill()}ctx.fillStyle='#fff7c2';ctx.beginPath();ctx.arc(x,y,.6,0,TAU);ctx.fill()}
    break;
  case 'check':
    ctx.fillStyle='rgba(0,0,0,.22)';for(let x=x0;x<x1;x+=5)ctx.fillRect(x,y0,1.8,y1-y0);for(let y=y0;y<y1;y+=5)ctx.fillRect(x0,y,x1-x0,1.8);
    ctx.fillStyle='rgba(255,255,255,.12)';for(let x=x0+2.5;x<x1;x+=5)ctx.fillRect(x,y0,.6,y1-y0);break;
  case 'cloud':
    ctx.strokeStyle=acc;ctx.lineWidth=.8;
    for(let y=y0+4;y<y1;y+=9)for(let x=x0+((y/9)%2?4:0);x<x1;x+=9){ctx.beginPath();ctx.arc(x,y,2.2,Math.PI,TAU);ctx.arc(x+3,y,1.4,Math.PI,TAU*1.1);ctx.stroke()}
    break;
  case 'zari':
    ctx.fillStyle=acc;for(let y=y0;y<y1;y+=6)for(let x=x0+((y/6)%2?3:0);x<x1;x+=6){ctx.beginPath();ctx.arc(x,y,.7,0,TAU);ctx.fill()}
    break;
  case 'sequin':
    for(let i=0;i<60;i++){ctx.fillStyle=i%3?acc:'#ffffff';ctx.beginPath();ctx.arc(x0+R()*(x1-x0),y0+R()*(y1-y0),.8,0,TAU);ctx.fill()}break;
  case 'motif':
    ctx.strokeStyle=acc;ctx.lineWidth=.9;
    for(let y=y0+4;y<y1;y+=10){ctx.beginPath();for(let x=x0;x<x1;x+=1)ctx.lineTo(x,y+Math.sin(x*.55)*2.2);ctx.stroke();
      for(let x=x0+3;x<x1;x+=7){ctx.beginPath();ctx.arc(x,y+4,1.6,0,Math.PI*1.5);ctx.stroke()}}
    break;
  case 'beads':
    const bc=[acc,'#ffffff','#f2c230','#e63946','#2ec4b6'];
    for(let y=y0+3;y<y1;y+=6){for(let x=x0,i=0;x<x1;x+=2,i++){ctx.fillStyle=bc[(i+Math.round(y))%bc.length];ctx.fillRect(x,y,1.6,1.6)}}
    break;
  }
}
function withClip(ctx,p,fn){ctx.save();ctx.clip(p);fn();ctx.restore()}

function headPath(face){
  const p=new Path2D();
  switch(face){
  case 1:p.ellipse(0,0,22.5,24,0,0,TAU);break;
  case 2:p.moveTo(-24,-3);p.bezierCurveTo(-24,-31,24,-31,24,-3);p.bezierCurveTo(24,10,11,22,0,23.5);p.bezierCurveTo(-11,22,-24,10,-24,-3);break;
  case 3:rrp(p,-23.5,-22.5,47,45,15);break;
  default:p.ellipse(0,0,24,22.5,0,0,TAU);
  }
  return p;
}

// ---- colour helpers for vivid anime eyes
function toHsl(hex){let n=parseInt(hex.slice(1),16),r=(n>>16)/255,g=((n>>8)&255)/255,b=(n&255)/255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b);let h=0,s=0,l=(mx+mn)/2;
  if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);h=mx===r?(g-b)/d+(g<b?6:0):mx===g?(b-r)/d+2:(r-g)/d+4;h/=6}return[h,s,l]}
function hslHex(h,s,l){const f=n=>{const k=(n+h*12)%12,a=s*Math.min(l,1-l);const c=l-a*Math.max(-1,Math.min(k-3,9-k,1));return Math.round(c*255).toString(16).padStart(2,'0')};return'#'+f(0)+f(8)+f(4)}
const _viv={};function vivid(hex,l,sMin){const k=hex+l+(sMin||0);if(_viv[k])return _viv[k];const [h,s]=toHsl(hex);return _viv[k]=hslHex(h,Math.min(.95,Math.max(s,sMin==null?.5:sMin)),l)}

// hair shapes: front (bangs) path, back path; strands are drawn with curved sides
function hairPaths(C){
  const f=C.g==='f', st=C.hair;
  const front=new Path2D(), back=new Path2D(); let tail=null,ahoge=false,curly=false;
  const crown=(r,spiky)=>{
    front.moveTo(-25,8);
    if(spiky){const n=14;let px=-25,py=8;for(let i=0;i<=n;i++){const a=Math.PI+i/n*Math.PI;const rr=r+(i%2?4.5:0);const x=Math.cos(a)*rr,y=-2+Math.sin(a)*rr*1.02;front.quadraticCurveTo((px+x)/2+Math.cos(a)*1.5,(py+y)/2+Math.sin(a)*1.5,x,y);px=x;py=y}}
    else if(curly){const n=11;for(let i=0;i<=n;i++){const a=Math.PI+i/n*Math.PI,a0=Math.PI+(i-.5)/n*Math.PI;front.quadraticCurveTo(Math.cos(a0)*(r+6),-2+Math.sin(a0)*(r+6),Math.cos(a)*r,-2+Math.sin(a)*r)}}
    else{front.lineTo(-r,-2);front.ellipse(0,-2,r,r*1.02,0,Math.PI,TAU)}
    front.lineTo(25,8);
  };
  const wavy=()=>{back.moveTo(-22,-21);back.lineTo(22,-21);back.quadraticCurveTo(30,-20,30,-16);{let y=-16;for(let i=0;i<4;i++){back.quadraticCurveTo(i%2?28:34,y+6,30,y+12);y+=12}back.quadraticCurveTo(31,36,24,37);for(let x=24;x>-24;x-=12)back.quadraticCurveTo(x-6,41,x-12,37);back.quadraticCurveTo(-31,36,-30,32);y=32;for(let i=0;i<4;i++){back.quadraticCurveTo(i%2?-28:-34,y-6,-30,y-12);y-=12}}back.closePath();};
  const bangs=(pts,round)=>{let p=[25,8];for(const q of pts){
      if(round){front.quadraticCurveTo((p[0]+q[0])/2,Math.max(p[1],q[1])+4,q[0],q[1])}
      else if(q[1]>p[1])front.quadraticCurveTo(p[0]+(q[0]-p[0])*.18,p[1]+(q[1]-p[1])*.72,q[0],q[1]);
      else front.quadraticCurveTo(q[0]-(q[0]-p[0])*.18,q[1]+(p[1]-q[1])*.72,q[0],q[1]);
      p=q}front.closePath()};
  if(!f){
    switch(st){
    case 0:crown(27,1);bangs([[24,4],[20,-5],[16,3],[11,-7],[6,1],[1,-9],[-4,0],[-9,-6],[-14,3],[-19,-3],[-25,5]]);break;
    case 1:crown(27);bangs([[24,2],[21,-6],[14,-10],[7,-3],[1,-10],[-7,-5],[-13,-11],[-19,-2],[-25,4]]);break;
    case 2:crown(26.5);bangs([[23,-3],[18,-10],[12,-7],[6,-12],[0,-9],[-6,-12],[-12,-7],[-18,-10],[-23,-3]]);break;
    case 3:crown(27);bangs([[24,8],[20,-2],[12,-10],[3,-15],[0,-11],[-3,-15],[-12,-10],[-20,-2],[-24,8]]);break;
    case 4:crown(28,1);bangs([[22,-8],[16,-14],[10,-10],[4,-16],[-2,-12],[-8,-16],[-15,-12],[-22,-8]]);break;
    case 6:crown(28.5,1);bangs([[25,10],[22,-1],[18,5],[14,-6],[10,4],[5,-8],[1,5],[-4,-7],[-8,3],[-13,-5],[-17,4],[-21,-2],[-26,10]]);break;
    case 7:curly=true;crown(27.5);bangs([[24,2],[18,-5],[12,-2],[6,-6],[0,-3],[-6,-6],[-12,-2],[-18,-5],[-24,2]],true);break;
    default:crown(25.5);bangs([[23,-6],[17,-12],[10,-11],[3,-14],[-4,-13],[-11,-14],[-17,-12],[-23,-6]]);
    }
  } else {
    crown(27.5);
    const fringe=[[24,7],[20,-3],[15,1],[10,-8],[5,-1],[0,-9],[-5,-2],[-10,-9],[-15,0],[-20,-4],[-25,6]];
    switch(st){
    case 0:bangs(fringe);rrp(back,-28,-22,56,56,14);break;
    case 1:bangs([[24,9],[21,-4],[14,-11],[7,-5],[1,-12],[-6,-7],[-12,-11],[-18,-3],[-25,7]]);
      wavy();break;
    case 2:bangs([[24,5],[19,-6],[12,-12],[5,-6],[-2,-11],[-9,-5],[-15,-10],[-25,3]]);tail='pony';break;
    case 3:bangs(fringe);tail='bun';break;
    case 4:bangs([[24,11],[21,-4],[14,-7],[7,-9],[0,-8],[-7,-9],[-14,-7],[-21,-4],[-24,11]]);rrp(back,-28,-20,56,36,13);break;
    case 5:bangs(fringe);tail='twin';break;
    case 7:bangs([[24,6],[18,-6],[10,-13],[2,-9],[-6,-13],[-14,-6],[-25,4]]);rrp(back,-27,-20,54,30,12);tail='braid';break;
    case 8:bangs([[24,8],[21,-3],[16,0],[11,-8],[5,-2],[0,-9],[-5,-3],[-11,-8],[-16,-1],[-21,-4],[-25,7]]);wavy();tail='bun';break;
    case 9:bangs([[24,9],[21.5,-1],[17,1.6],[12,.2],[7,1.8],[2,.2],[-3,1.8],[-8,.2],[-13,1.6],[-18,.2],[-21.5,-1],[-24,9]]);rrp(back,-28,-22,56,60,9);break;
    default:bangs([[24,5],[20,-7],[12,-12],[4,-6],[-4,-12],[-12,-6],[-18,-9],[-24,4]]);rrp(back,-27,-20,54,28,12);
    }
  }
  return {front,back,tail,ahoge};
}
// glossy hair fill: gradient, outline, anime shine ring and strand lines
function hairFill(ctx,p,hc,y0,y1,shine,noStroke){
  const g=ctx.createLinearGradient(0,y0,0,y1);g.addColorStop(0,shade(hc,.2));g.addColorStop(.5,hc);g.addColorStop(1,shade(hc,-.25));
  ctx.fillStyle=g;ctx.fill(p);if(!noStroke){ctx.strokeStyle=shade(hc,-.55);ctx.lineWidth=1.1;ctx.stroke(p)}
  if(!shine)return;
  ctx.save();ctx.clip(p);ctx.lineCap='round';
  ctx.strokeStyle='rgba(255,255,255,.3)';ctx.lineWidth=2;
  ctx.strokeStyle='rgba(255,255,255,.2)';ctx.lineWidth=2.6;for(const [a,b] of [[1.18,1.4],[1.56,1.74]]){ctx.beginPath();ctx.arc(0,-1,19.5,Math.PI*a,Math.PI*b);ctx.stroke()}
  
  ctx.strokeStyle=shade(hc,-.38);ctx.globalAlpha=.55;ctx.lineWidth=.8;
  ctx.globalAlpha=.32;for(const x of [-12,-3,8,15]){ctx.beginPath();ctx.moveTo(x*.75,-19);ctx.quadraticCurveTo(x*.95,-12,x,-5);ctx.stroke()}
  ctx.restore();
}
function hairShadow(ctx,hd,front,sk){ctx.save();ctx.clip(hd);ctx.translate(0,2.6);ctx.fillStyle=shade(sk,-.22);ctx.globalAlpha=.55;ctx.fill(front);ctx.restore()}
function skinShade(ctx,p,sk){ctx.save();ctx.clip(p);
  let g=ctx.createRadialGradient(-7,-9,2,-4,-4,30);g.addColorStop(0,'rgba(255,255,255,.28)');g.addColorStop(.6,'rgba(255,255,255,0)');g.addColorStop(1,'rgba(150,70,80,.14)');ctx.fillStyle=g;ctx.fillRect(-32,-32,64,64);ctx.restore()}

const EXPRS=['Biasa','Gembira','Kenyit Mata','Malu-malu','Teruja','Yakin','Terkejut'];
function drawEye(ctx,x,y,C,side,far,mode){
  const col=EYECOL[C.eyeCol]||EYECOL[0];
  let w=7.3,h=9.4,tilt=0,droop=0;
  switch(C.eye){case 1:h=7.8;w=7.8;tilt=.2;break;case 2:h=8.8;droop=1.6;break;case 3:w=7.8;h=10.4;break;case 4:h=8.4;w=7.6;tilt=.3;break;case 5:h=6.6;break}
  if(C.g==='m'){h*=.92}
  if(far)w*=.62;
  ctx.save();ctx.translate(x,y);ctx.rotate(tilt*side*-1);
  const lash='#2b1a24';ctx.lineCap='round';ctx.lineJoin='round';
  if(mode==='happy'||mode==='wink'){
    ctx.strokeStyle=lash;ctx.lineWidth=2.4;ctx.beginPath();
    if(mode==='happy'){ctx.moveTo(-w,2);ctx.quadraticCurveTo(0,-h*.95,w,2)}else{ctx.moveTo(-w*.9,1.5);ctx.quadraticCurveTo(0,-h*.45,w*.9,1.5)}
    ctx.stroke();
    if(C.g==='f'){ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(side*w*.95,1);ctx.lineTo(side*(w+2.6),-1.5);ctx.stroke()}
    ctx.restore();return;
  }
  const top=-h*.42,bot=h*.95;
  const eye=new Path2D();eye.moveTo(-w,top+(side<0?droop:0)*.0);eye.bezierCurveTo(-w*1.05,bot*.8,-w*.5,bot,0,bot);eye.bezierCurveTo(w*.5,bot,w*1.05,bot*.8,w,top);eye.quadraticCurveTo(0,-h*1.25,-w,top);eye.closePath();
  ctx.fillStyle='#fffdfb';ctx.fill(eye);
  ctx.save();ctx.clip(eye);
  const iy=mode==='down'?h*.25:h*.1, irx=w*.9, iry=h*.98;
  const g=ctx.createLinearGradient(0,iy-iry,0,iy+iry);g.addColorStop(0,vivid(col,.14,.4));g.addColorStop(.42,vivid(col,.3,.5));g.addColorStop(1,vivid(col,.62,.6));
  ctx.fillStyle=g;ctx.beginPath();ctx.ellipse(0,iy,irx,iry,0,0,TAU);ctx.fill();
  ctx.strokeStyle=vivid(col,.14,.35);ctx.lineWidth=.5;ctx.stroke();
  ctx.fillStyle=vivid(col,.06,.3);ctx.beginPath();ctx.ellipse(0,iy+.4,irx*.44,iry*.48,0,0,TAU);ctx.fill();
  ctx.fillStyle='rgba(255,255,255,.28)';ctx.beginPath();ctx.ellipse(0,iy+iry*.62,irx*.62,iry*.28,0,0,TAU);ctx.fill();
  const ls=ctx.createLinearGradient(0,-h,0,0);ls.addColorStop(0,'rgba(40,10,40,.22)');ls.addColorStop(1,'rgba(40,10,40,0)');ctx.fillStyle=ls;ctx.fillRect(-w-2,-h*1.3,w*2+4,h*1.1);
  ctx.restore();
  
  // upper lash (tapered crescent)
  const X=v=>v*side,lt=C.g==='m'?.75:1;ctx.fillStyle=lash;ctx.beginPath();ctx.moveTo(X(-w-.6),top+2.2);ctx.quadraticCurveTo(X(-w*.1),-h*(1.32+.16*lt),X(w+1.8),top-.9*lt);ctx.lineTo(X(w+.3),top+1.5);ctx.quadraticCurveTo(X(0),-h*1.15,X(-w+.2),top+2.6);ctx.closePath();ctx.fill();
  if(C.g==='f'){ctx.strokeStyle=lash;ctx.lineWidth=1.3;const ox=side*(w+.8);ctx.beginPath();ctx.moveTo(ox,top+(side>0?-.2:1));ctx.lineTo(ox+side*2.6,top-2.2);ctx.moveTo(ox-side*1.2,top-1.2);ctx.lineTo(ox+side*1.4,top-3.6);ctx.stroke()}
  if(C.eye===5){ctx.fillStyle=shade(SKIN[C.skin]||SKIN[1],-.06);ctx.beginPath();ctx.moveTo(-w-1,top+1);ctx.quadraticCurveTo(0,-h*1.4,w+1,top);ctx.lineTo(w+1,top+2.6);ctx.quadraticCurveTo(0,-h*.35,-w-1,top+3.2);ctx.fill();ctx.strokeStyle=lash;ctx.lineWidth=1.8;ctx.beginPath();ctx.moveTo(-w-1,top+3);ctx.quadraticCurveTo(0,-h*.35,w+1,top+2.6);ctx.stroke()}
  ctx.strokeStyle='rgba(60,30,40,.55)';ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(side*w*.45,bot+.9);ctx.quadraticCurveTo(side*w*.85,bot*.85,side*w*.98,bot*.55);ctx.stroke();
  // highlights (light from upper-left)
  ctx.fillStyle='#fff';ctx.beginPath();ctx.ellipse(-w*.3,iy-h*.38,w*.3,h*.24,-.4,0,TAU);ctx.fill();
  ctx.beginPath();ctx.arc(w*.34,iy+h*.38,w*.13,0,TAU);ctx.fill();
  ctx.globalAlpha=.7;ctx.beginPath();ctx.arc(w*.12,iy-h*.5,w*.07,0,TAU);ctx.fill();ctx.globalAlpha=1;
  if(C.eye===3||mode==='star'){const s=mode==='star'?w*.42:w*.26,sx=mode==='star'?w*.1:w*.32,sy=mode==='star'?iy+h*.05:iy-h*.05;ctx.beginPath();ctx.moveTo(sx,sy-s);ctx.quadraticCurveTo(sx,sy,sx+s,sy);ctx.quadraticCurveTo(sx,sy,sx,sy+s);ctx.quadraticCurveTo(sx,sy,sx-s,sy);ctx.quadraticCurveTo(sx,sy,sx,sy-s);ctx.fill()}
  ctx.restore();
}

function drawFace(ctx,C,side){
  // head-local coords, centre 0,0 ; side: 0 front, 1 right profile-ish
  const dx=side?6:0, hc=HAIRCOL[C.hairCol]||'#222', sk=SKIN[C.skin]||SKIN[1], ex=C.expr||0;
  // blush
  const bl=ex===3?.7:.42;
  for(const s of (side?[1]:[-1,1])){const bx=s*13.5+dx*(s>0?1:.5),by=11;const g=ctx.createRadialGradient(bx,by,.5,bx,by,6);g.addColorStop(0,`rgba(255,105,130,${bl})`);g.addColorStop(1,'rgba(255,105,130,0)');ctx.fillStyle=g;ctx.beginPath();ctx.ellipse(bx,by,6.2,3.8,0,0,TAU);ctx.fill();
    if(ex===3){ctx.strokeStyle='rgba(225,70,100,.6)';ctx.lineWidth=.8;for(let k=-1;k<=1;k++){ctx.beginPath();ctx.moveTo(bx+k*2.2-1,by+1.4);ctx.lineTo(bx+k*2.2+1,by-1.4);ctx.stroke()}}
    else{ctx.fillStyle='rgba(255,255,255,.7)';ctx.beginPath();ctx.arc(bx+1.8,by-1,.7,0,TAU);ctx.fill()}}
  // eyes
  const mL=ex===1?'happy':ex===4?'star':ex===3?'down':null, mR=ex===1?'happy':ex===2?'wink':ex===4?'star':ex===3?'down':null;
  const ey=4.2;
  if(side){drawEye(ctx,-7+dx,ey,C,-1,1,mL);drawEye(ctx,11+dx,ey,C,1,0,mR)}
  else{drawEye(ctx,-9.6,ey,C,-1,0,mL);drawEye(ctx,9.6,ey,C,1,0,mR)}
  // brows (tapered)
  const bc=shade(hc,hc==='#1f1a24'?.12:-.18);ctx.fillStyle=bc;
  const bw=[1.5,1.4,2.3,.95,1.5,1.7][C.brow]||1.5;
  for(const s of [-1,1]){const bx=s*9.8+dx*(s>0?1.1:.6);let y0=-7.2,yi=-7.2,yo=-7.6,cy=-8.6;
    if(C.brow===1){cy=-10.2}if(C.brow===4){yi=-8.6;yo=-6.4;cy=-8}if(C.brow===5||ex===5){yi=-6.2;yo=-8.6;cy=-7.8}if(ex===6){y0-=1.6;yi-=1.6;yo-=1.6;cy-=2}
    const xi=bx-s*4.8,xo=bx+s*5;ctx.beginPath();ctx.moveTo(xi,yi);ctx.quadraticCurveTo(bx,cy-bw*.5,xo,yo);ctx.quadraticCurveTo(bx,cy+bw*.9,xi,yi+bw);ctx.closePath();ctx.fill()}
  // nose
  ctx.fillStyle=shade(sk,-.28);
  if(C.nose===2){ctx.strokeStyle=shade(sk,-.3);ctx.lineWidth=.9;ctx.beginPath();ctx.moveTo(dx+.4,7.6);ctx.quadraticCurveTo(dx+1.6,10.4,dx-.4,10.8);ctx.stroke()}
  else{ctx.beginPath();ctx.ellipse(dx+.3,10.2,C.nose===1?.9:1.2,.7,0,0,TAU);ctx.fill()}
  // facial hair
  if(C.g==='m'&&C.beard){const bcol=shade(hc,-.05);ctx.fillStyle=bcol;ctx.strokeStyle=bcol;
    if(C.beard===1){ctx.beginPath();ctx.moveTo(dx-5,13.4);ctx.quadraticCurveTo(dx,10.6,dx+5,13.4);ctx.quadraticCurveTo(dx,12.6,dx-5,13.4);ctx.fill()}
    else if(C.beard===2){ctx.beginPath();ctx.moveTo(dx-3,19.5);ctx.lineTo(dx+3,19.5);ctx.lineTo(dx,23.5);ctx.closePath();ctx.fill()}
    else{ctx.globalAlpha=.4;ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-22,4);ctx.quadraticCurveTo(-19,19,dx,22.5);ctx.quadraticCurveTo(19,19,22,4);ctx.stroke();ctx.globalAlpha=1}}
  // mouth (expression overrides)
  const mx=dx,my=15.2;ctx.lineWidth=1.25;ctx.strokeStyle='#7a2a3a';ctx.lineCap='round';
  const open=(wd,ht)=>{ctx.fillStyle='#8a2438';ctx.beginPath();ctx.moveTo(mx-wd,my-1);ctx.quadraticCurveTo(mx,my-.2,mx+wd,my-1);ctx.quadraticCurveTo(mx+wd*.6,my+ht,mx,my+ht);ctx.quadraticCurveTo(mx-wd*.6,my+ht,mx-wd,my-1);ctx.fill();
    ctx.fillStyle='#ff8fa3';ctx.beginPath();ctx.ellipse(mx,my+ht*.72,wd*.55,ht*.3,0,0,TAU);ctx.fill();ctx.fillStyle='#fff';ctx.fillRect(mx-wd*.6,my-1,wd*1.2,1.1)};
  const m=ex===1||ex===4?1:ex===2?4:ex===3?2:ex===5?5:ex===6?6:C.mouth;
  switch(m){
  case 1:open(4.6,6.2);break;
  case 2:ctx.beginPath();ctx.moveTo(mx-3.6,my);ctx.quadraticCurveTo(mx-1.8,my+2.4,mx,my+.2);ctx.quadraticCurveTo(mx+1.8,my+2.4,mx+3.6,my);ctx.stroke();break;
  case 3:ctx.beginPath();ctx.moveTo(mx-2.2,my+.8);ctx.quadraticCurveTo(mx,my+1.6,mx+2.2,my+.8);ctx.stroke();break;
  case 4:ctx.fillStyle='#fff';ctx.beginPath();ctx.moveTo(mx-5,my-1);ctx.quadraticCurveTo(mx,my+5,mx+5,my-1);ctx.closePath();ctx.fill();ctx.stroke();ctx.strokeStyle='rgba(122,42,58,.35)';ctx.lineWidth=.6;ctx.beginPath();ctx.moveTo(mx-4,my+.6);ctx.lineTo(mx+4,my+.6);ctx.stroke();break;
  case 5:ctx.beginPath();ctx.moveTo(mx-3.4,my+1.2);ctx.quadraticCurveTo(mx+.6,my+2.6,mx+3.6,my-.6);ctx.stroke();break;
  case 6:ctx.fillStyle='#8a2438';ctx.beginPath();ctx.ellipse(mx,my+1.6,2.2,2.8,0,0,TAU);ctx.fill();break;
  default:ctx.beginPath();ctx.moveTo(mx-3.4,my);ctx.quadraticCurveTo(mx,my+3.6,mx+3.4,my);ctx.stroke();
  }
}

function drawHeadwear(ctx,kind,o,C){
  const acc=(o&&o.accent)||'#e2b44a', top=(o&&o.top)||'#222';
  const P=()=>new Path2D();
  let p;
  switch(kind){
  case 'songkok':case 'songkokgold':
    p=P();rrp(p,-17,-33,34,14,3);fillP(ctx,p,'#1b1a20');ctx.fillStyle='rgba(255,255,255,.12)';ctx.fillRect(-14,-31,10,10);
    if(kind==='songkokgold'){ctx.fillStyle='#e2b44a';ctx.fillRect(-17,-24,34,3)}break;
  case 'tanjak':
    p=P();p.moveTo(-22,-17);p.lineTo(-16,-34);p.lineTo(10,-48);p.lineTo(14,-34);p.lineTo(24,-17);p.closePath();fillP(ctx,p,top==='#f4eadb'?'#f4eadb':shade(top,.05));
    withClip(ctx,p,()=>drawPattern(ctx,'songket',top,acc,-24,-50,26,-15));ctx.strokeStyle=shade(acc,-.2);ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(-16,-24);ctx.lineTo(12,-40);ctx.stroke();break;
  case 'siga':
    p=P();rrp(p,-25,-26,50,11,4);p.moveTo(14,-26);p.lineTo(26,-40);p.lineTo(22,-24);fillP(ctx,p,'#1b1a20');
    ctx.fillStyle='#e63946';ctx.fillRect(-24,-22,48,1.6);ctx.fillStyle='#f2c230';ctx.fillRect(-24,-19,48,1.2);break;
  case 'destar':case 'saluak':
    p=P();p.moveTo(-25,-16);p.quadraticCurveTo(-24,-36,0,-37);p.quadraticCurveTo(24,-36,25,-16);p.closePath();fillP(ctx,p,kind==='saluak'?'#1b1a20':acc==='#f2c230'?'#c8102e':'#2b2b33');
    withClip(ctx,p,()=>drawPattern(ctx,'songket','#222',acc,-26,-40,26,-14));
    p=P();p.moveTo(-4,-36);p.lineTo(4,-46);p.lineTo(8,-34);fillP(ctx,p,kind==='saluak'?'#1b1a20':'#c8102e');break;
  case 'meukeutop':
    const bands=['#c8102e','#f2c230','#2a9a3a','#17171c'];
    for(let i=0;i<8;i++){const y=-18-i*5,w=22-i*2.2;ctx.fillStyle=bands[i%4];ctx.beginPath();ctx.ellipse(0,y,w,4,0,0,TAU);ctx.fill()}
    ctx.fillStyle='#e2b44a';ctx.beginPath();ctx.arc(0,-60,3.4,0,TAU);ctx.fill();break;
  case 'feather':
    for(const [x,a] of [[-8,-.25],[0,0],[8,.25]]){ctx.save();ctx.translate(x,-22);ctx.rotate(a);p=P();p.ellipse(0,-14,3.2,14,0,0,TAU);fillP(ctx,p,'#f4f4f4',.8);ctx.fillStyle='#1b1a20';ctx.beginPath();ctx.ellipse(0,-25,3,4,0,0,TAU);ctx.fill();ctx.restore()}
    p=P();rrp(p,-24,-26,48,8,3);fillP(ctx,p,'#17171c');withClip(ctx,p,()=>drawPattern(ctx,'beads','#17171c',acc,-24,-28,24,-17));break;
  case 'sugu':
    ctx.fillStyle='#c9ced6';ctx.strokeStyle='#7a808a';ctx.lineWidth=.7;
    for(let i=-6;i<=6;i++){ctx.beginPath();ctx.moveTo(i*3.4,-22);ctx.lineTo(i*3.4-1,-48+Math.abs(i)*2.6);ctx.lineTo(i*3.4+1,-48+Math.abs(i)*2.6);ctx.closePath();ctx.fill();ctx.stroke()}
    p=P();rrp(p,-23,-26,46,7,3);fillP(ctx,p,'#d4d8e0');break;
  case 'sipiah':
    p=P();rrp(p,-19,-38,38,18,4);fillP(ctx,p,'#17171c');withClip(ctx,p,()=>drawPattern(ctx,'beads','#17171c','#e63946',-20,-40,20,-18));break;
  case 'beadcrown':{p=P();p.moveTo(-26,-6);p.quadraticCurveTo(0,-36,26,-6);p.lineTo(25,1);p.quadraticCurveTo(0,-27,-25,1);p.closePath();fillP(ctx,p,'#17171c');
    ctx.save();ctx.clip(p);ctx.strokeStyle='#e2b44a';ctx.lineWidth=1.2;ctx.beginPath();for(let i=0;i<=24;i++){const t=i/24,x=-26+t*52,y=-2-Math.sin(t*Math.PI)*22.5+(i%2?3:-1);i?ctx.lineTo(x,y):ctx.moveTo(x,y)}ctx.stroke();ctx.restore();
    const bc=['#e23b3b','#2ec4b6','#f2c230','#ffffff'];for(let i=0;i<13;i++){const t=(i+.5)/13,x=-25+t*50,y=-1-Math.sin(t*Math.PI)*21;ctx.fillStyle=bc[i%4];ctx.beginPath();ctx.arc(x,y,1.3,0,TAU);ctx.fill()}
    for(let i=0;i<9;i++){const t=(i+.5)/9,x=-23+t*46,y=-7-Math.sin(t*Math.PI)*23;ctx.fillStyle='#e2b44a';ctx.beginPath();ctx.moveTo(x-1.6,y+2);ctx.lineTo(x,y-3.4);ctx.lineTo(x+1.6,y+2);ctx.fill()}
    for(let k=0;k<6;k++){const a=k/6*TAU;ctx.fillStyle='#e02a2a';ctx.beginPath();ctx.ellipse(20+Math.cos(a)*3.4,-12+Math.sin(a)*3.4,3,2.1,a,0,TAU);ctx.fill()}ctx.fillStyle='#f2c230';ctx.beginPath();ctx.arc(20,-12,1.8,0,TAU);ctx.fill();ctx.fillStyle='#2f8a4a';ctx.beginPath();ctx.ellipse(25,-7,3.4,1.4,.8,0,TAU);ctx.fill();break}
  case 'beadband':
    p=P();rrp(p,-25,-25,50,7,3);fillP(ctx,p,'#17171c');withClip(ctx,p,()=>drawPattern(ctx,'beads','#17171c',acc,-25,-27,25,-16));break;
  case 'sarempak':
    ctx.fillStyle='#f2c230';ctx.strokeStyle='#b07a12';ctx.lineWidth=.7;
    p=P();p.moveTo(-22,-20);for(let i=0;i<=8;i++){const x=-22+i*5.5;p.lineTo(x,i%2?-26:-36)}p.lineTo(22,-20);p.closePath();ctx.fill(p);ctx.stroke(p);
    for(let i=-3;i<=3;i++){ctx.beginPath();ctx.arc(i*6,-15,1.3,0,TAU);ctx.fill()}break;
  case 'suntiang':
    ctx.fillStyle='#f2c230';ctx.strokeStyle='#b07a12';ctx.lineWidth=.6;
    for(let r=0;r<3;r++)for(let i=0;i<11;i++){const a=Math.PI*1.08+i/10*Math.PI*.84;const R=30+r*6;ctx.beginPath();ctx.ellipse(Math.cos(a)*R,-4+Math.sin(a)*R,2.6,4.5,a+Math.PI/2,0,TAU);ctx.fill();ctx.stroke()}
    break;
  case 'goldflower':
    ctx.fillStyle='#f2c230';ctx.strokeStyle='#b07a12';ctx.lineWidth=.6;
    for(const [x,y,r] of [[-14,-24,4],[0,-29,5],[14,-24,4]]){for(let k=0;k<6;k++){const a=k/6*TAU;ctx.beginPath();ctx.arc(x+Math.cos(a)*r*.7,y+Math.sin(a)*r*.7,r*.45,0,TAU);ctx.fill();ctx.stroke()}ctx.fillStyle='#c8102e';ctx.beginPath();ctx.arc(x,y,r*.35,0,TAU);ctx.fill();ctx.fillStyle='#f2c230'}
    break;
  case 'veil':
    ctx.fillStyle='rgba(255,255,255,.55)';ctx.beginPath();ctx.moveTo(-20,-24);ctx.quadraticCurveTo(0,-34,20,-24);ctx.lineTo(30,30);ctx.lineTo(-30,30);ctx.closePath();ctx.fill();
    ctx.fillStyle='#f2c230';for(let i=-2;i<=2;i++){ctx.beginPath();ctx.arc(i*6,-27+Math.abs(i),1.6,0,TAU);ctx.fill()}break;
  case 'policecap':
    p=P();p.moveTo(-25,-18);p.quadraticCurveTo(-26,-36,0,-38);p.quadraticCurveTo(26,-36,25,-18);p.closePath();fillP(ctx,p,'#1d2d55');
    ctx.fillStyle='#111';ctx.beginPath();ctx.ellipse(0,-16,21,4,0,0,Math.PI);ctx.fill();ctx.fillStyle='#f2c230';ctx.beginPath();ctx.arc(0,-26,3.6,0,TAU);ctx.fill();ctx.fillRect(-24,-21,48,1.6);break;
  case 'firehelmet':
    p=P();p.moveTo(-27,-12);p.quadraticCurveTo(-28,-40,0,-42);p.quadraticCurveTo(28,-40,27,-12);p.closePath();fillP(ctx,p,'#f2c230');
    ctx.fillStyle='#d8a20c';ctx.fillRect(-2,-41,4,28);ctx.fillStyle='#c8102e';ctx.beginPath();ctx.arc(0,-28,3.4,0,TAU);ctx.fill();break;
  case 'chefhat':
    p=P();p.arc(-9,-38,9,0,TAU);p.arc(9,-38,9,0,TAU);p.arc(0,-44,10,0,TAU);fillP(ctx,p,'#ffffff',.8);p=P();rrp(p,-17,-32,34,12,2);fillP(ctx,p,'#ffffff',.8);break;
  case 'helmet':
    p=P();p.moveTo(-27,-6);p.quadraticCurveTo(-28,-40,0,-41);p.quadraticCurveTo(28,-40,27,-6);p.lineTo(18,-10);p.lineTo(-18,-10);p.closePath();fillP(ctx,p,top);
    ctx.fillStyle='#fff';ctx.fillRect(-3,-40,6,26);break;
  case 'hardhat':
    p=P();p.moveTo(-26,-14);p.quadraticCurveTo(-26,-40,0,-41);p.quadraticCurveTo(26,-40,26,-14);p.closePath();fillP(ctx,p,'#ffd23f');p=P();rrp(p,-30,-17,60,5,2);fillP(ctx,p,'#f2a20c');ctx.fillStyle='rgba(255,255,255,.4)';ctx.fillRect(-2,-39,4,22);break;
  case 'mortar':
    p=P();p.moveTo(-18,-20);p.quadraticCurveTo(0,-28,18,-20);p.lineTo(18,-28);p.lineTo(-18,-28);p.closePath();fillP(ctx,p,'#1d1d24');
    p=P();p.moveTo(0,-40);p.lineTo(32,-31);p.lineTo(0,-22);p.lineTo(-32,-31);p.closePath();fillP(ctx,p,'#1d1d24');ctx.strokeStyle='#f2c230';ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(0,-31);ctx.lineTo(22,-27);ctx.lineTo(23,-14);ctx.stroke();ctx.fillStyle='#f2c230';ctx.fillRect(21.5,-15,3,5);break;
  case 'nursecap':
    p=P();p.moveTo(-12,-24);p.lineTo(12,-24);p.lineTo(9,-33);p.lineTo(-9,-33);p.closePath();fillP(ctx,p,'#ffffff',.8);ctx.fillStyle='#3a86ff';ctx.fillRect(-2.5,-31,5,1.6);ctx.fillRect(-.8,-32.6,1.6,5);break;
  }
}
function dot2(ctx,c,x,y,r){ctx.fillStyle=c;ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.fill()}
function drawHat(ctx,h){
  let p=new Path2D();
  switch(h){
  case 1:p.moveTo(-25,-12);p.quadraticCurveTo(-26,-38,0,-39);p.quadraticCurveTo(26,-38,25,-12);p.closePath();fillP(ctx,p,'#2b2d42');
    p=new Path2D();p.ellipse(4,-12,22,5,0,0,Math.PI);fillP(ctx,p,'#1d1e2c');ctx.fillStyle='#e63946';ctx.beginPath();ctx.arc(0,-38,2.5,0,TAU);ctx.fill();break;
  case 2:p.moveTo(-22,-14);p.quadraticCurveTo(-22,-38,0,-38);p.quadraticCurveTo(22,-38,22,-14);p.closePath();fillP(ctx,p,'#c8b48a');p=new Path2D();p.ellipse(0,-13,31,6,0,0,TAU);fillP(ctx,p,'#b8a47a');break;
  case 3:p.moveTo(-25,-10);p.quadraticCurveTo(-26,-42,0,-42);p.quadraticCurveTo(26,-42,25,-10);p.closePath();fillP(ctx,p,'#e63946');p=new Path2D();rrp(p,-26,-16,52,8,4);fillP(ctx,p,'#c22b38');ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(0,-43,4,0,TAU);ctx.fill();break;
  case 4:drawHeadwear(ctx,'songkok');break;
  case 6:for(let k=0;k<6;k++){const a=k/6*TAU;ctx.fillStyle='#fffaf0';ctx.strokeStyle='#d9c9b0';ctx.lineWidth=.6;ctx.beginPath();ctx.ellipse(-17+Math.cos(a)*3.4,-15+Math.sin(a)*3.4,2.8,1.9,a,0,TAU);ctx.fill();ctx.stroke()}ctx.fillStyle='#f2c230';ctx.beginPath();ctx.arc(-17,-15,1.9,0,TAU);ctx.fill();break;
  case 7:case 8:{const c=h===7?'#efe6d6':'#1f1f26';p.moveTo(-25.5,-11);p.quadraticCurveTo(-26.5,-39,0,-40);p.quadraticCurveTo(26.5,-39,25.5,-11);p.closePath();fillP(ctx,p,c);ctx.save();ctx.clip(p);ctx.strokeStyle=shade(c,-.18);ctx.lineWidth=.7;ctx.beginPath();ctx.moveTo(0,-40);ctx.quadraticCurveTo(-3,-24,-2,-11);ctx.moveTo(-14,-36);ctx.quadraticCurveTo(-14,-22,-13,-11);ctx.moveTo(14,-36);ctx.quadraticCurveTo(14,-22,13,-11);ctx.stroke();ctx.restore();
    p=new Path2D();p.moveTo(-24,-12);p.quadraticCurveTo(0,-17,24,-12);p.quadraticCurveTo(26,-5,4,-5);p.quadraticCurveTo(-22,-5,-24,-12);fillP(ctx,p,shade(c,-.08));dot2(ctx,shade(c,-.2),0,-39.5,1.8);
    if(h===7){ctx.fillStyle='#5a3b22';ctx.font='bold 11px Fredoka,sans-serif';ctx.textAlign='center';ctx.fillText('K',0,-20);ctx.strokeStyle='#f2c230';ctx.lineWidth=.5;ctx.strokeText('K',0,-20)}break}
  case 9:{const W2='#ffffff',S2='#d9d0e6';ctx.save();ctx.translate(0,4);ctx.scale(.88,.88);for(const sd of [-1,1]){const l=new Path2D();l.moveTo(0,-30);l.bezierCurveTo(sd*10,-46,sd*30,-44,sd*26,-30);l.bezierCurveTo(sd*24,-24,sd*12,-26,0,-30);l.closePath();ctx.fillStyle=W2;ctx.fill(l);ctx.strokeStyle='#b8a8d0';ctx.lineWidth=.8;ctx.stroke(l);ctx.save();ctx.clip(l);ctx.fillStyle='rgba(150,130,180,.22)';ctx.beginPath();ctx.ellipse(sd*18,-31,8,4,0,0,TAU);ctx.fill();ctx.restore();
      const t=new Path2D();t.moveTo(sd*2,-28);t.quadraticCurveTo(sd*10,-20,sd*16,-12);t.lineTo(sd*11,-13);t.lineTo(sd*9,-9);t.quadraticCurveTo(sd*6,-18,sd*-1,-27);t.closePath();ctx.fillStyle=W2;ctx.fill(t);ctx.strokeStyle='#b8a8d0';ctx.lineWidth=.8;ctx.stroke(t)}
    const k=new Path2D();k.ellipse(0,-30,5,5.6,0,0,TAU);ctx.fillStyle='#f4f0fa';ctx.fill(k);ctx.strokeStyle='#b8a8d0';ctx.lineWidth=.8;ctx.stroke(k);ctx.strokeStyle=S2;ctx.lineWidth=.6;ctx.beginPath();ctx.moveTo(-3,-33);ctx.quadraticCurveTo(0,-30,-3,-27);ctx.stroke();ctx.restore();break}
  case 11:{for(let k=0;k<5;k++){const a=k/5*TAU-Math.PI/2;ctx.fillStyle='#f7a8c6';ctx.strokeStyle='#e07aa2';ctx.lineWidth=.6;ctx.beginPath();ctx.ellipse(-20+Math.cos(a)*3.8,-6+Math.sin(a)*3.8,3.6,2.5,a,0,TAU);ctx.fill();ctx.stroke()}ctx.fillStyle='#fff2a8';ctx.beginPath();ctx.arc(-20,-6,1.9,0,TAU);ctx.fill();
    ctx.strokeStyle='#d9a520';ctx.lineWidth=.5;ctx.beginPath();ctx.moveTo(-18,-2);ctx.lineTo(-17,3);ctx.stroke();ctx.fillStyle='#e8607e';ctx.beginPath();ctx.moveTo(-17,3);ctx.lineTo(-14.6,8);ctx.lineTo(-18.6,7.4);ctx.closePath();ctx.fill();break}
  case 10:{ctx.strokeStyle='#d9a520';ctx.lineWidth=1.6;ctx.beginPath();ctx.moveTo(17,-12);ctx.bezierCurveTo(13,-17,8,-12,13,-7);ctx.lineTo(17,-3);ctx.lineTo(21,-7);ctx.bezierCurveTo(26,-12,21,-17,17,-12);ctx.stroke();break}
  case 5:p.ellipse(0,-15,36,8,0,0,TAU);fillP(ctx,p,'#e3c27a');p=new Path2D();p.moveTo(-18,-15);p.quadraticCurveTo(-18,-36,0,-36);p.quadraticCurveTo(18,-36,18,-15);p.closePath();fillP(ctx,p,'#e9cc88');ctx.fillStyle='#c8102e';ctx.fillRect(-18,-21,36,4);break;
  }
}

function drawHijab(ctx,C,back){
  const col=HIJAB_COL[C.hijabCol]||HIJAB_COL[0], st=C.hijabSt, dk=shade(col,-.12);
  const P=()=>new Path2D();
  let d=P();
  if(st===0){d.moveTo(-28,-70);d.lineTo(-31,-46);d.quadraticCurveTo(-24,-34,0,-22);d.quadraticCurveTo(24,-34,31,-46);d.lineTo(28,-70);d.closePath()}
  else if(st===1){d.moveTo(-28,-70);d.lineTo(-30,-44);d.quadraticCurveTo(0,-30,30,-44);d.lineTo(28,-70);d.closePath()}
  else if(st===2){d.moveTo(-28,-70);d.lineTo(-31,-44);d.quadraticCurveTo(-20,-24,6,-26);d.quadraticCurveTo(24,-30,31,-48);d.lineTo(28,-70);d.closePath()}
  else{d.moveTo(-10,-52);d.lineTo(-11,-42);d.lineTo(11,-42);d.lineTo(10,-52);d.closePath()}
  fillP(ctx,d,col);clothShade(ctx,d,-32,32,-72,-20);
  const h=P();h.ellipse(0,-69,st===3?27:29.5,st===3?26:28.5,0,0,TAU);fillP(ctx,h,col);clothShade(ctx,h,-30,30,-98,-40,.9);
  if(back){ctx.strokeStyle=dk;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(-18,-80);ctx.quadraticCurveTo(0,-60,0,-40);ctx.stroke();return}
  if(st===3){ctx.fillStyle=dk;ctx.beginPath();ctx.ellipse(0,-93,8,5,0,0,TAU);ctx.fill();ctx.strokeStyle=shade(col,-.3);ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(-20,-85);ctx.quadraticCurveTo(0,-95,20,-85);ctx.stroke()}
  ctx.strokeStyle=shade(col,-.25);ctx.lineWidth=.9;
  ctx.beginPath();ctx.moveTo(-24,-56);ctx.quadraticCurveTo(-20,-44,-10,-38);ctx.moveTo(24,-56);ctx.quadraticCurveTo(20,-44,10,-38);ctx.stroke();
  if(st===2){ctx.fillStyle=dk;ctx.beginPath();ctx.moveTo(24,-60);ctx.quadraticCurveTo(-4,-40,-26,-46);ctx.quadraticCurveTo(-4,-34,26,-48);ctx.fill()}
}

const SHOEKIND={sh14:'sneak',sh15:'hightop',sh13:'laceboot',sh12:'chunky',sh11:'slip',sh1:'sneak',sh2:'canvas',sh3:'slip',sh4:'sneak',sh5:'slip',sh6:'loaf',sh7:'heel',sh8:'boot',sh9:'loaf',sh10:'slip'};
function clothShade(ctx,p,x0,x1,y0,y1,k){ctx.save();ctx.clip(p);k=k==null?1:k;
  const g=ctx.createLinearGradient(x0,0,x1,0);g.addColorStop(0,`rgba(255,255,255,${.2*k})`);g.addColorStop(.38,'rgba(255,255,255,0)');g.addColorStop(.7,'rgba(40,15,70,0)');g.addColorStop(1,`rgba(40,15,70,${.22*k})`);ctx.fillStyle=g;ctx.fillRect(x0,y0,x1-x0,y1-y0);
  const v=ctx.createLinearGradient(0,y0,0,y1);v.addColorStop(0,'rgba(40,15,70,0)');v.addColorStop(.75,'rgba(40,15,70,0)');v.addColorStop(1,`rgba(40,15,70,${.16*k})`);ctx.fillStyle=v;ctx.fillRect(x0,y0,x1-x0,y1-y0);ctx.restore()}
function drawShoe(ctx,x,y,sh,side,sk){
  const c=sh.c||'#ffffff',k=SHOEKIND[sh.id]||'sneak',W=side?12.2:11.4,x0=x-5.7,x1=x0+W,light=['#ffffff','#f4f4f4'].includes(c);
  const O=(p,col,lw)=>{ctx.fillStyle=col;ctx.fill(p);ctx.strokeStyle=light&&col===c?'#8f86a8':shade(col,-.5);ctx.lineWidth=lw||.9;ctx.stroke(p)};
  const dome=(h,yb)=>{const p=new Path2D();p.moveTo(x0,yb);p.lineTo(x0,y-h*.4);p.bezierCurveTo(x0,y-h*1.05,x1,y-h*1.05,x1,y-h*.4);p.lineTo(x1,yb);p.closePath();return p};
  ctx.lineJoin='round';
  if(k==='slip'){
    const f=new Path2D();rrp(f,x0+1,y-5,W-2,5.4,2.6);O(f,sk||'#f1c7a5',.7);
    const so=new Path2D();rrp(so,x0-.6,y-.8,W+1.2,2.2,1.1);O(so,shade(c,-.15),.7);
    ctx.strokeStyle=c;ctx.lineWidth=2;ctx.beginPath();if(sh.id==='sh3'){ctx.moveTo(x0+1.6,y-1.6);ctx.lineTo(x,y-4.4);ctx.lineTo(x1-1.6,y-1.6)}else{ctx.moveTo(x0+1,y-3.2);ctx.lineTo(x1-1,y-3.2)}ctx.stroke();
    if(sh.id==='sh10'){for(let i=0;i<4;i++){ctx.fillStyle=['#e63946','#fff','#2ec4b6','#f2c230'][i];ctx.beginPath();ctx.arc(x0+2+i*2.2,y-3.2,.7,0,TAU);ctx.fill()}}
    return}
  if(k==='hightop'){const b=new Path2D();b.moveTo(x0+.5,y-11.5);b.lineTo(x1-2,y-11.5);b.lineTo(x1-1.2,y-5.4);b.quadraticCurveTo(x1+1.4,y-4,x1+.4,y-.6);b.lineTo(x0,y-.6);b.closePath();O(b,c);
    ctx.fillStyle='#f6f6f8';ctx.beginPath();ctx.ellipse(x+1.4,y-2,W*.34,2.4,0,Math.PI,TAU);ctx.fill();ctx.beginPath();ctx.arc(x0+2.6,y-7.6,1.9,0,TAU);ctx.fill();ctx.fillStyle=c;ctx.beginPath();ctx.arc(x0+2.6,y-7.6,.8,0,TAU);ctx.fill();
    ctx.strokeStyle='#fff';ctx.lineWidth=.7;for(let i=0;i<3;i++){const yy=y-10+i*2.2;ctx.beginPath();ctx.moveTo(x-1.4,yy);ctx.lineTo(x+2.2,yy+1.3);ctx.moveTo(x+2.2,yy);ctx.lineTo(x-1.4,yy+1.3);ctx.stroke()}
    const s1=new Path2D();rrp(s1,x0-.8,y-1.8,W+1.8,2.4,1.1);O(s1,'#ffffff',.6);ctx.fillStyle='#2a2a30';ctx.fillRect(x0-.6,y+.2,W+1.4,.9);return}
  if(k==='laceboot'){const b=new Path2D();b.moveTo(x0+.6,y-12);b.lineTo(x1-.6,y-12);b.lineTo(x1,y-3.4);b.quadraticCurveTo(x1+.6,y+.6,x1-2,y+.8);b.lineTo(x0+1,y+.8);b.quadraticCurveTo(x0-.8,y+.4,x0,y-3.4);b.closePath();O(b,c);
    const bg=ctx.createLinearGradient(x0,0,x1,0);bg.addColorStop(0,'rgba(255,255,255,.22)');bg.addColorStop(.5,'rgba(255,255,255,0)');bg.addColorStop(1,'rgba(0,0,0,.18)');ctx.fillStyle=bg;ctx.fill(b);
    ctx.strokeStyle='#f3e6d6';ctx.lineWidth=.6;for(let i=0;i<3;i++){const yy=y-10+i*2.4;ctx.beginPath();ctx.moveTo(x-1.8,yy);ctx.lineTo(x+1.8,yy+1.6);ctx.moveTo(x+1.8,yy);ctx.lineTo(x-1.8,yy+1.6);ctx.stroke()}
    const so=new Path2D();rrp(so,x0-.4,y-.6,W+.8,1.8,.9);O(so,'#3a2618',.6);
    ctx.fillStyle='#fffdf8';ctx.strokeStyle='#d9cfc4';ctx.lineWidth=.5;for(let i=0;i<4;i++){ctx.beginPath();ctx.arc(x0+1.4+i*(W-2.8)/3,y-12.4,1.9,Math.PI,TAU);ctx.fill();ctx.stroke()}ctx.fillRect(x0+.2,y-12.8,W-.4,1.6);return}
  if(k==='boot'){const b=new Path2D();b.moveTo(x0+.4,y-11);b.lineTo(x1-.4,y-11);b.lineTo(x1,y-3);b.lineTo(x1,y+.8);b.lineTo(x0,y+.8);b.lineTo(x0,y-3);b.closePath();O(b,c);ctx.fillStyle=shade(c,.25);ctx.fillRect(x0+.4,y-11,W-.8,1.6);
    const so=new Path2D();rrp(so,x0-.4,y-.6,W+.8,1.9,.9);O(so,'#2a1d18',.6);ctx.fillStyle='rgba(255,255,255,.25)';ctx.fillRect(x0+1.4,y-9,1.2,6);return}
  if(k==='heel'){const p=dome(5.6,y+.2);O(p,c);ctx.fillStyle=sk||'#f1c7a5';ctx.beginPath();ctx.ellipse(x,y-4.6,W*.3,1.6,0,0,TAU);ctx.fill();ctx.strokeStyle=shade(c,-.2);ctx.lineWidth=1.1;ctx.beginPath();ctx.moveTo(x0+1,y-5.6);ctx.lineTo(x1-1,y-5.6);ctx.stroke();
    ctx.fillStyle='rgba(255,255,255,.55)';ctx.beginPath();ctx.ellipse(x-2,y-2,1.6,.8,-.3,0,TAU);ctx.fill();return}
  if(k==='loaf'){const p=dome(5.2,y+.6);O(p,c);ctx.strokeStyle=shade(c,-.35);ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(x0+2,y-3.6);ctx.quadraticCurveTo(x,y-2.4,x1-2,y-3.6);ctx.stroke();
    const so=new Path2D();rrp(so,x0-.3,y-.4,W+.6,1.6,.8);O(so,'#2a1d18',.6);ctx.fillStyle='rgba(255,255,255,.45)';ctx.beginPath();ctx.ellipse(x-2.2,y-2.6,1.8,.8,-.3,0,TAU);ctx.fill();return}
  if(k==='chunky'){const p=dome(9,y-1.6);O(p,c);ctx.fillStyle='#ecebf2';ctx.beginPath();ctx.ellipse(x,y-2.8,W*.36,2.2,0,Math.PI,TAU);ctx.fill();ctx.strokeStyle='#b9b2cc';ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(x0+1.5,y-5);ctx.quadraticCurveTo(x,y-2.5,x1-1.5,y-6);ctx.stroke();ctx.strokeStyle='#9a92b4';ctx.lineWidth=.7;for(const yy of [-7.4,-6.2]){ctx.beginPath();ctx.moveTo(x-1.8,y+yy);ctx.lineTo(x+1.8,y+yy);ctx.stroke()}
    const s1=new Path2D();rrp(s1,x0-1,y-2.4,W+2,2.6,1.2);O(s1,'#f6f4fa',.7);const s2=new Path2D();rrp(s2,x0-1,y-.2,W+2,1.8,.9);O(s2,'#d9d4e6',.6);return}
  // sneakers / canvas shoes
  const p=dome(7.6,y);O(p,c);
  const cap=new Path2D();cap.ellipse(x,y-1.4,W*.38,2,0,Math.PI,TAU);ctx.fillStyle=light?'#ecebf2':shade(c,.18);ctx.fill(cap);
  if(k==='sneak'&&light){ctx.fillStyle='#b9b2cc';ctx.beginPath();ctx.moveTo(x1-.6,y-4.2);ctx.quadraticCurveTo(x+1,y-3,x1-.6,y-1.6);ctx.fill()}
  ctx.strokeStyle=light?'#9a92b4':'#f4f4f4';ctx.lineWidth=.8;for(const yy of [-5.2,-4]){ctx.beginPath();ctx.moveTo(x-1.8,y+yy);ctx.lineTo(x+1.8,y+yy);ctx.stroke()}
  const so=new Path2D();rrp(so,x0-.6,y-1,W+1.2,2.4,1.2);O(so,k==='canvas'?'#fafafa':light?'#d9d4e6':'#f6f6f6',.7);
  if(k==='canvas'){ctx.strokeStyle='#c9c2da';ctx.lineWidth=.5;ctx.beginPath();ctx.moveTo(x0,y+.2);ctx.lineTo(x1,y+.2);ctx.stroke()}
}
function drawChibi(ctx,x,y,s,C,dir,frame){
  dir=dir||0;frame=frame||0;
  const o=OUT[C.outfit]||OUT.h2, sh=SHOE[C.shoes]||SHOE.sh1;
  ctx.save();ctx.translate(x,y);ctx.scale(s,s);ctx.lineJoin='round';
  if(dir===1){ctx.scale(-1,1);dir=2}
  const back=dir===3, side=dir===2;
  const sk=SKIN[C.skin]||SKIN[1], hc=HAIRCOL[C.hairCol]||'#222', hij=!!C.hijab;
  const S=STYLE[o.style]||STYLE.casual;
  const lA=frame===1?-3:0,lB=frame===3?-3:0,bob=(frame%2)?-1.2:0;
  const fem=C.g==='f';
  let bot=o.bot||S.bot;if((o.style==='uniform'||o.style==='borneo'||o.style==='office')&&fem)bot='skirt';
  if(bot==='shorts'&&(hij||o.id==='sp4'||o.id==='sp5'))bot='pants';
  let sleeve='long';
  if(['sport','nurse','cheongsam','sari'].includes(o.style)||(o.style==='casual'&&!['hoodie','jacket','cardigan','varsity','check','blouse','denim','track','lace'].includes(o.pat))||(o.style==='uniform'&&o.id==='s1')||(o.style==='dress'&&o.cat==='moden')||(o.style==='borneo'&&!fem&&o.id!=='t19'))sleeve='short';
  if(hij)sleeve='long';
  // shadow
  ctx.fillStyle='rgba(30,20,60,.22)';ctx.beginPath();ctx.ellipse(0,0,17,4.5,0,0,TAU);ctx.fill();
  const BP=BODIES[C.body||0]||BODIES[0],CS=CSTYLES[C.style||0]||CSTYLES[0],hs=CS[1],bsx=BP[1],bsy=BP[2]*CS[2],hshift=-48*(bsy-1);
  const headXf=()=>{ctx.translate(0,hshift-48);ctx.scale(hs,hs);ctx.translate(0,48)};
  // ----- back layers
  const hp=hij?null:hairPaths(C);
  const headY=-68+bob;
  if(!back){
    if(o.head==='veil'){ctx.save();headXf();ctx.translate(0,headY);drawHeadwear(ctx,'veil',o,C);ctx.restore()}
    if(hp){ctx.save();headXf();ctx.translate(0,headY);const hb=shade(hc,-.1);hairFill(ctx,hp.back,hb,-24,36);if(hp.tail==='pony'){const t=new Path2D();t.moveTo(18,-18);t.quadraticCurveTo(38,-6,28,28);t.quadraticCurveTo(25,12,20,20);t.quadraticCurveTo(22,4,14,-12);hairFill(ctx,t,hb,-18,28)}if(hp.tail==='twin'){for(const sx of [-1,1]){const t=new Path2D();t.moveTo(sx*22,-12);t.quadraticCurveTo(sx*40,4,sx*31,34);t.quadraticCurveTo(sx*29,18,sx*25,24);t.quadraticCurveTo(sx*26,8,sx*18,-6);hairFill(ctx,t,hb,-12,34)}}ctx.restore()}
  }
  // ----- legs & shoes
  ctx.save();ctx.scale(bsx,bsy);
  const legCol=bot==='shorts'||bot==='pina'?sk:bot==='pants'?o.bottom:sk;
  const lx=side?[-3,1]:[-9,2];
  if(side){lx[0]+= frame===1?-3:frame===3?3:0;lx[1]+= frame===1?3:frame===3?-3:0}
  for(let i=0;i<2;i++){const ly=i?lB:lA;const pants=bot==='pants',cg=pants&&o.bp==='cargo',wd=pants&&o.bp==='wide';const lw=cg?8.4:7.5,lx0=lx[i]-(cg?.45:0);const p=new Path2D();
    if(wd){const b=-4+ly;p.moveTo(lx0,-26);p.lineTo(lx0+lw,-26);p.lineTo(lx0+lw+(i?2.6:.6),b);p.quadraticCurveTo(lx0+lw/2,b+1,lx0-(i?.6:2.6),b);p.closePath()}else rrp(p,lx0,-26,lw,22+ly,3);
    fillP(ctx,p,pants?o.bottom:sk,.9);clothShade(ctx,p,lx0-3,lx0+lw+3,-26,-4+ly,.8);
    if(cg&&!back){const px=i?lx0+lw-4.7:lx0+.3;const q=new Path2D();rrp(q,px,-19.5,4.4,6.4,1);fillP(ctx,q,shade(o.bottom,-.05),.6);ctx.strokeStyle=shade(o.bottom,-.42);ctx.lineWidth=.6;ctx.beginPath();ctx.moveTo(px,-17.6);ctx.lineTo(px+4.4,-17.6);ctx.stroke();ctx.fillStyle=shade(o.bottom,-.2);ctx.fillRect(lx0+.5,-7.8+ly,lw-1,1.4)}
    if(wd&&!back){ctx.strokeStyle=shade(o.bottom,-.25);ctx.lineWidth=.6;ctx.beginPath();ctx.moveTo(lx0+lw/2,-24);ctx.lineTo(lx0+lw/2+(i?.9:-.9),-6+ly);ctx.stroke()}
    if(bot==='shorts'){const q=new Path2D();rrp(q,lx[i]-.5,-26,8.5,12,2);fillP(ctx,q,o.bottom,.9)}
    if(bot==='pina'&&!hij){ctx.fillStyle='#fff';ctx.fillRect(lx[i],-10+ly,7.5,6)}
    drawShoe(ctx,lx[i]+(side?4.5:3.8),-1+ly,sh,side,sk)}
  if(bot==='pants'){const p=new Path2D();rrp(p,-12,-29,24,8,3);fillP(ctx,p,o.bottom,0)}
  // ----- skirt / one-piece lower
  ctx.translate(0,bob);
  const fl=S.flare||0;
  const skirtP=(y0,y1,w0,w1)=>{const p=new Path2D();p.moveTo(-w0,y0);p.lineTo(w0,y0);p.quadraticCurveTo(w1,y0+(y1-y0)*.5,w1,y1);p.quadraticCurveTo(0,y1+2,-w1,y1);p.quadraticCurveTo(-w1,y0+(y1-y0)*.5,-w0,y0);p.closePath();return p};
  let topCol=o.top;
  if(S.one){
    const p=skirtP(-27,S.end-bob,12.5,15+fl);fillP(ctx,p,o.top);clothShade(ctx,p,-18-fl,18+fl,-28,S.end-bob+2);
    if(['floral','cloud','zari','goldtrim'].includes(o.pat))withClip(ctx,p,()=>drawPattern(ctx,o.pat,o.top,o.accent,-30,-28,30,2));
    if(o.style==='cheongsam'&&!hij){ctx.strokeStyle=shade(o.top,-.4);ctx.lineWidth=.9;ctx.beginPath();ctx.moveTo(10,-14);ctx.lineTo(12,-4);ctx.stroke()}
    if(o.style==='sari'){ctx.strokeStyle=o.accent;ctx.lineWidth=1.8;ctx.beginPath();ctx.moveTo(-16,-5);ctx.quadraticCurveTo(0,-3,16,-5);ctx.stroke();ctx.lineWidth=.7;ctx.strokeStyle=shade(o.top,-.3);for(let i=-2;i<=2;i++){ctx.beginPath();ctx.moveTo(i*1.8,-26);ctx.lineTo(i*2.6,-4);ctx.stroke()}}
    if(o.style==='gown'){ctx.strokeStyle=shade(o.top,-.18);ctx.lineWidth=.8;for(const i of [-8,-3,3,8]){ctx.beginPath();ctx.moveTo(i*.6,-26);ctx.quadraticCurveTo(i,-14,i*1.5,-2);ctx.stroke()}}
  } else if(bot==='skirt'){
    const p=skirtP(-27,(o.skEnd||-3)-bob,12.5,(o.skEnd?14.5:15)+fl);const bc=o.bottom;fillP(ctx,p,bc);if(o.bpat)withClip(ctx,p,()=>{drawPattern(ctx,o.bpat==='plaid'?'check':'floral',bc,o.accent,-30,-28,30,2);if(o.bpat==='plaid'){ctx.fillStyle='rgba(230,200,120,.35)';for(let x=-18;x<18;x+=5)ctx.fillRect(x+1.2,-28,.6,30);for(let y=-28;y<2;y+=5)ctx.fillRect(-20,y+1.2,40,.6)}});clothShade(ctx,p,-18-fl,18+fl,-28,0);
    const bp=(['batik','songket','zari','beads','motif','sequin','silver'].includes(o.pat))&&!(o.style==='casual');
    if(bp)withClip(ctx,p,()=>drawPattern(ctx,o.pat==='silver'?'beads':o.pat,bc,o.accent,-30,-28,30,2));
    if(o.style==='borneo'||o.style==='lehenga'){ctx.fillStyle=o.accent;ctx.fillRect(-18-fl,-9-bob,36+fl*2,1.8);ctx.fillRect(-18-fl,-6-bob,36+fl*2,1)}
    if(o.style==='kebaya'||o.style==='kedah'||o.style==='bodo'){ctx.strokeStyle=shade(bc,-.35);ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(4,-26);ctx.lineTo(7,-4);ctx.stroke()}
    if(o.style==='kurung'){ctx.strokeStyle=shade(bc,-.3);ctx.lineWidth=.7;ctx.beginPath();ctx.moveTo(-9,-10);ctx.lineTo(-11,-4);ctx.moveTo(9,-10);ctx.lineTo(11,-4);ctx.stroke()}
  } else if(bot==='pina'){
    const p=skirtP(-27,hij?-3-bob:-9-bob,12,15);fillP(ctx,p,o.bottom);
  }
  if(o.style==='borneo'&&bot==='pants'){ctx.fillStyle=o.accent;for(const i of [0,1]){ctx.fillRect(lx[i],-10+(i?lB:lA)-bob,7.5,1.6)}}
  // ----- neck
  ctx.fillStyle=shade(sk,-.08);ctx.fillRect(-4.5,-51,9,7);
  // ----- torso
  let te=S.one?-24:(o.te||S.top);if(o.style==='lehenga')te=-25;
  const tw=te<=-24?12.5:12.5+(te+24)*.27+(o.style==='bodo'?3:0);
  const tp=new Path2D();tp.moveTo(-9,-48);tp.quadraticCurveTo(-15.5,-48,-15.5,-42);tp.lineTo(-12.5,-28);tp.lineTo(-tw,te);tp.quadraticCurveTo(0,te+1.5,tw,te);tp.lineTo(12.5,-28);tp.lineTo(15.5,-42);tp.quadraticCurveTo(15.5,-48,9,-48);tp.closePath();
  if(o.style==='pinafore'||o.style==='labcoat'||o.style==='apron'){topCol=o.style==='labcoat'?'#cfe3f7':o.top}
  if(o.style==='sari'||o.style==='lehenga')topCol=shade(o.top,-.12);
  if(o.style==='blazer'||o.style==='suit')topCol='#ffffff';
  if(o.pat==='silver')topCol='#3a2a2a';
  fillP(ctx,tp,topCol);clothShade(ctx,tp,-16,16,-50,te+1);{ctx.save();ctx.clip(tp);ctx.fillStyle='rgba(40,15,60,.16)';ctx.beginPath();ctx.ellipse(0,-48.5,9,3.4,0,0,TAU);ctx.fill();ctx.restore()}
  const tpat=(['batik','floral','check'].includes(o.pat)&&['casual','kedah','tunic'].includes(o.style)&&!(o.style==='kedah'))||['cloud','zari'].includes(o.pat)&&!S.one||(o.pat==='songket'&&['kurung','bodo'].includes(o.style))||(['beads','motif','sequin'].includes(o.pat)&&o.style==='borneo');
  if(tpat)withClip(ctx,tp,()=>drawPattern(ctx,o.pat,topCol,o.accent,-18,-50,18,te+2));
  if(o.pat==='floral'&&o.style==='casual')withClip(ctx,tp,()=>drawPattern(ctx,'floral',topCol,o.accent,-18,-50,18,te+2));
  if(o.pat==='batikshirt')withClip(ctx,tp,()=>{drawPattern(ctx,'batik',topCol,o.accent,-18,-50,18,te+2);ctx.strokeStyle=o.accent;ctx.globalAlpha=.55;ctx.lineWidth=.6;for(let y=-46;y<te;y+=6){ctx.beginPath();ctx.moveTo(-16,y);ctx.bezierCurveTo(-8,y-3,-4,y+3,4,y);ctx.bezierCurveTo(9,y-3,13,y+2,17,y);ctx.stroke()}ctx.globalAlpha=1});
  if(o.pat==='hawaii')withClip(ctx,tp,()=>{for(const [fx,fy,r] of [[-8,-42,3.6],[7,-37,4.2],[-5,-29,3.4],[10,-26,3],[2,-46,2.6],[-12,-34,2.6],[0,-23,2.8]]){ctx.fillStyle='#2f8a4a';ctx.beginPath();ctx.ellipse(fx+r*.9,fy+r*.7,r*.6,r*.22,.6,0,TAU);ctx.fill();ctx.fillStyle=o.accent;for(let k=0;k<5;k++){const a=k/5*TAU;ctx.beginPath();ctx.ellipse(fx+Math.cos(a)*r*.55,fy+Math.sin(a)*r*.55,r*.52,r*.34,a,0,TAU);ctx.fill()}ctx.fillStyle='#fff3c4';ctx.beginPath();ctx.arc(fx,fy,r*.26,0,TAU);ctx.fill()}});
  if(o.belt&&!S.one){const bcol=o.style==='borneo'?o.accent:'#4a3222';const bw=te<=-24?12.5:tw;ctx.fillStyle=bcol;ctx.fillRect(-bw,te-1.4,bw*2,2.8);ctx.fillStyle=o.style==='borneo'?shade(o.accent,.3):'#e2c06a';ctx.fillRect(-2,te-2,4,4);ctx.fillStyle=bcol;ctx.fillRect(-.9,te-.9,1.8,1.8)}
  // ----- garment details
  const line=(c,w,pts)=>{ctx.strokeStyle=c;ctx.lineWidth=w;ctx.beginPath();pts.forEach(([a,b],i)=>i?ctx.lineTo(a,b):ctx.moveTo(a,b));ctx.stroke()};
  const dot=(c,x,y,r)=>{ctx.fillStyle=c;ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.fill()};
  if(!back){
   const dk=shade(o.top,-.35);
   switch(o.style){
   case 'casual':
    if(o.pat==='hoodie'){line(shade(o.top,-.25),3,[[-9,-48],[0,-43],[9,-48]]);line('#fff',.8,[[-3,-44],[-3,-36]]);line('#fff',.8,[[3,-44],[3,-36]]);const k=new Path2D();rrp(k,-8,-31,16,8,3);fillP(ctx,k,shade(o.top,-.08),.6)}
    if(o.pat==='jacket'||o.pat==='varsity'){ctx.fillStyle=o.pat==='varsity'?'#ffffff':'#f2f2f2';ctx.fillRect(-3,-47,6,te+47);line(dk,1,[[-3,-47],[-3,te]]);line(dk,1,[[3,-47],[3,te]]);line(shade(o.top,-.2),2.2,[[-9,-48],[-3,-40]]);line(shade(o.top,-.2),2.2,[[9,-48],[3,-40]]);if(o.pat==='varsity'){ctx.fillStyle=o.accent;ctx.fillRect(-tw,te-3,tw*2,2)}}
    if(o.pat==='cardigan'){ctx.fillStyle=o.accent;ctx.beginPath();ctx.moveTo(-6,-48);ctx.lineTo(0,-38);ctx.lineTo(6,-48);ctx.fill();line(dk,.8,[[0,-38],[0,te]]);for(let y=-36;y<te;y+=4)dot(shade(o.top,-.5),1.6,y,.7)}
    if(o.pat==='collar'){ctx.fillStyle='#fff';ctx.beginPath();ctx.moveTo(-8,-48);ctx.lineTo(0,-43);ctx.lineTo(-3,-41);ctx.closePath();ctx.moveTo(8,-48);ctx.lineTo(0,-43);ctx.lineTo(3,-41);ctx.closePath();ctx.fill()}
    if(!o.pat||o.pat==='batik'||o.pat==='floral'||o.pat==='check')line(shade(o.top,-.3),1,[[-5,-48],[0,-45],[5,-48]]);
    break;
   case 'skirt':case 'kedah':case 'tunic':line(shade(o.top,-.3),1,[[-5,-48],[0,-44],[5,-48]]);if(o.pat==='cardigan'||o.pat==='collar'){line(dk,.8,[[0,-44],[0,te]])}break;
   case 'uniform':
    ctx.fillStyle=shade(o.top,-.1);ctx.beginPath();ctx.moveTo(-8,-48);ctx.lineTo(0,-43);ctx.lineTo(-3,-40);ctx.closePath();ctx.moveTo(8,-48);ctx.lineTo(0,-43);ctx.lineTo(3,-40);ctx.closePath();ctx.fill();
    if(o.pat==='tie'){ctx.fillStyle=o.accent;ctx.beginPath();ctx.moveTo(-1.6,-43);ctx.lineTo(1.6,-43);ctx.lineTo(2.4,-31);ctx.lineTo(0,-29);ctx.lineTo(-2.4,-31);ctx.fill()}
    if(o.pat==='badge'){dot(o.accent,-7,-38,1.8);ctx.fillStyle=o.accent;ctx.fillRect(-15,-47,6,1.6);ctx.fillRect(9,-47,6,1.6);line(dk,.8,[[0,-43],[0,te]])}
    if(o.pat==='reflect'){ctx.fillStyle=o.accent;ctx.fillRect(-tw,-31,tw*2,2.2);ctx.fillRect(-tw,-26,tw*2,1.4);ctx.fillStyle='#c0c0c0';ctx.fillRect(-tw,-30,tw*2,.6)}
    break;
   case 'kurung':
    line(shade(o.top,-.35),1,[[-4.5,-48],[0,-45],[4.5,-48]]);line(shade(o.top,-.35),.8,[[0,-45],[0,-40]]);
    if(o.pat==='goldtrim'){ctx.fillStyle=o.accent;ctx.fillRect(-tw,te-2.5,tw*2,1.6);line(o.accent,1.2,[[-5,-48],[0,-44],[5,-48]])}
    break;
   case 'pinafore':{const p=new Path2D();p.moveTo(-9,-40);p.lineTo(9,-40);p.lineTo(12,-27);p.lineTo(-12,-27);p.closePath();fillP(ctx,p,o.bottom);line(o.bottom,2,[[-8,-40],[-9,-48]]);line(o.bottom,2,[[8,-40],[9,-48]]);ctx.fillStyle=o.bottom;ctx.fillRect(-12,-29,24,3)}break;
   case 'sport':ctx.fillStyle=o.accent;ctx.fillRect(-tw+1,-46,2,te+46);ctx.fillRect(tw-3,-46,2,te+46);line(shade(o.top,-.3),1.6,[[-5,-48],[0,-44],[5,-48]]);break;
   case 'nurse':line(o.accent,1.4,[[-7,-48],[0,-41],[7,-48]]);{const k=new Path2D();rrp(k,4,-38,6,5,1);fillP(ctx,k,o.top,.6)}line(o.accent,.8,[[5,-38],[5,-34]]);break;
   case 'labcoat':{const c=new Path2D();c.moveTo(-15.5,-44);c.lineTo(-3,-47);c.lineTo(-4,-28);c.lineTo(-3,-9);c.lineTo(-15.5,-9);c.closePath();c.moveTo(15.5,-44);c.lineTo(3,-47);c.lineTo(4,-28);c.lineTo(3,-9);c.lineTo(15.5,-9);c.closePath();fillP(ctx,c,'#ffffff');
     ctx.strokeStyle='#3a3f4a';ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(-6,-47);ctx.quadraticCurveTo(-8,-34,-1,-32);ctx.quadraticCurveTo(6,-34,6,-47);ctx.stroke();dot('#9aa',-1,-32,1.6);ctx.fillStyle=o.accent;ctx.fillRect(7,-40,4,1.4)}break;
   case 'chef':for(let y=-42;y<-23;y+=5){dot('#2b2b33',-3.5,y,.9);dot('#2b2b33',3.5,y,.9)}line(shade('#fff',-.3),1,[[-6,-48],[0,-45],[6,-48]]);ctx.fillStyle='#e63946';ctx.fillRect(-6,-49,12,2);break;
   case 'office':ctx.fillStyle='#fff';ctx.beginPath();ctx.moveTo(-7,-48);ctx.lineTo(0,-44);ctx.lineTo(-3,-41);ctx.closePath();ctx.moveTo(7,-48);ctx.lineTo(0,-44);ctx.lineTo(3,-41);ctx.fill();
     if(!fem){ctx.fillStyle=o.accent;ctx.beginPath();ctx.moveTo(-1.5,-44);ctx.lineTo(1.5,-44);ctx.lineTo(2.2,-30);ctx.lineTo(0,-28);ctx.lineTo(-2.2,-30);ctx.fill()}
     else{line(o.accent,.9,[[-5,-47],[0,-34],[5,-47]]);const k=new Path2D();rrp(k,-2.5,-35,5,6,1);fillP(ctx,k,'#fff',.6)}break;
   case 'apron':{const a=new Path2D();rrp(a,-10,-40,20,te<-20?32:30,3);fillP(ctx,a,o.accent);line(o.accent,1.4,[[-8,-40],[-6,-48]]);line(o.accent,1.4,[[8,-40],[6,-48]]);const k=new Path2D();rrp(k,-5,-30,10,5,1);fillP(ctx,k,shade(o.accent,-.1),.6)}break;
   case 'blazer':case 'suit':{const c=new Path2D();c.moveTo(-15.5,-44);c.lineTo(-6,-48);c.lineTo(-1,-34);c.lineTo(-1,te);c.lineTo(-tw,te);c.lineTo(-12.5,-28);c.closePath();c.moveTo(15.5,-44);c.lineTo(6,-48);c.lineTo(1,-34);c.lineTo(1,te);c.lineTo(tw,te);c.lineTo(12.5,-28);c.closePath();fillP(ctx,c,o.top);
     line(shade(o.top,-.4),1,[[-6,-48],[-4,-38],[-1,-34]]);line(shade(o.top,-.4),1,[[6,-48],[4,-38],[1,-34]]);
     if(o.style==='suit'){ctx.fillStyle=o.accent;ctx.beginPath();ctx.moveTo(-1.4,-46);ctx.lineTo(1.4,-46);ctx.lineTo(2,-35);ctx.lineTo(0,-33);ctx.lineTo(-2,-35);ctx.fill()}
     dot(shade(o.top,-.5),-2.5,-28,.8)}break;
   case 'bajumelayu':
     if(o.pat==='kelim'){line(o.accent,1.2,[[-5,-48],[0,-45],[5,-48]]);line(o.accent,.9,[[0,-45],[0,-38]])}
     else{ctx.fillStyle=shade(o.top,-.1);ctx.fillRect(-5,-49,10,3);line(shade(o.top,-.4),.6,[[-5,-49],[5,-49]])}
     for(const y of [-44,-40,-36])dot(o.accent,0,y,1.1);
     {const sm=new Path2D();sm.moveTo(-14,-30);sm.lineTo(14,-30);sm.lineTo(15,-14);sm.lineTo(-2,-11);sm.lineTo(-15,-14);sm.closePath();const smc=o.id==='t2'?'#7a1f2b':o.id==='f5'?'#e8d6a8':o.id==='t1'?'#3a1f6e':shade(o.top,o.top==='#1d1d24'||o.top==='#17171c'?.12:-.1);
      fillP(ctx,sm,smc);withClip(ctx,sm,()=>drawPattern(ctx,o.pat==='goldtrim'?'zari':'songket',smc,o.accent,-16,-31,16,-10));ctx.fillStyle=o.accent;ctx.fillRect(-14,-30,28,1.4);
      if(o.pat==='goldtrim'){ctx.fillStyle=o.accent;ctx.fillRect(-tw,te-2,tw*2,1.4);line(o.accent,1,[[-5,-48],[0,-42],[5,-48]])}}
     break;
   case 'kebaya':{ctx.fillStyle=o.pat==='batik'&&o.accent==='#ffffff'?'#fff':shade(o.top,.4);ctx.beginPath();ctx.moveTo(-6,-48);ctx.lineTo(0,-33);ctx.lineTo(6,-48);ctx.fill();
     line(shade(o.top,-.35),1,[[-6,-48],[0,-33],[6,-48]]);line(shade(o.top,-.35),1,[[0,-33],[-3,te]]);
     for(const y of [-40,-35,-30])dot('#f2c230',0,y+(y+40)*.1,1.6);
     if(o.accent==='#ffffff'){ctx.strokeStyle='#fff';ctx.lineWidth=.8;for(let x=-tw;x<tw;x+=3){ctx.beginPath();ctx.arc(x+1.5,te-1.5,1.4,0,Math.PI);ctx.stroke()}}}break;
   case 'cheongsam':case 'samfu':case 'robe':
     ctx.fillStyle=shade(o.top,-.08);ctx.fillRect(-5,-50,10,3.4);line(o.accent,.8,[[-5,-50],[5,-50]]);
     if(o.style==='cheongsam'){line(shade(o.top,-.45),1,[[0,-47],[8,-42],[12,-38]]);for(const [x,y] of [[4,-44.5],[9,-40.5]]){line(o.accent,1.3,[[x-1.6,y],[x+1.6,y]])}}
     else{for(let y=-44;y<(o.style==='robe'?-14:te-2);y+=5)line(o.accent,1.4,[[-2.2,y],[2.2,y]]);line(shade(o.top,-.45),.8,[[0,-47],[0,te]])}
     if(o.style==='robe'&&o.pat==='zari'){ctx.fillStyle=o.accent;ctx.fillRect(-tw,te-2,tw*2,1.6)}
     break;
   case 'sari':{const d=new Path2D();d.moveTo(-15,-46);d.lineTo(-8,-48);d.lineTo(14,-24);d.lineTo(14,-15);d.lineTo(6,-15);d.closePath();fillP(ctx,d,o.top);ctx.save();ctx.clip(d);drawPattern(ctx,'zari',o.top,o.accent,-16,-50,16,-14);ctx.restore();line(o.accent,1.6,[[-15,-46],[6,-15]]);line(o.accent,1.6,[[-8,-48],[14,-24]])}break;
   case 'kurta':case 'punjabi':
     ctx.fillStyle=shade(o.top,-.06);ctx.fillRect(-4,-50,8,3);line(shade(o.top,-.4),.8,[[0,-47],[0,-34]]);for(const y of [-44,-40,-36])dot(o.accent,0,y,.9);
     line(shade(o.top,-.3),.8,[[-tw+1,te],[-tw+.5,te-6]]);line(shade(o.top,-.3),.8,[[tw-1,te],[tw-.5,te-6]]);
     if(o.style==='punjabi'){ctx.globalAlpha=.9;line(o.accent,5,[[-12,-24],[-10,-46],[0,-42],[10,-46],[12,-24]]);ctx.globalAlpha=1}
     break;
   case 'lehenga':{ctx.fillStyle=o.accent;ctx.fillRect(-12.5,-27,25,1.6);ctx.globalAlpha=.75;const d=new Path2D();d.moveTo(-15,-46);d.lineTo(-8,-48);d.lineTo(16,-16);d.lineTo(9,-14);d.closePath();fillP(ctx,d,o.accent,0);ctx.globalAlpha=1;ctx.save();ctx.clip(d);drawPattern(ctx,'zari','#000','#ffffff',-16,-50,16,-12);ctx.restore()}break;
   case 'bodo':ctx.globalAlpha=.35;ctx.fillStyle='#fff';ctx.fill(tp);ctx.globalAlpha=1;line(o.accent,1,[[-5,-48],[0,-45],[5,-48]]);break;
   case 'borneo':
     ctx.fillStyle=o.accent;ctx.fillRect(-tw,te-3,tw*2,2);ctx.fillRect(-tw,te-5.2,tw*2,.9);line(o.accent,1.6,[[-6,-48],[0,-42],[6,-48]]);
     if(o.pat==='goldtrim'||o.pat==='coinbelt'){line(o.accent,1.2,[[0,-42],[0,te]]);for(let y=-40;y<te-4;y+=4)dot(o.accent,0,y,.9)}
     if(o.pat==='coinbelt'){for(let x=-12;x<=12;x+=3)dot(o.gold?'#f2c84a':'#d8dce4',x,-26,1.6);for(let x=-11;x<=11;x+=3)dot(o.gold?'#d9a520':'#b8bcc4',x,-23.5,1.3)}
     if(o.pat==='cross'){ctx.lineWidth=3;for(const [a,b] of [[[-14,-46],[12,-26]],[[14,-46],[-12,-26]]]){ctx.strokeStyle='#c8102e';ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);ctx.stroke()}ctx.lineWidth=1;ctx.strokeStyle='#f2c230';for(const [a,b] of [[[-14,-46],[12,-26]],[[14,-46],[-12,-26]]]){ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);ctx.stroke()}}
     if(o.pat==='silver'){for(let y=-44;y<te;y+=3){ctx.fillStyle=y%2?'#d4d8e0':'#aab0ba';ctx.fillRect(-tw,y,tw*2,1.6)}}
     if(o.top==='#6b4a2b'){ctx.strokeStyle=shade(o.top,-.3);ctx.lineWidth=.6;for(let x=-11;x<12;x+=3){ctx.beginPath();ctx.moveTo(x,-46);ctx.lineTo(x+1,te);ctx.stroke()}}
     break;
   case 'gown':ctx.fillStyle=o.accent;ctx.fillRect(-12.5,-28,25,2.2);line(shade(o.top,-.3),1,[[-7,-48],[0,-42],[7,-48]]);break;
   case 'dress':line(shade(o.top,-.3),1,[[-5,-48],[0,-44],[5,-48]]);if(o.pat==='goldtrim'){line(o.accent,1.2,[[0,-44],[0,-6]]);ctx.fillStyle=o.accent;ctx.fillRect(-16,-6,32,1.4)}else{ctx.fillStyle=shade(o.top,-.15);ctx.fillRect(-12.5,-28,25,1.6)}break;
   }
   const collar=(c,oc,big)=>{ctx.fillStyle=c;ctx.strokeStyle=oc;ctx.lineWidth=.7;const b=big?1.4:1;for(const sd of [-1,1]){ctx.beginPath();ctx.moveTo(sd*9*b,-48.6);ctx.lineTo(sd*1,-44);ctx.lineTo(sd*5.8*b,-40.5);ctx.closePath();ctx.fill();ctx.stroke()}};
   if(o.pat==='blouse'){collar('#ffffff','#b9b2c8');line('#d9d3e6',.7,[[0,-44],[0,te]]);for(let y=-41;y<te-1;y+=4)dot('#cfc6e0',0,y,.8)}
   if(o.pat==='cardigan'&&o.style==='skirt'){ctx.fillStyle=o.accent;ctx.beginPath();ctx.moveTo(-6,-48);ctx.lineTo(0,-37);ctx.lineTo(6,-48);ctx.fill();line(dk,.8,[[0,-37],[0,te]]);for(let y=-35;y<te;y+=4)dot(shade(o.top,-.45),1.7,y,.75)}
   if(o.pat==='denim'){ctx.fillStyle=o.accent;ctx.beginPath();ctx.moveTo(-5,-48);ctx.lineTo(5,-48);ctx.lineTo(3.2,te);ctx.lineTo(-3.2,te);ctx.fill();line(dk,1,[[-4,-46],[-3.2,te]]);line(dk,1,[[4,-46],[3.2,te]]);collar(shade(o.top,-.1),dk,1);
     for(const sd of [-1,1]){const k=new Path2D();rrp(k,sd>0?5.5:-11.5,-39,6,5.4,1);fillP(ctx,k,shade(o.top,-.04),.6);line(dk,.6,[[sd>0?5.5:-11.5,-37.2],[sd>0?11.5:-5.5,-37.2]]);dot('#d9b44a',sd*8.5,-36.6,.6)}
     ctx.fillStyle=shade(o.top,-.15);ctx.fillRect(-tw,te-2.6,tw*2,2.6);ctx.strokeStyle=shade(o.top,.35);ctx.setLineDash([1,1]);ctx.lineWidth=.4;ctx.beginPath();ctx.moveTo(-tw,te-3.2);ctx.lineTo(-4,te-3.2);ctx.moveTo(4,te-3.2);ctx.lineTo(tw,te-3.2);ctx.stroke();ctx.setLineDash([])}
   if(o.pat==='track'){ctx.fillStyle='#ffffff';ctx.beginPath();ctx.moveTo(-4.5,-48);ctx.lineTo(4.5,-48);ctx.lineTo(2.8,te);ctx.lineTo(-2.8,te);ctx.fill();line('#ffffff',1.1,[[-4,-47],[-3.2,te]]);line('#ffffff',1.1,[[4,-47],[3.2,te]]);
     const k=new Path2D();rrp(k,-9,-50.5,18,3.6,1.6);fillP(ctx,k,shade(o.top,.08),.6);line('#ffffff',.6,[[-8,-47.2],[8,-47.2]]);ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(-8.5,-39,1.3,0,TAU);ctx.fill();ctx.fillStyle=shade(o.top,.1);ctx.fillRect(-tw,te-2.4,tw*2,2.4)}
   if(o.pat==='lace'){ctx.strokeStyle='#e8dccb';ctx.lineWidth=.6;for(let x=-6;x<=6;x+=2){ctx.beginPath();ctx.arc(x,-47.6,1,0,Math.PI);ctx.stroke()}for(let x=-tw+1;x<tw;x+=2.4){ctx.beginPath();ctx.arc(x,te-1,1.1,0,Math.PI);ctx.stroke()}
     ctx.globalAlpha=.5;for(const x of [-7,-3.5,3.5,7]){ctx.beginPath();ctx.moveTo(x,-44);ctx.lineTo(x,te-2);ctx.stroke()}ctx.globalAlpha=1;for(let y=-44;y<te-2;y+=3.5)dot('#e2d4c2',0,y,.7)}
   if(o.pat==='batikshirt'||o.pat==='hawaii'){if(o.pat==='hawaii'){ctx.fillStyle=sk;ctx.beginPath();ctx.moveTo(-4,-48);ctx.lineTo(0,-41);ctx.lineTo(4,-48);ctx.fill()}collar(shade(o.top,o.pat==='hawaii'?.06:-.06),shade(o.top,-.45),1);line(shade(o.top,-.35),.7,[[0,-41],[0,te]]);for(let y=-38;y<te-1;y+=4.5)dot(shade(o.top,.5),.9,y,.7)}
   if(o.pat==='lanyard'){ctx.strokeStyle='#2c56b8';ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(-6.5,-48);ctx.lineTo(-1.4,-33);ctx.moveTo(6.5,-48);ctx.lineTo(1.4,-33);ctx.stroke();const k=new Path2D();rrp(k,-3.4,-34,6.8,8.4,1);fillP(ctx,k,'#ffffff',.6);ctx.fillStyle='#2c56b8';ctx.fillRect(-3.4,-34,6.8,2);ctx.fillStyle='#c9c2da';ctx.fillRect(-2.2,-30.8,2.2,2.6);ctx.fillRect(.6,-30.4,2,.7);ctx.fillRect(.6,-29.2,2,.7)}
  } else {
   if(o.style==='bajumelayu'){const sm=new Path2D();sm.moveTo(-14,-30);sm.lineTo(14,-30);sm.lineTo(15,-14);sm.lineTo(-15,-14);sm.closePath();fillP(ctx,sm,shade(o.top,-.1));withClip(ctx,sm,()=>drawPattern(ctx,'songket',o.top,o.accent,-16,-31,16,-12))}
   if(o.style==='borneo'){ctx.fillStyle=o.accent;ctx.fillRect(-tw,te-3,tw*2,2)}
  }
  // ----- arms
  const sleeveCol=o.pat==='varsity'?o.accent:o.style==='labcoat'?'#ffffff':(o.style==='blazer'||o.style==='suit')?o.top:o.style==='sari'||o.style==='lehenga'?shade(o.top,-.12):o.pat==='silver'?'#3a2a2a':o.top;
  const sw=frame===1?2.2:frame===3?-2.2:0;
  for(const sd of (side?[1]:[-1,1])){
    const x0=sd*14.5,y0=-44,x1=sd*16.6+(side?sw*2:sd*sw*.4),y1=-26;
    ctx.lineCap='round';
    const seg=(c,w,ya,yb)=>{ctx.strokeStyle=c;ctx.lineWidth=w;ctx.beginPath();ctx.moveTo(x0+(x1-x0)*ya,y0+(y1-y0)*ya);ctx.lineTo(x0+(x1-x0)*yb,y0+(y1-y0)*yb);ctx.stroke()};
    seg(shade(sk,-.35),8.6,0,1);seg(sk,6.8,0,1);
    const sl=sleeve==='long'?.92:.42;
    seg(shade(sleeveCol,-.4),9.2,0,sl);seg(sleeveCol,7.4,0,sl);
    if(o.pat==='track'){ctx.strokeStyle='#ffffff';ctx.lineWidth=1.3;ctx.beginPath();ctx.moveTo(x0+sd*2.2,y0+1);ctx.lineTo(x0+(x1-x0)*sl+sd*2.6,y0+(y1-y0)*sl);ctx.stroke()}
    if(o.pat==='denim'||o.pat==='blouse'||o.pat==='lace'){ctx.strokeStyle=o.pat==='denim'?shade(sleeveCol,-.15):'#f1ece4';ctx.lineWidth=7.6;ctx.beginPath();const t=sl-.08;ctx.moveTo(x0+(x1-x0)*t,y0+(y1-y0)*t);ctx.lineTo(x0+(x1-x0)*sl,y0+(y1-y0)*sl);ctx.stroke()}
    if(o.style==='borneo'||(o.style==='bajumelayu'&&o.pat==='goldtrim')){ctx.strokeStyle=o.accent;ctx.lineWidth=7.4;ctx.beginPath();const t=sl-.06;ctx.moveTo(x0+(x1-x0)*t,y0+(y1-y0)*t);ctx.lineTo(x0+(x1-x0)*sl,y0+(y1-y0)*sl);ctx.stroke()}
    ctx.fillStyle=sk;ctx.beginPath();ctx.arc(x1,y1+1.6,3.6,0,TAU);ctx.fill();ctx.strokeStyle=shade(sk,-.35);ctx.lineWidth=.8;ctx.stroke();
    if(C.acc===4&&sd===-1){ctx.fillStyle='#2b2b33';ctx.fillRect(x1-3,y1-3,6,2.4);ctx.fillStyle='#f2c230';ctx.fillRect(x1-1.5,y1-2.6,3,1.6)}
  }
  // backpack straps / scarf / necklace / bags
  const bg=C.bag|0;
  if(bg===2){line('#6b4426',1.5,[[-11,-47],[11,-25]]);if(!back){const b=new Path2D();rrp(b,6.5,-27.5,10.5,8.4,2.6);fillP(ctx,b,'#8a5a3a',.8);line('#6e4529',.7,[[6.5,-24.8],[17,-24.8]]);dot('#e2c06a',11.7,-23.8,.9)}}
  if(bg>=3&&!back){const hx=16.6+(side?sw*2:sw*.4),hy=-24.4;
    if(bg===5){ctx.strokeStyle='#2a1a10';ctx.lineWidth=1.3;ctx.beginPath();ctx.arc(hx+1.5,hy+2.4,2.6,Math.PI,TAU);ctx.stroke();const b=new Path2D();rrp(b,hx-5,hy+2.4,13,9.6,1.6);fillP(ctx,b,'#4a2f1e',.8);ctx.fillStyle='#6a4630';ctx.fillRect(hx-5,hy+5,13,1);dot('#e2c06a',hx+1.5,hy+5.6,1)}
    else{const col=bg===3?'#efe1c6':'#d6ad6c';ctx.strokeStyle=shade(col,-.4);ctx.lineWidth=1.1;ctx.beginPath();ctx.moveTo(hx-2.4,hy+5);ctx.quadraticCurveTo(hx,hy-2.4,hx+3.4,hy+5);ctx.stroke();const b=new Path2D();b.moveTo(hx-4.6,hy+4.6);b.lineTo(hx+5.4,hy+4.6);b.lineTo(hx+6.6,hy+15.6);b.lineTo(hx-5.8,hy+15.6);b.closePath();fillP(ctx,b,col,.8);clothShade(ctx,b,hx-6,hx+7,hy+4,hy+16,.8);
      if(bg===4)withClip(ctx,b,()=>{ctx.strokeStyle=shade(col,-.25);ctx.lineWidth=.5;for(let y=hy+6;y<hy+16;y+=1.8){ctx.beginPath();ctx.moveTo(hx-7,y);ctx.lineTo(hx+8,y);ctx.stroke()}for(let x=hx-6;x<hx+8;x+=2){ctx.beginPath();ctx.moveTo(x,hy+4);ctx.lineTo(x+.8,hy+16);ctx.stroke()}});
      else{ctx.fillStyle='#d9c6a2';ctx.fillRect(hx-4.6,hy+4.6,10,1.6)}}}
  if(C.acc===6&&!back){ctx.strokeStyle='#1d1d24';ctx.lineWidth=2.2;ctx.beginPath();ctx.moveTo(-10.5,-44);ctx.quadraticCurveTo(0,-37.5,10.5,-44);ctx.stroke();for(const sd of [-1,1]){const p=new Path2D();p.ellipse(sd*11,-44.5,3.4,4.4,sd*.45,0,TAU);fillP(ctx,p,'#26262e',.7);ctx.fillStyle='#55556a';ctx.beginPath();ctx.ellipse(sd*11,-44.5,1.6,2.4,sd*.45,0,TAU);ctx.fill()}}
  if(C.acc===1||bg===1){if(back){const b=new Path2D();rrp(b,-11,-46,22,22,5);fillP(ctx,b,'#3a5a9a')}else{line('#2b3a5a',2.2,[[-9,-47],[-10,-30]]);line('#2b3a5a',2.2,[[9,-47],[10,-30]])}}
  if(C.acc===3){line('#5a3a20',1.6,[[-11,-47],[11,-26]]);if(!back){const b=new Path2D();rrp(b,7,-28,9,8,2.5);fillP(ctx,b,'#c8603a',.8)}}
  if(C.neck===2){line('#c8102e',4.5,[[-8,-47],[0,-45],[8,-47]]);if(!back)line('#c8102e',3.6,[[4,-45],[6,-36]])}
  if(C.neck===1&&!back&&!hij){ctx.strokeStyle='#f2c230';ctx.lineWidth=.9;ctx.beginPath();ctx.moveTo(-5,-48);ctx.quadraticCurveTo(0,-39,5,-48);ctx.stroke();dot('#f2c230',0,-41,1.3)}
  if(C.neck===3&&!back&&!hij){const bc=['#e63946','#f2c230','#fff','#2ec4b6'];for(let i=0;i<9;i++){const a=Math.PI*(.12+i*.095);dot(bc[i%4],Math.cos(a)*7,-49+Math.sin(a)*8,1.1)}}
  // ----- hijab / head
  ctx.restore();ctx.save();ctx.translate(0,bob*bsy);headXf();
  if(hij){
    drawHijab(ctx,C,back);
    if(!back){ctx.save();ctx.translate(0,headY-bob);const fp=new Path2D();fp.ellipse(side?3:0,2,20.5,21.5,0,0,TAU);fillP(ctx,fp,sk,.8);skinShade(ctx,fp,sk);ctx.strokeStyle=shade(HIJAB_COL[C.hijabCol]||'#ccc',-.2);ctx.lineWidth=2.2;ctx.beginPath();ctx.ellipse(side?3:0,2,20.5,21.5,0,Math.PI*1.12,Math.PI*1.88);ctx.stroke();drawFace(ctx,C,side);ctx.restore()}
  } else {
    ctx.save();ctx.translate(0,headY-bob);
    if(!back){ctx.fillStyle=sk;for(const sx of (side?[-1]:[-1,1])){ctx.beginPath();ctx.ellipse(sx*23.5,3,3.6,5,0,0,TAU);ctx.fill();ctx.strokeStyle=shade(sk,-.35);ctx.lineWidth=.8;ctx.stroke()}}
    const hd=headPath(C.face);fillP(ctx,hd,sk,.9);if(!back)skinShade(ctx,hd,sk);
    if(back){if(hp.back)hairFill(ctx,hp.back,shade(hc,-.06),-24,36);ctx.strokeStyle=shade(hc,-.55);ctx.lineWidth=2.2;if(!hp.back)ctx.stroke(hd);ctx.stroke(hp.front);hairFill(ctx,hd,hc,-30,24,false,true);hairFill(ctx,hp.front,hc,-30,24,false,true);ctx.save();ctx.clip(hd);ctx.strokeStyle='rgba(255,255,255,.35)';ctx.lineWidth=2.6;ctx.beginPath();ctx.arc(0,-1,19.5,Math.PI*1.15,Math.PI*1.45);ctx.stroke();ctx.strokeStyle=shade(hc,-.35);ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(0,-20);ctx.quadraticCurveTo(-2,0,0,20);ctx.stroke();ctx.restore();if(hp.tail==='pony'){const t=new Path2D();t.moveTo(-4,-6);t.quadraticCurveTo(6,10,0,30);t.quadraticCurveTo(-6,12,-6,-4);fillP(ctx,t,shade(hc,-.06))}}
    else{
      drawFace(ctx,C,side);
      hairShadow(ctx,hd,hp.front,sk);
      hairFill(ctx,hp.front,hc,-30,10,true);
      if(C.g==='f'&&[0,1,7,8,9].includes(C.hair)){for(const sx of (C.hair===7?[-1]:[-1,1])){const l=new Path2D();l.moveTo(sx*25,-2);l.quadraticCurveTo(sx*29,14,sx*24.5,30);l.quadraticCurveTo(sx*22.5,22,sx*21,25);l.quadraticCurveTo(sx*20.5,12,sx*20,2);l.closePath();hairFill(ctx,l,hc,-2,30)}}
      if(C.g==='f'&&C.hair===4){for(const sx of [-1,1]){const l=new Path2D();l.moveTo(sx*25,-2);l.quadraticCurveTo(sx*27.5,10,sx*22,15);l.quadraticCurveTo(sx*21,8,sx*19,0);l.closePath();hairFill(ctx,l,hc,-2,15)}}
      if(C.g==='m'&&[0,1,6].includes(C.hair)){for(const sx of [-1,1]){const l=new Path2D();l.moveTo(sx*25.5,0);l.quadraticCurveTo(sx*26.5,9,sx*23.5,14);l.quadraticCurveTo(sx*22.5,7,sx*20.5,2);l.closePath();hairFill(ctx,l,hc,0,14)}}
      if(hp.ahoge&&!C.hat&&!o.head){const a=new Path2D();a.moveTo(-2,-27.5);a.quadraticCurveTo(-1,-38,7,-39.5);a.quadraticCurveTo(2,-36.5,1.6,-27.5);a.closePath();hairFill(ctx,a,hc,-40,-26)}
      if(C.ear){for(const ex of (side?[-23.5]:[-23.5,23.5])){if(C.ear===2){ctx.strokeStyle='#f2c230';ctx.lineWidth=1;ctx.beginPath();ctx.arc(ex,11,2.6,0,TAU);ctx.stroke()}else dot(C.ear===3?'#fffaf0':'#f2c230',ex,9.5,C.ear===3?1.8:1.3)}}
    }
    if(hp.tail==='bun'){const b=new Path2D();b.arc(0,-27,9.5,0,TAU);hairFill(ctx,b,hc,-36,-18);ctx.strokeStyle='rgba(255,255,255,.35)';ctx.lineWidth=1.6;ctx.beginPath();ctx.arc(0,-27,6,Math.PI*1.1,Math.PI*1.5);ctx.stroke()}
    if(hp.tail==='braid'&&!back){for(let i=0;i<5;i++){const b=new Path2D();b.ellipse(21+i*1.2,10+i*5.6,4.4-i*.3,3.6,.3,0,TAU);hairFill(ctx,b,hc,6+i*5.6,14+i*5.6)}ctx.fillStyle='#ff7aa8';ctx.beginPath();ctx.arc(26,37,2.4,0,TAU);ctx.fill()}
    if(hp.tail==='twin'&&!back){ctx.fillStyle='#e63946';ctx.beginPath();ctx.arc(-22,-12,2.6,0,TAU);ctx.arc(22,-12,2.6,0,TAU);ctx.fill()}
    ctx.restore();
  }
  // ----- headwear / hat / glasses / headphones (head-local)
  ctx.save();ctx.translate(0,headY-bob);
  if(o.head&&o.head!=='veil')drawHeadwear(ctx,o.head,o,C);
  else if(C.hat)drawHat(ctx,C.hat);
  if(C.glasses===5&&!back){for(const x of [-9.5,9.5]){const p=new Path2D();rrp(p,x-8,-28,16,9,4);const g=ctx.createLinearGradient(0,-28,0,-19);g.addColorStop(0,'#1e1e2a');g.addColorStop(1,'#5a4a7a');ctx.fillStyle=g;ctx.fill(p);ctx.strokeStyle='#121218';ctx.lineWidth=1.2;ctx.stroke(p);ctx.fillStyle='rgba(255,255,255,.4)';ctx.fillRect(x-5,-26,3,3)}ctx.strokeStyle='#121218';ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(-1.6,-24.5);ctx.lineTo(1.6,-24.5);ctx.stroke()}
  if(!back&&C.glasses&&C.glasses!==5){
    const gx=side?[ -4,14]:[-10,10];
    ctx.lineWidth=1.3;ctx.strokeStyle='#2b2b33';
    for(const x of (side?[14]:gx)){ctx.beginPath();
      if(C.glasses===1)ctx.arc(x,3.6,8.2,0,TAU);
      else if(C.glasses===4){ctx.moveTo(x-8,-1);ctx.lineTo(x+8,-1);ctx.lineWidth=2.2}
      else{const p=new Path2D();rrp(p,x-8.5,-2.5,17,12,3);if(C.glasses===3){const g=ctx.createLinearGradient(0,-3,0,9);g.addColorStop(0,'#2a2a40');g.addColorStop(1,'#6a5a9a');ctx.fillStyle=g;ctx.fill(p);ctx.fillStyle='rgba(255,255,255,.4)';ctx.fillRect(x-5,0,3,4)}ctx.stroke(p);continue}
      ctx.stroke()}
    if(!side){ctx.beginPath();ctx.moveTo(-2,2);ctx.lineTo(2,2);ctx.stroke()}
  }
  if(C.acc===2||C.acc===5){const cat=C.acc===5,bc=cat?'#f3a9c8':'#f0a6c6';if(cat){for(const sd of [-1,1]){const e=new Path2D();e.moveTo(sd*10,-25);e.lineTo(sd*19,-38);e.lineTo(sd*23,-20);e.closePath();fillP(ctx,e,'#f6b8d1',.9);ctx.fillStyle='#ffdce9';ctx.beginPath();ctx.moveTo(sd*13.5,-25);ctx.lineTo(sd*18.6,-33);ctx.lineTo(sd*20.5,-23.5);ctx.fill()}}
    ctx.strokeStyle=shade(bc,-.35);ctx.lineWidth=4.6;ctx.beginPath();ctx.arc(0,-2,27,Math.PI*1.08,Math.PI*1.92);ctx.stroke();ctx.strokeStyle=bc;ctx.lineWidth=3;ctx.stroke();
    for(const sx of (side?[-1]:[-1,1])){const p=new Path2D();rrp(p,sx*27-4.5,-5,9,15,4.5);fillP(ctx,p,bc);ctx.fillStyle='#fff0f6';ctx.beginPath();ctx.ellipse(sx*27,2.5,2.2,4.4,0,0,TAU);ctx.fill()}}
  ctx.restore();
  ctx.restore();
  ctx.restore();
}
