// ===================== CORE STATE =====================
let S=null;
const SAVE_KEY='kotakita_dunia_malaysia_v1';
const $=q=>document.querySelector(q);
const fmt=n=>'RM '+Math.round(n).toLocaleString('en-MY');
const fmt2=n=>'RM '+(Math.round(n*100)/100).toLocaleString('en-MY',{minimumFractionDigits:2,maximumFractionDigits:2});
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const rnd=(a,b)=>a+Math.random()*(b-a);
const pick=a=>a[Math.floor(Math.random()*a.length)];
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const START_DAY=31+13; // 14 Februari

function newSave(look,name,stage){
  const g=look.g;
  S={v:1,name,look,stage,
    money:stage==='sekolah'?350:800,bank:0,debt:0,mortgage:null,
    xp:0,lvl:1,energy:100,stats:{akademik:stage==='sekolah'?25:40,karisma:20,cergas:20,gembira:65},
    time:START_DAY*1440+7*60,weather:'cerah',pos:null,
    owned:['h1','h2','h3','h4','s1','s2','s4',look.outfit].filter((v,i,a)=>a.indexOf(v)===i),
    ownedShoes:['sh1','sh2','sh3'],ownedHijab:[0,1],ownedGlasses:[0,1,2],ownedHats:[0,1],ownedAccs:[0,1],ownedBags:[0,1],ownedEars:[0,1],ownedNecks:[0],styles:[],gems:20,sk:{},mq:0,dq:null,wq:null,aqua:[],certs:[],
    school:{classes:0},spm:stage==='lepasan'?7:null,
    edu:null,apps:[],degrees:[],clubs:[],
    job:null,ptSkill:{},workLog:{},
    biz:{},
    home:{type:'keluarga',owned:false,rooms:{bilik:{wall:2,floor:0,items:['katil1','almari','meja']},tamu:{wall:0,floor:0,items:['sofa1','pasu']},dapur:{wall:5,floor:3,items:['dapurgas','meja2']},mandi:{wall:1,floor:3,items:['shower']},belajar:{wall:1,floor:0,items:[]},balkoni:{wall:0,floor:0,items:[]},laman:{wall:0,floor:0,items:['bunga']}}},
    furn:[],vehicles:[],ride:null,
    rod:0,rodsOwned:[0],baits:{cacing:15,udang:5},bait:'cacing',fishInv:[],fishdex:{},journal:[],consXP:0,
    farm:{plots:Array(6).fill(null),size:6,animals:[],barn:1},
    inv:{telur:4,padi:2,cili:3,kelapa:1,feed:10},
    friends:{},talked:{},msgd:{},gifted:{},invited:{},
    ach:{},notifs:[],msgs:[],visited:{},
    cnt:{shifts:0,fish:0,prot:0,harvest:0,cook:0,fest:0,champ:0,classes:0,released:0},
    festDone:{},daily:{},events:{},bday:[1+Math.floor(Math.random()*12),1+Math.floor(Math.random()*28)],
  };
  addMsg('Mak','Selamat datang ke Kota Kita!',`Assalamualaikum ${name}! Selamat memulakan hidup baharu di Kota Kita. Rumah keluarga kita di Kawasan Perumahan. Jangan lupa makan, dan rajin-rajin belajar dan bekerja ya. Mak dah letak sedikit duit dalam dompet.`);
  addMsg('Pusat Kerjaya','Peluang kerja sambilan',`Pelajar boleh bekerja sambilan sebagai barista, juruwang, tutor dan banyak lagi. Lihat menu Kerjaya.`);
  if(stage==='lepasan')addMsg('Lembaga Peperiksaan','Keputusan SPM anda',`Tahniah! Anda memperoleh 7A dalam SPM. Anda kini layak memohon ke universiti dan kolej. Buka menu Pendidikan.`);
  else addMsg('SMK Kota Kita','Tingkatan 5',`Hadiri 10 kelas di Sekolah Menengah dan duduki peperiksaan SPM untuk melayakkan diri ke universiti.`);
  rollMissions(dayIdx());checkAch(true);
}
function save(){if(!S)return;S.pos=[P.x,P.y];try{localStorage.setItem(SAVE_KEY,JSON.stringify(S))}catch(e){}}
function loadSave(){try{const t=localStorage.getItem(SAVE_KEY);return t?JSON.parse(t):null}catch(e){return null}}
function wipeSave(){try{localStorage.removeItem(SAVE_KEY)}catch(e){}}

// ---- date & time
const dayIdx=()=>Math.floor(S.time/1440);
function dateOf(d){const y=Math.floor(d/365)+1;let doy=d%365,m=0;while(doy>=MDAYS[m]){doy-=MDAYS[m];m++}return{y,m:m+1,d:doy+1,w:d%7}}
function dateStr(d){const t=dateOf(d===undefined?dayIdx():d);return`${WEEK[t.w]}, ${t.d} ${MONTHS[t.m-1]}`}
function timeStr(){const m=S.time%1440,h=Math.floor(m/60),mm=Math.floor(m%60);return`${h%12===0?12:h%12}:${String(mm).padStart(2,'0')} ${h<12?'pg':h<19?'ptg':'mlm'}`}
const hourNow=()=>(S.time%1440)/60;
function festToday(d){const t=dateOf(d===undefined?dayIdx():d);const f=FESTS.find(f=>f[0]===t.m&&f[1]===t.d);return f?{id:f[2],name:f[3],desc:f[4]}:null}

function advance(min){
  let left=min;
  while(left>0){
    const step=Math.min(left,60);
    const before=dayIdx();
    S.time+=step;left-=step;
    // energy drain
    S.energy=Math.max(0,S.energy-step/60*1.1);
    // farm
    for(const p of S.farm.plots){if(p&&p.wet>S.time-step){const g=Math.min(step,p.wet-(S.time-step));p.g+=g}}
    for(const a of S.farm.animals){const A=ANIMAL[a.t];if(a.fed>S.time-step&&!a.ready){a.prog+=Math.min(step,a.fed-(S.time-step));if(a.prog>=A.hrs*60){a.ready=true;a.prog=A.hrs*60}}}
    if(dayIdx()!==before)newDay();
  }
}
let tickAcc=0;
function gameTick(dt){
  tickAcc+=dt*2; // 1 real second = 2 game minutes
  if(tickAcc>=1){const m=Math.floor(tickAcc);tickAcc-=m;advance(m)}
  RT.saveT+=dt;if(RT.saveT>15){RT.saveT=0;save();checkAch()}
  RT.misT=(RT.misT||0)+dt;if(RT.misT>1.5){RT.misT=0;checkMissions()}
}

function newDay(){
  const d=dayIdx(),t=dateOf(d);
  // weather
  const wet=[11,12,1,2].includes(t.m)?.4:.2;const r=Math.random();
  S.weather=r<wet*.3?'ribut':r<wet?'hujan':r<wet+.22?'mendung':'cerah';
  if(S.weather==='hujan'||S.weather==='ribut'){for(const p of S.farm.plots)if(p)p.wet=S.time+1440;notify('Hujan hari ini — tanaman disiram secara semula jadi.')}
  if(S.weather==='ribut')notify('Amaran ribut petir! Memancing di laut ditutup hari ini.');
  rollMissions(d);
  S.talked={};S.msgd={};S.gifted={};S.invited={};S.daily={};
  S.stats.gembira=clamp(S.stats.gembira-2,0,100);
  // bank interest
  if(S.bank>0)S.bank+=S.bank*.0001;
  // business
  let bizTot=0;for(const id in S.biz){const B=BIZ.find(b=>b[0]===id),b=S.biz[id];const inc=B[3]*b.lvl*(1+.45*b.staff)*rnd(.8,1.2)-b.staff*B[6];b.last=Math.round(inc);b.total=(b.total||0)+inc;bizTot+=inc}
  if(Object.keys(S.biz).length){S.bank+=bizTot;trackInc('biz',bizTot);notify(`Pendapatan perniagaan semalam: ${fmt(bizTot)} (dimasukkan ke bank)`)}
  // monthly bills on day 1
  if(t.d===1){
    const H=HOUSE[S.home.type];
    if(!S.home.owned&&H.rent>0){payBill(H.rent,`Sewa ${H.name}`)}
    if(S.mortgage&&S.mortgage.left>0){const p=Math.min(S.mortgage.pay,S.mortgage.left);payBill(p,'Ansuran pinjaman perumahan');S.mortgage.left-=p}
    if(S.debt>0&&!S.edu){const p=Math.min(200,S.debt);payBill(p,'Bayaran balik pinjaman pendidikan');S.debt-=p}
  }
  // admissions
  for(const a of S.apps){if(a.status==='menunggu'&&a.day<d)decideApp(a)}
  // festival
  const f=festToday(d);RT.fest=f;
  if(f){addMsg('Kota Kita',`Selamat ${f.name}!`,`${f.desc} Datang ke Pusat Bandar untuk sertai sambutan hari ini.`);toast(`🎉 Hari ini: ${f.name}!`,'y')}
  // birthday
  if(t.m===S.bday[0]&&t.d===S.bday[1]){if(S.age!=null){S.age++;notify(`Umur anda kini ${S.age} tahun`);if(S.age===18)addMsg('Kota Kita','Selamat 18 tahun!','Anda kini dewasa: kerja sepenuh masa, perniagaan, sewa rumah dan pinjaman pendidikan telah dibuka.')}addMoney(100,'Hadiah hari jadi daripada keluarga');addMsg('Keluarga','Selamat Hari Jadi!',`Selamat hari jadi ${S.name}! Semoga panjang umur dan murah rezeki. Kami hadiahkan RM100.`);S.stats.gembira=clamp(S.stats.gembira+20,0,100)}
  // random events
  if(Math.random()<.06){const a=pick(NPCS),b=pick(NPCS.filter(n=>n[2]!==a[2]));S.events.wedding={day:d,a:a[0],b:b[0],names:`${a[1].split(' ')[0]} & ${b[1].split(' ')[0]}`};addMsg('Jemputan Kahwin',`Walimatul urus ${S.events.wedding.names}`,`Anda dijemput ke majlis perkahwinan ${S.events.wedding.names} hari ini di Pusat Bandar. Pakai baju tradisional atau formal untuk bonus!`)}
  if(t.w===5)notify('Sabtu: Gotong-royong di Kampung Tradisional hari ini.');
  if(t.w===6)notify('Ahad: Pertandingan Memancing di Jeti hari ini!');

  if(t.m===12&&t.d===1&&S.spm!=null)addMsg('Alumni SMK Kota Kita','Majlis Reunion Sekolah',`Jom hadir reunion sekolah hari ini di Sekolah Menengah!`);
  if(S.edu)S.edu.daysIn=(S.edu.daysIn||0)+1;
  save();
}
function payBill(amt,why){if(S.bank>=amt)S.bank-=amt;else if(S.bank+S.money>=amt){S.money-=amt-S.bank;S.bank=0}else{S.money=0;S.bank=0;S.stats.gembira=clamp(S.stats.gembira-10,0,100);addMsg('Notis Tunggakan',why,`Bayaran ${fmt(amt)} untuk ${why} tidak dapat dijelaskan sepenuhnya. Sila tambah simpanan anda.`);return}
  notify(`Bayaran ${why}: ${fmt(amt)}`)}

// ---- money / xp / energy
function addMoney(n,why){S.money+=n;if(why)toast(`+${fmt(n)} · ${why}`,'g');hud()}
function spend(n,why){if(n>0&&!(S.money+S.bank>=n)){toast(`Wang tidak cukup (perlu ${fmt(n)})`,'r');return false}S.cnt.buy=(S.cnt.buy||0)+1;if(S.money>=n){S.money-=n}else if(S.money+S.bank>=n){S.bank-=n-S.money;S.money=0}else{toast(`Wang tidak cukup (perlu ${fmt(n)})`,'r');return false}if(why)toast(`−${fmt(n)} · ${why}`);hud();return true}
const canPay=n=>S.money+S.bank>=n;
const xpNeed=l=>Math.round(100*Math.pow(l,1.35));
function addXP(n){
  n=Math.round(n*(S.stats.gembira>70?1.1:1));S.xp+=n;
  while(S.xp>=xpNeed(S.lvl)){S.xp-=xpNeed(S.lvl);S.lvl++;const bonus=50*S.lvl;S.money+=bonus;if(DLG){toast(`Naik ke Tahap ${S.lvl}! Ganjaran ${fmt(bonus)} & tenaga penuh`,'y');notify(`Naik ke Tahap ${S.lvl}`)}else showDlg({title:`Naik ke Tahap ${S.lvl}!`,body:`<p>Hebat, ${esc(S.name)}! Anda kini di <b>Tahap ${S.lvl}</b>.</p><div class="note g">Ganjaran: <b>${fmt(bonus)}</b> dan tenaga penuh.</div>`,buttons:[{label:'Teruskan',cls:'g',a:'closeDlg'}]});S.energy=maxEnergy()}
  hud();
}
const maxEnergy=()=>100+Math.floor(S.stats.cergas/5)+skillLv('sports')*2;
function useEnergy(n){if(S.energy<n){toast('Tenaga tidak cukup — makan atau tidur dahulu.','r');return false}S.energy-=n;hud();return true}
function gainEnergy(n){S.energy=clamp(S.energy+n,0,maxEnergy());hud()}
function stat(k,n){S.stats[k]=clamp((S.stats[k]||0)+n,0,100)}
function inv(id,n){S.inv[id]=(S.inv[id]||0)+n;if(S.inv[id]<=0)delete S.inv[id]}
function notify(t){S.notifs.unshift({t,d:dayIdx(),tm:timeStr()});if(S.notifs.length>60)S.notifs.length=60;hud()}
function addMsg(from,title,body){S.msgs.unshift({from,title,body,d:S?dayIdx():0,read:false});if(S.msgs.length>50)S.msgs.length=50;hud()}
function visit(id){if(!S.visited[id]){S.visited[id]=1;addXP(10)}}
function checkAch(silent){
  if(!S)return;
  for(const a of ACH){if(!S.ach[a[0]]&&a[3](S)){S.ach[a[0]]=dayIdx()+1;if(!silent){toast(`🏆 Pencapaian: ${a[1]}`,'y');notify(`Pencapaian dibuka: ${a[1]}`);S.xp+=40}}}
}
function netWorth(){return S.money+S.bank-S.debt-(S.mortgage?S.mortgage.left:0)+(S.home.owned?HOUSE[S.home.type].buy:0)}
// qualification helpers
function bestQual(){let r=S.spm!=null?1:0,q=S.spm!=null?'spm':null;for(const d of S.degrees){if(QRANK[d.level]>r){r=QRANK[d.level];q=d.level}}return{r,q}}
function hasQual(level,courses){
  if(level==='spm')return S.spm!=null&&S.spm>=0;
  return S.degrees.some(d=>QRANK[d.level]>=QRANK[level]&&(!courses||courses.includes(d.course)));
}
const isStudent=()=>S.stage==='sekolah'||!!S.edu;
function friendLvl(p){return p>=80?'Sahabat':p>=50?'Kawan Baik':p>=30?'Kawan Rapat':p>=10?'Kawan':'Kenalan'}
function addFriend(id,n){const m=(1+S.stats.karisma/200)*(1+skillLv('social')*.05);S.friends[id]=clamp((S.friends[id]||0)+n*m,0,100)}
function atLoc(id,r){const L=LOC[id];return Math.hypot(P.x-(L.door[0]*TS+16),P.y-(L.door[1]*TS+16))<(r||14)*TS}
function homeLoc(){return HOUSE[S.home.type].loc}

// ---- weather helpers
const WNAME={cerah:'Cerah',mendung:'Mendung',hujan:'Hujan',ribut:'Ribut Petir'};
function temp(){const h=hourNow(),base={cerah:31,mendung:29,hujan:26,ribut:25}[S.weather]||30;return Math.round(base+(h>11&&h<17?2:h<7||h>20?-3:0))}
const outdoorOK=()=>S.weather!=='ribut';
// ---- skills
const skillLv=id=>S&&S.sk?Math.min(10,Math.floor(Math.sqrt((S.sk[id]||0)/20))):0;
function addSkill(id,n){if(!S.sk)S.sk={};const b=skillLv(id);S.sk[id]=(S.sk[id]||0)+n;const a=skillLv(id);if(a>b){const k=SKILLS.find(x=>x[0]===id);toast(`Kemahiran ${k[1]} naik ke Tahap ${a}!`,'y');notify(`Kemahiran ${k[1]} kini Tahap ${a}`)}}
function addGems(n,why){S.gems=(S.gems||0)+n;if(why)toast(`+${n} permata · ${why}`,'y')}
// ---- missions
function rollMissions(d){
  if(!S.dq||S.dq.d!==d){const pool=DAILYQ.filter(q=>!['walk','talk'].includes(q[0]));const pick3=['walk','talk',pick(pool)[0]];S.dq={d,list:pick3.map(id=>{const q=DAILYQ.find(x=>x[0]===id);return{id,base:q[2](S),done:0}})}}
  const wk=Math.floor((d)/7);
  if(!S.wq||S.wq.w!==wk){const ids=[...WEEKLYQ].sort(()=>Math.random()-.5).slice(0,3).map(q=>q[0]);S.wq={w:wk,list:ids.map(id=>{const q=WEEKLYQ.find(x=>x[0]===id);return{id,base:q[2](S),done:0}})}}
}
function mqProg(m,tbl){const q=tbl.find(x=>x[0]===m.id);return{q,cur:Math.min(q[3],Math.max(0,q[2](S)-m.base))}}
function checkMissions(){
  if(!S)return;rollMissions(dayIdx());
  const M=mainQ()[S.mq];if(M&&M[1](S)){S.mq++;S.money+=M[2];addGems(M[3]);addXP(40+S.mq*10);toast(`Misi Utama selesai: ${M[0]} (+${fmt(M[2])})`,'g');notify(`Misi Utama selesai: ${M[0]}`)}
  for(const m of S.dq.list){const {q,cur}=mqProg(m,DAILYQ);if(!m.done&&cur>=q[3]){m.done=1;S.money+=40;addGems(3);addXP(25);S.cnt.dq=(S.cnt.dq||0)+1;toast(`Misi Harian selesai: ${q[1]} (+RM40, +3 permata)`,'g')}}
  for(const m of S.wq.list){const {q,cur}=mqProg(m,WEEKLYQ);if(!m.done&&cur>=q[3]){m.done=1;S.money+=200;addGems(15);addXP(100);toast(`Misi Mingguan selesai: ${q[1]} (+RM200, +15 permata)`,'y')}}
}
