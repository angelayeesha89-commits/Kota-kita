// ===================== CHARACTER CREATOR v2 (premium chibi, adult profile, state flags) =====================
const CR_BASE={pose:0,skin:1,face:0,eye:0,eyeCol:0,brow:1,nose:0,mouth:0,hair:0,hairCol:0,hijab:0,hijabSt:0,hijabCol:0,glasses:0,hat:0,acc:0,bag:0,ear:0,neck:0,beard:0,body:0,style:0,expr:0,shoes:'sh1'};
const crP=o=>Object.assign({},CR_BASE,o);
// the 16 reference characters ("Contoh Watak")
const PEN_LOOK=crP({g:'f',face:2,eye:3,hair:1,hairCol:2,glasses:5,ear:2,neck:1,outfit:'r15',bag:1,shoes:'sh12',brow:1,mouth:4});
const CR_PRESETS={
 f:[crP({g:'f',face:2,eye:3,hair:8,hairCol:2,glasses:6,hat:11,ear:2,mouth:1,brow:1,outfit:'r17',bag:6,shoes:'sh14',pose:1}),
    crP({g:'f',face:2,eye:3,hijab:1,hijabSt:0,hijabCol:4,glasses:6,mouth:1,brow:1,outfit:'r17',bag:6,shoes:'sh14',pose:1}),
    crP({g:'f',face:2,eye:3,hair:1,hairCol:2,glasses:5,ear:2,neck:1,outfit:'r15',bag:1,shoes:'sh12',brow:1,mouth:4}),
    crP({g:'f',face:2,eye:0,hijab:1,hijabSt:0,hijabCol:1,outfit:'r3',bag:3,shoes:'sh2'}),
    crP({g:'f',face:2,eye:3,hair:1,hairCol:2,hat:9,acc:7,outfit:'r16',bag:2,shoes:'sh13',mouth:3}),
    crP({g:'f',face:2,eye:3,hair:9,hairCol:0,acc:5,outfit:'r7',bag:1}),
    crP({g:'f',face:2,eye:3,hair:0,hairCol:0,ear:2,outfit:'t20',shoes:'sh11'}),
    crP({g:'f',face:2,eye:3,hair:8,hairCol:1,glasses:1,ear:2,outfit:'r5',bag:2})],
 m:[crP({g:'m',hair:6,hairCol:2,glasses:5,acc:6,mouth:1,brow:2,outfit:'r18',bag:7,shoes:'sh15',pose:2}),
    crP({g:'m',hair:6,hairCol:0,outfit:'h1',bag:1,brow:2}),
    crP({g:'m',hair:1,hairCol:2,glasses:1,outfit:'r9',bag:1,shoes:'sh9'}),
    crP({g:'m',hair:2,hairCol:0,hat:8,acc:6,outfit:'r10',brow:2}),
    crP({g:'m',hair:3,hairCol:1,outfit:'r11',acc:4,shoes:'sh9'}),
    crP({g:'m',hair:2,hairCol:0,outfit:'t19',shoes:'sh9',brow:2}),
    crP({g:'m',hair:6,hairCol:2,glasses:5,outfit:'r12',shoes:'sh11',expr:0,mouth:4}),
    crP({g:'m',hair:1,hairCol:0,outfit:'r14',bag:5,shoes:'sh9',brow:2})]};
const CR_STATE_ORDER=['perlis','selangor','melaka','labuan','kedah','kl','johor','kelantan','penang','nsembilan','pahang','sabah','perak','putrajaya','terengganu','sarawak'];
const CR_SHORT={kl:'K. LUMPUR',penang:'P. PINANG',nsembilan:'N. SEMBILAN'};
const CR_AGES=[18,19,20,21,22,23,24,25,26,27,28,29,30];
const CR_OUTFITS=['r17','r18','r16','r15','r1','r2','r3','r4','r5','r6','r7','h1','r9','r10','r11','r12','r13','r14','t19','t20','h2','h4','h5','h7','h8'];
const CRI={user:'<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4.2" fill="currentColor"/><path d="M3.5 21c.8-4.6 4.2-7 8.5-7s7.7 2.4 8.5 7z" fill="currentColor"/></svg>',
 info:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9.5" fill="none" stroke="currentColor" stroke-width="2.2"/><circle cx="12" cy="7.6" r="1.5" fill="currentColor"/><rect x="10.8" y="10.4" width="2.4" height="7.4" rx="1.2" fill="currentColor"/></svg>',
 cal:'<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="3" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M3 10h18M8 3v4M16 3v4" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><circle cx="8" cy="14.5" r="1.3" fill="currentColor"/><circle cx="12" cy="14.5" r="1.3" fill="currentColor"/><circle cx="16" cy="14.5" r="1.3" fill="currentColor"/></svg>',
 flag:'<svg viewBox="0 0 24 24"><path d="M5 21V4" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><path d="M5 4.5c4-2.4 7 2.2 13 0v9c-6 2.2-9-2.4-13 0z" fill="currentColor"/></svg>',
 pin:'<svg viewBox="0 0 24 24"><path d="M12 22s7-6.6 7-12.2A7 7 0 0 0 5 9.8C5 15.4 12 22 12 22z" fill="currentColor"/><circle cx="12" cy="9.6" r="2.6" fill="#fff"/></svg>',
 shirt:'<svg viewBox="0 0 24 24"><path d="M8.5 3 3 6.5l2.4 4.2 2.1-1.1V21h9V9.6l2.1 1.1L21 6.5 15.5 3c-.6 1.6-2 2.6-3.5 2.6S9.1 4.6 8.5 3z" fill="currentColor"/></svg>',
 check:'<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="#fff" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 close:'<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18" stroke="currentColor" stroke-width="2.8" stroke-linecap="round"/></svg>',
 dice:'<svg viewBox="0 0 24 24"><path d="M12 2.5 21 7.4v9.4L12 21.6 3 16.8V7.4z" fill="#7b4fe0"/><path d="M12 2.5 21 7.4 12 12.3 3 7.4z" fill="#a27cf5"/><path d="M12 12.3v9.3l9-4.8V7.4z" fill="#5a33c0"/><circle cx="12" cy="7.4" r="1.3" fill="#fff"/><circle cx="7" cy="12.6" r="1.2" fill="#fff"/><circle cx="8.8" cy="16.4" r="1.2" fill="#fff"/><circle cx="15" cy="14" r="1.2" fill="#fff"/><circle cx="18" cy="12" r="1.2" fill="#fff"/><circle cx="16.4" cy="17.6" r="1.2" fill="#fff"/></svg>'};
const CR_CATS=[
 ['rambut','Gaya Rambut','<svg viewBox="0 0 24 24"><path d="M4 13c0-6 3.6-9 8-9s8 3 8 9c-1.6-1.4-2.6-3.6-3-5.6-1.8 2-5.2 3.2-9 3-1.4 1-2.8 1.8-4 2.6z" fill="currentColor"/><path d="M6.5 12.6c.6 4.4 2.8 7.4 5.5 7.4s4.9-3 5.5-7.4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>'],
 ['warna','Warna Rambut','<svg viewBox="0 0 24 24"><path d="M12 3s6.5 7 6.5 11.4A6.5 6.5 0 0 1 5.5 14.4C5.5 10 12 3 12 3z" fill="currentColor"/><path d="M9 14.6a3 3 0 0 0 3 3" stroke="#fff" stroke-width="1.8" fill="none" stroke-linecap="round"/></svg>'],
 ['mata','Mata','<svg viewBox="0 0 24 24"><path d="M2 12s3.8-6.5 10-6.5S22 12 22 12s-3.8 6.5-10 6.5S2 12 2 12z" fill="none" stroke="currentColor" stroke-width="2.2"/><circle cx="12" cy="12" r="3.6" fill="currentColor"/><circle cx="10.8" cy="10.8" r="1.1" fill="#fff"/></svg>'],
 ['kening','Kening','<svg viewBox="0 0 24 24"><path d="M3 10c2.4-3 5.6-3.6 8-2M13 8c2.4-1.6 5.6-1 8 2" stroke="currentColor" stroke-width="2.6" fill="none" stroke-linecap="round"/><path d="M5 15.5c1.4-1.4 3.6-1.4 5 0M14 15.5c1.4-1.4 3.6-1.4 5 0" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg>'],
 ['wajah','Wajah & Ekspresi','<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9.4" fill="none" stroke="currentColor" stroke-width="2.2"/><circle cx="8.8" cy="10" r="1.4" fill="currentColor"/><circle cx="15.2" cy="10" r="1.4" fill="currentColor"/><path d="M8 14.2c2 2.6 6 2.6 8 0" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg>'],
 ['aksesori','Aksesori','<svg viewBox="0 0 24 24"><circle cx="6.5" cy="13" r="4" fill="none" stroke="currentColor" stroke-width="2.2"/><circle cx="17.5" cy="13" r="4" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M10.5 12.6c1-.9 2-.9 3 0M2.5 11 1.5 9M21.5 11l1-2" stroke="currentColor" stroke-width="2" stroke-linecap="round" fill="none"/></svg>'],
 ['pakaian','Pakaian',CRI.shirt],
 ['kasut','Kasut','<svg viewBox="0 0 24 24"><path d="M2.5 17.5V9.5h5.2l1.6 2.6 3.2-.6 4.5 2.4 4.4.9c.9.2 1.1 1 1.1 2.7z" fill="currentColor"/><rect x="2" y="17.4" width="20.6" height="2.8" rx="1.4" fill="currentColor" opacity=".55"/></svg>'],
 ['hijab','Hijab','<svg viewBox="0 0 24 24"><path d="M12 2.5c5 0 8 3.8 8 8.6 0 3.2-1.4 6.2-3.2 8.4L12 21.5l-4.8-2c-1.8-2.2-3.2-5.2-3.2-8.4 0-4.8 3-8.6 8-8.6z" fill="currentColor"/><ellipse cx="12" cy="11.6" rx="4.6" ry="5.2" fill="#fff"/></svg>'],
 ['gaya','Gaya & Badan','<svg viewBox="0 0 24 24"><path d="M12 2.5l2.2 5.6 5.8.5-4.4 3.8 1.4 5.8L12 15l-5 3.2 1.4-5.8L4 8.6l5.8-.5z" fill="currentColor"/></svg>']];

// ---- rendering helpers
function crHeadCentre(C,fy){return animeHeadCentre(C,fy)}
function crHeadCentreOld(C,fy){const CS=CSTYLES[C.style||0]||CSTYLES[0],BP=BODIES[C.body||0]||BODIES[0],hs=CS[1],bsy=BP[2]*CS[2];return{hs,cy:(-20+(fy||0))*hs-48*(bsy-1)-48}}
function crHead(C,size,zoom,fy){const k='crh'+JSON.stringify(C)+size+zoom+(fy||0);let u=imgCache.get(k);if(u)return u;
  const c=document.createElement('canvas');c.width=c.height=size;const x=c.getContext('2d');const {hs,cy}=crHeadCentre(C,fy);const s=size*zoom/(40*hs);
  drawChibi(x,size/2,size/2-cy*s,s,C,0,0);u=c.toDataURL();imgCache.set(k,u);if(imgCache.size>500)imgCache.delete(imgCache.keys().next().value);return u}
function crShoeImg(id,sk){const k='crs'+id+sk;let u=imgCache.get(k);if(u)return u;const c=document.createElement('canvas');c.width=120;c.height=72;const x=c.getContext('2d');x.save();x.scale(4,4);x.lineJoin='round';drawShoe(x,10,15,SHOE[id],0,SKIN[sk]);x.translate(9,0);drawShoe(x,10,15,SHOE[id],0,SKIN[sk]);x.restore();u=c.toDataURL();imgCache.set(k,u);return u}
const crChk=()=>`<span class="chk">${CRI.check}</span>`;
const crH=(icon,t,extra)=>`<div class="crh">${icon}<span>${t}</span>${extra||''}</div>`;
function crThumbs(key,list,cur,mk,cls){return`<div class="crthumbs ${cls||''}">${list.map((n,i)=>`<button class="${cur===i?'on':''}" data-a="crSet" data-v="${key}:${i}" aria-label="${esc(n)}"><img src="${mk(i)}" alt=""><small>${esc(n)}</small>${cur===i?crChk():''}</button>`).join('')}</div>`}
function crOpts(key,list,cur){return`<div class="opts">${list.map((n,i)=>`<button class="opt ${cur===i?'on':''}" data-a="crSet" data-v="${key}:${i}">${esc(n)}</button>`).join('')}</div>`}
function crSw(key,list,cur){return`<div class="crsw">${list.map((c,i)=>`<button class="${cur===i?'on':''}" style="background:${c}" data-a="crSet" data-v="${key}:${i}" aria-label="warna ${i+1}">${cur===i?crChk():''}</button>`).join('')}</div>`}
const crG=t=>`<div class="crg">${t}</div>`;

function crDrawer(L){
  const v=(o)=>Object.assign({},L,o);
  switch(CR.drawer){
  case 'rambut':return L.hijab?`<div class="note">Rambut tersembunyi semasa berhijab. Tukar di bahagian <b>Hijab</b>.</div>`:crThumbs('hair',L.g==='m'?HAIR_M:HAIR_F,L.hair,i=>crHead(v({hair:i,hat:0}),120,.92,-2));
  case 'warna':return`${crG('Warna Rambut')}${crSw('hairCol',HAIRCOL,L.hairCol)}<img class="crbig" src="${crHead(v({}),200,.95,-2)}" alt="">`;
  case 'mata':return`${crG('Bentuk Mata')}${crThumbs('eye',EYES,L.eye,i=>crHead(v({eye:i,expr:0}),120,1.9,4),'eyes')}${crG('Warna Mata')}${crSw('eyeCol',EYECOL,L.eyeCol)}`;
  case 'kening':return`${crThumbs('brow',BROWS,L.brow,i=>crHead(v({brow:i,expr:0,hair:L.g==='m'?5:4,hat:0}),120,1.7,-1),'eyes')}<div class="note">Kening mungkin tertutup sedikit oleh rambut depan.</div>`;
  case 'wajah':return`${crG('Ekspresi Muka')}${crThumbs('expr',EXPRS,L.expr||0,i=>crHead(v({expr:i}),120,1.15,4))}${crG('Bentuk Wajah')}${crOpts('face',FACES,L.face)}${crG('Hidung')}${crOpts('nose',NOSES,L.nose)}${crG('Mulut (ekspresi Biasa)')}${crOpts('mouth',MOUTHS,L.mouth)}`;
  case 'aksesori':return`${crG('Cermin Mata')}${crOpts('glasses',GLASSES.map(g=>g[0]),L.glasses)}${L.hijab?'':crG('Topi')+crOpts('hat',HATS.map(g=>g[0]),L.hat)}${crG('Beg')}${crOpts('bag',BAGS.map(g=>g[0]),L.bag||0)}${crG('Fon Kepala & Jam')}${crOpts('acc',ACCS.map(g=>g[0]),L.acc)}${L.hijab?'':crG('Anting-anting')+crOpts('ear',EARS.map(g=>g[0]),L.ear||0)}${crG('Leher')}${crOpts('neck',NECKS.map(g=>g[0]),L.neck||0)}<div class="note">Semua aksesori yang dipilih di sini menjadi milik anda.</div>`;
  case 'pakaian':{const ids=CR_OUTFITS.filter(i=>OUT[i]&&(OUT[i].g==='u'||OUT[i].g===L.g));return`<div class="crthumbs tall">${ids.map(i=>`<button class="${L.outfit===i?'on':''}" data-a="crSet" data-v="outfit:${i}"><img src="${charImg(v({outfit:i}),120,160,1.02,6)}" alt=""><small>${esc(OUT[i].name)}</small>${L.outfit===i?crChk():''}</button>`).join('')}</div><div class="note">Lebih 80 pakaian termasuk busana tradisional Melayu, Cina, India, Sabah & Sarawak boleh dibeli dalam permainan.</div>`}
  case 'kasut':return`<div class="crthumbs shoes">${SHOES.map(s=>`<button class="${L.shoes===s[0]?'on':''}" data-a="crShoe" data-v="${s[0]}"><img src="${crShoeImg(s[0],L.skin)}" alt=""><small>${esc(s[1])}</small>${L.shoes===s[0]?crChk():''}</button>`).join('')}</div>`;
  case 'hijab':return L.g!=='f'?'<div class="note">Pilihan hijab tersedia untuk watak perempuan.</div>':`<div class="gbtn"><button class="opt ${!L.hijab?'on':''}" data-a="crSet" data-v="hijab:0">Tanpa Hijab</button><button class="opt ${L.hijab?'on':''}" data-a="crSet" data-v="hijab:1">Berhijab</button></div>
    ${L.hijab?`${crG('Gaya Hijab')}${crThumbs('hijabSt',HIJAB_ST.map(h=>h[0]),L.hijabSt,i=>crHead(v({hijabSt:i}),120,.92,-2))}${crG('Warna Hijab')}${crSw('hijabCol',HIJAB_COL,L.hijabCol)}`:''}`;
  case 'gaya':return`${crG('Gaya Watak')}${crOpts('style',CSTYLES.map(c=>c[0]),L.style||0)}${crG('Pose')}${crOpts('pose',POSES,L.pose||0)}${crG('Bentuk Badan')}${crOpts('body',BODIES.map(b=>b[0]),L.body||0)}${L.g==='m'?crG('Misai & Janggut')+crOpts('beard',BEARDS,L.beard||0):''}`;
  }
  return'';
}
function crInfo(){const bg=CR.bg,st=STATE[CR.state];const hi=bg.degrees.length?degName(bg.degrees[bg.degrees.length-1]):bg.spm!=null?`SPM (${bg.spm}A)`:QUAL_NAME.none;
  return`<div class="crinfo"><p>Cipta karakter anda, pilih negeri asal, tetapkan umur, jantina dan rupa mengikut gaya anda. Karakter ini akan digunakan dalam permainan.</p>
  <div class="crsum"><span>Umur</span><b>${CR.age} tahun</b><span>Negeri</span><b>${flagTag(CR.state,13)} ${esc(st.name)}</b><span>Kampung</span><b>${esc(CR.town)}</b>
  <span>Pendidikan</span><b class="edu">${esc(hi)} <button class="mini" data-a="crBg" title="Jana semula latar pendidikan">🎲</button></b><span>Pengalaman</span><b>${bg.expYears} tahun</b><span>Mula sebagai</span><b>Dewasa · mencari kerja</b></div>
  <p class="crtip">Kelayakan menentukan jawatan yang boleh dipohon. Mohon kerja sepenuh masa di Pusat Kerjaya dan bekerja sambilan sementara menunggu.</p></div>`}

let _crScroll=0,_crDScroll=0;
renderCreator=function(){
  const L=CR.look,g=L.g;
  const sc=$('#cRight .crScroll'),ds=$('#cRight .crDBody');if(sc)_crScroll=sc.scrollTop;const keepD=ds&&CR._dOpen===CR.drawer;if(ds)_crDScroll=ds.scrollTop;
  $('#cLeft').innerHTML=`${crH(CRI.user,'Pilih Avatar')}<div class="crav">${CR_PRESETS[g].map((p,i)=>`<button class="${CR.preset===i?'on':''}" data-a="crPreset" data-v="${i}" aria-label="Avatar ${i+1}"><img src="${crHead(p,160,.95,7)}" alt="">${CR.preset===i?crChk():''}</button>`).join('')}</div>${crH(CRI.info,'Info')}${crInfo()}`;
  const ages=CR_AGES.map(a=>{const on=a===30?CR.age>=30:CR.age===a;return`<button class="${on?'on':''}" data-a="crAgeSel" data-v="${a}">${a===30?'30+':a}</button>`}).join('');
  const cats=CR_CATS.filter(c=>c[0]!=='hijab'||g==='f').map(c=>`<button class="${CR.drawer===c[0]?'on':''}" data-a="crCat" data-v="${c[0]}">${c[2]}<span>${c[1].replace(' & Ekspresi','').replace(' & Badan','')}</span></button>`).join('');
  const cat=CR_CATS.find(c=>c[0]===CR.drawer);
  $('#cRight').innerHTML=`<div class="crBody"><div class="crScroll">
    ${crH(CRI.cal,'Umur')}<div class="crages">${ages}</div>
    ${CR.age>=30?`<div class="crstep"><span>Umur tepat</span><button data-a="crAge30" data-v="-1" aria-label="Kurang">−</button><b>${CR.age}</b><button data-a="crAge30" data-v="1" aria-label="Tambah">+</button><small>(30–60 tahun)</small></div>`:''}
    ${crH(CRI.flag,'Negeri Asal (Malaysia)')}<div class="crflags">${CR_STATE_ORDER.map(id=>`<button class="${CR.state===id?'on':''}" data-a="crState" data-v="${id}"><img src="${flagImg(id)}" alt="Bendera ${esc(STATE[id].name)}"><b>${CR_SHORT[id]||STATE[id].name.toUpperCase()}</b>${CR.state===id?crChk():''}</button>`).join('')}</div>
    ${crH(CRI.pin,'Kampung Halaman',`<em>${esc(STATE[CR.state].name)}</em>`)}<div class="crtowns">${STATE[CR.state].towns.map(t=>`<button class="${CR.town===t?'on':''}" data-a="crTown" data-v="${esc(t)}">${esc(t)}</button>`).join('')}</div>
    ${crH(CRI.shirt,'Warna Kulit')}<div class="crskin">${SKIN.map((c,i)=>`<button class="${L.skin===i?'on':''}" style="background:linear-gradient(145deg,${shade(c,.18)},${c} 55%,${shade(c,-.12)})" data-a="crSet" data-v="skin:${i}" aria-label="Warna kulit ${i+1}">${L.skin===i?crChk():''}</button>`).join('')}</div>
  </div>
  ${cat?`<div class="crDrawer"><div class="crDHead">${cat[2]}<b>${cat[1]}</b><button class="crX" data-a="crCat" data-v="${cat[0]}" aria-label="Tutup">${CRI.close}</button></div><div class="crDBody">${crDrawer(L)}</div><button class="crDone" data-a="crCat" data-v="${cat[0]}">Selesai</button></div>`:''}</div>
  <div class="crCats">${cats}</div>`;
  const ns=$('#cRight .crScroll');if(ns)ns.scrollTop=_crScroll;const nd=$('#cRight .crDBody');if(nd&&keepD)nd.scrollTop=_crDScroll;CR._dOpen=CR.drawer;
  document.querySelectorAll('#creator .cgender button').forEach(b=>b.classList.toggle('on',b.dataset.v===g));
  drawCreatorPrev();
  const ni=$('#cName');if(ni&&ni.value!==CR.name)ni.value=CR.name;
};
drawCreatorPrev=function(){
  const c=$('#cvPrev');if(!c)return;const W=c.clientWidth,H=c.clientHeight;if(!W||!H)return;const d=pxr();c.width=W*d;c.height=H*d;const x=c.getContext('2d');x.setTransform(d,0,0,d,0,0);
  // sunset lake scene
  let g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,'#7b5bd6');g.addColorStop(.35,'#c98be0');g.addColorStop(.6,'#f6b6c8');g.addColorStop(1,'#e9c8f0');x.fillStyle=g;x.fillRect(0,0,W,H);
  const hz=H*.6;
  // sun glow
  g=x.createRadialGradient(W*.55,hz-H*.04,4,W*.55,hz-H*.04,W*.5);g.addColorStop(0,'rgba(255,230,200,.85)');g.addColorStop(.3,'rgba(255,190,210,.35)');g.addColorStop(1,'rgba(255,190,210,0)');x.fillStyle=g;x.fillRect(0,0,W,H);
  // clouds
  x.fillStyle='rgba(255,255,255,.22)';for(const [cx,cy,r] of [[.15,.14,.1],[.32,.1,.07],[.78,.16,.12],[.9,.08,.06]]){x.beginPath();x.ellipse(W*cx,H*cy,W*r,H*.025,0,0,TAU);x.fill()}
  // Kinabalu-like mountain (right)
  g=x.createLinearGradient(0,hz-H*.3,0,hz);g.addColorStop(0,'#8d7fd6');g.addColorStop(1,'#6a5cb8');x.fillStyle=g;x.beginPath();x.moveTo(W*.45,hz);x.lineTo(W*.58,hz-H*.12);x.lineTo(W*.64,hz-H*.16);x.lineTo(W*.69,hz-H*.26);x.lineTo(W*.72,hz-H*.22);x.lineTo(W*.75,hz-H*.29);x.lineTo(W*.78,hz-H*.23);x.lineTo(W*.82,hz-H*.27);x.lineTo(W*.86,hz-H*.18);x.lineTo(W*.95,hz-H*.12);x.lineTo(W,hz-H*.1);x.lineTo(W,hz);x.fill();
  x.fillStyle='rgba(255,255,255,.75)';x.beginPath();x.moveTo(W*.69,hz-H*.26);x.lineTo(W*.72,hz-H*.22);x.lineTo(W*.75,hz-H*.29);x.lineTo(W*.78,hz-H*.23);x.lineTo(W*.82,hz-H*.27);x.lineTo(W*.8,hz-H*.22);x.lineTo(W*.75,hz-H*.24);x.lineTo(W*.71,hz-H*.21);x.fill();
  // city skyline with lit windows
  const R=seeded(9);for(let i=0;i<26;i++){const bx=i*W*.04-4,bh=H*(.05+R()*.17)*(i>14&&i<20?.6:1);x.fillStyle=i%3?'#5b4aa8':'#6c58b8';x.fillRect(bx,hz-bh,W*.034,bh);x.fillStyle='rgba(255,214,150,.75)';for(let wy=hz-bh+4;wy<hz-3;wy+=6)for(let wx=bx+2;wx<bx+W*.034-2;wx+=5)if(R()<.4)x.fillRect(wx,wy,2,2.4)}
  // KL Tower + twin towers
  const tx=W*.14;x.fillStyle='#4e3f98';x.fillRect(tx-3,hz-H*.5,6,H*.5);x.beginPath();x.ellipse(tx,hz-H*.42,12,8,0,0,TAU);x.fill();x.fillRect(tx-1,hz-H*.6,2,H*.12);x.fillStyle='rgba(255,220,160,.9)';x.fillRect(tx-10,hz-H*.425,20,2);
  x.fillStyle='#55449f';for(const ox of [W*.27,W*.33]){x.beginPath();x.moveTo(ox-9,hz);x.lineTo(ox-9,hz-H*.3);x.lineTo(ox-6,hz-H*.36);x.lineTo(ox-3,hz-H*.4);x.lineTo(ox,hz-H*.5);x.lineTo(ox+3,hz-H*.4);x.lineTo(ox+6,hz-H*.36);x.lineTo(ox+9,hz-H*.3);x.lineTo(ox+9,hz);x.fill()}x.fillRect(W*.27,hz-H*.24,W*.06,3);
  // lake with reflections
  g=x.createLinearGradient(0,hz,0,H);g.addColorStop(0,'#a58ae0');g.addColorStop(.5,'#c9a6ea');g.addColorStop(1,'#efd3f2');x.fillStyle=g;x.fillRect(0,hz,W,H-hz);
  x.globalAlpha=.25;x.save();x.translate(0,hz*2);x.scale(1,-1);x.fillStyle='#ffffff';x.fillRect(tx-3,hz-H*.4,6,H*.4);x.restore();x.globalAlpha=1;
  x.strokeStyle='rgba(255,255,255,.45)';x.lineWidth=1.2;for(let i=0;i<14;i++){const ly=hz+6+i*((H-hz)/14),lw=W*(.05+((i*37)%10)/40);x.beginPath();x.moveTo(W*((i*53)%100)/100,ly);x.lineTo(W*((i*53)%100)/100+lw,ly);x.stroke()}
  // pier
  x.fillStyle='rgba(120,90,160,.55)';x.fillRect(0,H*.72,W*.18,5);for(let i=0;i<4;i++)x.fillRect(W*.02+i*W*.05,H*.72,3,H*.08);
  // glowing platform
  const px=W/2,py=H-26,pr=Math.min(W*.38,200);
  g=x.createRadialGradient(px,py,4,px,py,pr);g.addColorStop(0,'rgba(255,255,255,.95)');g.addColorStop(.6,'rgba(236,222,255,.7)');g.addColorStop(1,'rgba(200,170,255,0)');x.fillStyle=g;x.beginPath();x.ellipse(px,py,pr,pr*.2,0,0,TAU);x.fill();
  x.strokeStyle='rgba(170,120,255,.95)';x.lineWidth=3;x.shadowColor='#c49bff';x.shadowBlur=16;x.beginPath();x.ellipse(px,py,pr*.7,pr*.14,0,0,TAU);x.stroke();x.shadowBlur=0;
  x.strokeStyle='rgba(255,255,255,.9)';x.lineWidth=1.4;x.beginPath();x.ellipse(px,py,pr*.55,pr*.1,0,0,TAU);x.stroke();
  const sp=(sx,sy,r)=>{x.fillStyle='rgba(255,255,255,.95)';x.beginPath();x.moveTo(sx,sy-r);x.quadraticCurveTo(sx,sy,sx+r,sy);x.quadraticCurveTo(sx,sy,sx,sy+r);x.quadraticCurveTo(sx,sy,sx-r,sy);x.quadraticCurveTo(sx,sy,sx,sy-r);x.fill()};
  sp(W*.1,H*.08,6);sp(W*.88,H*.06,8);sp(W*.92,H*.4,5);sp(W*.06,H*.5,4);
  // character
  const L=CR.look,BP=BODIES[L.body||0]||BODIES[0],hc=crHeadCentre(L,0);const tall=animeHeight(L)+(L.hat||OUT[L.outfit]&&OUT[L.outfit].head?6:0);
  const s=Math.min((H-30)/tall,W/(70*BP[1]));drawChibi(x,px,py+4,s,L,CR.dir,0);
};
startCreator=function(){
  CR.preset=0;CR.look=Object.assign({},CR_PRESETS.m[0]);CR.name='';CR.autoName=true;CR.dir=0;CR.drawer=null;CR.age=20;CR.state='sabah';CR.town='Kota Kinabalu';CR.bg=genBg(20);_crScroll=0;
  ['#game','#title'].forEach(q=>$(q).classList.add('hide'));$('#creator').classList.remove('hide');
  renderCreator();requestAnimationFrame(()=>drawCreatorPrev());
};
const crRandName=g=>pick(g==='m'?NAMES_M:NAMES_F);
ACT.crPreset=v=>{CR.preset=+v;const sk=CR.look.skin;CR.look=Object.assign({},CR_PRESETS[CR.look.g][+v]);if(CR._skinSet)CR.look.skin=sk;renderCreator()};
ACT.crGender=v=>{if(CR.look.g===v)return;const sk=CR.look.skin;const pi=CR.preset>=0&&CR.preset<8?CR.preset:0;CR.preset=pi;CR.look=Object.assign({},CR_PRESETS[v][pi]);if(CR._skinSet)CR.look.skin=sk;if(CR.drawer==='hijab'&&v==='m')CR.drawer=null;if(CR.autoName&&CR.name){CR.name=crRandName(v)}renderCreator()};
ACT.crAgeSel=v=>{v=+v;CR.age=v===30?Math.max(30,CR.age>=30?CR.age:30):v;CR.bg=genBg(CR.age);renderCreator()};
ACT.crAge30=v=>{CR.age=clamp(CR.age+(+v),30,60);CR.bg=genBg(CR.age);renderCreator()};
ACT.crState=v=>{CR.state=v;CR.town=STATE[v].towns[0];renderCreator()};
ACT.crTown=v=>{if(STATE[CR.state].towns.includes(v))CR.town=v;renderCreator()};
ACT.crBg=()=>{CR.bg=genBg(CR.age);renderCreator()};
ACT.crCat=v=>{CR.drawer=CR.drawer===v?null:v;renderCreator()};
ACT.crShoe=v=>{if(SHOE[v]){CR.look.shoes=v;CR.preset=-1}renderCreator()};
{const cs=ACT.crSet;ACT.crSet=v=>{if(SH.id!=='almari'&&!$('#creator').classList.contains('hide')){const [k]=v.split(':');if(k==='skin')CR._skinSet=true;if(k==='hijab'&&+v.split(':')[1])CR.look.hat=0,CR.look.ear=0;CR.preset=-1}cs(v)}}
ACT.crRandom=()=>{const g=Math.random()<.5?'m':'f',r=n=>Math.floor(Math.random()*n);const hij=g==='f'&&Math.random()<.45;
  const outs=CR_OUTFITS.filter(i=>OUT[i]&&(OUT[i].g==='u'||OUT[i].g===g)&&i!=='s4');
  CR.look={g,skin:r(SKIN.length),face:r(FACES.length),eye:r(EYES.length),eyeCol:r(EYECOL.length),brow:r(4),nose:r(NOSES.length),mouth:r(MOUTHS.length),hair:r((g==='m'?HAIR_M:HAIR_F).length),hairCol:r(HAIRCOL.length),
    hijab:hij?1:0,hijabSt:r(HIJAB_ST.length),hijabCol:r(HIJAB_COL.length),glasses:Math.random()<.25?1+r(GLASSES.length-1):0,hat:!hij&&Math.random()<.2?1+r(3):0,acc:Math.random()<.35?pick([2,4,5,6]):0,bag:Math.random()<.6?1+r(BAGS.length-1):0,
    ear:!hij&&g==='f'&&Math.random()<.5?1+r(EARS.length-1):0,neck:Math.random()<.15?1+r(NECKS.length-1):0,beard:g==='m'&&Math.random()<.2?1+r(3):0,body:0,style:0,expr:r(EXPRS.length),
    outfit:pick(outs),shoes:pick(['sh1','sh4','sh2','sh6','sh8'].concat(g==='f'?['sh7','sh10']:['sh9']))};
  if(CR.look.hairCol>=7&&Math.random()<.6)CR.look.hairCol=r(5);
  CR.preset=-1;CR._skinSet=false;if(CR.drawer==='hijab'&&g==='m')CR.drawer=null;
  if(CR.autoName||!($('#cName').value||'').trim()){CR.name=crRandName(g);CR.autoName=true}
  renderCreator()};
ACT.crDice=ACT.crRandom;
ACT.crStart=()=>{
  let n=($('#cName').value||'').trim();if(!n){n=crRandName(CR.look.g);CR.name=n;$('#cName').value=n;toast('Nama dijana: '+n)}
  CR.name=n.slice(0,18);CR.age=clamp(CR.age||20,18,60);const L=Object.assign({},CR.look);
  newSave(L,CR.name,'dewasa');
  const add=(k,v)=>{if(v!=null&&S[k]&&!S[k].includes(v))S[k].push(v)};
  add('ownedGlasses',L.glasses);add('ownedHats',L.hat);add('ownedAccs',L.acc);if(!S.ownedBags)S.ownedBags=[0,1];add('ownedBags',L.bag||0);add('ownedEars',L.ear||0);add('ownedNecks',L.neck||0);add('ownedHijab',L.hijabSt);add('ownedShoes',L.shoes);add('owned',L.outfit);
  applyProfile({age:CR.age,state:CR.state,town:CR.town,bg:CR.bg});startGame(true)};
ACT.crBack=()=>{CR.drawer=null;showTitle()};
// wardrobe face tab gains expressions
{const le=lookEditor;lookEditor=function(L,tab,ctxName){let h=le(L,tab,ctxName);if(tab==='muka')h=`<div class="chead">Ekspresi</div>${optBtns('expr',EXPRS,L.expr||0)}`+h;return h}}

// ---------------- special avatar from the player's own reference picture
const PHOTO_PRESET='gadis';
const photoImgs={};function photoImg(id,kind){const k=id+kind;if(!photoImgs[k]){const im=new Image();im.onload=()=>{if(!$('#creator').classList.contains('hide'))drawCreatorPrev();if(S&&S.photo===id)drawPortrait()};im.src=PHOTO_AVATARS[id][kind];photoImgs[k]=im}return photoImgs[k]}
ACT.crPhoto=v=>{if(!PHOTO_AVATARS[v])return;CR.look=Object.assign({},PEN_LOOK);CR.preset=-2;CR.photo=v;CR.showDrawn=false;CR._skinSet=false;
  if(CR.autoName||!($('#cName').value||'').trim()){CR.name='Nur Aleesya';CR.autoName=true}
  CR.age=20;CR.state='sabah';CR.town='Penampang';let bg=genBg(20),n=0;while((bg.degrees.length||bg.spm==null)&&n++<60)bg=genBg(20);bg.spm=6;bg.expYears=2;CR.bg=bg;renderCreator()};
ACT.crPhotoView=()=>{CR.showDrawn=!CR.showDrawn;renderCreator()};
// any manual change turns the photo off (the picture cannot change clothes/hair)
for(const k of ['crSet','crShoe','crGender','crPreset','crRandom']){const f=ACT[k];ACT[k]=v=>{if(SH.id!=='almari')CR.photo=null;return f(v)}}
{const rc=renderCreator;renderCreator=function(){rc();
  // photo tile in the avatar grid (female)
  if(CR.look.g==='f'){const g=$('#cLeft .crav');if(g){const b=document.createElement('button');b.className='phot'+(CR.photo?' on':'');b.dataset.a='crPhoto';b.dataset.v=PHOTO_PRESET;b.setAttribute('aria-label','Avatar gambar asal');b.innerHTML=`<img src="${PHOTO_AVATARS[PHOTO_PRESET].head}" alt=""><span class="phb">★ Asal</span>${CR.photo?crChk():''}`;g.prepend(b)}}
  const st=$('#creator .cstage');let t=$('#phToggle');if(t)t.remove();
  if(CR.photo&&st){t=document.createElement('button');t.id='phToggle';t.dataset.a='crPhotoView';t.textContent=CR.showDrawn?'🖼️ Lihat gambar asal':'🎮 Lihat versi permainan';st.appendChild(t)}
}}
{const dp=drawCreatorPrev;drawCreatorPrev=function(){if(!CR.photo||CR.showDrawn)return dp();const c=$('#cvPrev');if(!c)return;const W=c.clientWidth,H=c.clientHeight;if(!W||!H)return;const d=pxr();c.width=W*d;c.height=H*d;const x=c.getContext('2d');x.setTransform(d,0,0,d,0,0);
  const im=photoImg(CR.photo,'full');if(!im.complete||!im.naturalWidth){x.fillStyle='#e7d4ff';x.fillRect(0,0,W,H);return}
  const sc=Math.max(W/im.naturalWidth,H/im.naturalHeight);x.save();x.filter='blur(10px) saturate(1.1)';x.globalAlpha=.85;x.drawImage(im,(W-im.naturalWidth*sc)/2-10,(H-im.naturalHeight*sc)/2-10,im.naturalWidth*sc+20,im.naturalHeight*sc+20);x.restore();x.fillStyle='rgba(255,255,255,.12)';x.fillRect(0,0,W,H);
  const s=Math.min(W/im.naturalWidth,(H-6)/im.naturalHeight),iw=im.naturalWidth*s,ih=im.naturalHeight*s;x.save();x.shadowColor='rgba(60,20,110,.45)';x.shadowBlur=18;const ix=(W-iw)/2,iy=H-ih;const rp=new Path2D();rrp(rp,ix,iy,iw,ih,14);x.clip(rp);x.drawImage(im,ix,iy,iw,ih);x.restore()}}
{const sv=ACT.crStart;ACT.crStart=()=>{const ph=CR.photo&&!CR.showDrawn?CR.photo:CR.photo;sv();if(S){S.photo=ph||null;save();drawPortrait()}}}
{const dp=drawPortrait;drawPortrait=function(){if(S&&S.photo&&PHOTO_AVATARS[S.photo]){const c=$('#hPort');if(!c)return;const x=c.getContext('2d');c.width=c.height=100;const im=photoImg(S.photo,'head');x.clearRect(0,0,100,100);if(im.complete&&im.naturalWidth)x.drawImage(im,0,0,100,100);return}dp()}}
// wardrobe: changing face/hair/headwear makes the photo portrait out of date → switch back to drawn portrait
{const cs=ACT.crSet;ACT.crSet=v=>{if(SH.id==='almari'&&S&&S.photo&&/^(hair|hairCol|hijab|hijabSt|hijabCol|face|eye|eyeCol|skin|glasses|hat)\b/.test(v))S.photo=null;return cs(v)}}
{const wa=ACT.wearAcc;ACT.wearAcc=v=>{if(S&&S.photo&&/^(hat|glasses|hijabSt)/.test(v))S.photo=null;return wa(v)}}
