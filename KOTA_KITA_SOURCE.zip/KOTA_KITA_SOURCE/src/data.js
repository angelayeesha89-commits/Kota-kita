// ===================== DATA =====================
const SKIN=['#ffe6d4','#f9d3b6','#efbf98','#d9a17b','#b97d56','#8b5b3c'];
const FACES=['Bulat','Bujur','Hati','Petak'];
const EYES=['Bulat','Tajam','Lembut','Berkilau','Kucing','Mengantuk'];
const EYECOL=['#4a2c1d','#22160f','#7a4a22','#2f5d8a','#3d7a4a','#7a4ab0','#b07a12'];
const BROWS=['Lurus','Melengkung','Tebal','Nipis','Risau','Garang'];
const BODIES=[['Sederhana',1,1],['Tinggi',1,1.16],['Berisi',1.14,1.04],['Kecil Molek',.92,.92]];
const NOSES=['Kecil','Titik','Mancung'];
const MOUTHS=['Senyum','Ketawa','Comel','Tenang','Sengih'];
const HAIR_M=['Bertekstur','Belah Tepi','Pendek Kemas','Belah Tengah Korea','Undercut','Cepak','Korea Gebu','Kerinting'];
const HAIR_F=['Panjang Lurus','Panjang Ikal','Ekor Kuda','Sanggul','Bob','Dua Ekor','Pendek','Tocang Sisi','Sanggul Separuh','Lurus Berponi'];
const HAIRCOL=['#1f1a24','#3b2a20','#5c3a22','#8b5a2b','#c08a4a','#e3c27a','#a9adb8','#7a2e3a','#3f4f8f','#d977a8'];
const HIJAB_ST=[['Bawal',0],['Sarung',0],['Selendang',45],['Turban',35]];
const HIJAB_COL=['#f4b6c8','#c9a7ec','#a8d0f0','#2b2b33','#f3e7d3','#9bd3b0','#e8c26a','#ffffff','#7a5c9e','#d36b6b','#6fa8a0','#b0603c'];
const GLASSES=[['Tiada',0],['Bulat',0],['Petak',0],['Cermin Mata Hitam',120],['Separuh Bingkai',180],['Cermin Hitam di Kepala',120],['Cermin Bingkai Putih di Kepala',130]];
const HATS=[['Tiada',0],['Kep',0],['Topi Baldi',60],['Beanie',40],['Songkok',25],['Topi Jerami',45],['Klip Bunga',20],['Kep Krim',35],['Kep Hitam',35],['Reben Besar',40],['Klip Hati',25],['Klip Bunga Sakura',25]];
const ACCS=[['Tiada',0],['Beg Galas',0],['Fon Kepala',150],['Beg Silang',90],['Jam Tangan',250],['Fon Kepala Telinga Kucing',180],['Fon Kepala di Leher',150],['Cawan Kopi',12]];
const BAGS=[['Tiada',0],['Beg Galas',0],['Beg Silang Kulit',90],['Beg Tangan Krim',120],['Beg Anyaman Rotan',80],['Beg Bimbit Kerja',200],['Beg Galas Pink + Beruang',140],['Beg Galas Hitam',110]];
const EARS=[['Tiada',0],['Subang Kecil',0],['Anting Gelung',120],['Anting Mutiara',160]];
const NECKS=[['Tiada',0],['Rantai Emas',220],['Skaf Leher',60],['Kalung Manik Borneo',80]];
const BEARDS=['Tiada','Misai','Janggut Sejemput','Jambang Nipis'];
const POSES=['Berdiri','Tanda Peace ✌','Tangan dalam Poket'];
const CSTYLES=[['Chibi Comel 3D',1.62,.58,.97],['Anime Comel',1,1,1],['Semi-Realistik',.93,1.04,1]];

// outfit: id,name,cat,g,style,top,bottom,accent,pat,price,head,grp,desc
const OUTFIT_CATS=[['harian','Harian'],['sekolah','Sekolah'],['kolej','Kolej / Universiti'],['kerja','Kerja / Uniform'],['sukan','Sukan'],['moden','Moden & Trend'],['tradisi','Tradisional Malaysia'],['formal','Majlis & Formal'],['muslimah','Muslimah / Hijab'],['kasut','Kasut & Aksesori']];
const TRAD_GRP=[['Melayu','Melayu'],['Cina','Cina'],['India','India'],['Sabah','Sabah'],['Sarawak','Sarawak'],['Lain','Warisan Lain']];
const O=(id,name,cat,g,style,top,bottom,accent,pat,price,head,grp,desc)=>({id,name,cat,g,style,top,bottom:bottom||top,accent:accent||'#ffffff',pat:pat||'',price:price||0,head:head||'',grp:grp||'',desc:desc||''});
const OUTFITS=[
O('h1','Hoodie Merah & Kargo','harian','m','casual','#b8323a','#6b6648','#f5f5f5','hoodie',0),
O('h2','Kemeja-T Putih & Jeans','harian','u','casual','#f6f6f6','#4a6fa5','#ddd','',0),
O('h3','Kardigan Krim & Skirt Labuh','harian','f','skirt','#f0dcc0','#2b2b33','#fff','cardigan',0),
O('h4','Sweater Putih & Jeans Lebar','harian','f','casual','#f4f1ea','#7fa3cf','#ddd','',0),
O('h5','Jaket Denim','harian','u','casual','#3d5d8f','#2d2d36','#f6f6f6','jacket',120),
O('h6','Kemeja Flanel','harian','m','casual','#9c3b32','#3a3f4a','#2a2020','check',90),
O('h7','Blaus Bunga & Slack','harian','f','casual','#fbd0dc','#e8e0cf','#e86a8a','floral',95),
O('h8','Polo Hijau & Chino','harian','m','casual','#3f8f5a','#c9b48a','#fff','',70),
O('r1','Blaus Putih & Seluar Lebar Merah Jambu','harian','f','casual','#fbf9f4','#e9a7b8','#6b4a2b','blouse',110),
O('r2','Hoodie Merah Jambu & Kargo Krim','harian','f','casual','#f7b9d0','#efe3c6','#ffffff','hoodie',120),
O('r3','Kurung Moden Lilac','tradisi','f','kurung','#c4afe9','#f5ead6','#f1dfa8','goldtrim',150,'','Melayu','Baju kurung moden lilac bersulam emas dengan kain krim labuh.'),
O('r4','Jaket Denim & Kargo Hitam','harian','f','casual','#7ea7d8','#2a2a31','#f4f1ea','denim',140),
O('r5','Kardigan Krim & Skirt Kotak','harian','f','skirt','#f3e7d4','#3d3850','#1f1f26','cardigan',120),
O('r6','Blaus Renda & Skirt Bunga','harian','f','skirt','#fffaf2','#f9e8d2','#ef8a78','lace',130),
O('r7','Hoodie Hitam & Kargo Khaki','harian','u','casual','#2b2b34','#8c8566','#ffffff','hoodie',120),
O('r9','Kemeja Pejabat & Tali Leher','kerja','m','office','#ffffff','#24242b','#1f3a6b','lanyard',160),
O('r10','Jaket Trek Hitam & Kargo','harian','m','casual','#202028','#5c5a44','#ffffff','track',140),
O('r11','Kemeja Batik Biru','tradisi','m','casual','#25386b','#24242b','#d9b44a','batikshirt',150,'','Melayu','Kemeja batik Malaysia corak biru keemasan.'),
O('r12','Kemeja Hawaii & Seluar Pendek','harian','m','casual','#3e6db0','#e6d9bd','#f4a05a','hawaii',110),
O('r13','Hoodie Putih & Kargo Khaki','harian','m','casual','#f6f6fa','#b8ab88','#ffffff','hoodie',120),
O('r14','Sut Pejabat Biru Gelap','kerja','u','suit','#1e2944','#1e2944','#2b4a8a','lanyard',320),
O('r17','Jaket Pink & Kargo Krim','harian','f','casual','#f490ba','#dccfb6','#ffffff','hoodjacket',150),
O('r18','Jaket Bomber & Hoodie Hitam','harian','m','casual','#e8e0d1','#2d2b2c','#1d1d22','bomber',170),
O('r16','Blaus Renda & Skirt Lipit','harian','f','skirt','#fffaf2','#f6c1cf','#5a3b2a','lace',120),
O('r15','Jaket Pink & Kargo Longgar','harian','f','casual','#ee8fb8','#6e6450','#fbfaf7','hoodjacket',160),
O('s1','Seragam Sekolah Lelaki','sekolah','m','uniform','#fbfbfb','#2f4f3a','#2f4f3a','tie',0),
O('s2','Baju Kurung Sekolah','sekolah','f','kurung','#fbfbfb','#3aa0b5','#fff','',0),
O('s3','Pinafore Sekolah','sekolah','f','pinafore','#fbfbfb','#234b8a','#fff','',35),
O('s4','Baju Sukan Sekolah','sekolah','u','sport','#f2c230','#234b8a','#234b8a','',30),
O('k1','Hoodie Universiti','kolej','u','casual','#6a3fd0','#2d2d36','#ffffff','hoodie',85),
O('k2','Kemeja Kampus & Chino','kolej','m','casual','#a9c7e8','#c9b48a','#fff','collar',110),
O('k3','Blaus Kampus & Skirt Plet','kolej','f','skirt','#ffffff','#6c5a8f','#6c5a8f','collar',110),
O('k4','Jaket Varsiti','kolej','u','casual','#1f3a6b','#2d2d36','#f2c230','varsity',160),
O('w1','Uniform Jururawat','kerja','u','nurse','#ffffff','#ffffff','#3a86ff','',150,'nursecap'),
O('w2','Kot Makmal Doktor','kerja','u','labcoat','#ffffff','#34495e','#2f6fdb','',220),
O('w3','Uniform Polis','kerja','u','uniform','#1d2d55','#1d2d55','#f2c230','badge',260,'policecap'),
O('w4','Uniform Bomba','kerja','u','uniform','#1e2a44','#1e2a44','#f2c230','reflect',260,'firehelmet'),
O('w5','Pakaian Chef','kerja','u','chef','#ffffff','#2b2b33','#2b2b33','',180,'chefhat'),
O('w6','Pakaian Pejabat','kerja','u','office','#f4f4f4','#2d3446','#6a3fd0','tie',200),
O('w7','Apron Barista','kerja','u','apron','#f4f1ea','#2d2d36','#6b4423','',90),
O('w8','Jaket Rider','kerja','u','casual','#2fa84f','#2d2d36','#ffffff','jacket',120,'helmet'),
O('w10','Pakaian Guru','kerja','u','office','#6aa0d8','#2d3446','#1f3a6b','',180),
O('w11','Uniform Staf Runcit','kerja','u','uniform','#e5484d','#2d2d36','#ffffff','badge',120),
O('w12','Pakaian Pekerja Binaan','kerja','u','uniform','#f29b0c','#3a4a6a','#f2f2f2','reflect',150,'hardhat'),
O('k5','Jubah Graduasi','kolej','u','robe','#1d1d24','#1d1d24','#c8102e','',250,'mortar'),
O('k6','Uniform Kolej (Blazer)','kolej','u','blazer','#1f3a6b','#2d3446','#f2c230','',200),
O('w9','Uniform Hotel','kerja','u','uniform','#7a1f2b','#1d1d24','#f2c230','badge',200),
O('sp1','Jersi Bola Sepak','sukan','u','sport','#e63946','#1d1d24','#ffffff','',60),
O('sp2','Baju Larian','sukan','u','sport','#2ec4b6','#1d1d24','#ffffff','',75),
O('sp3','Baju Badminton','sukan','u','sport','#f9c80e','#2b2d42','#2b2d42','',80),
O('sp4','Set Sukan Muslimah','sukan','f','sport','#9b5de5','#2b2d42','#ffffff','',95),
O('sp5','Tracksuit Biru','sukan','u','sport','#3a86ff','#3a86ff','#ffffff','',120),
O('m1','Streetwear Hitam','moden','m','casual','#1d1d24','#6b6b5a','#e63946','hoodie',140),
O('m2','Gaun Pastel','moden','f','dress','#c9b6f2','#c9b6f2','#fff','',220),
O('m3','Blazer Oversize','moden','u','blazer','#d8c3a5','#2b2b33','#ffffff','',260),
O('m4','Set Korea Krim','moden','f','skirt','#fff3e0','#8d6e63','#8d6e63','cardigan',180),
O('m5','Kemeja Batik Moden','moden','m','casual','#1f6f8b','#2d2d36','#f2c230','batik',150),
O('m6','Jaket Kulit','moden','u','casual','#3b2a20','#1d1d24','#999','jacket',300),
O('m7','Dres Bunga','moden','f','dress','#ffd6e0','#ffd6e0','#e86a8a','floral',200),
O('m8','Kardigan Kampus','moden','m','casual','#8a9a5b','#e8e0cf','#fff','cardigan',130),
// Traditional — Melayu
O('t1','Baju Melayu Cekak Musang','tradisi','m','bajumelayu','#5b3a9e','#5b3a9e','#e2b44a','songket',320,'songkok','Melayu','Baju Melayu berkolar cekak musang dengan samping songket dan songkok.'),
O('t2','Baju Melayu Teluk Belanga','tradisi','m','bajumelayu','#f0e6d2','#f0e6d2','#7a1f2b','kelim',300,'songkok','Melayu','Leher bulat bersulam tulang belut, gaya Johor, dengan samping.'),
O('t3','Baju Kurung','tradisi','f','kurung','#f6b8cf','#f6b8cf','#ffffff','floral',260,'','Melayu','Baju kurung longgar paras lutut dengan kain sepasang.'),
O('t4','Kebaya Labuh','tradisi','f','kebaya','#b9cfee','#3f5b8f','#e2b44a','batik',280,'','Melayu','Kebaya labuh dengan kerongsang dan kain batik.'),
O('t5','Persalinan Songket (Lelaki)','tradisi','m','bajumelayu','#1d1d24','#1d1d24','#e2b44a','songket',650,'tanjak','Melayu','Busana istiadat bersongket penuh dengan tanjak.'),
O('t6','Persalinan Songket (Wanita)','tradisi','f','kurung','#a3202c','#a3202c','#e2b44a','songket',680,'goldflower','Melayu','Baju kurung songket tenunan benang emas.'),
O('t7','Baju Kedah','tradisi','f','kedah','#8fc9a8','#3d6b55','#e2b44a','batik',240,'','Melayu','Baju pendek longgar paras pinggul dengan kain batik.'),
// Cina
O('t8','Cheongsam','tradisi','f','cheongsam','#c8102e','#c8102e','#e2b44a','cloud',380,'','Cina','Gaun berkolar mandarin dengan sulaman awan emas.'),
O('t9','Samfu (Wanita)','tradisi','f','samfu','#e85d75','#c8102e','#e2b44a','',260,'','Cina','Baju dan seluar sepasang dengan butang simpul.'),
O('t10','Samfu / Tangzhuang (Lelaki)','tradisi','m','samfu','#c8102e','#1d1d24','#e2b44a','',260,'','Cina','Jaket tangzhuang berbutang simpul dengan seluar.'),
O('t11','Kebaya Nyonya','tradisi','f','kebaya','#7fd1c7','#d94f70','#ffffff','batik',360,'','Cina','Kebaya sulam halus dengan kain batik pesisir.'),
O('t12','Changshan','tradisi','m','robe','#1f3a6b','#1f3a6b','#e2b44a','cloud',300,'','Cina','Jubah panjang berkolar mandarin.'),
// India
O('t13','Sari','tradisi','f','sari','#7b2cbf','#7b2cbf','#e2b44a','zari',380,'','India','Sari dengan sempadan zari emas, dililit dengan pallu di bahu.'),
O('t14','Punjabi Suit','tradisi','f','punjabi','#1fa2c4','#f2c230','#f2c230','',300,'','India','Kameez labuh, salwar dan dupatta.'),
O('t15','Dhoti Kurta','tradisi','m','kurta','#f5ecd7','#fffaf0','#e2b44a','',280,'','India','Kurta labuh dengan dhoti putih.'),
O('t16','Lehenga','tradisi','f','lehenga','#e0559a','#e0559a','#e2b44a','zari',450,'','India','Skirt kembang bersulam, choli dan dupatta.'),
O('t17','Saree Moden','tradisi','f','sari','#4fbf9f','#4fbf9f','#f0f0f0','',400,'','India','Saree pastel ringan untuk majlis moden.'),
O('t18','Sherwani','tradisi','m','robe','#f2d7a7','#fffaf0','#b8860b','zari',420,'','India','Kot labuh berbutang untuk majlis.'),
// Sabah
O('t19','Kadazan-Dusun (Lelaki)','tradisi','m','borneo','#17171c','#17171c','#e2b44a','goldtrim',420,'siga','Sabah','Gaung dan souva hitam berhias emas, dengan siga di kepala.'),
O('t20','Kadazan-Dusun (Wanita)','tradisi','f','borneo','#17171c','#17171c','#e2b44a','coinbelt',440,'','Sabah','Sinuangga baldu hitam berlace emas dengan himpogot (tali pinggang syiling perak).'),
O('t21','Bajau (Lelaki)','tradisi','m','borneo','#1f4fa8','#1f4fa8','#f2c230','goldtrim',420,'destar','Sabah','Busana Bajau Kota Belud berwarna terang dengan destar.'),
O('t22','Bajau (Wanita)','tradisi','f','borneo','#2a63c9','#e83f6f','#f2c230','sequin',460,'sarempak','Sabah','Badu sampit berwarna-warni dengan mahkota sarempak keemasan.'),
O('t23','Murut (Lelaki)','tradisi','m','borneo','#6b4a2b','#17171c','#d64545','beads',400,'feather','Sabah','Busana Murut dengan hiasan manik dan bulu.'),
O('t24','Murut (Wanita)','tradisi','f','borneo','#17171c','#17171c','#d64545','beads',420,'beadband','Sabah','Pinongkoloh hitam bermanik merah, putih dan kuning.'),
O('t25','Rungus (Lelaki)','tradisi','m','borneo','#17171c','#17171c','#f2c230','beads',400,'siga','Sabah','Busana Rungus hitam dengan anyaman manik.'),
O('t26','Rungus (Wanita)','tradisi','f','borneo','#17171c','#17171c','#e2b44a','cross',430,'beadband','Sabah','Pakaian hitam dengan selempang manik bersilang dan gelang tembaga.'),
// Sarawak
O('t27','Iban (Lelaki)','tradisi','m','borneo','#7a1f1f','#17171c','#f2c230','beads',440,'feather','Sarawak','Busana pahlawan Iban dengan topi berhias bulu.'),
O('t28','Iban (Wanita)','tradisi','f','borneo','#b0b6c0','#7a1f1f','#d9d9d9','silver',480,'sugu','Sarawak','Ngepan Iban dengan rawai perak dan sugu tinggi.'),
O('t29','Bidayuh (Lelaki)','tradisi','m','borneo','#17171c','#17171c','#e63946','beads',400,'beadband','Sarawak','Busana hitam berhias manik merah, kuning dan putih.'),
O('t30','Bidayuh (Wanita)','tradisi','f','borneo','#17171c','#17171c','#e63946','beads',420,'sipiah','Sarawak','Pakaian hitam bermanik dengan topi sipiah.'),
O('t31','Kenyah (Lelaki)','tradisi','m','borneo','#17171c','#17171c','#f2c230','motif',420,'feather','Sarawak','Busana Kenyah bermotif aso berpilin.'),
O('t32','Kenyah (Wanita)','tradisi','f','borneo','#17171c','#17171c','#f2c230','motif',440,'beadband','Sarawak','Ta\'a bermanik dengan motif Orang Ulu.'),
O('t33','Kayan (Lelaki)','tradisi','m','borneo','#2b1d14','#17171c','#e2b44a','motif',420,'feather','Sarawak','Busana Kayan dengan sulaman motif tradisi.'),
O('t34','Kayan (Wanita)','tradisi','f','borneo','#17171c','#3b2a20','#2ec4b6','beads',440,'beadband','Sarawak','Pakaian bermanik warna-warni gaya Kayan.'),
O('t35','Melanau (Lelaki)','tradisi','m','bajumelayu','#17171c','#17171c','#e2b44a','songket',400,'destar','Sarawak','Baju hitam dengan samping dan destar.'),
O('t36','Melanau (Wanita)','tradisi','f','kurung','#17171c','#17171c','#e2b44a','goldtrim',420,'','Sarawak','Baju baldu hitam berhias benang emas.'),
// Lain
O('t37','Kebaya Sulam Peranakan','tradisi','f','kebaya','#f4a6c6','#2b7a78','#ffffff','batik',420,'','Lain','Kebaya sulam Peranakan dengan kerongsang tiga.'),
O('t38','Busana Baba Peranakan','tradisi','m','samfu','#2b2b33','#2b2b33','#e2b44a','',380,'','Lain','Baju gaya Baba dengan butang emas.'),
O('t39','Minangkabau (Wanita)','tradisi','f','kurung','#a3202c','#1d1d24','#e2b44a','songket',600,'suntiang','Lain','Baju kurung basiba dengan suntiang keemasan.'),
O('t40','Minangkabau (Lelaki)','tradisi','m','bajumelayu','#1d1d24','#1d1d24','#e2b44a','songket',520,'saluak','Lain','Baju hitam dengan sisampiang dan saluak.'),
O('t41','Bugis — Baju Bodo','tradisi','f','bodo','#e85d75','#5b1a8a','#e2b44a','songket',480,'','Lain','Baju bodo longgar dengan kain sarung sutera.'),
O('t42','Bugis (Lelaki)','tradisi','m','bajumelayu','#1d1d24','#1d1d24','#e2b44a','songket',460,'songkokgold','Lain','Jas tutup dengan songkok berbenang emas.'),
O('t43','Aceh — Linto Baro','tradisi','m','bajumelayu','#17171c','#17171c','#e2b44a','goldtrim',520,'meukeutop','Lain','Busana pengantin lelaki Aceh dengan meukeutop.'),
O('t44','Aceh — Daro Baro','tradisi','f','kurung','#a3202c','#17171c','#e2b44a','goldtrim',540,'goldflower','Lain','Busana pengantin perempuan Aceh berhias emas.'),
// Formal
O('f1','Sut Hitam','formal','m','suit','#1d1d24','#1d1d24','#c8102e','',550),
O('f2','Sut Biru Laut','formal','m','suit','#1f3a6b','#1f3a6b','#f2c230','',520),
O('f3','Gaun Malam Ungu','formal','f','gown','#6a3fd0','#6a3fd0','#e2b44a','',450),
O('f4','Gaun Pengantin Moden','formal','f','gown','#fbf6ef','#fbf6ef','#e2b44a','',1200,'veil'),
O('f5','Baju Pengantin Songket','formal','m','bajumelayu','#f4eadb','#f4eadb','#e2b44a','songket',1200,'tanjak'),
O('f6','Kurung Pengantin Songket','formal','f','kurung','#f4eadb','#f4eadb','#e2b44a','songket',1300,'goldflower'),
// Muslimah
O('mu1','Jubah Moden','muslimah','f','dress','#6c5a8f','#6c5a8f','#fff','',180),
O('mu2','Abaya Hitam Elegan','muslimah','f','dress','#1d1d24','#1d1d24','#e2b44a','goldtrim',260),
O('mu3','Tunik & Palazzo','muslimah','f','tunic','#9bd3b0','#f3e7d3','#fff','',160),
O('mu4','Kurung Moden Plain','muslimah','f','kurung','#c9a7ec','#c9a7ec','#fff','',190),
O('mu5','Blaus Labuh & Skirt Plet','muslimah','f','skirt','#f4b6c8','#6c5a8f','#fff','',150),
O('mu6','Kaftan Pastel','muslimah','f','dress','#a8d0f0','#a8d0f0','#fff','floral',210),
];
const OUT=Object.fromEntries(OUTFITS.map(o=>[o.id,o]));
// extra garment detail: bp = trouser cut, bot = bottom override, te = top hem, bpat = skirt print, skEnd = skirt hem, belt
Object.entries({h1:{bp:'cargo'},r1:{bp:'wide',te:-25,belt:1},r2:{bp:'cargo'},r4:{bp:'cargo'},r5:{bpat:'plaid',skEnd:-13,te:-22},r6:{bpat:'floral',belt:1,te:-25},r7:{bp:'cargo'},
  r9:{te:-25,belt:1},r10:{bp:'cargo'},r11:{bp:''},r12:{bot:'shorts'},r13:{bp:'cargo'},r15:{bp:'jogger',belt:1},r16:{bpat:'pleat',skEnd:-14},r17:{bp:'jogger'},r18:{bp:'jogger'},t19:{belt:1},t20:{gold:1}}).forEach(([k,v])=>Object.assign(OUT[k],v));
OUT.t20.head='beadcrown';
const SHOES=[['sh1','Kasut Sukan Putih','#ffffff',0],['sh2','Kasut Sekolah Putih','#f4f4f4',0],['sh3','Selipar','#3a86ff',0],['sh4','Kasut Sukan Hitam','#2b2b33',80],['sh5','Capal','#7a4a22',60],['sh6','Loafer Coklat','#5c3a22',150],['sh7','Kasut Tumit','#c8102e',180],['sh8','But Kulit','#3b2a20',200],['sh9','Kasut Kerja Hitam','#17171c',140],['sh10','Sandal Manik','#e2b44a',90],['sh11','Sandal Kulit','#3b2a20',70],['sh12','Kasut Sukan Tebal','#ffffff',130],['sh13','But Bertali Coklat','#6b4226',160],['sh14','Kasut Sukan Merah Jambu','#f6a3c2',120],['sh15','Kasut High-Top Hitam','#1f1f24',140]];
const SHOE=Object.fromEntries(SHOES.map(s=>[s[0],{id:s[0],name:s[1],c:s[2],price:s[3]}]));

// ===== WORLD LOCATIONS =====
// id,name,short,door[x,y], icon colour
const LOCS=[
['bandar','Pusat Bandar','Bandar',[55,46],'#6a3fd0'],
['mall','Asia Mall','Mall',[73,45],'#c03fd0'],
['sekolah','Sekolah Menengah','Sekolah',[36,29],'#3a86ff'],
['uni','Universiti & Kolej','Universiti',[37,15],'#1f3a6b'],
['hospital','Hospital Kota Kita','Hospital',[55,11],'#e5484d'],
['klinik','Klinik Kesihatan','Klinik',[60,28],'#e5484d'],
['pejabat','Pejabat Kerajaan','Kerajaan',[52,28],'#1f6f8b'],
['kerjaya','Pusat Kerjaya','Kerjaya',[69,28],'#f29b0c'],
['perumahan','Kawasan Perumahan','Perumahan',[37,46],'#38b84a'],
['kampung','Kampung Tradisional','Kampung',[10,42],'#8b5a2b'],
['ladang','Ladang & Pertanian','Ladang',[9,57],'#2a9a3a'],
['pasar','Pasar Tani','Pasar Tani',[33,56],'#f29b0c'],
['jeti','Jeti Memancing','Jeti',[79,55],'#3a86ff'],
['pantai','Pantai Rekreasi','Pantai',[83,29],'#2ec4b6'],
['pulau','Pulau Peranginan','Pulau',[94,62],'#2ec4b6'],
['hutan','Hutan Rekreasi & Sungai','Hutan',[13,21],'#2a6a3a'],
['lrt','Stesen LRT / MRT','LRT/MRT',[52,55],'#6a3fd0'],
['bas','Terminal Bas','Bas',[59,56],'#f29b0c'],
['keretapi','Stesen Kereta Api','Kereta Api',[70,56],'#1f3a6b'],
['airport','Lapangan Terbang','Lapangan Terbang',[71,10],'#3a86ff'],
['pelabuhan','Pelabuhan','Pelabuhan',[74,64],'#1f6f8b'],
['taman','Taman Awam & Tasik','Taman',[44,62],'#38b84a'],
['polis','Balai Polis','Polis',[76,28],'#1d2d55'],
['bomba','Balai Bomba','Bomba',[82,28],'#e5484d'],
['perpustakaan','Perpustakaan Awam','Perpustakaan',[59,16],'#7a5ac8'],
['stadium','Stadium & Kompleks Sukan','Stadium',[33,64],'#e5484d'],
['pawagam','Pawagam Kota Kita','Pawagam',[60,36],'#c8102e'],
['medan','Medan Selera','Medan Selera',[50,45],'#f29b0c'],
['pasarmalam','Pasar Malam','Pasar Malam',[61,45],'#ff8c42'],
];
const LOC=Object.fromEntries(LOCS.map(l=>[l[0],{id:l[0],name:l[1],short:l[2],door:l[3],col:l[4]}]));

// ===== FISHING =====
const RAR=[['c','Biasa'],['u','Luar Biasa'],['r','Jarang'],['e','Epik'],['l','Legenda']];
const RARN=Object.fromEntries(RAR);
const RARW={c:46,u:28,r:15,e:8,l:3};
// [name, rarity, minLegalCm, maxCm, RM/kg, group, colour, night?]
const FISHSPOTS=[
{id:'jeti',name:'Jeti Kota Kita',sub:'Pesisir / Laut Cetek',loc:'jeti',spot:[93,47],water:'#3d9fd6',stars:3,salt:1,fish:[
['Ikan Kembung','c',14,28,12,'ikan','#7f9fb8'],['Ikan Selar','c',12,26,10,'ikan','#9ab0bd'],['Ikan Cencaru','c',15,35,9,'ikan','#8aa86a'],['Kerang','c',3,7,14,'kerang','#a88a6a'],
['Sotong','u',10,30,22,'sotong','#f2d3c8',1],['Udang Putih','u',8,18,38,'udang','#f0c8b0',1],['Ketam Bunga','r',9,20,40,'ketam','#4f78b0'],['Ikan Siakap','e',30,80,35,'ikan','#a8b4b8']],
prot:[['Kuda Laut','kudalaut','#e8a33a'],['Penyu Agar','penyu','#5b8a4a']]},
{id:'labuan',name:'Laut Dalam Labuan',sub:'Laut Dalam (Offshore)',loc:'pelabuhan',spot:null,water:'#1d5fa0',stars:5,salt:1,deep:1,fish:[
['Ikan Talang','c',40,100,12,'ikan','#8fa8b8'],['Mahi-mahi','c',50,120,18,'ikan','#5fc06a'],['Tuna','u',40,150,25,'ikan','#3f5f9a'],['Sotong Kurita','u',20,60,28,'kurita','#c06a6a',1],
['Udang Harimau','r',15,30,65,'udang','#5a6a8a',1],['Lobster','e',20,45,120,'udang','#c0502a'],['Kerapu Besar','e',60,150,45,'ikan','#7a6a4a'],['Marlin Kecil','l',100,250,30,'marlin','#2f4f8a']],
prot:[['Yu Paus','yupaus','#4a6a8a'],['Penyu Karah','penyu','#a8743a'],['Dugong','dugong','#9aa0a8']]},
{id:'teluk',name:'Teluk Tanjung Aru',sub:'Teluk / Pantai Berbatu',loc:'pantai',spot:[85,39],water:'#3fb0d6',stars:4,salt:1,fish:[
['Ikan Gerut-gerut','c',18,45,14,'ikan','#b8b8a0'],['Sotong','c',10,30,22,'sotong','#f2d3c8',1],['Pepahat / Lokan','c',4,9,16,'kerang','#c8b090'],['Ketam Nipah','u',8,16,30,'ketam','#6a8a5a'],
['Ikan Siakap','u',30,80,35,'ikan','#a8b4b8'],['Bawal Emas','r',20,45,48,'ikan','#e2c050'],['Ikan Kerapu','e',30,90,40,'ikan','#8a6a4a'],['Udang Kara','l',20,40,110,'udang','#c06a30',1]],
prot:[['Penyu Agar','penyu','#5b8a4a'],['Kuda Laut','kudalaut','#e8a33a']]},
{id:'manukan',name:'Pulau Manukan',sub:'Pulau & Terumbu Karang',loc:'pulau',spot:[97,57],water:'#2ec4c6',stars:4,salt:1,fish:[
['Ikan Cencaru','c',15,35,9,'ikan','#8aa86a'],['Sotong','c',10,30,22,'sotong','#f2d3c8',1],['Siput Laut (Gonggong)','c',4,9,20,'siput','#d8b890'],['Ketam Batu','u',8,18,32,'ketam','#7a5a4a'],
['Udang Galah','u',12,28,55,'udang','#4a7ab0'],['Ikan Jenahak','r',25,70,38,'ikan','#c87a6a'],['Ikan Merah Pisang','e',20,50,42,'ikan','#e86a6a'],['Kerapu Karang','l',30,80,85,'ikan','#d84a4a']],
prot:[['Kima Gergasi','kima','#6ab0c8'],['Terumbu Karang','karang','#ff7a8a'],['Penyu Karah','penyu','#a8743a']]},
{id:'muara',name:'Muara Sungai Pitas',sub:'Muara / Paya Bakau',loc:'pasar',spot:[20,67],water:'#6a9a7a',stars:3,salt:1,fish:[
['Lokan','c',5,10,16,'kerang','#8a7a5a'],['Udang Kelong','c',8,16,30,'udang','#c8a890',1],['Ikan Tepeng','c',15,30,10,'ikan','#b0b8a8'],['Ikan Senangin','u',25,60,22,'ikan','#c8c8b0'],
['Ketam Bakau','u',10,22,55,'ketam','#4a5a3a'],['Belangkas','r',15,40,8,'belangkas','#7a6a4a'],['Kakap Merah','e',30,80,45,'ikan','#c8503a'],['Siakap Merah','l',35,90,60,'ikan','#d8604a']],
prot:[['Tuntung Sungai','penyu','#6a6a4a'],['Dugong','dugong','#9aa0a8']]},
{id:'tasik',name:'Tasik Danau Harmoni',sub:'Tasik Air Tawar',loc:'taman',spot:[50,58],water:'#4a9ab0',stars:3,salt:0,fish:[
['Tilapia','c',12,35,8,'ikan','#8a9a8a'],['Talapia Merah','c',12,35,10,'ikan','#e88a7a'],['Ikan Keli','c',20,50,9,'keli','#4a4a3a'],['Ikan Lampam','u',12,30,12,'ikan','#c8c8a8'],
['Ikan Rohu','u',25,60,11,'ikan','#a8a090'],['Ikan Baung','r',25,60,24,'keli','#7a6a5a'],['Ikan Patin','e',35,100,20,'keli','#a8a8b0'],['Ikan Toman','l',50,120,28,'ikan','#3a4a2a']],
prot:[['Kelesa (Arowana Asia)','arowana','#d8a84a']]},
{id:'sungai',name:'Sungai Hutan Kinabalu',sub:'Sungai Air Tawar (Hulu)',loc:'hutan',spot:[20,9],water:'#3a8a8a',stars:4,salt:0,fish:[
['Ikan Tengas','c',15,40,25,'ikan','#b0a890'],['Lampam Jawa','c',12,30,12,'ikan','#d8d8b8'],['Ikan Terbul','c',6,14,30,'ikan','#c8b8a0'],['Ikan Keli Borneo','u',20,50,18,'keli','#5a4a3a'],
['Ikan Baung','u',25,60,24,'keli','#7a6a5a'],['Ikan Sebarau','r',20,50,30,'ikan','#c8a85a'],['Ikan Kelabau','e',25,70,60,'ikan','#8a8a7a'],['Ikan Kelah','l',30,100,180,'ikan','#c8903a']],
prot:[['Kelesa (Arowana Asia)','arowana','#d8a84a'],['Tuntung Sungai','penyu','#6a6a4a']]},
];
const RODS=[['Joran Buluh',0,0,0],['Joran Gentian',150,1,.06],['Joran Karbon',650,2,.12],['Joran Pro Laut Dalam',2200,3,.2],['Joran Legenda',8500,4,.3]];
// bait: id,name,price,qty,salt bonus,fresh bonus,rare bonus,reusable
const BAITS=[['cacing','Cacing',2,1,.0,.35,0,0],['udang','Udang Hidup',4,1,.35,.1,.04,0],['sotong','Sotong Potong',5,1,.25,0,.08,0],['pelet','Pelet / Dedak',2,1,0,.3,0,0],['tiruan','Umpan Tiruan (Lure)',120,1,.15,.15,.1,1]];

// ===== EDUCATION =====
const COURSES=[['med','Perubatan'],['nurse','Kejururawatan'],['eng','Kejuruteraan'],['bus','Perniagaan'],['acc','Perakaunan'],['edu','Pendidikan'],['it','Teknologi Maklumat'],['cs','Sains Komputer'],['agri','Pertanian'],['tour','Pelancongan'],['hosp','Hospitaliti'],['art','Seni Kreatif & Reka Bentuk'],['law','Undang-undang'],['com','Komunikasi'],['env','Sains Alam Sekitar'],['ai','AI & Sains Data'],['fish','Perikanan'],['culi','Seni Kulinari'],['sport','Sains Sukan'],['arch','Seni Bina']];
const COURSE=Object.fromEntries(COURSES);
const LEVELS=[['sijil','Sijil','1 tahun',2,800,1],['diploma','Diploma','2–3 tahun',3,1500,2],['ijazah','Ijazah Sarjana Muda','3–4 tahun',4,2500,4],['sarjana','Sarjana','1–2 tahun',2,4200,5],['phd','Doktor Falsafah (PhD)','3–5 tahun',3,5200,6]];
const LEVEL=Object.fromEntries(LEVELS.map(l=>[l[0],{id:l[0],name:l[1],dur:l[2],sems:l[3],fee:l[4],rank:l[5]}]));
const QRANK={spm:1,sijil:2,diploma:3,ijazah:4,sarjana:5,phd:6};
// id,name,abbr,tier,courses,levels,colour,emblem
const INSTS=[
['riu','Rivermere International University','RIU','elite',['bus','med','eng','acc','law','com','arch'],['diploma','ijazah','sarjana','phd'],'#1f3a6b','R'],
['agu','Aurelion Global University','AGU','elite',['it','cs','ai','art','eng','bus','com'],['diploma','ijazah','sarjana','phd'],'#2a2a3a','A'],
['luc','Lynford University College','LUC','elite',['law','acc','hosp','tour','bus','culi'],['diploma','ijazah','sarjana'],'#7a5a1a','L'],
['sbsu','Sinarbangsa Sponsorship University','SBSU','tajaan',['edu','com','env','bus','sport'],['diploma','ijazah','sarjana'],'#6a3fd0','S'],
['pcsu','Putra Cendekia Sponsored University','PCSU','tajaan',['nurse','med','com','acc'],['diploma','ijazah','sarjana'],'#3a86ff','P'],
['htu','Harmoni Tech University','HTU','tajaan',['it','eng','env','cs','ai','arch'],['diploma','ijazah','sarjana','phd'],'#1f6f8b','H'],
['ukk','Universiti Kota Kita','UKK','awam',['med','cs','it','ai','eng','bus','law','edu','acc','nurse','arch','sport'],['diploma','ijazah','sarjana','phd'],'#c8102e','K'],
['ubm','Universiti Borneo Maju','UBM','awam',['env','agri','fish','eng','edu'],['diploma','ijazah','sarjana','phd'],'#2a9a3a','B'],
['utj','Universiti Timur Jaya','UTJ','awam',['tour','agri','fish','hosp','culi','env','com'],['diploma','ijazah','sarjana'],'#f29b0c','T'],
['usn','Universiti Sabah Nusantara','USN','awam',['tour','art','com','edu','nurse','sport'],['diploma','ijazah','sarjana','phd'],'#2ec4b6','N'],
['uss','Universiti Sarawak Sejahtera','USS','awam',['env','eng','art','nurse','cs'],['diploma','ijazah','sarjana','phd'],'#7a1f1f','W'],
['kkk','Kolej Komuniti Kota Kita','KKK','awam',['hosp','it','agri','bus','art','acc','tour','culi','fish'],['sijil','diploma'],'#5a3a9e','KK'],
].map(a=>({id:a[0],name:a[1],abbr:a[2],tier:a[3],courses:a[4],levels:a[5],col:a[6],em:a[7]}));
const INST=Object.fromEntries(INSTS.map(i=>[i.id,i]));
const TIER={elite:{name:'Elite',mult:6,min:{sijil:3,diploma:6,ijazah:8},col:'#f2a20c'},tajaan:{name:'Tajaan',mult:3,min:{sijil:2,diploma:5,ijazah:7},col:'#3a86ff'},awam:{name:'Awam',mult:1,min:{sijil:0,diploma:2,ijazah:4},col:'#2a9a3a'}};
const CLUBS=[['Kelab Debat','karisma'],['Kelab Robotik','akademik'],['Kelab Bola Sepak','cergas'],['Kelab Fotografi','karisma'],['Persatuan Kebudayaan','karisma'],['Kelab Sukarelawan','gembira']];

// ===== JOBS =====
// part-time: id,name,min,max RM/hour,location,req item,emoji set
const PT_JOBS=[
['barista','Barista',8,12,'mall','','☕🥤🧋🍵🍰🥐'],
['cashier','Juruwang',8,12,'mall','','🧾💵🪙🛒💳🛍️'],
['retail','Pembantu Kedai',8,12,'mall','','👕👖👟🧢👗🎒'],
['waiter','Pelayan Restoran',8,15,'bandar','','🍛🍜🥘🍗🥤🍮'],
['kitchen','Pembantu Dapur',8,14,'bandar','','🧅🥕🍳🔪🥬🌶️'],
['event','Krew Acara',10,20,'bandar','','🎤🎈🪑🔦📦🎶'],
['promoter','Promoter',10,18,'mall','','📣🧴📱🎁🧃🏷️'],
['tutor','Tutor',15,30,'sekolah','','➕📐📚✏️🧪🌍'],
['ridefood','Rider Makanan',10,25,'bandar','bike','🍔🍕🍜🥡🧋🍗'],
['rideparcel','Rider Parcel',10,25,'pelabuhan','moto','📦✉️🗳️📮🏠🏢'],
['creator','Content Creator',12,40,'any','phone','📱🎬🎮🍜💄🎵'],
['photo','Jurugambar',15,35,'any','camera','📷🌸💍🎓🌅🏙️'],
['library','Pembantu Perpustakaan',8,12,'perpustakaan','','📚📖🔖🗂️🖨️📰'],
['cinema','Staf Pawagam',8,13,'pawagam','','🍿🎟️🥤🎬🍫🧃'],
['hotelast','Pembantu Hotel',9,14,'pulau','','🛎️🗝️🧳🛏️🧺🍹'],
['market','Pembantu Pasar Raya',8,12,'mall','','🥫🧃🥚🍞🧻🛒'],
['cafe','Pembantu Kafe',8,12,'bandar','','☕🧁🥪🍪🥤🍩'],
['stallast','Pembantu Gerai Makanan',8,13,'medan','','🍢🍜🥘🍗🍚🧋'],
];
// full-time: id,name,minQual,courses(null=any),min,max,hours,loc,levels,emoji
const FT_JOBS=[
['nurse','Jururawat','diploma',['nurse'],2800,4500,'7:00–15:00','hospital',['Jururawat','Jururawat Kanan','Ketua Jururawat','Penyelia Jururawat'],'🩺💉🩹💊🌡️🧴'],
['doctor','Doktor','ijazah',['med'],4500,12000,'8:00–17:00','hospital',['Pegawai Perubatan Siswazah','Pegawai Perubatan','Pakar Perubatan','Pakar Kanan'],'🩺💊🫀🧪🩻💉'],
['teacher','Guru','ijazah',['edu'],2900,6500,'7:30–14:30','sekolah',['Guru Permulaan','Guru','Guru Kanan','Guru Besar'],'📚✏️📐🧪🌍🎨'],
['police','Pegawai Polis','spm',null,2500,6000,'8:00–17:00','polis',['Konstabel','Koperal','Sarjan','Inspektor'],'🚓📋🔦📻🚨🗺️'],
['fire','Ahli Bomba','spm',null,2500,5500,'Syif 8 jam','bomba',['Ahli Bomba','Pegawai Bomba','Ketua Balai','Penguasa Bomba'],'🧯🚒🪜💧🔥⛑️'],
['ptd','Pegawai Tadbir Kerajaan','ijazah',null,3500,9000,'8:00–17:00','pejabat',['Pegawai Tadbir','Penolong Setiausaha','Timbalan Pengarah','Pengarah'],'📁🖋️📊📞🗂️🏛️'],
['bank','Pegawai Bank','ijazah',['bus','acc'],2800,7500,'9:00–17:30','bandar',['Pegawai Bank','Eksekutif Kanan','Pengurus Cawangan','Pengurus Wilayah'],'🏦💳💵📈🧾🔐'],
['hotel','Kakitangan Hotel','spm',null,2000,3800,'Syif 8 jam','pulau',['Penyambut Tetamu','Penyelia Kaunter','Ketua Unit','Pengurus Bertugas'],'🛎️🗝️🧳🛏️🍹📋'],
['chef','Chef','spm',null,2500,6000,'10:00–19:00','mall',['Commis Chef','Chef de Partie','Sous Chef','Chef Eksekutif'],'🍳🥘🍜🔪🧂🍤'],
['hotelmgr','Pengurus Hotel','ijazah',['hosp','tour','bus'],5000,12000,'9:00–18:00','pulau',['Penolong Pengurus','Pengurus Hotel','Pengurus Besar','Pengarah Operasi'],'🏨📊🛎️🤝📞🗝️'],
['accountant','Akauntan','ijazah',['acc'],3500,9000,'9:00–18:00','bandar',['Akauntan Pelatih','Akauntan','Akauntan Kanan','Ketua Pegawai Kewangan'],'🧮📊💹🧾📑💼'],
['engineer','Jurutera','ijazah',['eng'],3800,10000,'8:30–17:30','pelabuhan',['Jurutera Siswazah','Jurutera','Jurutera Kanan','Jurutera Utama'],'⚙️🔧📐🏗️⚡🛠️'],
['it','Pakar IT','diploma',['it','cs'],3500,9500,'9:00–18:00','bandar',['Juruteknik IT','Pakar IT','Arkitek Sistem','Ketua Pegawai Teknologi'],'💻🖥️🔒☁️🛰️⌨️'],
['designer','Pereka','diploma',['art'],2800,7000,'10:00–19:00','mall',['Pereka Junior','Pereka','Pereka Kanan','Pengarah Kreatif'],'🎨✏️🖌️🖼️📐💡'],
['journalist','Wartawan','ijazah',['com'],3000,7000,'Fleksibel','bandar',['Wartawan Pelatih','Wartawan','Wartawan Kanan','Ketua Pengarang'],'📰🎙️📷✍️🗞️📡'],
['pharma','Ahli Farmasi','ijazah',['med','nurse'],3800,8500,'8:00–17:00','klinik',['Pegawai Farmasi','Ahli Farmasi','Ahli Farmasi Kanan','Ketua Farmasi'],'💊🧪⚗️💉🩹📋'],
['vet','Pegawai Veterinar','ijazah',['agri'],3800,8500,'8:00–17:00','ladang',['Pegawai Veterinar','Pegawai Kanan','Ketua Veterinar','Pengarah Veterinar'],'🐄🐐🐔🩺💉🐇'],
['lawyer','Peguam','ijazah',['law'],4000,12000,'9:00–18:00','bandar',['Peguam Pelatih','Peguam','Peguam Kanan','Rakan Kongsi'],'⚖️📜🗂️🖋️🏛️📚'],
['architect','Arkitek','ijazah',['arch','eng'],3800,10000,'9:00–18:00','bandar',['Arkitek Siswazah','Arkitek','Arkitek Kanan','Pengarah Reka Bentuk'],'📐🏗️🖊️🏛️📏🧱'],
['pilot','Juruterbang','diploma',['eng','tour'],6000,18000,'Syif penerbangan','airport',['Pegawai Pertama','Kapten Muda','Kapten','Kapten Kanan'],'✈️🧭☁️🛫🛬📡'],
['bizmgr','Pengurus Perniagaan','ijazah',['bus','acc'],4000,11000,'9:00–18:00','bandar',['Eksekutif','Pengurus','Pengurus Kanan','Pengarah Urusan'],'📊💼📈🤝📞🗂️'],
['civil','Penjawat Awam','spm',null,1800,4500,'8:00–17:00','pejabat',['Pembantu Tadbir','Penolong Pegawai','Pegawai Eksekutif','Ketua Unit'],'📁📞🗂️🖋️📋🏛️'],
];
// business: id,name,capital,daily base,req,emoji,staffWage
const BIZ=[
['stall','Gerai Makanan',2500,90,'','🍢',60],
['resto','Restoran',30000,420,'','🍽️',80],
['boutique','Butik Pakaian',18000,300,'','👗',70],
['online','Perniagaan Online',3000,120,'laptop','🛒',60],
['bakery','Kedai Kek & Bakeri',12000,220,'','🎂',65],
['florist','Kedai Bunga',8000,160,'','💐',60],
['urban','Kebun Bandar',5000,140,'farm','🌱',55],
['fishbiz','Perikanan (Tangkap & Jual)',9000,200,'rod2','🐟',65],
['craft','Kraf Tangan',2000,90,'','🧺',50],
['freelance','Freelance Reka Bentuk',1500,130,'laptop','🖌️',70],
['photobiz','Studio Fotografi',7000,180,'camera','📸',70],
['musician','Pemuzik / Artis',1200,110,'','🎸',60],
['stream','Live Streamer',2500,140,'phone','🎥',60],
['content','Pencipta Kandungan',2000,130,'phone','🎬',60],
];

// ===== HOUSING =====
// id,name,rent,buy,slots per room,location,comfort
const HOUSES=[
['keluarga','Rumah Keluarga (Teres)',0,0,3,'perumahan',1],
['kampung','Rumah Kampung',300,85000,4,'kampung',2],
['teres','Rumah Teres',900,380000,4,'perumahan',3],
['apartmen','Apartmen',700,250000,4,'perumahan',3],
['kondo','Kondominium',1800,650000,5,'bandar',4],
['semid','Rumah Moden Bandar',2800,1200000,6,'perumahan',5],
['banglo','Banglo Mewah',4500,2500000,7,'perumahan',6],
['vila','Rumah Tepi Air',9000,6800000,8,'pantai',8],
].map(h=>({id:h[0],name:h[1],rent:h[2],buy:h[3],slots:h[4],loc:h[5],comfort:h[6]}));
const HOUSE=Object.fromEntries(HOUSES.map(h=>[h.id,h]));
const ROOMS=[['bilik','Bilik Tidur'],['tamu','Ruang Tamu'],['dapur','Dapur'],['mandi','Bilik Air'],['belajar','Bilik Belajar'],['balkoni','Balkoni'],['laman','Taman / Laman']];
// furniture: id,name,room,price,shape,colour,comfort
const FURN=[
['katil1','Katil Bujang','bilik',350,'bed','#8fb0e8',2],['katil2','Katil Queen','bilik',1200,'bed','#c9a7ec',4],['katil3','Katil Mewah Kanopi','bilik',4800,'bed','#f4b6c8',7],
['almari','Almari Pakaian','bilik',650,'wardrobe','#c8a070',2],['meja','Meja Belajar','bilik',280,'desk','#d8b080',2],['pc','Komputer Riba','bilik',2600,'pc','#4a4a5a',3],
['lampu','Lampu Tidur','bilik',90,'lamp','#ffd56b',1],['ac','Penghawa Dingin','bilik',1500,'ac','#f4f4f4',4],
['sofa1','Sofa 2-Tempat','tamu',900,'sofa','#6a8ac8',3],['sofa2','Sofa L Baldu','tamu',3200,'sofa','#7a5ac8',6],['tv','TV Pintar 55"','tamu',2200,'tv','#2b2b33',4],
['rak','Rak Buku','tamu',420,'shelf','#a8784a',2],['permaidani','Permaidani Songket','tamu',650,'rug','#c03050',3],['pasu','Pokok Hiasan','tamu',120,'plant','#3a9a4a',1],
['frame','Bingkai Seni','tamu',300,'frame','#e2b44a',2],['ketupat','Hiasan Ketupat','tamu',60,'deco','#4aa04a',1],
['dapurgas','Dapur Gas','dapur',450,'stove','#c8c8c8',2],['peti','Peti Sejuk','dapur',1800,'fridge','#e8eef5',3],['meja2','Meja Makan','dapur',900,'table','#b0804a',3],
['singki','Singki Kabinet','dapur',600,'sink','#d8d8e0',2],['oven','Ketuhar','dapur',1100,'oven','#3a3a44',3],
['tab','Tab Mandi','mandi',2400,'bath','#f4f8ff',4],['shower','Pancuran','mandi',500,'shower','#cfe0f0',2],['mesinbasuh','Mesin Basuh','mandi',1300,'washer','#f0f0f4',3],['cermin','Cermin Besar','mandi',260,'mirror','#c0e0f0',1],
['buaian','Buaian Taman','laman',800,'swing','#8b5a2b',3],['bunga','Pasu Bunga Raya','laman',80,'flower','#e5484d',1],['bbq','Set BBQ','laman',700,'bbq','#3a3a3a',2],
['kolam','Kolam Ikan Hiasan','laman',2500,'pond','#3a9ad0',4],['bangku','Bangku Kayu','laman',350,'bench','#a87040',2],
['akuarium','Akuarium (simpan ikan)','tamu',1600,'aquarium','#5ac8f0',4],['trofi','Rak Trofi & Koleksi','tamu',900,'trophy','#a8784a',3],
['tanglung','Tanglung Merah (CNY)','tamu',80,'deco','#e5484d',1],['pelita','Pelita Raya / Deepavali','laman',70,'deco','#f2a20c',1],['pokokkrismas','Pokok Krismas','tamu',260,'plant','#2a8a4a',2],
['meja3','Meja Belajar Besar','belajar',650,'desk','#b08050',3],['rak2','Rak Buku Tinggi','belajar',520,'shelf','#8a5a33',3],['pc2','Komputer Meja','belajar',3200,'pc','#2b2b33',4],
['kerusi','Kerusi Malas','balkoni',380,'bench','#3a86ff',2],['pokok2','Pokok Bunga Balkoni','balkoni',120,'flower','#ff5ea8',1],['lampu2','Lampu Pelita Balkoni','balkoni',150,'lamp','#ffd56b',1],
].map(f=>({id:f[0],name:f[1],room:f[2],price:f[3],shape:f[4],c:f[5],comfort:f[6]}));
const FURNI=Object.fromEntries(FURN.map(f=>[f.id,f]));
const WALLS=[['#fbe7d0','Krim',0],['#dfe9ff','Biru Lembut',80],['#e9dcff','Lavender',80],['#ffe0ea','Merah Jambu',80],['#e0f3e4','Pudina',80],['#f4f4f4','Putih',50],['#3a3550','Malam',150],['#ffe9a8','Kuning Mentega',80],['pat:batik','Batik',250],['pat:songket','Songket',300]];
const FLOORS=[['#c9a074','Kayu Oak',0],['#8b5a33','Kayu Gelap',150],['#e8e2d8','Jubin Marmar',250],['#b8c4d0','Jubin Kelabu',120],['#d8b890','Tikar Mengkuang',90],['#9a7ab0','Permaidani Ungu',180]];
const VEHICLES=[['basikal','Basikal',450,1.35,'bike'],['moto','Motosikal',6500,1.75,'moto'],['kompak','Kereta Kompak',38000,2.05,'car'],['suv','Kereta SUV',120000,2.15,'car'],['mewah','Kereta Mewah',320000,2.35,'car'],['bot','Bot Laju',28000,0,'boat']];
const VEH=Object.fromEntries(VEHICLES.map(v=>[v[0],{id:v[0],name:v[1],price:v[2],spd:v[3],kind:v[4]}]));

// ===== FARM =====
// id,name,seed price,grow hours,sell price,colour,emoji
const CROPS=[
['sayur','Sayur Sawi',6,16,14,'#5cb85c','🥬'],['timun','Timun',8,22,18,'#4a9a3a','🥒'],['cili','Cili',10,28,24,'#e5383b','🌶️'],['tomato','Tomato',10,28,22,'#e85a3a','🍅'],
['terung','Terung',10,30,24,'#7a3fa0','🍆'],['jagung','Jagung',12,34,28,'#f2c230','🌽'],['padi','Padi (Beras)',14,48,38,'#d8b84a','🌾'],['tembikai','Tembikai',22,58,70,'#3a9a4a','🍉'],
['nanas','Nanas',24,66,78,'#f2a20c','🍍'],['pisang','Pisang',26,70,80,'#f2d33a','🍌'],['kelapa','Kelapa',30,90,95,'#8b5a2b','🥥'],
].map(c=>({id:c[0],name:c[1],seed:c[2],grow:c[3],sell:c[4],c:c[5],e:c[6]}));
const CROP=Object.fromEntries(CROPS.map(c=>[c.id,c]));
// animals: id,name,price,product,product id,product price,emoji,hours
const ANIMALS=[['ayam','Ayam',30,'Telur','telur',2,'🐔',24],['itik','Itik',35,'Telur Itik','teluritik',3,'🦆',24],['lembu','Lembu',2500,'Susu Lembu','susu',12,'🐄',24],['kambing','Kambing',900,'Susu Kambing','susukambing',15,'🐐',24],['arnab','Arnab',60,'Baja Organik','baja',6,'🐇',24],['kolam','Kolam Ternakan Ikan',1500,'Ikan Ternakan','ikanternak',28,'🐟',36]].map(a=>({id:a[0],name:a[1],price:a[2],pname:a[3],pid:a[4],pprice:a[5],e:a[6],hrs:a[7]}));
const ANIMAL=Object.fromEntries(ANIMALS.map(a=>[a.id,a]));

// ===== ITEMS (generic inventory) =====
// id: [name, emoji, sell, energy(if edible), happiness]
const ITEMS={
telur:['Telur Ayam','🥚',2],telurItik:['Telur Itik','🥚',3],
susu:['Susu Lembu','🥛',12],susukambing:['Susu Kambing','🥛',15],baja:['Baja Organik','🧪',6],ikanternak:['Ikan Ternakan','🐟',28],
santan:['Santan','🥥',4],daging:['Daging','🥩',0],mee:['Mee','🍜',0],tepung:['Tepung','🌾',3],gula:['Gula','🧂',3],bawang:['Bawang','🧅',2],rempah:['Rempah Ratus','🫙',5],
feed:['Makanan Haiwan','🌾',0],bunga:['Jambangan Bunga','💐',0],coklat:['Coklat','🍫',0,10,5],buku:['Buku Novel','📖',0],kuih:['Kuih Muih','🍡',0,15,6],
bungatelur:['Bunga Telur','🌸',0],angpow:['Ang Pow','🧧',0],muruku:['Muruku','🥨',0,12,6],
};
ANIMAL.itik.pid='telurItik';
CROPS.forEach(c=>ITEMS[c.id]=[c.name,c.e,c.sell]);
// recipes: id,name,emoji,needs{key:qty} (fish groups prefixed f:), energy, happiness, sell
const RECIPES=[
['ikanbakar','Ikan Bakar','🐟',{'f:ikan':1,cili:1},35,8,26],
['asampedas','Asam Pedas','🍲',{'f:ikan':1,tomato:1,cili:1},45,10,40],
['gulai','Gulai Ikan Kelapa','🥘',{'f:ikan':1,kelapa:1},45,10,42],
['sambaludang','Sambal Udang','🦐',{'f:udang':1,cili:2},40,12,48],
['sotonggoreng','Sotong Goreng Tepung','🦑',{'f:sotong':1,telur:1},38,12,40],
['ketamlemak','Ketam Masak Lemak','🦀',{'f:ketam':1,kelapa:1},45,14,58],
['kerangrebus','Kerang Rebus','🐚',{'f:kerang':1,cili:1},25,8,22],
['nasilemak','Nasi Lemak','🍛',{padi:1,kelapa:1,telur:1,cili:1},60,15,30],
['nasigoreng','Nasi Goreng Kampung','🍚',{padi:1,telur:1,cili:1},50,10,22],
['pajeri','Pajeri Terung','🍆',{terung:1,kelapa:1},35,8,30],
['supjagung','Sup Jagung','🌽',{jagung:1,telur:1},30,8,20],
['kerabu','Kerabu Timun','🥗',{timun:1,cili:1,tomato:1},28,8,24],
['lepat','Lepat Pisang','🍌',{pisang:2},30,10,30],
['jemnanas','Tart Nanas','🍍',{nanas:1,telur:1},25,14,45],
['airtembikai','Jus Tembikai','🍉',{tembikai:1},22,10,30],
['tehtarik','Teh Tarik','🥤',{susu:1},20,10,8],
['sayurgoreng','Sayur Goreng Belacan','🥬',{sayur:1,cili:1},25,6,14],
['rotican','Roti Canai','🫓',{tepung:1,telur:1},30,8,10],
['cendol','Cendol','🍧',{santan:1,gula:1},20,14,15],
['abc','Ais Batu Campur (ABC)','🍨',{gula:1,susu:1},18,14,14],
['satay','Satay','🍢',{daging:1,rempah:1},40,12,35,2],
['kolomee','Kolo Mee','🍜',{mee:1,daging:1},45,10,30,2],
['tuaran','Mee Tuaran','🍜',{mee:1,telur:1,sayur:1},42,10,28,2],
['hinava','Hinava','🐟',{'f:ikan':1,cili:1,bawang:1},35,12,45,3],
['ambuyat','Ambuyat','🥣',{tepung:2},30,8,20,3],
['ckt','Char Kuey Teow','🍝',{mee:1,'f:udang':1,telur:1},45,12,32,4],
['laksa','Laksa Sarawak','🍲',{mee:1,'f:udang':1,santan:1},50,14,40,5],
['rendang','Rendang Daging','🍛',{daging:1,santan:1,rempah:1},55,16,60,6],
];
RECIPES.forEach(r=>ITEMS['d_'+r[0]]=[r[1],r[2],r[6],r[4],r[5]]);
// shop food (instant eat)
const MEALS=[['Nasi Lemak Bungkus','🍛',5,30,4],['Roti Canai & Teh Tarik','🫓',6,30,5],['Mee Goreng Mamak','🍜',8,35,5],['Char Kuey Teow','🍝',10,38,6],['Nasi Kerabu','🍚',10,38,7],['Laksa Sarawak','🍲',12,42,8],['Kolo Mee','🍜',9,36,6],['Mee Tuaran','🍜',9,36,6],['Hinava & Nasi','🐟',12,40,8],['Ambuyat','🥣',10,34,7],['Satay (10 cucuk)','🍢',14,40,10],['Cendol','🍧',5,12,8],['ABC','🍨',6,12,8]];
const GROCERY=[['telur','Telur (10)',5,10],['daging','Daging (500g)',14,1],['mee','Mee kuning',3,1],['tepung','Tepung',3,1],['gula','Gula',3,1],['rempah','Rempah ratus',5,1],['bawang','Bawang',2,1],['padi','Beras (1kg)',4,1],['kelapa','Kelapa',4,1],['cili','Cili',3,1],['tomato','Tomato',3,1],['sayur','Sawi',3,1],['timun','Timun',3,1],['susu','Susu',7,1],['santan','Santan',4,1],['feed','Makanan Haiwan (10)',25,10],['coklat','Coklat',9,1],['bunga','Jambangan Bunga',35,1]];

// ===== NPCS =====
// id,name,gender,skin,hair,hairCol,hijab,outfit,role,zone[x,y],likes,line
const NPCS=[
['aiman','Aiman','m',2,1,0,0,'k1','Pelajar universiti',[36,13],['kuih','d_nasilemak'],'Assignment banyak gila minggu ni! Jom study group?'],
['siti','Siti Nurhaliza','f',1,0,2,1,'h3','Pelajar kolej',[40,12],['bunga','coklat'],'Saya nak mohon biasiswa tahun ni. Doakan ya!'],
['meiling','Tan Mei Ling','f',0,4,0,0,'h7','Pereka grafik',[57,38],['coklat','d_jemnanas'],'Asia Mall ada jualan murah hari ni tau!'],
['arjun','Arjun Pillai','m',4,2,0,0,'h8','Jurutera muda',[60,42],['d_tehtarik','muruku'],'Saya baru naik pangkat. Kerja keras berbaloi!'],
['priya','Priya Devi','f',4,1,1,0,'t14','Doktor',[56,13],['bunga','buku'],'Jangan lupa jaga kesihatan. Klinik caj RM1 sahaja!'],
['jason','Jason Wong','m',0,3,0,0,'m6','Peniaga',[66,42],['d_tehtarik','coklat'],'Bisnes online saya makin laju. Nak join?'],
['nurul','Nurul Izzah','f',2,0,3,1,'mu3','Guru',[34,25],['buku','bunga'],'Pelajar saya semua rajin. Belajar rajin-rajin ya!'],
['danial','Danial Hakim','m',3,0,0,0,'w3','Pegawai polis',[76,31],['d_nasigoreng','kuih'],'Kota Kita selamat. Laporkan apa-apa yang mencurigakan.'],
['kavitha','Kavitha','f',5,0,0,0,'t13','Ahli farmasi',[61,30],['bunga','muruku'],'Deepavali nanti datang rumah saya, ada muruku!'],
['ahkeong','Ah Keong','m',1,5,6,0,'h6','Nelayan',[80,49],['f:ikan','d_ikanbakar'],'Ikan kerapu banyak waktu hujan. Petua orang lama!'],
['joanna','Joanna Gimbang','f',3,1,1,0,'t20','Pemandu pelancong',[84,33],['bunga','d_lepat'],'Kotobian Tadau Tagazo do Kaamatan! Saya dari Penampang.'],
['mering','Mering anak Jalong','m',4,0,0,0,'h2','Petani',[8,55],['d_supjagung','kuih'],'Gayu guru gerai nyamai! Musim Gawai paling meriah.'],
['faridah','Mak Cik Faridah','f',2,0,6,1,'t3','Penjual pasar',[32,52],['bunga','coklat'],'Sayur segar dari ladang! Murah-murah!'],
['haziq','Haziq','m',2,4,0,0,'s1','Pelajar sekolah',[38,24],['coklat','kuih'],'SPM makin dekat... cuak betul.'],
['lim','Lim Wei Jie','m',0,2,0,0,'w5','Chef',[72,40],['d_asampedas','d_ketamlemak'],'Rahsia asam pedas? Asam keping dan kesabaran!'],
['rajesh','Rajesh Kumar','m',5,1,0,0,'w4','Ahli bomba',[82,31],['d_tehtarik','kuih'],'Pastikan alat pemadam api ada di rumah!'],
['aisyah','Aisyah','f',1,0,0,1,'mu1','Usahawan butik',[70,38],['bunga','coklat'],'Koleksi raya baru dah sampai di butik saya!'],
['farhan','Farhan','m',3,5,0,0,'sp1','Jurulatih sukan',[45,60],['d_airtembikai','kuih'],'Jom jogging keliling tasik! Bagus untuk stamina.'],
['dayang','Dayang Nurfaizah','f',2,1,1,0,'t36','Penari budaya',[12,40],['bunga','kuih'],'Tarian tradisional ni warisan kita semua.'],
['ken','Kenneth Lojuki','m',3,3,0,0,'t19','Renjer hutan',[14,18],['d_ikanbakar','kuih'],'Sungai di hulu ni ada ikan kelah. Tapi jaga alam ya!'],
['mei','Chloe Lim','f',0,5,9,0,'m2','Pempengaruh media',[66,36],['coklat','bunga'],'Jom buat content kat pantai petang ni!'],
['hafiz','Pak Hafiz','m',3,5,6,0,'t2','Ketua kampung',[9,37],['kuih','d_nasilemak'],'Sabtu ni gotong-royong. Datang ramai-ramai!'],
['siew','Siew Lan','f',0,3,0,0,'t11','Pemilik kedai',[52,36],['bunga','d_lepat'],'Kebaya nyonya ni jahitan tangan, warisan nenek saya.'],
['amir','Amir','m',2,0,1,0,'w8','Rider penghantaran',[48,48],['d_tehtarik','kuih'],'Order banyak waktu tengah hari. Rezeki!'],
];
const FAMILY=[['Mak','f',2,0,6,1,'t3'],['Ayah','m',2,2,6,0,'t2'],['Adik','u',2,0,0,0,'s1']];

// ===== FESTIVALS =====
// month(1-12), day, id, name, desc, reward
const FESTS=[
[2,17,'cny','Tahun Baru Cina','Ang pow, tarian singa dan limau mandarin!'],
[2,18,'cny','Tahun Baru Cina (Hari 2)','Kunjung-mengunjung rumah terbuka.'],
[3,20,'raya','Hari Raya Aidilfitri','Duit raya, ketupat dan rendang di rumah terbuka!'],
[3,21,'raya','Hari Raya Aidilfitri (Hari 2)','Beraya ke rumah jiran dan saudara.'],
[5,30,'kaamatan','Pesta Kaamatan','Pesta menuai Kadazan-Dusun: Unduk Ngadau dan tarian Sumazau.'],
[5,31,'kaamatan','Pesta Kaamatan (Hari 2)','Sambutan kesyukuran menuai.'],
[6,1,'gawai','Hari Gawai Dayak','Pesta menuai Sarawak: ngajat dan rumah panjang terbuka.'],
[6,2,'gawai','Hari Gawai (Hari 2)','Gayu guru gerai nyamai!'],
[8,31,'merdeka','Hari Kebangsaan (Merdeka)','Perarakan dan kibar Jalur Gemilang!'],
[9,16,'malaysia','Hari Malaysia','Raikan gabungan Semenanjung, Sabah dan Sarawak.'],
[11,8,'deepavali','Deepavali','Pesta cahaya: kolam, pelita dan muruku!'],
[12,25,'krismas','Krismas','Pokok Krismas, hadiah dan nyanyian!'],
[4,15,'makanan','Pesta Makanan Malaysia','Gerai makanan dari seluruh negeri di Medan Selera!'],
[7,15,'makanan','Pesta Makanan Malaysia','Rasa laksa, hinava, kolo mee dan banyak lagi!'],
[10,15,'makanan','Pesta Makanan Malaysia','Pesta juadah tempatan di Medan Selera!'],
[5,27,'cuti','Cuti Sekolah Bermula','Cuti sekolah! Masa untuk kerja sambilan dan bercuti.'],
[11,21,'cuti','Cuti Akhir Tahun Bermula','Cuti panjang akhir tahun — percutian keluarga!'],
];
const MONTHS=['Januari','Februari','Mac','April','Mei','Jun','Julai','Ogos','September','Oktober','November','Disember'];
const MDAYS=[31,28,31,30,31,30,31,31,30,31,30,31];
const WEEK=['Isnin','Selasa','Rabu','Khamis','Jumaat','Sabtu','Ahad'];

// ===== ACHIEVEMENTS =====
const ACH=[
['start','Selamat Datang!','Cipta watak anda',s=>true],
['pay1','Gaji Pertama','Siapkan syif kerja pertama',s=>s.cnt.shifts>=1],
['pay20','Pekerja Rajin','Siapkan 20 syif kerja',s=>s.cnt.shifts>=20],
['fish1','Tangkapan Pertama','Tangkap ikan pertama',s=>s.cnt.fish>=1],
['fish10','Kaki Pancing','Kumpul 10 spesies',s=>Object.keys(s.fishdex).length>=10],
['fish28','Pakar Memancing','Kumpul 28 spesies',s=>Object.keys(s.fishdex).length>=28],
['fish56','Legenda Laut & Sungai','Lengkapkan semua 56 spesies',s=>Object.keys(s.fishdex).length>=56],
['cons1','Penjaga Alam','Lepaskan haiwan dilindungi',s=>s.cnt.prot>=1],
['cons10','Wira Pemuliharaan','Lepaskan 10 haiwan dilindungi',s=>s.cnt.prot>=10],
['farm1','Petani Muda','Tuai hasil pertama',s=>s.cnt.harvest>=1],
['farm50','Petani Jaya','Tuai 50 hasil',s=>s.cnt.harvest>=50],
['cook10','Tukang Masak','Masak 10 hidangan',s=>s.cnt.cook>=10],
['spm','Lulus SPM','Dapat keputusan SPM',s=>s.spm!=null],
['grad','Graduan','Tamat pengajian pertama',s=>s.degrees.length>=1],
['ijazah','Ijazah Sarjana Muda','Graduasi ijazah',s=>s.degrees.some(d=>d.level==='ijazah')],
['phd','Doktor Falsafah','Graduasi PhD',s=>s.degrees.some(d=>d.level==='phd')],
['ft','Kerjaya Bermula','Dapat kerja sepenuh masa',s=>!!s.job],
['promo','Naik Pangkat','Dinaikkan pangkat',s=>s.job&&s.job.lvl>=1],
['biz','Usahawan','Buka perniagaan',s=>Object.keys(s.biz).length>=1],
['rm10k','Simpanan RM10K','Jumlah aset tunai RM10,000',s=>s.money+s.bank>=10000],
['rm100k','Jutawan Kecil','Jumlah aset tunai RM100,000',s=>s.money+s.bank>=100000],
['home','Pemilik Rumah','Beli rumah pertama',s=>s.home.owned],
['veh','Bergerak!','Beli kenderaan',s=>s.vehicles.length>=1],
['friend','Kawan Baik','Capai tahap Kawan Baik',s=>Object.values(s.friends).some(v=>v>=50)],
['friend5','Disenangi Ramai','5 Kawan Baik',s=>Object.values(s.friends).filter(v=>v>=50).length>=5],
['fest','Anak Malaysia','Sertai sambutan perayaan',s=>s.cnt.fest>=1],
['fest5','Malaysia Bersatu','Sertai 5 perayaan berbeza',s=>Object.keys(s.festDone).length>=5],
['champ','Juara Memancing','Menang pertandingan memancing',s=>s.cnt.champ>=1],
['trad10','Pencinta Warisan','Miliki 10 pakaian tradisional',s=>s.owned.filter(i=>OUT[i]&&OUT[i].cat==='tradisi').length>=10],
['explore','Peneroka Kota','Lawati semua 29 lokasi',s=>Object.keys(s.visited).length>=LOCS.length],
['skill5','Pakar','Capai tahap 5 dalam satu kemahiran',s=>SKILLS.some(k=>skillLv(k[0])>=5)],
['daily10','Rajin Setiap Hari','Siapkan 10 misi harian',s=>(s.cnt.dq||0)>=10],
['aqua','Akuaris','Simpan 3 ikan dalam akuarium',s=>(s.aqua||[]).length>=3],
['lv10','Tahap 10','Capai tahap 10',s=>s.lvl>=10],
['lv25','Tahap 25','Capai tahap 25',s=>s.lvl>=25],
];

const SKILLS=[['edu','Pendidikan'],['career','Kerjaya'],['fish','Memancing'],['cook','Masakan'],['farm','Pertanian'],['social','Sosial'],['creative','Kreativiti'],['sports','Sukan']];
const CERTS=[['firstaid','Sijil Pertolongan Cemas',150,'hospital',['nurse','doctor','fire','police','pharma']],['food','Sijil Pengendalian Makanan',80,'klinik',['chef','stallast','waiter','kitchen','cafe','barista','hotel']],['digital','Sijil Pemasaran Digital',300,'kerjaya',['creator','it','designer','journalist','bizmgr']],['drive','Lesen Memandu',250,'polis',['pilot','ridefood','rideparcel','police']],['lang','Sijil Bahasa Inggeris (MUET)',200,'perpustakaan',['hotel','hotelmgr','teacher','lawyer','bizmgr','bank']],['safety','Sijil Keselamatan Tapak',180,'bomba',['engineer','architect','fire']]];
const MAINQ=[['Masuk ke Rumah Anda',s=>s.visited.perumahan,100,3],['Bercakap dengan seorang penduduk',s=>(s.cnt.talk||0)>=1,80,2],['Siapkan kerja sambilan pertama',s=>s.cnt.shifts>=1,150,3],['Cuba aktiviti memancing',s=>s.cnt.fish>=1,120,3],['Tanam benih di ladang',s=>s.farm.plots.some(p=>p)||s.cnt.harvest>0,120,3],['Beli pakaian baharu',s=>(s.cnt.outfit||0)>=1,100,3],['Masak satu hidangan',s=>s.cnt.cook>=1,120,3],['Mohon ke universiti atau kerja',s=>s.apps.length>0||!!s.job,200,5],['Lawati 10 lokasi',s=>Object.keys(s.visited).length>=10,250,5],['Capai Tahap 5',s=>s.lvl>=5,300,8],['Simpan RM5,000 di bank',s=>s.bank>=5000,400,8],['Miliki kenderaan atau rumah',s=>s.vehicles.length>0||s.home.owned,500,10],['Lengkapkan 20 spesies ikan',s=>Object.keys(s.fishdex).length>=20,600,12],['Graduasi dari IPT',s=>s.degrees.length>0,800,15],['Capai Tahap 15',s=>s.lvl>=15,1000,20]];
const DAILYQ=[['fish','Tangkap 3 hasil laut',s=>s.cnt.fish,3],['walk','Berjalan 500 meter',s=>Math.floor(s.cnt.walk||0),500],['talk','Bercakap dengan NPC',s=>s.cnt.talk||0,1],['shift','Siapkan 1 syif kerja',s=>s.cnt.shifts,1],['harvest','Tuai 3 hasil ladang',s=>s.cnt.harvest,3],['cook','Masak 1 hidangan',s=>s.cnt.cook,1],['enter','Masuk 3 lokasi',s=>s.cnt.enter||0,3],['class','Hadiri 1 kelas',s=>s.cnt.classes,1],['buy','Beli sesuatu',s=>s.cnt.buy||0,1],['sport','Bersukan sekali',s=>s.cnt.sport||0,1]];
const WEEKLYQ=[['fish','Tangkap 15 hasil laut',s=>s.cnt.fish,15],['shift','Siapkan 5 syif kerja',s=>s.cnt.shifts,5],['harvest','Tuai 15 hasil ladang',s=>s.cnt.harvest,15],['cook','Masak 5 hidangan',s=>s.cnt.cook,5],['walk','Berjalan 3 km',s=>Math.floor(s.cnt.walk||0),3000],['talk','Berbual 7 kali',s=>s.cnt.talk||0,7],['prot','Lepaskan 1 haiwan dilindungi',s=>s.cnt.prot,1],['class','Hadiri 6 kelas',s=>s.cnt.classes,6]];
const INTERVIEW=[['Kenapa anda memohon jawatan ini?',['Saya minat bidang ini dan mahu menyumbang kepada organisasi','Saya cuma perlukan gaji','Kawan saya yang suruh','Tidak pasti'],0],['Apakah kekuatan utama anda?',['Bertanggungjawab dan boleh bekerja dalam pasukan','Selalu lewat tetapi pandai','Tidak suka bekerja','Tiada'],0],['Bagaimana anda menangani tekanan kerja?',['Merancang tugasan dan berbincang dengan pasukan','Menangguhkan kerja','Marah kepada rakan sekerja','Terus berhenti kerja'],0],['Di mana anda melihat diri anda dalam 5 tahun?',['Berkembang dan memegang tanggungjawab lebih besar','Tidak pernah fikir','Bercuti panjang','Tukar kerja setiap bulan'],0],['Jika pelanggan marah, apa yang anda lakukan?',['Dengar dengan tenang dan cari penyelesaian','Abaikan pelanggan','Balas dengan marah','Suruh pelanggan pergi'],0],['Apakah pakaian sesuai untuk temu duga?',['Kemas dan formal','Baju tidur','Pakaian sukan yang kotor','Selipar dan seluar pendek'],0],['Rakan sepasukan memerlukan bantuan, anda…',['Membantu sambil menyiapkan tugas sendiri','Pura-pura tidak nampak','Ambil kredit kerjanya','Mengadu kepada semua orang'],0]];
const QUIZ=[
['Ibu negeri Sabah ialah…',['Kota Kinabalu','Sandakan','Tawau','Kudat'],0],
['Ibu negeri Sarawak ialah…',['Kuching','Miri','Sibu','Bintulu'],0],
['Malaysia mencapai kemerdekaan pada tahun…',['1957','1963','1945','1969'],0],
['Malaysia dibentuk pada tahun…',['1963','1957','1965','1971'],0],
['Gunung tertinggi di Malaysia ialah…',['Gunung Kinabalu','Gunung Tahan','Gunung Ledang','Gunung Mulu'],0],
['Sungai terpanjang di Malaysia ialah…',['Sungai Rajang','Sungai Pahang','Sungai Kinabatangan','Sungai Perak'],0],
['Bunga kebangsaan Malaysia ialah…',['Bunga Raya','Orkid','Melur','Teratai'],0],
['Pesta menuai di Sabah dipanggil…',['Kaamatan','Gawai','Thaipusam','Chap Goh Mei'],0],
['Pesta menuai di Sarawak dipanggil…',['Gawai','Kaamatan','Deepavali','Vesak'],0],
['Berapa buah negeri di Malaysia?',['13','14','11','12'],0],
['H₂O ialah formula bagi…',['Air','Garam','Oksigen','Gula'],0],
['Planet terbesar dalam Sistem Suria ialah…',['Musytari','Zuhal','Bumi','Marikh'],0],
['Haiwan yang wajib dilepaskan jika tertangkap ialah…',['Penyu','Ikan kembung','Sotong','Ikan selar'],0],
['Mata wang Malaysia ialah…',['Ringgit','Rupiah','Baht','Dolar'],0],
['Kain tenunan benang emas tradisional Melayu ialah…',['Songket','Batik','Pua Kumbu','Tekat'],0],
['Pua Kumbu ialah tenunan tradisional kaum…',['Iban','Bajau','Melayu','Murut'],0],
['Pesta cahaya yang disambut masyarakat India ialah…',['Deepavali','Ponggal','Holi','Onam'],0],
['Pulau Manukan terletak berhampiran…',['Kota Kinabalu','Langkawi','Pulau Pinang','Kuching'],0],
['Organ yang mengepam darah ialah…',['Jantung','Paru-paru','Hati','Buah pinggang'],0],
['Fotosintesis berlaku di bahagian tumbuhan yang dipanggil…',['Daun','Akar','Batang','Bunga'],0],
];
