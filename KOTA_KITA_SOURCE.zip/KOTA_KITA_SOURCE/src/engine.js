// ===================== ENGINE =====================
const RT={k:1,zoom:1,dpr:1,W:0,H:0,cam:{x:0,y:0},keys:{},joy:{x:0,y:0,on:false},target:null,near:null,npcs:[],cars:[],rain:[],paused:true,last:0,run:false,ride:false,stuck:0,acc:0,saveT:0,clock:0};
const P={x:0,y:0,dir:0,frame:0,ft:0,moving:false};
let cv,ctx;
const spriteCache=new Map();
const SPR_S=.46;
function charSprite(id,C,dir,frame){
  const key=id+'|'+dir+'|'+frame+'|'+RT.k;let sp=spriteCache.get(key);if(sp)return sp;
  const k=RT.k,w=Math.ceil(100*SPR_S*k),h=Math.ceil(150*SPR_S*k);
  sp=document.createElement('canvas');sp.width=w;sp.height=h;const c=sp.getContext('2d');
  drawChibi(c,w/2,h-4*k,SPR_S*k,C,dir,frame);
  spriteCache.set(key,sp);if(spriteCache.size>600){spriteCache.delete(spriteCache.keys().next().value)}
  return sp;
}
function clearSprites(id){for(const k of [...spriteCache.keys()])if(!id||k.startsWith(id+'|'))spriteCache.delete(k)}

function npcLook(n,i){return{body:i%4===1?1:i%5===2?2:0,g:n[2],skin:n[3],face:i%4,eye:i%4,eyeCol:i%7,brow:i%4,nose:i%3,mouth:i%5,hair:n[4],hairCol:n[5],hijab:n[6],hijabSt:i%2,hijabCol:(i*3)%HIJAB_COL.length,glasses:i%7===3?1:0,hat:0,acc:i%5===2?1:0,outfit:n[7],shoes:['sh1','sh4','sh6','sh3'][i%4]}}
const FOLK=[['m',1,2,1,0,'h2'],['f',2,0,3,1,'mu4'],['m',3,5,0,0,'h8'],['f',0,4,2,0,'m4'],['m',4,1,0,0,'sp2'],['f',3,1,0,1,'h3'],['m',0,3,4,0,'k2'],['f',5,2,1,0,'h7'],['m',2,0,0,0,'w7'],['f',1,6,5,0,'k3'],['m',5,4,0,0,'h5'],['f',2,0,0,1,'sp4']];
const FOLK_LINES=['Cuaca hari ni panas betul!','Dah makan? Jom ke Pusat Bandar.','Asia Mall ada jualan murah minggu ni.','Saya baru balik dari Pulau Manukan, cantik sangat!','Jangan lupa bawa payung, nanti hujan.','Selamat datang ke Kota Kita!','Ladang di barat bandar tu subur betul.','LRT pukul 8 pagi memang sesak.'];
const FOLK_ZONES=[[55,40],[60,44],[72,48],[40,48],[50,60],[30,38],[68,30],[80,40],[34,58],[12,48],[58,26],[44,20]];
function initEntities(){
  RT.npcs=NPCS.map((n,i)=>({id:n[0],name:n[1],role:n[8],C:npcLook(n,i),home:n[9],x:n[9][0]*TS+16,y:n[9][1]*TS+16,dir:0,frame:0,ft:0,wait:Math.random()*3,tx:null,ty:null,line:n[11],likes:n[10],named:1}));
  FOLK.forEach((f,i)=>{const z=FOLK_ZONES[i];RT.npcs.push({id:'folk'+i,name:'Penduduk',role:'Penduduk Kota Kita',C:npcLook([0,'',f[0],f[1],f[2],f[3],f[4],f[5]],i+3),home:z,x:z[0]*TS+16,y:z[1]*TS+16,dir:0,frame:0,ft:0,wait:Math.random()*3,line:FOLK_LINES[i%FOLK_LINES.length],named:0})});
  for(const n of RT.npcs){if(isBlocked(n.x,n.y)){const f=findFree(Math.floor(n.x/TS),Math.floor(n.y/TS));n.x=f[0];n.y=f[1]}}
  RT.cars=[];const cc=['#e5484d','#3a86ff','#f2c230','#ffffff','#2b2b33','#38b84a','#ff8c42','#8c5cf2'];
  const lanes=[[17,0,26,86],[18,1,26,86],[30,0,0,86],[31,1,0,86],[47,0,0,86],[48,1,0,86],[65,0,10,86],[66,1,10,86]];
  lanes.forEach((l,i)=>RT.cars.push({h:1,y:l[0]*TS+16,x:(l[2]+Math.random()*(l[3]-l[2]))*TS,v:(l[1]?1:-1)*(70+Math.random()*40),min:l[2]*TS,max:l[3]*TS,c:cc[i%cc.length]}));
  [[46,0,66],[47,1,66],[63,10,66],[64,11,66]].forEach((l,i)=>RT.cars.push({h:0,x:l[0]*TS+16,y:(l[1]+Math.random()*(l[2]-l[1]))*TS,v:(i%2?1:-1)*(70+Math.random()*30),min:(i<2?0:10)*TS,max:66*TS,c:cc[(i+3)%cc.length]}));
}
function findFree(tx,ty){for(let r=0;r<8;r++)for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++){if(!isSolidTile(tx+dx,ty+dy))return[(tx+dx)*TS+16,(ty+dy)*TS+20]}return[tx*TS,ty*TS]}
function isBlocked(x,y){const pts=[[x-7,y-4],[x+7,y-4],[x-7,y+3],[x+7,y+3]];for(const [a,b] of pts){if(isSolidTile(Math.floor(a/TS),Math.floor(b/TS)))return true}return false}
function moveEnt(e,dx,dy){let moved=false;if(dx&&!isBlocked(e.x+dx,e.y)){e.x+=dx;moved=true}if(dy&&!isBlocked(e.x,e.y+dy)){e.y+=dy;moved=true}return moved}
function setDir(e,dx,dy){if(Math.abs(dx)>Math.abs(dy))e.dir=dx<0?1:2;else if(dy)e.dir=dy<0?3:0}

function resize(){
  RT.dpr=Math.min(2.5,pxr());RT.W=STG.w;RT.H=STG.h;
  RT.zoom=Math.max(1,Math.min(1.4,RT.H/520));
  const k=Math.round(RT.zoom*RT.dpr*4)/4;
  if(k!==RT.k){RT.k=k;clearChunks();spriteCache.clear()}
  RT.zoom=RT.k/RT.dpr;
  cv.width=Math.round(RT.W*RT.dpr);cv.height=Math.round(RT.H*RT.dpr);
  RT.chunkLimit=Math.max(24,Math.ceil((RT.W/RT.zoom/CH+2)*(RT.H/RT.zoom/CH+2)*1.3));
}
function viewW(){return RT.W/RT.zoom}
function viewH(){return RT.H/RT.zoom}

function placePlayerAt(locId){
  const L=LOC[locId];if(!L)return;
  const f=findFree(L.door[0],L.door[1]+1);P.x=f[0];P.y=f[1];P.dir=0;RT.target=null;
  S.pos=[P.x,P.y];visit(locId);
}

// ---- interaction targets
function interactables(){
  const list=[];
  for(const L of LOCS){const l=LOC[L[0]];list.push({kind:'loc',id:l.id,x:l.door[0]*TS+16,y:l.door[1]*TS+10,label:'Masuk '+l.name})}
  for(const s of SPOTS){const fs=FISHSPOTS.find(f=>f.id===s.id);list.push({kind:'fish',id:s.id,x:s.x*TS+16,y:s.y*TS+16,label:'Memancing: '+fs.name})}
  for(const s of SPECIAL)list.push({kind:'special',id:s.id,x:s.x*TS+16,y:s.y*TS+16,label:s.label});
  for(const n of RT.npcs)list.push({kind:'npc',id:n.id,x:n.x,y:n.y,label:(n.named?'Borak dengan ':'Tegur ')+n.name,npc:n});
  return list;
}
let IA=[];
function findNear(){
  let best=null,bd=1e9;
  for(const it of IA){const it2=it.kind==='npc'?{x:it.npc.x,y:it.npc.y}:it;const d=Math.hypot(it2.x-P.x,it2.y-P.y);const lim=it.kind==='npc'?38:it.kind==='fish'?56:46;if(d<lim&&d<bd){bd=d;best=it}}
  return best;
}

function update(dt){
  // player input
  let ix=0,iy=0;const K=RT.keys;
  if(K.ArrowLeft||K.KeyA)ix-=1;if(K.ArrowRight||K.KeyD)ix+=1;if(K.ArrowUp||K.KeyW)iy-=1;if(K.ArrowDown||K.KeyS)iy+=1;
  if(RT.joy.on){ix=RT.joy.x;iy=RT.joy.y}
  if(ix||iy)RT.target=null;
  if(!ix&&!iy&&RT.target){const dx=RT.target.x-P.x,dy=RT.target.y-P.y,d=Math.hypot(dx,dy);if(d<6){RT.target=null}else{ix=dx/d;iy=dy/d}}
  const mag=Math.hypot(ix,iy);
  let spd=115*(RT.run?1.55:1);
  if(RT.ride&&S.ride){const v=VEH[S.ride];if(v&&v.spd)spd=115*v.spd}
  if(S.energy<=0)spd*=.6;
  if(mag>0){ix/=Math.max(1,mag);iy/=Math.max(1,mag);
    const ox=P.x,oy=P.y;const moved=moveEnt(P,ix*spd*dt,iy*spd*dt);setDir(P,ix,iy);P.moving=true;S.cnt.walk=(S.cnt.walk||0)+Math.hypot(P.x-ox,P.y-oy)/16;
    if(!moved&&RT.target){RT.stuck+=dt;if(RT.stuck>.4){RT.target=null;RT.stuck=0}}else RT.stuck=0;
    P.ft+=dt*(RT.ride?6:9);P.frame=Math.floor(P.ft)%4;
    if(RT.run&&!RT.ride)S.energy=Math.max(0,S.energy-dt*.35);
  } else {P.moving=false;P.frame=0}
  // NPCs
  for(const n of RT.npcs){
    if(n.talk>0){n.talk-=dt;n.frame=0;continue}
    if(n.wait>0){n.wait-=dt;n.frame=0;if(n.wait<=0){const a=Math.random()*TAU,r=(1+Math.random()*4)*TS;n.tx=n.home[0]*TS+16+Math.cos(a)*r;n.ty=n.home[1]*TS+16+Math.sin(a)*r}continue}
    const dx=n.tx-n.x,dy=n.ty-n.y,d=Math.hypot(dx,dy);
    if(d<4||n.tx==null){n.wait=1+Math.random()*4;continue}
    const s=38*dt;if(!moveEnt(n,dx/d*s,dy/d*s)){n.wait=.5+Math.random()*2}
    setDir(n,dx,dy);n.ft+=dt*7;n.frame=Math.floor(n.ft)%4;
  }
  for(const c of RT.cars){if(c.h){c.x+=c.v*dt;if(c.x>c.max)c.x=c.min;if(c.x<c.min)c.x=c.max}else{c.y+=c.v*dt;if(c.y>c.max)c.y=c.min;if(c.y<c.min)c.y=c.max}}
  // camera
  const vw=viewW(),vh=viewH();
  RT.cam.x=Math.max(0,Math.min(MW*TS-vw,P.x-vw/2));RT.cam.y=Math.max(0,Math.min(MH*TS-vh,P.y-vh/2-20));
  if(vw>MW*TS)RT.cam.x=(MW*TS-vw)/2;
  // near
  RT.near=findNear();
  // rain
  if(S.weather==='hujan'||S.weather==='ribut'){const n=S.weather==='ribut'?240:140;while(RT.rain.length<n)RT.rain.push({x:Math.random()*RT.W,y:Math.random()*RT.H,v:500+Math.random()*300});for(const r of RT.rain){r.y+=r.v*dt;r.x-=r.v*dt*.15;if(r.y>RT.H){r.y=-10;r.x=Math.random()*(RT.W+100)}}}else RT.rain.length=0;
}

function drawCar(c,car){
  c.save();c.translate(car.x,car.y);if(!car.h)c.rotate(Math.PI/2);if(car.v<0)c.scale(-1,1);
  c.fillStyle='rgba(0,0,0,.22)';c.beginPath();c.ellipse(2,9,24,6,0,0,TAU);c.fill();
  const p=new Path2D();rrp(p,-22,-10,44,20,7);c.fillStyle=car.c;c.fill(p);c.strokeStyle=shade(car.c,-.4);c.lineWidth=1.2;c.stroke(p);
  c.fillStyle='#bfe3ff';const w=new Path2D();rrp(w,-6,-8,18,16,4);c.fill(w);c.fillStyle=shade(car.c,.25);c.fillRect(-18,-8,10,16);
  c.fillStyle='#fff6a0';c.fillRect(19,-8,3,4);c.fillRect(19,4,3,4);c.restore();
}
function drawVehicleUnder(c,x,y,kind,dir){
  c.save();c.translate(x,y);if(dir===1)c.scale(-1,1);
  if(kind==='bike'||kind==='moto'){c.strokeStyle='#2b2b33';c.lineWidth=2.2;const side=dir===1||dir===2;
    if(side){c.beginPath();c.arc(-12,-6,7,0,TAU);c.arc(12,-6,7,0,TAU);c.stroke();c.strokeStyle=kind==='moto'?'#e5484d':'#3a86ff';c.lineWidth=3;c.beginPath();c.moveTo(-12,-6);c.lineTo(0,-14);c.lineTo(12,-6);c.moveTo(0,-14);c.lineTo(10,-20);c.stroke();if(kind==='moto'){c.fillStyle='#e5484d';const p=new Path2D();rrp(p,-14,-18,24,8,4);c.fill(p)}}
    else{c.fillStyle='#2b2b33';c.fillRect(-3,-14,6,14);c.fillStyle=kind==='moto'?'#e5484d':'#3a86ff';c.fillRect(-10,-20,20,3)}}
  c.restore();
}

function render(){
  const k=RT.k,cx=RT.cam.x,cy=RT.cam.y;
  ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#3aa6de';ctx.fillRect(0,0,cv.width,cv.height);
  const c0=Math.floor(cx/CH),c1=Math.floor((cx+viewW())/CH),r0=Math.floor(cy/CH),r1=Math.floor((cy+viewH())/CH);
  let made=0;
  for(let j=r0;j<=r1;j++)for(let i=c0;i<=c1;i++){
    if(i<0||j<0||i*CH>=MW*TS||j*CH>=MH*TS)continue;
    const key=i+','+j;let ch=chunks.get(key);
    if(!ch&&made<3){ch=chunkCanvas(i,j,k);made++}
    if(ch)ctx.drawImage(ch,Math.round((i*CH-cx)*k),Math.round((j*CH-cy)*k));
    else{ctx.fillStyle='#7cc95a';ctx.fillRect(Math.round((i*CH-cx)*k),Math.round((j*CH-cy)*k),Math.ceil(CH*k),Math.ceil(CH*k))}
  }
  ctx.setTransform(k,0,0,k,-cx*k,-cy*k);
  const vx0=cx-60,vx1=cx+viewW()+60,vy0=cy-80,vy1=cy+viewH()+80;
  // festival bunting
  if(RT.fest){const cols=['#e5484d','#f2c230','#3a86ff','#38b84a','#ff5ea8'];for(const yy of [32*TS+6,46*TS+4]){ctx.strokeStyle='#888';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(48*TS,yy);ctx.quadraticCurveTo(55*TS,yy+18,63*TS,yy);ctx.stroke();for(let i=0;i<28;i++){const t=i/27,x=48*TS+t*15*TS,y=yy+Math.sin(t*Math.PI)*9;ctx.fillStyle=cols[i%5];ctx.beginPath();ctx.moveTo(x-5,y);ctx.lineTo(x+5,y);ctx.lineTo(x,y+10);ctx.fill()}}}
  // spot markers
  const tm=performance.now()/1000;
  for(const s of SPOTS){const x=s.x*TS+16,y=s.y*TS+16;if(x<vx0||x>vx1||y<vy0||y>vy1)continue;ctx.strokeStyle='rgba(255,255,255,.8)';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(x,y+8,12+Math.sin(tm*3)*3,5+Math.sin(tm*3),0,0,TAU);ctx.stroke()}
  // entities sorted
  const ents=[];
  for(const n of RT.npcs)if(n.x>vx0&&n.x<vx1&&n.y>vy0&&n.y<vy1)ents.push(n);
  ents.push(P);
  for(const c of RT.cars)if(c.x>vx0&&c.x<vx1&&c.y>vy0&&c.y<vy1)ents.push({car:c,y:c.y});
  ents.sort((a,b)=>a.y-b.y);
  const s=1/k;
  for(const e of ents){
    if(e.car){drawCar(ctx,e.car);continue}
    if(e===P){
      const veh=RT.ride&&S.ride?VEH[S.ride]:null;
      if(veh&&veh.kind==='car'){drawCar(ctx,{x:P.x,y:P.y-6,h:P.dir!==0&&P.dir!==3,v:P.dir===1?-1:1,c:'#8c5cf2'});const sp=charSprite('player',S.look,P.dir===3?3:0,0);ctx.save();ctx.beginPath();ctx.rect(P.x-14,P.y-46,28,32);ctx.clip();ctx.drawImage(sp,P.x-sp.width*s/2,P.y-sp.height*s+12,sp.width*s,sp.height*s);ctx.restore();continue}
      if(veh)drawVehicleUnder(ctx,P.x,P.y,veh.kind,P.dir);
      const sp=charSprite('player',S.look,P.dir,veh?0:P.frame);
      ctx.drawImage(sp,P.x-sp.width*s/2,P.y-sp.height*s+(veh?-6:0)+2,sp.width*s,sp.height*s);
      continue;
    }
    const sp=charSprite(e.id,e.C,e.dir,e.frame);ctx.drawImage(sp,e.x-sp.width*s/2,e.y-sp.height*s+2,sp.width*s,sp.height*s);
  }
  // occluders in front of player (redraw trees/buildings whose base is below player)
  for(const o of OBJS){if(!o.occ||o.base<=P.y+2)continue;if(P.x>o.x&&P.x<o.x+o.w&&P.y-50<o.base&&P.y>o.y){if(o.type==='tree'){const d=Math.abs(o.tx*TS+16-P.x);if(d<40&&o.base-P.y<70){ctx.globalAlpha=.55;drawObj(ctx,o);ctx.globalAlpha=1}}}}
  // npc name tags for named nearby
  ctx.font='800 10px Nunito,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';
  for(const n of RT.npcs){if(!n.named)continue;const d=Math.hypot(n.x-P.x,n.y-P.y);if(d>170)continue;const w=ctx.measureText(n.name).width+10;ctx.fillStyle='rgba(42,31,71,.75)';const p=new Path2D();rrp(p,n.x-w/2,n.y-72,w,15,7);ctx.fill(p);ctx.fillStyle='#fff';ctx.fillText(n.name,n.x,n.y-64.5);
    const f=S.friends[n.id]||0;if(f>0){ctx.fillStyle='#ff5ea8';ctx.fillText('♥'.repeat(Math.min(4,1+Math.floor(f/25))),n.x,n.y-80)}}
  // location labels
  ctx.font='800 12px Nunito,sans-serif';
  for(const b of BLDS){if(!b.loc)continue;const L=LOC[b.loc];const x=(b.x+b.w/2)*TS,y=b.y*TS-(b.tall||0)-30;if(x<vx0-80||x>vx1+80||y<vy0||y>vy1+60)continue;
    const t=L.name,w=ctx.measureText(t).width+30;const p=new Path2D();rrp(p,x-w/2,y-12,w,24,12);ctx.fillStyle='rgba(255,255,255,.95)';ctx.fill(p);ctx.strokeStyle=L.col;ctx.lineWidth=2;ctx.stroke(p);ctx.fillStyle=L.col;ctx.beginPath();ctx.arc(x-w/2+12,y,5,0,TAU);ctx.fill();ctx.fillStyle='#2a1f47';ctx.fillText(t,x+7,y+.5)}
  for(const s2 of SPOTS){const x=s2.x*TS+16,y=s2.y*TS-14;if(x<vx0||x>vx1||y<vy0||y>vy1)continue;const fs=FISHSPOTS.find(f=>f.id===s2.id);const t='Memancing: '+fs.name,w=ctx.measureText(t).width+14;const p=new Path2D();rrp(p,x-w/2,y-11,w,22,11);ctx.fillStyle='rgba(58,134,255,.92)';ctx.fill(p);ctx.fillStyle='#fff';ctx.fillText(t,x,y+.5)}
  // target marker
  if(RT.target){ctx.strokeStyle='#ffd23f';ctx.lineWidth=2.5;ctx.beginPath();ctx.ellipse(RT.target.x,RT.target.y,10,5,0,0,TAU);ctx.stroke()}
  // near highlight
  if(RT.near){const n=RT.near;const x=n.kind==='npc'?n.npc.x:n.x,y=n.kind==='npc'?n.npc.y-82:n.y-30;ctx.fillStyle='#ffd23f';ctx.beginPath();ctx.moveTo(x-7,y-10+Math.sin(tm*6)*2);ctx.lineTo(x+7,y-10+Math.sin(tm*6)*2);ctx.lineTo(x,y+Math.sin(tm*6)*2);ctx.fill()}
  // overlays (screen space)
  ctx.setTransform(1,0,0,1,0,0);
  const hr=(S.time%1440)/60;let dark=0;
  if(hr>=19.5||hr<5)dark=.5;else if(hr>=18)dark=(hr-18)/1.5*.5;else if(hr<6.5)dark=(6.5-hr)/1.5*.5;
  if(S.weather==='hujan')dark=Math.max(dark,.12);if(S.weather==='ribut')dark=Math.max(dark,.22);else if(S.weather==='mendung')dark=Math.max(dark,.06);
  if(dark>0){ctx.fillStyle=`rgba(14,18,66,${dark})`;ctx.fillRect(0,0,cv.width,cv.height);
    if(dark>.2){ctx.globalCompositeOperation='lighter';for(const [lx,ly] of LAMPS){const x=((lx*TS+16)-cx)*k,y=((ly*TS-24)-cy)*k;if(x<-100||y<-100||x>cv.width+100||y>cv.height+100)continue;const g=ctx.createRadialGradient(x,y,2,x,y,70*k);g.addColorStop(0,`rgba(255,220,140,${dark*.8})`);g.addColorStop(1,'rgba(255,200,100,0)');ctx.fillStyle=g;ctx.fillRect(x-70*k,y-70*k,140*k,140*k)}ctx.globalCompositeOperation='source-over'}}
  if(S.weather==='ribut'){RT.flT=(RT.flT||0)-1;if(RT.flT<=0){RT.fl=1;RT.flT=180+Math.random()*420}if(RT.fl>0){ctx.fillStyle=`rgba(255,255,240,${RT.fl*.55})`;ctx.fillRect(0,0,cv.width,cv.height);RT.fl-=.08}}
  if(RT.rain.length){ctx.strokeStyle='rgba(200,220,255,.55)';ctx.lineWidth=1.2*RT.dpr;ctx.beginPath();for(const r of RT.rain){ctx.moveTo(r.x*RT.dpr,r.y*RT.dpr);ctx.lineTo((r.x-3)*RT.dpr,(r.y+14)*RT.dpr)}ctx.stroke()}
}

function loop(t){
  const dt=Math.min(.05,(t-(RT.last||t))/1000);RT.last=t;
  if(!RT.paused&&!RT.blocked){update(dt);gameTick(dt)}
  if(!RT.blocked&&document.getElementById('game').classList.contains('hide')===false)render();
  hudTick();
  requestAnimationFrame(loop);
}

// ---- input
function setupInput(){
  addEventListener('keydown',e=>{
    if(e.target.tagName==='INPUT'||e.target.tagName==='TEXTAREA'||e.target.tagName==='SELECT')return;
    RT.keys[e.code]=true;
    if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].includes(e.code))e.preventDefault();
    if(e.code==='Escape'){if(!$('#dlg').classList.contains('hide'))closeDlg();else if(!$('#sheet').classList.contains('hide'))closeSheet();else if(S&&!$('#game').classList.contains('hide'))ACT.settings();return}
    if(RT.paused)return;
    if(e.code==='KeyE'||e.code==='Space'||e.code==='Enter')doInteract();
    if(e.code==='ShiftLeft'||e.code==='ShiftRight')RT.run=true;
    if(e.code==='KeyM')openPanel('peta');
    if(e.code==='KeyR')toggleRide();
    if(e.code==='KeyI')openPanel('inventori');
    if(e.code==='KeyF')openPanel('memancing');
    if(e.code==='KeyH')openPanel('rumah');
  });
  addEventListener('keyup',e=>{RT.keys[e.code]=false;if(e.code==='ShiftLeft'||e.code==='ShiftRight')RT.run=false});
  addEventListener('blur',()=>{RT.keys={}});
  // joystick
  const joy=$('#joy'),knob=joy.querySelector('i');let jid=null;
  const jmove=e=>{const r=joy.getBoundingClientRect(),sc=r.width/joy.offsetWidth,cx=r.left+r.width/2,cy=r.top+r.height/2;let dx=(e.clientX-cx)/sc,dy=(e.clientY-cy)/sc;const m=joy.offsetWidth/2-14,d=Math.hypot(dx,dy);if(d>m){dx=dx/d*m;dy=dy/d*m}knob.style.transform=`translate(${dx}px,${dy}px)`;RT.joy.x=dx/m;RT.joy.y=dy/m;RT.joy.on=Math.hypot(RT.joy.x,RT.joy.y)>.15;RT.run=Math.hypot(RT.joy.x,RT.joy.y)>.95};
  joy.addEventListener('pointerdown',e=>{jid=e.pointerId;joy.setPointerCapture(jid);jmove(e)});
  joy.addEventListener('pointermove',e=>{if(e.pointerId===jid)jmove(e)});
  const jend=e=>{if(e.pointerId!==jid)return;jid=null;knob.style.transform='';RT.joy.on=false;RT.joy.x=RT.joy.y=0;RT.run=false};
  joy.addEventListener('pointerup',jend);joy.addEventListener('pointercancel',jend);
  // canvas tap
  let down=null;
  cv.addEventListener('pointerdown',e=>{down={x:e.clientX,y:e.clientY,t:performance.now()}});
  cv.addEventListener('pointerup',e=>{if(!down||RT.paused)return;const moved=Math.hypot(e.clientX-down.x,e.clientY-down.y);down=null;if(moved>12)return;
    const r=cv.getBoundingClientRect(),lx=(e.clientX-r.left)*RT.W/r.width,ly=(e.clientY-r.top)*RT.H/r.height;
    const wx=RT.cam.x+lx/RT.zoom,wy=RT.cam.y+ly/RT.zoom;
    // tapped interactable?
    let hit=null,hd=1e9;for(const it of IA){const x=it.kind==='npc'?it.npc.x:it.x,y=it.kind==='npc'?it.npc.y-20:it.y;const d=Math.hypot(x-wx,y-wy);if(d<34&&d<hd){hd=d;hit=it}}
    if(hit){const x=hit.kind==='npc'?hit.npc.x:hit.x,y=hit.kind==='npc'?hit.npc.y:hit.y;if(Math.hypot(x-P.x,y-P.y)<70){RT.near=hit;doInteract();return}RT.target={x,y:y+(hit.kind==='npc'?0:18)};return}
    RT.target={x:wx,y:wy};
  });
}
function toggleRide(){
  if(!S.vehicles.filter(v=>VEH[v].kind!=='boat').length){toast('Anda belum ada kenderaan. Beli di menu Rumah → Kenderaan.','y');return}
  if(!S.ride||VEH[S.ride].kind==='boat')S.ride=S.vehicles.find(v=>VEH[v].kind!=='boat');
  RT.ride=!RT.ride;toast(RT.ride?'Menunggang '+VEH[S.ride].name:'Berjalan kaki');updateActBtns();
}
