// ===================== FEATURES (landscape update) =====================
// ---- HUD mission panel & location chip
let MIS_OPEN=true,misHTML='';
function renderMis(){
  if(!S||!S.dq)return;const el=$('#mis');
  const M=mainQ()[S.mq];let h=`<button class="mh" data-a="misT"><span class="msc"><svg viewBox="0 0 20 20"><rect x="4" y="3" width="12" height="14" rx="2" fill="#fff6e0" stroke="#8a5a2a" stroke-width="1.4"/><path d="M7 7h6M7 10h6M7 13h4" stroke="#8a5a2a" stroke-width="1.3" stroke-linecap="round"/></svg></span><b>Misi Harian</b><span class="mch">${MIS_OPEN?'‹ ›':'▸'}</span></button>`;
  if(MIS_OPEN){
    h+=`<button class="mr" data-a="nav" data-v="misi" style="width:100%;text-align:left"><i style="border-color:var(--gold);background:#fff6d6"></i><span>${M?esc(M[0]):'Semua misi utama selesai!'}</span><em>Utama</em></button>`;
    for(const m of S.dq.list){const {q,cur}=mqProg(m,DAILYQ);h+=`<div class="mr ${m.done?'ok':''}"><i></i><span>${esc(q[1])}</span><em>${m.done?'✓':cur+'/'+q[3]}</em></div>`}
  }
  if(h!==misHTML){el.innerHTML=h;misHTML=h}
}
function locChip(){const el=$('#hLoc');if(!el||!S)return;let best=null,bd=14*TS;for(const l of LOCS){const L=LOC[l[0]];const d=Math.hypot(P.x-(L.door[0]*TS+16),P.y-(L.door[1]*TS+16));if(d<bd){bd=d;best=L}}
  const t=best?`<i style="background:${best.col}"></i>${esc(best.name)}`:'<i style="background:#38b84a"></i>Kota Kita';if(el.innerHTML!==t)el.innerHTML=t}
ACT.misT=()=>{MIS_OPEN=!MIS_OPEN;misHTML='';renderMis()};

// ---- skill gains from activity counters
const SKMAP={classes:['edu',10],shifts:['career',10],fish:['fish',8],prot:['fish',12],cook:['cook',12],harvest:['farm',6],talk:['social',4],fest:['social',10],sport:['sports',10],creative:['creative',10],cert:['career',20]};
function skillTick(){if(!S)return;S.skSnap=S.skSnap||{};for(const k in SKMAP){const v=S.cnt[k]||0,o=S.skSnap[k]==null?v:S.skSnap[k];if(v>o)addSkill(SKMAP[k][0],(v-o)*SKMAP[k][1]);S.skSnap[k]=v}}
const _cm=checkMissions;checkMissions=function(){skillTick();_cm()};
const bump=k=>{S.cnt[k]=(S.cnt[k]||0)+1};

// ---- wrap actions to count things
{const w=(name,fn)=>{const o=ACT[name];ACT[name]=(v,el)=>fn(o,v,el)};
 w('talkTo',(o,v)=>{const had=S.talked[v];o(v);if(!had&&S.talked[v])bump('talk')});
 w('msgNpc',(o,v)=>{const had=S.msgd[v];o(v);if(!had&&S.msgd[v])bump('talk')});
 w('gift',(o,v)=>{const id=v.split(':')[0],had=S.gifted[id];o(v);if(!had&&S.gifted[id])bump('talk')});
 w('buyOutfit',(o,v)=>{const n=S.owned.length;o(v);if(S.owned.length>n)bump('outfit')});
}
const _openLoc=openLoc;openLoc=function(id){bump('enter');if(LOCK[id]&&S.lvl<LOCK[id]){toast(`${LOC[id].name} dibuka pada Tahap ${LOCK[id]}.`,'y');return}_openLoc(id)};
const LOCK={pulau:3,airport:4};

// ---- unlocked locations in travel
const _ot=openTravel;openTravel=function(dest,then){if(LOCK[dest]&&S.lvl<LOCK[dest]){toast(`${LOC[dest].name} dikunci sehingga Tahap ${LOCK[dest]}.`,'y');return}_ot(dest,then)};

// ---- MISI panel
const GEMSHOP=[['energy','Isi Semula Tenaga Penuh',20],['box','Kotak Hadiah Misteri',15],['fert','Baja Organik ×5',8],['bait','Umpan Tiruan (Lure)',25]];
PANELS.misi={title:'Misi & Ganjaran',tabs:[['utama','Misi Utama'],['harian','Misi Harian'],['mingguan','Misi Mingguan'],['permata','Kedai Permata']],
render(t){
  rollMissions(dayIdx());
  if(t==='utama')return`<div class="note" style="margin-bottom:10px">Ikuti kisah hidup anda di Kota Kita. Ganjaran diberi automatik apabila misi selesai.</div><div class="list">${mainQ().map((m,i)=>`<div class="li" style="${i===S.mq?'border-color:var(--pur)':''}"><span class="emo" style="font-size:16px;font-family:Fredoka">${i<S.mq?'✓':i+1}</span><div class="t"><b>${esc(m[0])}</b><span>${fmt(m[2])} · ${m[3]} permata</span></div><span class="tagx ${i<S.mq?'u':i===S.mq?'y':''}">${i<S.mq?'Selesai':i===S.mq?'Semasa':'Akan datang'}</span></div>`).join('')}</div>`;
  if(t==='harian'||t==='mingguan'){const L=t==='harian'?S.dq.list:S.wq.list,tbl=t==='harian'?DAILYQ:WEEKLYQ;
    return`<div class="note" style="margin-bottom:10px">${t==='harian'?'Misi baharu setiap hari. Ganjaran: RM40 + 3 permata + 25 XP setiap satu.':'Misi baharu setiap minggu. Ganjaran: RM200 + 15 permata + 100 XP setiap satu.'}</div><div class="list">${L.map(m=>{const {q,cur}=mqProg(m,tbl);return`<div class="li"><div class="t"><b>${esc(q[1])}</b><div class="bar ${m.done?'g':''}" style="margin-top:6px"><i style="width:${pct(cur,q[3])}%"></i></div></div><b style="white-space:nowrap">${m.done?'Selesai ✓':cur+' / '+q[3]}</b></div>`}).join('')}</div>`}
  return`<div class="row" style="margin-bottom:10px"><span class="chip" style="background:var(--pur3)">Permata anda: <b>${S.gems||0}</b></span><span style="font-size:13px;color:var(--mut)">Permata diperoleh daripada misi & pencapaian sahaja — tiada pembelian wang sebenar.</span></div><div class="grid w">${GEMSHOP.map(g=>`<div class="card"><h4>${g[1]}</h4><div class="row"><span class="price" style="color:#7a2cc0">${g[2]} permata</span><span class="sp"></span>${B('Tukar','gemBuy',g[0],'y',(S.gems||0)<g[2])}</div></div>`).join('')}</div>`;
}};
ACT.gemBuy=v=>{const g=GEMSHOP.find(x=>x[0]===v);if((S.gems||0)<g[2])return;S.gems-=g[2];
  if(v==='energy'){S.energy=maxEnergy();toast('Tenaga penuh!','g')}else if(v==='fert'){inv('baja',5);toast('+5 Baja Organik','g')}else if(v==='bait'){S.baits.tiruan=(S.baits.tiruan||0)+1;toast('Umpan tiruan diterima','g')}
  else{const r=Math.random();if(r<.5){const m=Math.round(rnd(50,300));S.money+=m;toast(`Kotak misteri: ${fmt(m)}!`,'g')}else if(r<.8){inv('kuih',3);inv('coklat',2);toast('Kotak misteri: kuih & coklat!','g')}else{S.energy=maxEnergy();addXP(80);toast('Kotak misteri: tenaga penuh + 80 XP!','g')}}rerender()};

// ---- INVENTORI panel
const GADGETN={phone:'Telefon Pintar',laptop:'Komputer Riba',camera:'Kamera DSLR',console:'Konsol Permainan'};
const hasAquarium=()=>Object.values(S.home.rooms).some(r=>r.items.includes('akuarium'));
PANELS.inventori={title:'Inventori',tabs:[['barang','Barang'],['ikan','Tong Ikan'],['akuarium','Akuarium'],['gajet','Gajet & Peralatan'],['perabot','Stor Perabot']],
render(t){
  if(t==='barang'){const ks=Object.keys(S.inv).filter(k=>ITEMS[k]&&!GADGETN[k]);return ks.length?`<div class="grid s">${ks.map(k=>{const it=ITEMS[k];return`<div class="card" style="justify-items:center;text-align:center"><span class="emo" style="width:56px;height:56px;font-size:32px">${it[1]}</span><h4>${esc(it[0])}</h4><p>×${S.inv[k]}</p><div class="row">${it[3]?B('Makan','eatItem',k,'g'):''}${it[2]&&!it[3]?B(fmt(it[2]),'sellItem',k,'y'):''}</div></div>`}).join('')}</div>`:'<div class="note">Inventori kosong.</div>'}
  if(t==='ikan')return`<div class="row" style="margin-bottom:8px"><b>${S.fishInv.length} tangkapan</b><span class="sp"></span>${B('Pasar Ikan','goPanel','memancing:tangkapan','y')}</div><div class="grid s">${S.fishInv.map((f,i)=>`<div class="card"><img class="im wide" src="${creatureImg(f.g,f.col,false,96,64)}" alt=""><h4>${esc(f.name)}</h4><p>${f.cm} cm · ${fmt(f.price)}</p>${B('Ke Akuarium','toAqua',i,'w',!hasAquarium()||(S.aqua||[]).length>=6)}</div>`).join('')||'<div class="note">Tong ikan kosong.</div>'}</div>`;
  if(t==='akuarium')return`${hasAquarium()?`<div class="note g" style="margin-bottom:8px">Akuarium di ruang tamu: ${(S.aqua||[]).length}/6 ikan. Ikan di akuarium dipelihara (tidak dijual). Haiwan dilindungi tidak boleh disimpan.</div>`:`<div class="note y" style="margin-bottom:8px">Beli <b>Akuarium</b> di Rumah → Kedai Perabot dan letak di Ruang Tamu.</div>`}<div class="grid s">${(S.aqua||[]).map((f,i)=>`<div class="card"><img class="im wide" src="${creatureImg(f.g,f.col,false,96,64)}" alt=""><h4>${esc(f.name)}</h4><p>${f.cm} cm</p>${B('Keluarkan','fromAqua',i,'w')}</div>`).join('')}</div>`;
  if(t==='gajet'){const g=Object.keys(GADGETN).filter(k=>S.inv[k]);return`<div class="sec">Gajet</div><div class="row">${g.map(k=>`<span class="tagx">${GADGETN[k]}</span>`).join('')||'<span class="note">Tiada gajet — beli di Elektronik, Asia Mall.</span>'}</div>
    <div class="sec">Kenderaan</div><div class="row">${S.vehicles.map(v=>`<span class="tagx">${VEH[v].name}</span>`).join('')||'<span class="note">Tiada kenderaan.</span>'}</div>
    <div class="sec">Peralatan Memancing</div><div class="row"><span class="tagx">${RODS[S.rod][0]}</span><span class="tagx">${HOOKS[S.hook||0][0]}</span><span class="tagx">${LINES[S.line||0][0]}</span>${BAITS.filter(b=>S.baits[b[0]]).map(b=>`<span class="tagx">${b[1]} ×${S.baits[b[0]]}</span>`).join('')}</div>
    <div class="sec">Sijil & Lesen</div><div class="row">${(S.certs||[]).map(c=>`<span class="tagx u">${CERTS.find(x=>x[0]===c)[1]}</span>`).join('')||'<span class="note">Belum ada sijil — ambil kursus di Kerjaya → Latihan & Sijil.</span>'}</div>`}
  return S.furn.length?`<div class="list">${S.furn.map(f=>`<div class="li"><div class="t"><b>${esc(FURNI[f].name)}</b><span>${ROOMS.find(r=>r[0]===FURNI[f].room)[1]}</span></div>${B('Letak di Rumah','goPanel','rumah:rumah','g')}</div>`).join('')}</div>`:'<div class="note">Stor perabot kosong.</div>';
}};
ACT.toAqua=v=>{if(!hasAquarium()||(S.aqua||[]).length>=6)return;S.aqua=S.aqua||[];S.aqua.push(S.fishInv.splice(+v,1)[0]);addXP(5);toast('Ikan dipindahkan ke akuarium 🐠','g');checkAch();rerender()};
ACT.fromAqua=v=>{S.fishInv.push(S.aqua.splice(+v,1)[0]);rerender()};

// ---- Fishing hooks & lines
const HOOKS=[['Mata Kail Biasa',0],['Mata Kail Tajam',90],['Mata Kail Karbon',380],['Mata Kail Pro',1200]];
const LINES=[['Tali Nilon',0],['Tali Fluorokarbon',120],['Tali Anyaman',450],['Tali Pro Laut Dalam',1500]];
{const r=PANELS.memancing.render;PANELS.memancing.render=t=>{let h=r(t);if(t==='alat')h+=`<div class="sec">Mata Kail <small>tingkap sentap lebih lama</small></div><div class="grid">${HOOKS.map((x,i)=>`<div class="card ${(S.hook||0)===i?'on':''}"><h4>${x[0]}</h4><p>Masa sentap +${i*0.15}s</p>${(S.hooks||[0]).includes(i)?B((S.hook||0)===i?'Digunakan':'Guna','useHook',i,'w',(S.hook||0)===i):B(fmt(x[1]),'buyHook',i,'y')}</div>`).join('')}</div>
  <div class="sec">Tali Pancing <small>ikan lebih sukar terlepas</small></div><div class="grid">${LINES.map((x,i)=>`<div class="card ${(S.line||0)===i?'on':''}"><h4>${x[0]}</h4><p>Ketahanan +${i*15}%</p>${(S.lines||[0]).includes(i)?B((S.line||0)===i?'Digunakan':'Guna','useLine',i,'w',(S.line||0)===i):B(fmt(x[1]),'buyLine',i,'y')}</div>`).join('')}</div>
  <div class="note" style="margin-top:8px">Tahap kemahiran memancing: <b>${skillLv('fish')}</b> — setiap tahap membesarkan zon tarikan.</div>`;return h}}
ACT.buyHook=v=>{if(!spend(HOOKS[+v][1],HOOKS[+v][0]))return;S.hooks=(S.hooks||[0]);S.hooks.push(+v);S.hook=+v;rerender()};ACT.useHook=v=>{S.hook=+v;rerender()};
ACT.buyLine=v=>{if(!spend(LINES[+v][1],LINES[+v][0]))return;S.lines=(S.lines||[0]);S.lines.push(+v);S.line=+v;rerender()};ACT.useLine=v=>{S.line=+v;rerender()};

// ---- Kerjaya: training & resume tabs + interview
PANELS.kerjaya.tabs.push(['latihan','Latihan & Sijil'],['resume','Resume Saya']);
{const r=PANELS.kerjaya.render;PANELS.kerjaya.render=t=>{
  if(t==='latihan')return`<div class="note" style="margin-bottom:10px">Sijil menambah gaji kerja berkaitan (+5% sepenuh masa, +10% sambilan) dan dipaparkan dalam resume.</div><div class="grid w">${CERTS.map(c=>{const has=(S.certs||[]).includes(c[0]);return`<div class="card ${has?'on':''}"><h4>${c[1]}</h4><p>Kursus 4 jam di ${LOC[c[3]].name}. Berguna untuk: ${c[4].map(j=>{const J=FT_JOBS.find(x=>x[0]===j)||PT_JOBS.find(x=>x[0]===j);return J?J[1]:j}).join(', ')}</p><div class="row"><span class="price">${fmt(c[2])}</span><span class="sp"></span>${has?'<span class="tagx u">Diperoleh</span>':B('Daftar Kursus','takeCert',c[0],'g')}</div></div>`}).join('')}</div>`;
  if(t==='resume'){const q=bestQual();return`<div class="card" style="max-width:720px"><div class="row"><img src="${headImg(S.look)}" style="width:72px;border-radius:50%;background:var(--lil)" alt=""><div><h4 style="font-size:20px">${esc(S.name)}</h4><p>${S.job?FT_JOBS.find(j=>j[0]===S.job.id)[8][S.job.lvl]:isStudent()?'Pelajar':'Mencari pekerjaan'} · Tahap ${S.lvl}</p></div></div>
    <div class="sec">Pendidikan</div><p>${S.spm!=null?`SPM — ${S.spm}A`:'Tingkatan 5 (sedang belajar)'}</p>${S.degrees.map(d=>`<p><b>${LEVEL[d.level].name} ${COURSE[d.course]}</b> — ${INST[d.inst].name}, CGPA ${d.cgpa.toFixed(2)}</p>`).join('')}${S.edu?`<p>Sedang belajar: ${LEVEL[S.edu.level].name} ${COURSE[S.edu.course]} (${INST[S.edu.inst].abbr})</p>`:''}
    <div class="sec">Pengalaman Kerja</div>${Object.entries(S.ptSkill).map(([k,h])=>`<p>${PT_JOBS.find(j=>j[0]===k)[1]} — ${h} jam</p>`).join('')||'<p>Belum ada</p>'}${S.job?`<p>${FT_JOBS.find(j=>j[0]===S.job.id)[1]} — ${S.job.shifts} syif</p>`:''}
    <div class="sec">Sijil</div><p>${(S.certs||[]).map(c=>CERTS.find(x=>x[0]===c)[1]).join(', ')||'—'}</p>
    <div class="sec">Kemahiran</div><div class="row">${SKILLS.map(k=>`<span class="tagx">${k[1]} Tahap ${skillLv(k[0])}</span>`).join('')}</div></div>`}
  return r(t)}}
ACT.takeCert=v=>{const c=CERTS.find(x=>x[0]===v);needAt(c[3],()=>{if((S.certs||[]).includes(v))return;if(!useEnergy(15))return;if(!spend(c[2],c[1]))return;advance(240);S.certs=S.certs||[];S.certs.push(v);bump('cert');addXP(60);showDlg({title:'Sijil Diperoleh!',body:`<p><b>${esc(c[1])}</b> telah ditambah ke resume anda.</p>`,buttons:[{label:'Bagus',cls:'g',a:'closeDlg'}]})},'Pergi ke')};
const certBonus=(jobId,pct)=>(S.certs||[]).some(c=>CERTS.find(x=>x[0]===c)[4].includes(jobId))?pct:0;
// interview
ACT.applyFT=(()=>{return v=>{const J=FT_JOBS.find(j=>j[0]===v);if(isStudent()){toast('Tamatkan pengajian dahulu.','r');return}
  const go=()=>startQuiz('Temu Duga: '+J[1],3,(sc)=>{const d=S.degrees.find(x=>QRANK[x.level]>=QRANK[J[2]]);const formal=['formal','kerja'].includes(OUT[S.look.outfit].cat);
    const p=clamp(.25+sc*.5+S.stats.karisma/350+(d&&d.cgpa>=3.5?.1:0)+(d&&INST[d.inst].tier==='elite'?.08:0)+(formal?.08:0)+certBonus(v,.06),0,.97);advance(90);
    if(Math.random()<p){S.job={id:v,lvl:0,shifts:0,perfSum:0,start:dayIdx(),inc:0};addXP(80);addMsg(J[1],'Tawaran Kerja',`Tahniah! Anda diterima sebagai ${J[8][0]}. Gaji permulaan ${fmt(ftSalary())} sebulan.`);showDlg({title:'Tahniah! Anda diterima!',body:`<p>Skor temu duga: <b>${Math.round(sc*100)}%</b>${formal?' · berpakaian kemas ✓':''}</p><p>Jawatan: <b>${esc(J[8][0])}</b><br>Lokasi: ${esc(LOC[J[7]].name)}<br>Gaji: <b>${fmt(ftSalary())}</b> sebulan</p>`,buttons:[{label:'Yeay!',cls:'g',a:'closeDlg'}]});checkAch()}
    else showDlg({title:'Permohonan tidak berjaya',body:`<p>Skor temu duga: ${Math.round(sc*100)}%. Tip: pakai pakaian formal/pejabat, tingkatkan karisma dan ambil sijil berkaitan.</p>`,buttons:[{label:'Okey',cls:'w',a:'closeDlg'}]});rerender()},INTERVIEW);
  if(S.job)confirmDlg('Tukar kerja?','<p>Anda akan berhenti kerja semasa jika diterima.</p>','Teruskan',go);else go()}})();

// ---- Scholarships (6 funding routes)
const FUNDS=[['full','Biasiswa Penuh (Merit)',1,'SPM 9A / CGPA 3.70'],['partial','Biasiswa Separa (50%)',.5,'SPM 7A / CGPA 3.30'],['gov','Tajaan Kerajaan',1,'Institusi tajaan/awam · SPM 7A / CGPA 3.30 · elaun RM300/sem'],['private','Tajaan Swasta',1,'Institusi elite/tajaan · temu duga (karisma)'],['loan','Pinjaman Pendidikan',0,'Bayar balik RM200/bulan selepas tamat'],['self','Biaya Sendiri',0,'Bayar yuran setiap semester']];
const cgMax=()=>S.degrees.length?Math.max(...S.degrees.map(d=>d.cgpa)):0;
function fundChance(k){const e=S.edu,I=INST[e.inst],spm=S.spm||0,cg=cgMax();
  if(k==='full')return(spm>=9||cg>=3.7)?.8:.06;if(k==='partial')return(spm>=7||cg>=3.3)?.88:.3;
  if(k==='gov')return I.tier==='elite'?0:(spm>=7||cg>=3.3)?(I.tier==='tajaan'?.92:.75):.25;if(k==='private')return I.tier==='awam'?0:clamp(.3+S.stats.karisma/250,0,.85);return 1}
{const r=PANELS.pendidikan.render;PANELS.pendidikan.render=t=>{
  if(t==='biasiswa'){const e=S.edu;if(!e)return'<div class="note">Daftar ke institusi dahulu untuk memohon biasiswa, tajaan atau pinjaman.</div>';e.tried=e.tried||{};
    return`<div class="note" style="margin-bottom:10px">Yuran semester: <b>${fmt(semFee(e))}</b>. Pembiayaan semasa: <b>${e.sponsor||(e.loan?'Pinjaman Pendidikan':'Biaya Sendiri')}</b>${e.fpct&&e.fpct<1?` (${e.fpct*100}% ditanggung)`:''}.</div><div class="grid w">${FUNDS.map(f=>{const ch=['loan','self'].includes(f[0])?1:fundChance(f[0]);const cur=(e.fund===f[0])||(f[0]==='loan'&&e.loan&&!e.fund);return`<div class="card ${cur?'on':''}"><h4>${f[1]}</h4><p>${f[3]}</p>${cur?'<span class="tagx u">Aktif</span>':e.tried[f[0]]?'<span class="tagx p">Tidak berjaya</span>':ch===0?'<span class="tagx">Tidak layak</span>':B(f[0]==='self'?'Pilih':'Mohon','applyFund',f[0],'g',!!e.fund&&f[0]!=='loan')}</div>`}).join('')}</div>`}
  if(t==='kuliah'&&S.edu){const e=S.edu;e.sched=e.sched||pick([[0,2,4],[1,3],[0,1,3]]);return`<div class="note" style="margin-bottom:8px"><b>Jadual Kuliah:</b> ${e.sched.map(i=>WEEK[i]).join(', ')} · 9:00 pg – 5:00 ptg. Hadir mengikut jadual untuk bonus akademik.</div>`+r(t)}
  return r(t)}}
ACT.applyFund=k=>{const e=S.edu;e.tried=e.tried||{};if(k==='self'){e.fund=null;e.sponsor=null;e.loan=false;e.fpct=0;rerender();return}
  if(k==='loan'){return ACT.applyLoan()}
  const go=()=>{e.tried[k]=1;if(Math.random()<fundChance(k)){const f=FUNDS.find(x=>x[0]===k);const refund=e.feePaid&&!e.loan?semFee(e)*f[2]:0;e.fund=k;e.sponsor=f[1];e.fpct=f[2];if(refund)S.money+=refund;if(f[2]>=1)e.feePaid=true;if(k==='gov')S.money+=300;addXP(60);showDlg({title:'Diluluskan!',body:`<p><b>${esc(f[1])}</b> menanggung ${f[2]*100}% yuran pengajian anda${k==='gov'?' serta elaun RM300 setiap semester':''}.</p>`,buttons:[{label:'Alhamdulillah!',cls:'g',a:'closeDlg'}]})}else showDlg({title:'Permohonan tidak berjaya',body:'<p>Cuba laluan pembiayaan lain seperti biasiswa separa atau pinjaman pendidikan.</p>',buttons:[{label:'Okey',cls:'w',a:'closeDlg'}]});rerender()};
  if(k==='private')startQuiz('Temu Duga Tajaan Swasta',3,sc=>{S.stats.karisma+=0;if(sc<.67){e.tried[k]=1;showDlg({title:'Temu duga kurang memuaskan',body:'<p>Panel penaja memilih calon lain.</p>',buttons:[{label:'Okey',cls:'w',a:'closeDlg'}]});rerender();return}go()},INTERVIEW);else go()};
// partial funding in fee payment
{const pf=ACT.payFee;ACT.payFee=()=>{const e=S.edu;if(e.fpct&&e.fpct<1&&!e.loan){const f=semFee(e)*(1-e.fpct);if(!spend(f,'Baki yuran semester'))return;e.feePaid=true;rerender();return}pf()}}
{const ue=ACT.uniClass;ACT.uniClass=()=>{const e=S.edu,w=dateOf(dayIdx()).w,h=hourNow();if(e&&e.sched&&e.sched.includes(w)&&h>=8&&h<=17&&atLoc('uni')){const c=e.classes;ue();if(S.edu&&S.edu.classes>c){stat('akademik',1);toast('Hadir mengikut jadual: akademik +1','g')}}else ue()}}

// ---- character creator extras
{const le=lookEditor;lookEditor=function(L,tab,ctxName){let h=le(L,tab,ctxName);
  if(tab==='asas')h+=`<div class="chead">Gaya Watak</div>${optBtns('style',CSTYLES.map(c=>c[0]),L.style||0)}${L.g==='m'?`<div class="chead">Misai & Janggut</div>${optBtns('beard',BEARDS,L.beard||0)}`:''}${ctxName==='creator'?`<div class="chead">Rawak</div><button class="btn y full" data-a="crRandom">Jana Watak Rawak</button>`:''}`;
  if(tab==='aksesori')h+=`<div class="chead">Anting-anting</div>${optBtns('ear',EARS.map(e=>e[0]),L.ear||0,EARS.map(e=>e[1]),S?S.ownedEars:[0,1])}<div class="chead">Aksesori Leher</div>${optBtns('neck',NECKS.map(e=>e[0]),L.neck||0,NECKS.map(e=>e[1]),S?S.ownedNecks:[0])}`;
  return h}}
ACT.crRandom=()=>{const g=Math.random()<.5?'m':'f',r=n=>Math.floor(Math.random()*n);const hij=g==='f'&&Math.random()<.5;
  CR.look={g,skin:r(6),face:r(4),eye:r(4),eyeCol:r(7),brow:r(4),nose:r(3),mouth:r(5),hair:r(g==='m'?6:7),hairCol:r(8),hijab:hij?1:0,hijabSt:r(2),hijabCol:r(12),glasses:r(3),hat:hij?0:r(2),acc:r(2),ear:hij?0:r(2),neck:0,beard:g==='m'&&Math.random()<.3?1+r(3):0,body:r(4),style:r(3),outfit:pick(g==='m'?['h1','h2','s1']:['h3','h4','s2']),shoes:'sh1'};
  CR.name=pick(g==='m'?NAMES_M:NAMES_F);renderCreator()};
{const ba=ACT.buyAcc;ACT.buyAcc=v=>{const [k,i,ok]=v.split(':');if(k==='ear'||k==='neck'||k==='bag'){const list=k==='ear'?EARS:k==='bag'?BAGS:NECKS;if(!spend(list[+i][1],list[+i][0]))return;S[ok].push(+i);S.look[k]=+i;refreshLook();return}ba(v)}}

// ---- farming equipment
PANELS.ladang.tabs[3]=['naiktaraf','Besarkan & Peralatan'];
{const r=PANELS.ladang.render;PANELS.ladang.render=t=>{let h=r(t);if(t==='naiktaraf')h+=`<div class="sec">Peralatan Ladang</div><div class="grid w"><div class="card ${S.sprinkler?'on':''}"><h4>Sistem Pemercik Automatik</h4><p>Semua petak disiram automatik setiap pagi.</p>${S.sprinkler?'<span class="tagx u">Dipasang</span>':B(fmt(2500),'farmEq','sprinkler','y')}</div><div class="card ${S.tools?'on':''}"><h4>Peralatan Tuai Moden</h4><p>Peluang hasil berganda +25%.</p>${S.tools?'<span class="tagx u">Dimiliki</span>':B(fmt(1800),'farmEq','tools','y')}</div></div>`;return h}}
ACT.farmEq=v=>{if(!spend(v==='sprinkler'?2500:1800,v==='sprinkler'?'Sistem pemercik':'Peralatan tuai'))return;S[v]=1;addXP(40);rerender()};
{const nd=newDay;newDay=function(){nd();if(S.sprinkler)for(const p of S.farm.plots)if(p)p.wet=S.time+1440}}
{const h=harvest;harvest=function(i){const p=S.farm.plots[i];const ok=h(i);if(ok&&p&&Math.random()<skillLv('farm')*.04+(S.tools?.25:0))inv(p.c,1);return ok}}

// ---- cooking skill locks recipes
{const r=PANELS.masak.render;PANELS.masak.render=t=>{let h=r(t);if(t==='resepi')h=`<div class="note" style="margin-bottom:8px">Tahap kemahiran masakan: <b>${skillLv('cook')}</b>. Resepi baharu dibuka apabila tahap meningkat.</div>`+h;return h}}
{const ck=ACT.cook;ACT.cook=v=>{const r=RECIPES.find(x=>x[0]===v);if((r[7]||0)>skillLv('cook')){toast(`Resepi ini dibuka pada Tahap Masakan ${r[7]}.`,'y');return}ck(v)}}
