// ===================== MINI-GAMES =====================
// ---- sea creature icons
function drawCreature(c,w,h,g,col,sil){
  c.save();c.translate(w/2,h/2);const s=Math.min(w/96,h/64);c.scale(s,s);
  const F=sil?'rgba(60,50,90,.28)':col,D=sil?'rgba(60,50,90,.35)':shade(col,-.35),L=sil?'rgba(60,50,90,.2)':shade(col,.35);
  const eye=(x,y,r)=>{if(sil)return;c.fillStyle='#fff';c.beginPath();c.arc(x,y,r,0,TAU);c.fill();c.fillStyle='#1a1a2a';c.beginPath();c.arc(x+.4,y,r*.55,0,TAU);c.fill()};
  c.lineWidth=1.5;c.strokeStyle=D;c.fillStyle=F;
  const body=(len,ht,tail)=>{c.beginPath();c.moveTo(-len*.5,0);c.quadraticCurveTo(-len*.1,-ht,len*.45,-ht*.15);c.quadraticCurveTo(len*.55,0,len*.45,ht*.15);c.quadraticCurveTo(-len*.1,ht,-len*.5,0);c.fill();c.stroke();
    c.beginPath();c.moveTo(-len*.45,0);c.lineTo(-len*.5-tail,-ht*.8);c.lineTo(-len*.5-tail*.6,0);c.lineTo(-len*.5-tail,ht*.8);c.closePath();c.fill();c.stroke();
    if(!sil){c.fillStyle=L;c.beginPath();c.ellipse(len*.02,ht*.35,len*.3,ht*.3,0,0,TAU);c.fill()}};
  switch(g){
  case 'ikan':case 'keli':case 'arowana':
    body(g==='keli'?62:g==='arowana'?66:56,g==='keli'?11:g==='arowana'?12:16,14);
    c.fillStyle=D;c.beginPath();c.moveTo(-10,-14);c.quadraticCurveTo(2,-24,10,-13);c.fill();
    if(g==='keli'){c.strokeStyle=D;c.beginPath();c.moveTo(28,2);c.quadraticCurveTo(36,6,40,12);c.moveTo(28,0);c.quadraticCurveTo(36,-4,40,-8);c.stroke()}
    if(g==='arowana'&&!sil){c.strokeStyle='rgba(255,240,180,.8)';for(let i=-16;i<20;i+=6){c.beginPath();c.arc(i,0,5,-.8,.8);c.stroke()}}
    eye(g==='keli'?24:20,-3,3.4);if(!sil){c.strokeStyle=D;c.beginPath();c.arc(14,0,8,-1,1);c.stroke()}break;
  case 'marlin':body(64,12,16);c.fillStyle=D;c.beginPath();c.moveTo(-14,-10);c.lineTo(-4,-30);c.lineTo(16,-10);c.fill();c.strokeStyle=D;c.lineWidth=2.5;c.beginPath();c.moveTo(30,-2);c.lineTo(46,-5);c.stroke();eye(22,-3,3);break;
  case 'udang':for(let i=0;i<6;i++){const a=-.9+i*.36;c.fillStyle=i%2?F:shade(col,sil?0:.12);c.beginPath();c.ellipse(Math.cos(a)*18,Math.sin(a)*18-4,8,6.5,a+Math.PI/2,0,TAU);c.fill();c.stroke()}
    c.beginPath();c.moveTo(14,18);c.lineTo(4,26);c.lineTo(18,24);c.fill();c.strokeStyle=D;c.beginPath();c.moveTo(18,-16);c.quadraticCurveTo(34,-30,44,-18);c.moveTo(18,-14);c.quadraticCurveTo(30,-22,40,-8);c.stroke();eye(16,-14,2.4);break;
  case 'sotong':c.beginPath();c.moveTo(-34,0);c.quadraticCurveTo(-20,-12,10,-9);c.lineTo(10,9);c.quadraticCurveTo(-20,12,-34,0);c.fill();c.stroke();c.beginPath();c.moveTo(-30,0);c.lineTo(-40,-10);c.lineTo(-38,0);c.lineTo(-40,10);c.closePath();c.fill();
    c.strokeStyle=F;c.lineWidth=2.4;for(let i=-3;i<=3;i++){c.beginPath();c.moveTo(10,i*2.4);c.quadraticCurveTo(24,i*4,34+Math.abs(i),i*6);c.stroke()}eye(4,-3,2.6);break;
  case 'kurita':c.beginPath();c.ellipse(0,-10,16,15,0,0,TAU);c.fill();c.stroke();c.strokeStyle=F;c.lineWidth=3.4;for(let i=0;i<8;i++){const x=-14+i*4;c.beginPath();c.moveTo(x,0);c.quadraticCurveTo(x+(i-3.5)*4,14,x+(i-3.5)*7,18+Math.sin(i)*4);c.stroke()}eye(-6,-10,3);eye(6,-10,3);break;
  case 'ketam':c.strokeStyle=D;c.lineWidth=2.4;for(let i=0;i<4;i++){c.beginPath();c.moveTo(-10,2+i*3);c.lineTo(-24,6+i*5);c.moveTo(10,2+i*3);c.lineTo(24,6+i*5);c.stroke()}
    c.fillStyle=F;c.lineWidth=1.5;c.beginPath();c.ellipse(0,2,22,13,0,0,TAU);c.fill();c.stroke();for(const sx of [-1,1]){c.beginPath();c.ellipse(sx*26,-12,7,5,sx*.5,0,TAU);c.fill();c.stroke();c.beginPath();c.moveTo(sx*14,-6);c.lineTo(sx*22,-10);c.stroke()}eye(-5,-9,2.4);eye(5,-9,2.4);break;
  case 'kerang':case 'siput':if(g==='siput'){c.beginPath();c.moveTo(-18,10);c.quadraticCurveTo(-20,-16,8,-14);c.quadraticCurveTo(26,-8,22,10);c.closePath();c.fill();c.stroke();c.beginPath();for(let a=0;a<12;a+=.3)c.lineTo(Math.cos(a)*a*1.2,Math.sin(a)*a*1.2-2);c.stroke()}
    else{c.beginPath();c.moveTo(0,16);c.lineTo(-22,-4);c.quadraticCurveTo(0,-24,22,-4);c.closePath();c.fill();c.stroke();for(let i=-3;i<=3;i++){c.beginPath();c.moveTo(0,16);c.lineTo(i*6,-14+Math.abs(i));c.stroke()}}break;
  case 'belangkas':c.beginPath();c.ellipse(0,-2,22,16,0,Math.PI,TAU);c.lineTo(22,6);c.lineTo(-22,6);c.closePath();c.fill();c.stroke();c.lineWidth=3;c.beginPath();c.moveTo(0,6);c.lineTo(0,28);c.stroke();eye(-8,-8,2);eye(8,-8,2);break;
  case 'penyu':for(const [x,y] of [[-16,-14],[16,-14],[-14,14],[14,14]]){c.beginPath();c.ellipse(x,y,9,5,Math.atan2(y,x),0,TAU);c.fill();c.stroke()}c.beginPath();c.arc(26,0,7,0,TAU);c.fill();c.stroke();
    c.fillStyle=sil?F:shade(col,-.15);c.beginPath();c.ellipse(0,0,22,17,0,0,TAU);c.fill();c.stroke();if(!sil){c.strokeStyle=L;for(const [x,y] of [[0,0],[-10,-6],[10,-6],[-10,6],[10,6]]){c.beginPath();c.arc(x,y,5,0,TAU);c.stroke()}}eye(29,-2,1.8);break;
  case 'dugong':c.beginPath();c.ellipse(0,0,34,13,0,0,TAU);c.fill();c.stroke();c.beginPath();c.moveTo(-30,0);c.lineTo(-44,-10);c.lineTo(-40,0);c.lineTo(-44,10);c.closePath();c.fill();c.stroke();c.beginPath();c.ellipse(8,12,8,3,.5,0,TAU);c.fill();eye(24,-4,2);break;
  case 'yupaus':c.beginPath();c.ellipse(0,0,40,14,0,0,TAU);c.fill();c.stroke();c.beginPath();c.moveTo(-36,0);c.lineTo(-48,-16);c.lineTo(-42,0);c.lineTo(-48,12);c.closePath();c.fill();c.beginPath();c.moveTo(-4,-12);c.lineTo(4,-26);c.lineTo(10,-12);c.fill();
    if(!sil){c.fillStyle='#fff';for(let i=0;i<14;i++){c.beginPath();c.arc(-28+i*4.4,((i*7)%9)-5,1.4,0,TAU);c.fill()}}eye(32,-2,1.8);break;
  case 'kudalaut':c.lineWidth=7;c.strokeStyle=F;c.lineCap='round';c.beginPath();c.moveTo(4,-22);c.quadraticCurveTo(-8,-10,2,2);c.quadraticCurveTo(12,14,0,22);c.quadraticCurveTo(-8,26,-6,18);c.stroke();c.lineWidth=5;c.beginPath();c.moveTo(4,-22);c.lineTo(16,-20);c.stroke();eye(4,-22,2);break;
  case 'kima':c.fillStyle=sil?F:'#2a7ad0';c.beginPath();c.ellipse(0,0,24,8,0,0,TAU);c.fill();c.fillStyle=F;c.beginPath();c.moveTo(-28,0);for(let i=0;i<=8;i++)c.lineTo(-28+i*7,(i%2?-14:-8));c.lineTo(28,0);c.closePath();c.fill();c.stroke();c.beginPath();c.moveTo(-28,0);for(let i=0;i<=8;i++)c.lineTo(-28+i*7,(i%2?14:8));c.lineTo(28,0);c.closePath();c.fill();c.stroke();break;
  case 'karang':c.strokeStyle=F;c.lineCap='round';const br=(x,y,a,l,d)=>{if(d>4)return;const x2=x+Math.cos(a)*l,y2=y+Math.sin(a)*l;c.lineWidth=6-d;c.beginPath();c.moveTo(x,y);c.lineTo(x2,y2);c.stroke();br(x2,y2,a-.5,l*.72,d+1);br(x2,y2,a+.5,l*.72,d+1)};br(0,26,-Math.PI/2,16,0);break;
  }
  c.restore();
}
function creatureImg(g,col,sil,w,h){w=w||96;h=h||64;const k='cr'+g+col+sil+w;let u=imgCache.get(k);if(u)return u;const c=document.createElement('canvas');c.width=w*2;c.height=h*2;drawCreature(c.getContext('2d'),w*2,h*2,g,col,sil);u=c.toDataURL();imgCache.set(k,u);return u}
const allSpecies=()=>{const out=[];for(const sp of FISHSPOTS)sp.fish.forEach((f,i)=>out.push({key:sp.id+':'+i,spot:sp,name:f[0],rar:f[1],min:f[2],max:f[3],ppk:f[4],g:f[5],col:f[6],night:f[7]}));return out};

// ---- FISHING
const FG={on:false};
function fishWeight(g,L){const k={ikan:.000012,keli:.00001,marlin:.000011,udang:.00002,ketam:.00012,kerang:.0006,siput:.0006,sotong:.00005,kurita:.00003,belangkas:.0001}[g]||.000012;return Math.max(.02,k*L*L*L)}
function rollCatch(sp){
  const rod=RODS[S.rod],bait=BAITS.find(b=>b[0]===S.bait&&(S.baits[S.bait]>0||b[7]&&S.baits[S.bait]));
  const pc=sp.deep?.06:.045;
  if(Math.random()<pc){const p=pick(sp.prot);return{prot:1,name:p[0],g:p[1],col:p[2],rarI:2}}
  if(Math.random()<.05)return{junk:1,name:pick(['Botol Plastik','Beg Plastik','Tin Minuman','Pukat Hanyut']),g:'kerang',col:'#9aa0a8',rarI:0};
  const night=hourNow()>=19||hourNow()<6,rain=S.weather==='hujan';
  const ws=sp.fish.map(f=>{let w=RARW[f[1]];const ri='curel'.indexOf(f[1]);if(ri>=2)w*=(1+rod[3]*3+(bait?bait[6]*4:0))*(rain?1.35:1);if(f[7]&&night)w*=2.2;return w});
  let r=Math.random()*ws.reduce((a,b)=>a+b,0),i=0;while(r>ws[i]){r-=ws[i];i++}
  const f=sp.fish[i];const lo=f[2]*.55,L=Math.round((lo+(f[3]-lo)*Math.pow(Math.random(),1.25))*10)/10;
  const kg=Math.round(fishWeight(f[5],L)*100)/100;const ri='curel'.indexOf(f[1]);
  return{key:sp.id+':'+i,name:f[0],rar:f[1],rarI:ri,g:f[5],col:f[6],cm:L,kg,min:f[2],legal:L>=f[2],price:Math.max(2,Math.round(kg*f[4]*(1+ri*.25)))};
}
function fishSpotConditions(sp){const h=hourNow(),parts=[];if(S.weather==='ribut')parts.push('RIBUT PETIR: laut ditutup');parts.push(h>=19||h<6?'Malam: sotong & udang lebih aktif':h<10?'Pagi: ikan aktif makan':'Siang');if(S.weather==='hujan')parts.push('Hujan: peluang ikan jarang meningkat');else if(S.weather==='mendung')parts.push('Mendung: cuaca selesa');return parts.join(' · ')}
function startFishing(spotId,opts){
  const sp=FISHSPOTS.find(s=>s.id===spotId);opts=opts||{};
  if(sp.salt&&S.weather==='ribut'){showDlg({title:'Amaran Ribut Petir',body:'<div class="note r">Memancing di laut ditutup semasa ribut petir demi keselamatan. Cuba tasik atau sungai, atau datang esok.</div>',buttons:[{label:'Faham',cls:'w',a:'closeDlg'}]});return}
  if(spotId==='labuan'&&S.lvl<5){toast('Laut Dalam Labuan dibuka pada Tahap 5.','y');return}
  Object.assign(FG,{on:true,sp,phase:'aim',power:0,pdir:1,t:0,hold:false,zone:150,zv:0,fy:150,ftarget:150,fT:0,prog:.3,cat:null,tour:opts.tour||null,last:0,msg:'Tekan BALING bila meter penuh!'});
  showDlg({wide:'fish',title:sp.name+(FG.tour?' — Pertandingan':''),body:`<div class="row" style="margin-bottom:6px"><span class="tagx">${esc(sp.sub)}</span><span class="tagx">${esc(RODS[S.rod][0])}</span><span class="tagx" id="fBait"></span>${FG.tour?`<span class="tagx l" id="fTour"></span>`:''}</div>
    <div style="font-size:13px;color:var(--mut);margin-bottom:6px">${esc(fishSpotConditions(sp))}</div>
    <div id="fStage"><canvas class="fishcv" id="fcv"></canvas><div class="row" style="margin-top:8px"><button class="btn w" data-a="fEnd">Selesai</button><button class="btn w" data-a="fBaitPick">Tukar Umpan</button><button class="btn full g" id="fBtn" style="flex:2;min-height:52px;font-size:17px">BALING!</button></div><p style="font-size:12px;color:var(--mut);margin:6px 0 0">Tenaga −3 & 15 minit setiap balingan. Komputer: tekan <b>Space</b>.</p></div><div id="fRes"></div>`,
    buttons:[],onclose:()=>{FG.on=false;if(FG.tour)finishTournament()},
    after:()=>{const b=$('#fBtn'),c=$('#fcv');const dn=e=>{e.preventDefault();fPress(true)},up=e=>{e.preventDefault();fPress(false)};
      b.addEventListener('pointerdown',dn);b.addEventListener('pointerup',up);b.addEventListener('pointerleave',up);c.addEventListener('pointerdown',dn);c.addEventListener('pointerup',up);
      fishBaitLabel();requestAnimationFrame(fishLoop)}});
}
function fishBaitLabel(){const b=BAITS.find(x=>x[0]===S.bait);const n=S.baits[S.bait]||0;const el=$('#fBait');if(el)el.textContent=n>0?`Umpan: ${b[1]}${b[7]?'':` (${n})`}`:'Tiada umpan';const t=$('#fTour');if(t&&FG.tour)t.textContent=`Baki: ${FG.tour.left} · ${FG.tour.total.toFixed(2)} kg`}
addEventListener('keydown',e=>{if(FG.on&&e.code==='Space'&&!e.repeat&&$('#fBtn')){e.preventDefault();fPress(true)}});
addEventListener('keyup',e=>{if(FG.on&&e.code==='Space'){e.preventDefault();fPress(false)}});
function fPress(down){
  if(!FG.on)return;FG.hold=down;if(!down)return;
  if(FG.phase==='aim'){
    if(!useEnergy(3))return;
    const has=S.baits[S.bait]>0;if(has&&!BAITS.find(b=>b[0]===S.bait)[7])S.baits[S.bait]--;
    advance(15);
    const b=BAITS.find(x=>x[0]===S.bait);const bonus=has?(FG.sp.salt?b[4]:b[5]):-.5;
    FG.phase='wait';FG.t=0;FG.biteAt=rnd(1.6,4.6)*(1-bonus*.6)*(S.weather==='hujan'?.8:1)*(1.15-FG.power*.3);FG.cast=FG.power;FG.msg=has?'Tunggu ikan makan umpan…':'Tiada umpan — ikan lambat mengena.';fishBaitLabel();
  } else if(FG.phase==='bite'){
    FG.phase='reel';FG.cat=rollCatch(FG.sp);FG.prog=.3;FG.zone=150;FG.zv=0;FG.fy=140;FG.msg='Tahan butang untuk naikkan zon hijau!';
  } else if(FG.phase==='wait'){FG.msg='Sabar… belum lagi!'}
}
function fishLoop(t){
  if(!FG.on)return;const c=$('#fcv');if(!c){FG.on=false;return}
  if(RT.blocked){FG.last=t;requestAnimationFrame(fishLoop);return}
  const dt=Math.min(.05,(t-(FG.last||t))/1000);FG.last=t;
  const W=c.clientWidth,H=c.clientHeight,d=pxr();if(c.width!==Math.round(W*d)){c.width=Math.round(W*d);c.height=Math.round(H*d)}
  const x=c.getContext('2d');x.setTransform(d,0,0,d,0,0);
  const btn=$('#fBtn');
  // update
  if(FG.phase==='aim'){FG.power+=FG.pdir*dt*1.2;if(FG.power>1){FG.power=1;FG.pdir=-1}if(FG.power<0){FG.power=0;FG.pdir=1}if(btn)btn.textContent='BALING!'}
  else if(FG.phase==='wait'){FG.t+=dt;if(btn)btn.textContent='Tunggu…';if(FG.t>FG.biteAt){FG.phase='bite';FG.t=0;FG.msg='ADA YANG MAKAN! Sentap sekarang!'}}
  else if(FG.phase==='bite'){FG.t+=dt;if(btn)btn.textContent='SENTAP!';if(FG.t>1.15+(S.hook||0)*.15){FG.phase='aim';FG.msg='Alamak, ikan terlepas. Cuba lagi!'}}
  else if(FG.phase==='reel'){
    if(btn)btn.textContent='TAHAN UNTUK TARIK';
    const top=24,bot=H-24,len=bot-top,zh=Math.max(52,84+S.rod*12+skillLv("fish")*3-FG.cat.rarI*6);
    FG.zv+=(FG.hold?-950:620)*dt;FG.zv=clamp(FG.zv,-420,420);FG.zone+=FG.zv*dt;if(FG.zone<top){FG.zone=top;FG.zv=0}if(FG.zone>bot-zh){FG.zone=bot-zh;FG.zv*=-.3}
    FG.fT-=dt;if(FG.fT<=0){FG.fT=rnd(.35,1.1)-FG.cat.rarI*.05;FG.ftarget=top+12+Math.random()*(len-24)}
    const fs=55+FG.cat.rarI*42;FG.fy+=clamp(FG.ftarget-FG.fy,-fs*dt,fs*dt);
    const inZ=FG.fy>FG.zone&&FG.fy<FG.zone+zh;FG.prog+=inZ?dt*.4*(1+S.rod*.08):-dt*.19*(1-(S.line||0)*.15);
    if(FG.prog>=1){FG.phase='done';showCatch()}else if(FG.prog<=0){FG.phase='aim';FG.msg=`${FG.cat.prot?'Haiwan itu':'Ikan'} terlepas! Cuba lagi.`;FG.cat=null}
  }
  // draw scene
  const hr=hourNow(),night=hr>=19||hr<6;
  const sky=x.createLinearGradient(0,0,0,H*.35);sky.addColorStop(0,night?'#1a1f4a':'#7cc4ff');sky.addColorStop(1,night?'#3a3f7a':'#d8f0ff');x.fillStyle=sky;x.fillRect(0,0,W,H*.35);
  if(FG.sp.salt===0){x.fillStyle='#3a8a4a';for(let i=0;i<8;i++){x.beginPath();x.arc(i*W/7,H*.35,40,Math.PI,TAU);x.fill()}}else{x.fillStyle=night?'#2a3060':'#a8c8e8';x.beginPath();x.moveTo(W*.5,H*.35);x.lineTo(W*.7,H*.22);x.lineTo(W*.9,H*.35);x.fill()}
  const wg=x.createLinearGradient(0,H*.35,0,H);wg.addColorStop(0,FG.sp.water);wg.addColorStop(1,shade(FG.sp.water,-.45));x.fillStyle=wg;x.fillRect(0,H*.35,W,H*.65);
  x.strokeStyle='rgba(255,255,255,.25)';x.lineWidth=1.5;for(let i=0;i<10;i++){const yy=H*.4+i*H*.06,o=(t/30+i*40)%60;x.beginPath();for(let xx=-60+o;xx<W;xx+=60){x.moveTo(xx,yy);x.quadraticCurveTo(xx+10,yy-4,xx+20,yy)}x.stroke()}
  if(S.weather==='hujan'){x.strokeStyle='rgba(220,235,255,.5)';x.beginPath();for(let i=0;i<40;i++){const rx=(i*97+t*.4)%W,ry=(i*53+t*.8)%H;x.moveTo(rx,ry);x.lineTo(rx-2,ry+10)}x.stroke()}
  // dock + player
  x.fillStyle='#9a653a';x.fillRect(0,H*.62,W*.22,16);x.fillStyle='#6b4426';for(let i=0;i<4;i++)x.fillRect(8+i*W*.05,H*.62+16,6,H*.4);
  const ps=Math.min(1.25,H/260);drawChibi(x,W*.1,H*.62,ps,S.look,2,0);
  const rodX=W*.1+20*ps,rodY=H*.62-60*ps,tipX=rodX+46*ps,tipY=rodY-40*ps;
  x.strokeStyle='#5a3a20';x.lineWidth=3;x.beginPath();x.moveTo(rodX,rodY);x.lineTo(tipX,tipY);x.stroke();
  const reelArea=FG.phase==='reel'?W-90:W;
  const bx=FG.phase==='aim'?tipX+10:W*.3+(FG.cast||0)*(reelArea-W*.4),by=FG.phase==='aim'?tipY+30:H*.55+Math.sin(t/300)*3+(FG.phase==='bite'?Math.sin(t/40)*5:0);
  x.strokeStyle='rgba(255,255,255,.8)';x.lineWidth=1;x.beginPath();x.moveTo(tipX,tipY);x.quadraticCurveTo((tipX+bx)/2,Math.min(tipY,by)-20,bx,by);x.stroke();
  x.fillStyle='#e5484d';x.beginPath();x.arc(bx,by,6,Math.PI,TAU);x.fill();x.fillStyle='#fff';x.beginPath();x.arc(bx,by,6,0,Math.PI);x.fill();
  if(FG.phase==='bite'){x.fillStyle='#ffd23f';x.font='900 40px Fredoka,sans-serif';x.textAlign='center';x.fillText('!',bx,by-20);x.strokeStyle='rgba(255,255,255,.7)';x.lineWidth=2;x.beginPath();x.arc(bx,by,14+FG.t*20,0,TAU);x.stroke()}
  // power meter
  if(FG.phase==='aim'){const mw=Math.min(240,W*.5),mx=W/2-mw/2+W*.08,my=H-34;x.fillStyle='rgba(0,0,0,.35)';x.fillRect(mx-3,my-3,mw+6,20);const pg=x.createLinearGradient(mx,0,mx+mw,0);pg.addColorStop(0,'#7cf08a');pg.addColorStop(.7,'#ffd23f');pg.addColorStop(1,'#e5484d');x.fillStyle=pg;x.fillRect(mx,my,mw*FG.power,14);x.fillStyle='#fff';x.font='800 12px Nunito';x.textAlign='center';x.fillText('KUASA BALINGAN',mx+mw/2,my-8)}
  // reel bar
  if(FG.phase==='reel'){const bx2=W-62,top=24,bot=H-24,zh=Math.max(52,84+S.rod*12+skillLv("fish")*3-FG.cat.rarI*6);
    x.fillStyle='rgba(20,30,60,.65)';const p=new Path2D();rrp(p,bx2-6,top-6,44,bot-top+12,12);x.fill(p);
    x.fillStyle='rgba(124,240,138,.75)';x.fillRect(bx2,FG.zone,32,zh);x.strokeStyle='#fff';x.lineWidth=2;x.strokeRect(bx2,FG.zone,32,zh);
    x.save();x.translate(bx2+16,FG.fy);drawCreature(x,40,26,FG.cat.prot?FG.cat.g:'ikan',FG.cat.col||'#ffd23f',false);x.restore();
    x.fillStyle='rgba(0,0,0,.35)';x.fillRect(bx2+44,top,10,bot-top);x.fillStyle=FG.prog>.6?'#7cf08a':FG.prog>.3?'#ffd23f':'#e5484d';x.fillRect(bx2+44,bot-(bot-top)*FG.prog,10,(bot-top)*FG.prog)}
  // message
  x.fillStyle='rgba(42,31,71,.78)';x.font='800 14px Nunito,sans-serif';const mw2=x.measureText(FG.msg).width+24;const mp=new Path2D();rrp(mp,W/2-mw2/2-(FG.phase==='reel'?40:0),10,mw2,28,14);x.fill(mp);x.fillStyle='#fff';x.textAlign='center';x.textBaseline='middle';x.fillText(FG.msg,W/2-(FG.phase==='reel'?40:0),24);x.textBaseline='alphabetic';
  requestAnimationFrame(fishLoop);
}
function showCatch(){
  const c=FG.cat;$('#fStage').classList.add('hide');
  let html=`<div class="card" style="text-align:center"><img class="im wide" src="${creatureImg(c.g,c.col,!!c.junk,160,90)}" alt="" style="aspect-ratio:16/9">`;
  if(c.junk){html+=`<h4 style="font-size:19px">${esc(c.name)}</h4><div class="note y">Sampah tersangkut pada kail! Buang ke tong sampah untuk menjaga kebersihan air.</div><div class="row"><button class="btn g full" data-a="fJunk">Buang ke Tong Sampah (+XP Pemuliharaan)</button></div></div>`;$('#fRes').innerHTML=html;return}
  if(c.prot){
    html+=`<h4 style="font-size:19px">${esc(c.name)}</h4><div class="note r"><b>HAIWAN DILINDUNGI — WAJIB DILEPASKAN.</b><br>Spesies ini dilindungi undang-undang. Ia tidak boleh dijual, dimasak atau disimpan. Lepaskan dengan cermat ke habitat asalnya.</div>
    <div class="row"><button class="btn g full" data-a="fRelease" data-v="prot" style="flex:2">Lepaskan (+XP Pemuliharaan)</button><button class="btn r" data-a="fKeepProt">Cuba Simpan</button></div>`;
  } else {
    html+=`<h4 style="font-size:19px">${esc(c.name)} <span class="tagx ${c.rar}">${RARN[c.rar]}</span></h4><div class="kv" style="justify-content:center;grid-template-columns:auto auto"><span>Saiz</span><b>${c.cm} cm</b><span>Berat</span><b>${c.kg} kg</b><span>Nilai pasaran</span><b>${fmt(c.price)}</b><span>Saiz minimum</span><b>${c.min} cm</b></div>`;
    if(!c.legal)html+=`<div class="note y">Saiz di bawah had minimum (${c.min} cm). Ikan kecil mesti dilepaskan supaya boleh membiak.</div><div class="row"><button class="btn g full" data-a="fRelease" data-v="small" style="flex:2">Lepaskan</button><button class="btn r" data-a="fKeep" data-v="illegal">Simpan (denda)</button></div>`;
    else html+=`<div class="row"><button class="btn g full" data-a="fKeep" style="flex:2">Simpan</button><button class="btn w" data-a="fRelease" data-v="kind">Lepaskan</button></div>`;
  }
  html+='</div>';$('#fRes').innerHTML=html;
  S.cnt.fish++;if(!c.prot){const d=S.fishdex[c.key];S.fishdex[c.key]={n:(d?d.n:0)+1,best:Math.max(d?d.best:0,c.cm)}}
  addXP(c.prot?10:6+c.rarI*8);
}
function backToFishing(){FG.phase='aim';FG.cat=null;FG.msg='Sedia untuk balingan seterusnya.';$('#fRes').innerHTML='';$('#fStage').classList.remove('hide');fishBaitLabel();
  if(FG.tour){FG.tour.left--;fishBaitLabel();if(FG.tour.left<=0){closeDlg()}}}
ACT.fKeep=v=>{const c=FG.cat;if(v==='illegal'){const fine=200;S.money=Math.max(0,S.money-fine);stat('karisma',-3);addMsg('Jabatan Perikanan','Notis Denda',`Anda didenda ${fmt(fine)} kerana menyimpan ${c.name} bersaiz ${c.cm} cm (minimum ${c.min} cm). Ikan telah dirampas.`);toast(`Denda ${fmt(fine)}! Ikan dirampas.`,'r');backToFishing();return}
  S.fishInv.push({k:c.key,name:c.name,g:c.g,col:c.col,cm:c.cm,kg:c.kg,price:c.price,rar:c.rar});if(FG.tour)FG.tour.total+=c.kg;toast(`${c.name} disimpan dalam tong ikan`,'g');backToFishing()};
ACT.fRelease=v=>{const c=FG.cat;
  if(v==='prot'){S.cnt.prot++;S.consXP+=50;S.journal.unshift({name:c.name,spot:FG.sp.name,d:dayIdx(),tm:timeStr()});addXP(50);stat('karisma',2);stat('gembira',5);toast(`${c.name} dilepaskan dengan selamat. +50 XP Pemuliharaan`,'g')}
  else{S.cnt.released++;S.consXP+=v==='small'?8:5;addXP(v==='small'?8:5);toast('Dilepaskan ke habitat. Terima kasih menjaga alam!','g')}
  backToFishing()};
ACT.fKeepProt=()=>{const c=FG.cat;const fine=Math.min(Math.max(S.money,0),1000);S.money-=fine;stat('karisma',-8);stat('gembira',-10);S.journal.unshift({name:c.name+' (dirampas)',spot:FG.sp.name,d:dayIdx(),tm:timeStr(),bad:1});
  addMsg('Jabatan Perikanan & PERHILITAN','Kesalahan Hidupan Dilindungi',`Menyimpan ${c.name} adalah satu kesalahan. Anda didenda ${fmt(fine)} dan haiwan tersebut telah dilepaskan semula oleh pegawai.`);
  showDlg({title:'Kesalahan Hidupan Dilindungi!',body:`<div class="note r"><b>${esc(c.name)}</b> ialah hidupan dilindungi. Pegawai telah merampas dan melepaskannya semula.<br><br>Denda: <b>${fmt(fine)}</b> · Karisma −8</div>`,buttons:[{label:'Faham',cls:'w',a:'closeDlg'}],onclose:()=>{}})};
ACT.fEnd=()=>closeDlg();
ACT.fJunk=()=>{S.consXP+=10;S.cnt.clean=(S.cnt.clean||0)+1;addXP(10);toast('Terima kasih menjaga kebersihan! +10 XP Pemuliharaan','g');backToFishing()};
ACT.fBaitPick=()=>{const list=BAITS.filter(b=>S.baits[b[0]]>0);if(!list.length){toast('Tiada umpan. Beli di Memancing → Peralatan.','r');return}const i=list.findIndex(b=>b[0]===S.bait);S.bait=list[(i+1)%list.length][0];fishBaitLabel();toast('Umpan: '+BAITS.find(b=>b[0]===S.bait)[1])};
function finishTournament(){const T=FG.tour;if(!T)return;FG.tour=null;
  const rivals=['Ah Keong','Pak Mat','Rajesh','Joanna','Haziq','Uncle Lim','Kak Ros'].map(n=>({n,kg:Math.round(rnd(.4,6.5)*100)/100}));rivals.push({n:S.name+' (Anda)',kg:Math.round(T.total*100)/100,me:1});rivals.sort((a,b)=>b.kg-a.kg);
  const rank=rivals.findIndex(r=>r.me)+1;const prize=[0,500,250,100][rank]||0;if(prize){S.money+=prize}if(rank===1)S.cnt.champ++;S.daily.tour=1;addXP(30+(4-Math.min(4,rank))*20);
  setTimeout(()=>showDlg({title:'Keputusan Pertandingan Memancing',body:`<div class="list">${rivals.map((r,i)=>`<div class="li" style="${r.me?'border-color:var(--pur)':''}"><b style="width:24px">${i+1}</b><div class="t"><b>${esc(r.n)}</b></div><b>${r.kg.toFixed(2)} kg</b></div>`).join('')}</div>${prize?`<div class="note g" style="margin-top:8px">Tahniah! Tempat ke-${rank}: hadiah <b>${fmt(prize)}</b>${rank===1?' dan trofi juara!':''}</div>`:'<div class="note" style="margin-top:8px">Cuba lagi minggu depan!</div>'}`,buttons:[{label:'Tutup',cls:'g',a:'closeDlg'}]}),200)}

// ---- RUSH (work shift mini-game)
const RG={};
function startRush(title,emojis,cb){
  const set=[...emojis].filter(c=>c.trim()&&c!=='️');const items=[];for(const ch of Intl.Segmenter?[...new Intl.Segmenter().segment(emojis)].map(s=>s.segment):set)items.push(ch);
  Object.assign(RG,{items:items.slice(0,6),score:0,miss:0,left:15,on:true,cb,target:null});
  showDlg({wide:true,title,body:`<div class="row" style="margin-bottom:8px"><span class="tagx">Skor: <b id="rS">0</b></span><span class="sp"></span><span class="tagx y">Masa: <b id="rT">15</b>s</span></div><div class="bar y" style="margin-bottom:10px"><i id="rB" style="width:100%"></i></div>
    <div class="order">Pesanan: <span id="rO"></span></div><div class="rush" style="margin-top:10px">${RG.items.map((e,i)=>`<button data-a="rTap" data-v="${i}">${e}</button>`).join('')}</div><p style="font-size:13px;color:var(--mut)">Tekan item yang sama dengan pesanan secepat mungkin!</p>`,
    buttons:[],onclose:()=>{RG.on=false},after:()=>{rNext();RG.t0=performance.now();requestAnimationFrame(rLoop)}});
}
function rNext(){RG.target=Math.floor(Math.random()*RG.items.length);const o=$('#rO');if(o)o.textContent=RG.items[RG.target]}
function rLoop(t){if(!RG.on)return;if(RT.blocked&&RG.lt)RG.t0+=t-RG.lt;RG.lt=t;const left=Math.max(0,15-(t-RG.t0)/1000);const tt=$('#rT'),b=$('#rB');if(!tt){RG.on=false;return}tt.textContent=Math.ceil(left);b.style.width=(left/15*100)+'%';
  if(left<=0){RG.on=false;const perf=clamp(.6+RG.score*.055-RG.miss*.04,.6,1.4);const cb=RG.cb;closeDlg();cb(perf,RG.score);return}requestAnimationFrame(rLoop)}
ACT.rTap=(v,el)=>{if(!RG.on)return;if(+v===RG.target){RG.score++;el.style.background='#dff6e3'}else{RG.miss++;el.style.background='#ffe5e5'}setTimeout(()=>{el.style.background=''},150);$('#rS').textContent=RG.score;rNext()};

// ---- QUIZ
const QG={};
function genArith(){const a=2+Math.floor(Math.random()*40),b=2+Math.floor(Math.random()*20),op=pick(['+','−','×']);const ans=op==='+'?a+b:op==='−'?a-b:a*b;const opts=[ans,ans+pick([1,2,10]),ans-pick([1,3,10]),ans+pick([5,7,11])].map(String);const uniq=[...new Set(opts)];while(uniq.length<4)uniq.push(String(ans+uniq.length*13));return[`Kira: ${a} ${op} ${b} = ?`,uniq,0]}
function startQuiz(title,n,cb,custom){
  const pool=[...(custom||QUIZ)].sort(()=>Math.random()-.5);const qs=[];for(let i=0;i<n;i++)qs.push(!custom&&i%3===2?genArith():pool[i%pool.length]);
  Object.assign(QG,{qs:qs.map(q=>{const order=q[1].map((o,i)=>i).sort(()=>Math.random()-.5);return{q:q[0],opts:order.map(i=>q[1][i]),ans:order.indexOf(q[2])}}),i:0,score:0,cb,title,lock:false});
  showDlg({title,body:'<div id="qz"></div>',buttons:[],after:qRender});
}
function qRender(){const q=QG.qs[QG.i];$('#qz').innerHTML=`<div class="row" style="margin-bottom:8px"><span class="tagx">Soalan ${QG.i+1}/${QG.qs.length}</span><span class="sp"></span><span class="tagx u">Betul: ${QG.score}</span></div><p style="font-weight:800;font-size:17px;margin:4px 0 12px">${esc(q.q)}</p><div class="qopt">${q.opts.map((o,i)=>`<button data-a="qAns" data-v="${i}">${esc(o)}</button>`).join('')}</div>`;QG.lock=false}
ACT.qAns=v=>{if(QG.lock)return;QG.lock=true;const q=QG.qs[QG.i];const bs=document.querySelectorAll('.qopt button');bs[q.ans].classList.add('ok');if(+v===q.ans)QG.score++;else bs[+v].classList.add('no');
  setTimeout(()=>{QG.i++;if(QG.i>=QG.qs.length){const cb=QG.cb,sc=QG.score/QG.qs.length;closeDlg();cb(sc,QG.score)}else qRender()},650)};
