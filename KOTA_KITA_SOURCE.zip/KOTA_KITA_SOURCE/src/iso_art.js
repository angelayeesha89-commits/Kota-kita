// ===================== ISO ART TOOLKIT + BUILDINGS + PROPS =====================
const IP=(x,y,z)=>[(x-y)*TS,(x+y)*TS/2-(z||0)];
function ipoly(c,pts,fill,stroke,lw){c.beginPath();c.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)c.lineTo(pts[i][0],pts[i][1]);c.closePath();if(fill){c.fillStyle=fill;c.fill()}if(stroke){c.strokeStyle=stroke;c.lineWidth=lw||1;c.lineJoin='round';c.stroke()}}
function vgrad(c,p0,p1,a,b){const g=c.createLinearGradient(p0[0],p0[1],p1[0],p1[1]);g.addColorStop(0,a);g.addColorStop(1,b);return g}
function faceY(c,x0,x1,y,z0,z1,col,st,lw){const g=vgrad(c,IP(x0,y,z1),IP(x0,y,z0),shade(col,.08),shade(col,-.06));ipoly(c,[IP(x0,y,z0),IP(x1,y,z0),IP(x1,y,z1),IP(x0,y,z1)],g,st,lw)}
function faceX(c,x,y0,y1,z0,z1,col,st,lw){const g=vgrad(c,IP(x,y0,z1),IP(x,y0,z0),shade(col,-.08),shade(col,-.22));ipoly(c,[IP(x,y0,z0),IP(x,y1,z0),IP(x,y1,z1),IP(x,y0,z1)],g,st,lw)}
function topF(c,x,y,w,d,z,col,st){ipoly(c,[IP(x,y,z),IP(x+w,y,z),IP(x+w,y+d,z),IP(x,y+d,z)],col,st)}
function box(c,x,y,z,w,d,h,col,o){o=o||{};const st=o.st===undefined?shade(col,-.5):o.st;faceY(c,x,x+w,y+d,z,z+h,o.l||col,st,.8);faceX(c,x+w,y,y+d,z,z+h,o.r||col,st,.8);if(!o.notop)topF(c,x,y,w,d,z+h,o.t||shade(col,.14),st)}
function planks(c,x0,x1,y,z0,z1,col,face){c.strokeStyle=shade(col,-.28);c.lineWidth=.7;for(let z=z0+4;z<z1;z+=5){c.beginPath();if(face==='y'){const a=IP(x0,y,z),b=IP(x1,y,z);c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1])}else{const a=IP(y,x0,z),b=IP(y,x1,z);c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1])}c.stroke()}}
// window on +y face (centre xc, width ww tiles, z0..z1) ; on +x face (centre yc)
function winY(c,xc,y,z0,z1,ww,o){o=o||{};const fr=o.frame||'#ffffff',x0=xc-ww/2,x1=xc+ww/2;ipoly(c,[IP(x0-.05,y,z0-2),IP(x1+.05,y,z0-2),IP(x1+.05,y,z1+2),IP(x0-.05,y,z1+2)],fr,shade(fr,-.45),.6);
  const night=o.lit;const g=vgrad(c,IP(x0,y,z1),IP(x0,y,z0),night?'#ffe9a8':'#bfe6ff',night?'#ffc860':'#4f95d6');ipoly(c,[IP(x0,y,z0),IP(x1,y,z0),IP(x1,y,z1),IP(x0,y,z1)],g);
  ipoly(c,[IP(x0+ww*.12,y,z1),IP(x0+ww*.38,y,z1),IP(x0+ww*.1,y,z0),IP(x0,y,z0),IP(x0,y,(z0+z1)/2)],'rgba(255,255,255,.45)');
  if(o.cross!==false){c.strokeStyle=fr;c.lineWidth=1;const a=IP(xc,y,z0),b=IP(xc,y,z1);c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1]);c.stroke()}
  if(o.shut){for(const s of [-1,1]){const xs=s<0?x0-ww*.45:x1+.02;ipoly(c,[IP(xs,y,z0),IP(xs+ww*.43,y,z0),IP(xs+ww*.43,y,z1),IP(xs,y,z1)],o.shut,shade(o.shut,-.4),.5)}}
  if(o.box){ipoly(c,[IP(x0-.05,y+.12,z0-6),IP(x1+.05,y+.12,z0-6),IP(x1+.05,y+.12,z0-1),IP(x0-.05,y+.12,z0-1)],'#8a5a33');for(let i=0;i<4;i++){const p=IP(x0+ww*(i+.5)/4,y+.12,z0);c.fillStyle=['#ff5ea8','#e5484d','#ffd23f','#ff8ab8'][i];c.beginPath();c.arc(p[0],p[1],2.2,0,TAU);c.fill()}}
  ipoly(c,[IP(x0-.08,y+.08,z0-3),IP(x1+.08,y+.08,z0-3),IP(x1+.08,y,z0-3),IP(x0-.08,y,z0-3)],shade(fr,-.1))}
function winX(c,x,yc,z0,z1,ww,o){o=o||{};const fr=o.frame||'#ffffff',y0=yc-ww/2,y1=yc+ww/2;ipoly(c,[IP(x,y0-.05,z0-2),IP(x,y1+.05,z0-2),IP(x,y1+.05,z1+2),IP(x,y0-.05,z1+2)],shade(fr,-.12),shade(fr,-.5),.6);
  const g=vgrad(c,IP(x,y0,z1),IP(x,y0,z0),o.lit?'#ffe0a0':'#a8d6f5',o.lit?'#e8b050':'#3f7fbf');ipoly(c,[IP(x,y0,z0),IP(x,y1,z0),IP(x,y1,z1),IP(x,y0,z1)],g);
  ipoly(c,[IP(x,y0+ww*.15,z1),IP(x,y0+ww*.35,z1),IP(x,y0+ww*.12,z0),IP(x,y0,z0)],'rgba(255,255,255,.3)');
  if(o.cross!==false){c.strokeStyle=shade(fr,-.12);c.lineWidth=1;const a=IP(x,yc,z0),b=IP(x,yc,z1);c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1]);c.stroke()}
  if(o.shut){for(const s of [-1,1]){const ys=s<0?y0-ww*.45:y1+.02;ipoly(c,[IP(x,ys,z0),IP(x,ys+ww*.43,z0),IP(x,ys+ww*.43,z1),IP(x,ys,z1)],shade(o.shut,-.18),shade(o.shut,-.5),.5)}}
  if(o.box){ipoly(c,[IP(x+.12,y0-.05,z0-6),IP(x+.12,y1+.05,z0-6),IP(x+.12,y1+.05,z0-1),IP(x+.12,y0-.05,z0-1)],'#6b4426');for(let i=0;i<4;i++){const p=IP(x+.12,y0+ww*(i+.5)/4,z0);c.fillStyle=['#ff5ea8','#e5484d','#ffd23f','#ff8ab8'][i];c.beginPath();c.arc(p[0],p[1],2.2,0,TAU);c.fill()}}}
function winRowY(c,x0,x1,y,z0,z1,n,o){const step=(x1-x0)/n;for(let i=0;i<n;i++)winY(c,x0+step*(i+.5),y,z0,z1,Math.min(step*.6,.75),o)}
function winRowX(c,x,y0,y1,z0,z1,n,o){const step=(y1-y0)/n;for(let i=0;i<n;i++)winX(c,x,y0+step*(i+.5),z0,z1,Math.min(step*.6,.75),o)}
function doorY(c,xc,y,w,h,col,o){o=o||{};const x0=xc-w/2,x1=xc+w/2;ipoly(c,[IP(x0-.08,y,0),IP(x1+.08,y,0),IP(x1+.08,y,h+4),IP(x0-.08,y,h+4)],o.frame||'#f4efe6',shade(o.frame||'#f4efe6',-.45),.6);
  const g=vgrad(c,IP(x0,y,h),IP(x0,y,0),shade(col,.15),shade(col,-.15));ipoly(c,[IP(x0,y,0),IP(x1,y,0),IP(x1,y,h),IP(x0,y,h)],g,shade(col,-.45),.6);
  if(o.glass){ipoly(c,[IP(x0+w*.1,y,4),IP(x1-w*.1,y,4),IP(x1-w*.1,y,h-3),IP(x0+w*.1,y,h-3)],'rgba(190,230,255,.85)');c.strokeStyle='#fff';const a=IP(xc,y,2),b=IP(xc,y,h);c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1]);c.stroke()}
  else{c.strokeStyle=shade(col,-.35);c.lineWidth=.6;ipoly(c,[IP(x0+w*.15,y,h*.55),IP(x1-w*.15,y,h*.55),IP(x1-w*.15,y,h*.88),IP(x0+w*.15,y,h*.88)],null,shade(col,-.35),.6);const k=IP(x1-w*.18,y,h*.45);c.fillStyle='#f2c230';c.beginPath();c.arc(k[0],k[1],1.4,0,TAU);c.fill()}
  ipoly(c,[IP(x0-.2,y,0),IP(x1+.2,y,0),IP(x1+.2,y+.35,0),IP(x0-.2,y+.35,0)],'#cfc5b6',shade('#cfc5b6',-.3),.5)}
function doorX(c,x,yc,w,h,col,o){o=o||{};const y0=yc-w/2,y1=yc+w/2;ipoly(c,[IP(x,y0-.08,0),IP(x,y1+.08,0),IP(x,y1+.08,h+4),IP(x,y0-.08,h+4)],shade(o.frame||'#f4efe6',-.12));const g=vgrad(c,IP(x,y0,h),IP(x,y0,0),shade(col,0),shade(col,-.28));ipoly(c,[IP(x,y0,0),IP(x,y1,0),IP(x,y1,h),IP(x,y0,h)],g,shade(col,-.5),.6);
  if(o.glass){ipoly(c,[IP(x,y0+w*.1,4),IP(x,y1-w*.1,4),IP(x,y1-w*.1,h-3),IP(x,y0+w*.1,h-3)],'rgba(170,215,245,.85)')}}
function onFace(c,face,x,y,z,fn){const p=IP(x,y,z);c.save();c.translate(p[0],p[1]);if(face==='y')c.transform(1,.5,0,1,0,0);else c.transform(1,-.5,0,1,0,0);fn();c.restore()}
function signY(c,xc,y,z,txt,bg,fg,size,face){face=face||'y';onFace(c,face,face==='y'?xc:y,face==='y'?y:xc,z,()=>{c.font=`900 ${size||9}px Nunito,sans-serif`;const w=c.measureText(txt).width+10,h=(size||9)+6;const p=new Path2D();rrp(p,-w/2,-h/2,w,h,3);c.fillStyle=bg;c.fill(p);c.strokeStyle=shade(bg,-.45);c.lineWidth=.8;c.stroke(p);c.fillStyle=fg;c.textAlign='center';c.textBaseline='middle';c.fillText(txt,0,.5)})}
// roofs
function roofTex(c,E0,E1,R1,R0,col,kind){c.save();c.beginPath();c.moveTo(E0[0],E0[1]);c.lineTo(E1[0],E1[1]);c.lineTo(R1[0],R1[1]);c.lineTo(R0[0],R0[1]);c.closePath();c.clip();
  const L=(a,b,t)=>[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t];const n=kind==='thatch'?9:7;
  c.lineWidth=kind==='thatch'?1:1.1;c.strokeStyle=shade(col,-.28);for(let i=1;i<n;i++){const t=i/n,a=L(E0,R0,t),b=L(E1,R1,t);c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1]);c.stroke()}
  c.strokeStyle=kind==='thatch'?shade(col,-.2):'rgba(255,255,255,.16)';c.lineWidth=.8;const m=kind==='thatch'?26:14;for(let i=1;i<m;i++){const s=i/m,a=L(E0,E1,s),b=L(R0,R1,s);c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1]);c.stroke()}
  const g=vgrad(c,L(E0,E1,.5),L(R0,R1,.5),'rgba(0,0,0,.08)','rgba(255,255,255,.14)');c.fillStyle=g;c.fillRect(-1e4,-1e4,2e4,2e4);c.restore()}
function roofPlane(c,pts,col,kind){ipoly(c,pts,col,shade(col,-.5),1);roofTex(c,pts[0],pts[1],pts[2],pts[3]||pts[2],col,kind)}
function hipRoof(c,x,y,z,w,d,rh,o,col,kind){const ex0=x-o,ey0=y-o,ex1=x+w+o,ey1=y+d+o;let r0,r1;
  if(w>=d){const m=(d+2*o)/2;r0=[ex0+m,ey0+m];r1=[ex1-m,ey0+m]}else{const m=(w+2*o)/2;r0=[ex0+m,ey0+m];r1=[ex0+m,ey1-m]}
  const E=(a,b)=>IP(a,b,z),Rr=p=>IP(p[0],p[1],z+rh);
  ipoly(c,[E(ex0,ey0),E(ex1,ey0),E(ex1,ey1),E(ex0,ey1)],'rgba(30,20,40,.25)');
  if(w>=d){roofPlane(c,[E(ex0,ey0),E(ex1,ey0),Rr(r1),Rr(r0)],shade(col,-.24),kind);roofPlane(c,[E(ex0,ey0),E(ex0,ey1),Rr(r0),Rr(r0)],shade(col,-.04),kind);roofPlane(c,[E(ex1,ey1),E(ex1,ey0),Rr(r1),Rr(r1)],shade(col,-.18),kind);roofPlane(c,[E(ex0,ey1),E(ex1,ey1),Rr(r1),Rr(r0)],shade(col,.06),kind)}
  else{roofPlane(c,[E(ex0,ey0),E(ex0,ey1),Rr(r1),Rr(r0)],shade(col,-.04),kind);roofPlane(c,[E(ex0,ey0),E(ex1,ey0),Rr(r0),Rr(r0)],shade(col,-.24),kind);roofPlane(c,[E(ex1,ey0),E(ex1,ey1),Rr(r1),Rr(r0)],shade(col,-.18),kind);roofPlane(c,[E(ex0,ey1),E(ex1,ey1),Rr(r1),Rr(r1)],shade(col,.06),kind)}
  // fascia + ridge cap
  ipoly(c,[E(ex0,ey1),E(ex1,ey1),IP(ex1,ey1,z-4),IP(ex0,ey1,z-4)],shade(col,-.35));ipoly(c,[E(ex1,ey0),E(ex1,ey1),IP(ex1,ey1,z-4),IP(ex1,ey0,z-4)],shade(col,-.48));
  c.strokeStyle=shade(col,.35);c.lineWidth=2;const a=Rr(r0),b=Rr(r1);c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1]);c.stroke();return[a,b]}
function gableRoof(c,x,y,z,w,d,rh,o,col,axis,gcol,kind){const ex0=x-o,ey0=y-o,ex1=x+w+o,ey1=y+d+o;
  if(axis==='x'){const ym=y+d/2;roofPlane(c,[IP(ex0,ey0,z),IP(ex1,ey0,z),IP(ex1,ym,z+rh),IP(ex0,ym,z+rh)],shade(col,-.24),kind);
    ipoly(c,[IP(x+w,y,z),IP(x+w,y+d,z),IP(x+w,ym,z+rh*(d/(d+2*o)))],shade(gcol,-.16),shade(gcol,-.5),.8);
    roofPlane(c,[IP(ex0,ey1,z),IP(ex1,ey1,z),IP(ex1,ym,z+rh),IP(ex0,ym,z+rh)],shade(col,.06),kind);
    c.strokeStyle=shade(col,-.45);c.lineWidth=2.4;const a=IP(ex1,ey0,z),m=IP(ex1,ym,z+rh),b=IP(ex1,ey1,z);c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(m[0],m[1]);c.lineTo(b[0],b[1]);c.stroke();
    ipoly(c,[IP(ex0,ey1,z),IP(ex1,ey1,z),IP(ex1,ey1,z-4),IP(ex0,ey1,z-4)],shade(col,-.35));c.strokeStyle=shade(col,.35);c.lineWidth=2;const r0=IP(ex0,ym,z+rh);c.beginPath();c.moveTo(r0[0],r0[1]);c.lineTo(m[0],m[1]);c.stroke();return m}
  const xm=x+w/2;roofPlane(c,[IP(ex0,ey0,z),IP(ex0,ey1,z),IP(xm,ey1,z+rh),IP(xm,ey0,z+rh)],shade(col,-.04),kind);
  ipoly(c,[IP(x,y+d,z),IP(x+w,y+d,z),IP(xm,y+d,z+rh*(w/(w+2*o)))],gcol,shade(gcol,-.5),.8);
  roofPlane(c,[IP(ex1,ey0,z),IP(ex1,ey1,z),IP(xm,ey1,z+rh),IP(xm,ey0,z+rh)],shade(col,-.18),kind);
  c.strokeStyle=shade(col,-.4);c.lineWidth=2.4;const a=IP(ex0,ey1,z),m=IP(xm,ey1,z+rh),b=IP(ex1,ey1,z);c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(m[0],m[1]);c.lineTo(b[0],b[1]);c.stroke();
  ipoly(c,[IP(ex1,ey0,z),IP(ex1,ey1,z),IP(ex1,ey1,z-4),IP(ex1,ey0,z-4)],shade(col,-.48));c.strokeStyle=shade(col,.35);c.lineWidth=2;const r0=IP(xm,ey0,z+rh);c.beginPath();c.moveTo(r0[0],r0[1]);c.lineTo(m[0],m[1]);c.stroke();return m}
function flatRoof(c,x,y,z,w,d,col,par){topF(c,x,y,w,d,z,col,shade(col,-.4));if(par){const pc=par;box(c,x,y,z,w,.15,6,pc);box(c,x,y,z,.15,d,6,pc);box(c,x,y+d-.15,z,w,.15,6,pc);box(c,x+w-.15,y,z,.15,d,6,pc)}}
function isoEll(cx,cy,r,z,n){const o=[];n=n||36;for(let i=0;i<n;i++){const a=i/n*TAU;o.push(IP(cx+Math.cos(a)*r,cy+Math.sin(a)*r,z))}return o}
function isoEll2(cx,cy,rx,ry,z,n){const o=[];n=n||48;for(let i=0;i<n;i++){const a=i/n*TAU;o.push(IP(cx+Math.cos(a)*rx,cy+Math.sin(a)*ry,z))}return o}
function cyl(c,cx,cy,r,z0,z1,col,o){o=o||{};const b=isoEll(cx,cy,r,z0),t=isoEll(cx,cy,r,z1);const L=IP(cx,cy,0);const sx=r*TS*Math.SQRT2;
  const g=c.createLinearGradient(L[0]-sx,0,L[0]+sx,0);g.addColorStop(0,shade(col,.12));g.addColorStop(.45,shade(col,.02));g.addColorStop(1,shade(col,-.3));
  c.beginPath();const p0=IP(cx-r*Math.SQRT1_2,cy+r*Math.SQRT1_2,z0),p1=IP(cx+r*Math.SQRT1_2,cy-r*Math.SQRT1_2,z0);// silhouette via ellipse halves
  const ex=L[0],ey0=IP(cx,cy,z0)[1],ey1=IP(cx,cy,z1)[1],ry=sx/2;c.moveTo(ex-sx,ey1);c.lineTo(ex-sx,ey0);c.ellipse(ex,ey0,sx,ry,0,Math.PI,0,true);c.lineTo(ex+sx,ey1);c.ellipse(ex,ey1,sx,ry,0,0,Math.PI,true);c.closePath();c.fillStyle=g;c.fill();c.strokeStyle=shade(col,-.5);c.lineWidth=.8;c.stroke();
  if(o.stripes){for(let i=0;i<o.stripes.length;i++){const [za,zb,sc]=o.stripes[i];const ya=IP(cx,cy,za)[1],yb=IP(cx,cy,zb)[1];c.save();c.beginPath();c.moveTo(ex-sx,yb);c.lineTo(ex-sx,ya);c.ellipse(ex,ya,sx,ry,0,Math.PI,0,true);c.lineTo(ex+sx,yb);c.ellipse(ex,yb,sx,ry,0,0,Math.PI,true);c.closePath();const g2=c.createLinearGradient(ex-sx,0,ex+sx,0);g2.addColorStop(0,shade(sc,.1));g2.addColorStop(1,shade(sc,-.3));c.fillStyle=g2;c.fill();c.restore()}}
  if(!o.notop){c.beginPath();c.ellipse(ex,ey1,sx,ry,0,0,TAU);c.fillStyle=o.top||shade(col,.18);c.fill();c.strokeStyle=shade(col,-.4);c.stroke()}}
function dome(c,cx,cy,r,z,h,col){const L=IP(cx,cy,z),sx=r*TS*Math.SQRT2,ry=sx/2;const g=c.createRadialGradient(L[0]-sx*.35,L[1]-h*.6,2,L[0],L[1]-h*.2,sx*1.2);g.addColorStop(0,shade(col,.55));g.addColorStop(.5,col);g.addColorStop(1,shade(col,-.35));c.beginPath();c.ellipse(L[0],L[1],sx,ry,0,0,Math.PI);c.ellipse(L[0],L[1],sx,h,0,Math.PI,TAU);c.closePath();c.fillStyle=g;c.fill();c.strokeStyle=shade(col,-.45);c.lineWidth=.8;c.stroke()}
function awningY(c,x0,x1,y,z,dep,h,cols){const n=Math.max(4,Math.round((x1-x0)*4));const st=(x1-x0)/n;for(let i=0;i<n;i++){const a=x0+i*st,b=a+st;ipoly(c,[IP(a,y,z),IP(b,y,z),IP(b,y+dep,z-h),IP(a,y+dep,z-h)],i%2?cols[1]:cols[0],shade(cols[0],-.45),.4);
  const p=IP(a,y+dep,z-h),q=IP(b,y+dep,z-h);c.fillStyle=i%2?cols[1]:cols[0];c.beginPath();c.moveTo(p[0],p[1]);c.lineTo(q[0],q[1]);c.quadraticCurveTo((p[0]+q[0])/2,(p[1]+q[1])/2+6,p[0],p[1]);c.fill()}}
function awningX(c,x,y0,y1,z,dep,h,cols){const n=Math.max(4,Math.round((y1-y0)*4));const st=(y1-y0)/n;for(let i=0;i<n;i++){const a=y0+i*st,b=a+st;ipoly(c,[IP(x,a,z),IP(x,b,z),IP(x+dep,b,z-h),IP(x+dep,a,z-h)],shade(i%2?cols[1]:cols[0],-.12),shade(cols[0],-.45),.4)}}
function post(c,x,y,z0,z1,col,w){w=w||.12;box(c,x-w/2,y-w/2,z0,w,w,z1-z0,col||'#8a5a33',{st:shade(col||'#8a5a33',-.5)})}
function flagJG(c,x0,y0,w,t){const h=w*.5,st=h/14;c.save();c.translate(x0,y0);const wave=i=>Math.sin(t+i*.4)*1.5;for(let i=0;i<14;i++){c.fillStyle=i%2?'#ffffff':'#cc0001';c.beginPath();for(let j=0;j<=8;j++){const xx=j/8*w;c.lineTo(xx,i*st+wave(j))}for(let j=8;j>=0;j--){const xx=j/8*w;c.lineTo(xx,(i+1)*st+wave(j)+.3)}c.fill()}
  c.fillStyle='#010066';c.beginPath();for(let j=0;j<=4;j++)c.lineTo(j/8*w,wave(j));for(let j=4;j>=0;j--)c.lineTo(j/8*w,st*8+wave(j));c.fill();c.fillStyle='#ffcc00';c.beginPath();c.arc(w*.16,st*4+wave(1),st*2.6,0,TAU);c.fill();c.fillStyle='#010066';c.beginPath();c.arc(w*.19,st*4+wave(1),st*2.2,0,TAU);c.fill();c.fillStyle='#ffcc00';c.beginPath();for(let k=0;k<14;k++){const a=k/14*TAU,r=k%2?st*.8:st*1.9;c.lineTo(w*.33+Math.cos(a)*r,st*4+wave(2)+Math.sin(a)*r)}c.fill();c.restore()}

// ---------------- BUILDING ART ----------------
const BART={};
BART.house=(c,b)=>{const {x,y,w,h}=b,v=b.v||0,wood=['#c98b55','#b77a4a','#d49a62'][v%3],pl=['#fbf1dc','#f4ecff','#eef8f2'][v%3];
  box(c,x-.1,y-.1,0,w+.2,h+.2,6,'#b9a58a');
  box(c,x,y,6,w,h,34,wood);planks(c,x,x+w,y+h,8,40,wood,'y');planks(c,y,y+h,x+w,8,40,shade(wood,-.15),'x');
  box(c,x-.12,y-.12,40,w+.24,h+.24,3,shade(wood,-.3));
  box(c,x,y,43,w,h,30,pl);
  doorY(c,x+w*.5,y+h,.55,26,'#7a4a2a');winY(c,x+w*.2,y+h,16,32,.42,{shut:'#3f7a4a'});winY(c,x+w*.8,y+h,16,32,.42,{shut:'#3f7a4a'});
  winRowX(c,x+w,y,y+h,16,32,2,{shut:'#3f7a4a'});
  winRowY(c,x,x+w,y+h,50,66,3,{box:1,frame:'#ffffff'});winRowX(c,x+w,y,y+h,50,66,2,{box:1});
  // balcony
  box(c,x+.4,y+h,40,w-.8,.45,3,'#8a5a33');for(let i=0;i<=8;i++){const xx=x+.4+(w-.8)*i/8;const a=IP(xx,y+h+.45,43),bb=IP(xx,y+h+.45,52);c.strokeStyle='#6b4426';c.lineWidth=1.2;c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(bb[0],bb[1]);c.stroke()}
  {const a=IP(x+.4,y+h+.45,52),bb=IP(x+w-.4,y+h+.45,52);c.strokeStyle='#8a5a33';c.lineWidth=2;c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(bb[0],bb[1]);c.stroke()}
  if(v===1)gableRoof(c,x,y,73,w,h,34,.32,b.c,'x',pl);else hipRoof(c,x,y,73,w,h,34,.32,b.c);
  box(c,x+w*.7,y+.3,90,.4,.4,26,'#b9a58a');};
BART.myhome=(c,b)=>{BART.house(c,Object.assign({},b,{v:0}));signY(c,b.x+b.w*.5,b.y+b.h,38,'RUMAH ANDA','#6a3fd0','#fff',8);
  post(c,b.x+b.w+.4,b.y+b.h+.6,0,14,'#6b4426',.1);box(c,b.x+b.w+.25,b.y+b.h+.45,14,.32,.3,7,'#e5484d')};
BART.apartment=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,170,'#f4e6d0');for(let f=0;f<5;f++){const z=10+f*32;winRowY(c,x,x+w,y+h,z,z+18,3,{});winRowX(c,x+w,y,y+h,z,z+18,3,{});box(c,x,y+h,z-3,w,.25,3,'#c8643a');box(c,x+w,y,z-3,.25,h,3,'#c8643a')}
  flatRoof(c,x,y,170,w,h,'#d8c8b0','#c8b8a0');cyl(c,x+w*.7,y+h*.4,.45,170,196,'#9aa6b8');signY(c,x+w/2,y+h,6,'APARTMEN SERI','#fff','#6a3fd0',8)};
BART.kampung=(c,b)=>{const {x,y,w,h}=b,rc=b.kind==='ranger'?'#3a7a3a':b.kind==='balai'?'#9a4a2a':'#8b5a2b';
  for(const [px,py] of [[x+.15,y+.15],[x+w-.15,y+.15],[x+.15,y+h-.15],[x+w-.15,y+h-.15],[x+w/2,y+h-.15]])post(c,px,py,0,16,'#5a3a20',.16);
  box(c,x-.05,y-.05,16,w+.1,h+.1,4,'#8a5a33');box(c,x+.1,y+.1,20,w-.2,h-.2,30,'#d6a26a');
  {const cc='#b8844e';c.strokeStyle=cc;c.lineWidth=.8;for(let i=1;i<w*6;i++){const xx=x+.1+i/6;const a=IP(xx,y+h-.1,20),q=IP(xx,y+h-.1,50);c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(q[0],q[1]);c.stroke()}}
  winY(c,x+w*.3,y+h-.1,28,42,.4,{frame:'#6b4426',cross:false});winX(c,x+w-.1,y+h*.5,28,42,.4,{frame:'#6b4426',cross:false});doorY(c,x+w*.68,y+h-.1,.35,24,'#5a3a20',{frame:'#8a5a33'});
  for(let s=0;s<4;s++)box(c,x+w*.55,y+h+.1+s*.18,16-s*4,.35,.18,3,'#8a5a33');
  const m=gableRoof(c,x,y,50,w,h,b.kind==='balai'?46:40,.35,rc,'x','#d6a26a','thatch');c.strokeStyle='#5a2f18';c.lineWidth=2.4;c.beginPath();c.moveTo(m[0]-6,m[1]-9);c.lineTo(m[0]+6,m[1]+2);c.moveTo(m[0]+6,m[1]-9);c.lineTo(m[0]-6,m[1]+2);c.stroke();
  if(b.label)signY(c,x+w*.5,y+h-.1,58,b.label,b.kind==='ranger'?'#2a6a3a':'#8b4a2b','#fff',7)};
BART.balai=BART.kampung;BART.ranger=BART.kampung;
BART.pasar=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,4,'#d8c8b0');
  for(let i=0;i<=4;i++)for(const yy of [y+.15,y+h-.15]){if(yy===y+.15&&i>0&&i<4)continue;post(c,x+.15+(w-.3)*i/4,yy,4,44,'#7a4a2a',.16)}for(const xx of [x+.15,x+w-.15])post(c,xx,y+h/2,4,44,'#7a4a2a',.16);
  for(let r=0;r<2;r++)for(let i=0;i<3;i++){const tx=x+.6+i*1.1,ty=y+.7+r*1.2;box(c,tx,ty,4,.8,.5,14,'#c8925a');for(let k=0;k<5;k++){const p=IP(tx+.1+k*.15,ty+.25,19);c.fillStyle=['#e5484d','#f2c230','#38b84a','#ff8c42','#8c5cf2'][(k+i+r)%5];c.beginPath();c.arc(p[0],p[1],3,0,TAU);c.fill()}}
  hipRoof(c,x,y,44,w,h,40,.4,'#c8503a');signY(c,x+w*.5,y+h+.4,36,'PASAR TANI','#8a3a1a','#ffe08a',9)};
BART.pasarmalam=(c,b)=>{const {x,y,w,h}=b;const cols=[['#e5484d','#fff'],['#3a86ff','#fff'],['#38b84a','#fff']];for(let i=0;i<3;i++){const sx=x+i*w/3;box(c,sx+.1,y+.5,0,w/3-.2,h-1,16,'#c8925a');for(const [px,py] of [[sx+.15,y+.4],[sx+w/3-.15,y+.4],[sx+.15,y+h-.4],[sx+w/3-.15,y+h-.4]])post(c,px,py,0,40,'#6b4426',.1);
    hipRoof(c,sx+.05,y+.3,40,w/3-.1,h-.6,16,.15,cols[i][0]);for(let k=0;k<4;k++){const p=IP(sx+.3+k*.2,y+h-.6,18);c.fillStyle=['#ffd23f','#e5484d','#38b84a','#ff8c42'][k];c.beginPath();c.arc(p[0],p[1],3,0,TAU);c.fill()}}
  c.strokeStyle='#444';c.lineWidth=1;const a=IP(x,y+h,46),bb=IP(x+w,y+h,46);c.beginPath();c.moveTo(a[0],a[1]);c.quadraticCurveTo((a[0]+bb[0])/2,(a[1]+bb[1])/2+10,bb[0],bb[1]);c.stroke();for(let i=0;i<8;i++){const t=i/7,p=[a[0]+(bb[0]-a[0])*t,a[1]+(bb[1]-a[1])*t+Math.sin(t*Math.PI)*8];c.fillStyle='#ffe066';c.shadowColor='#ffd23f';c.shadowBlur=6;c.beginPath();c.arc(p[0],p[1],2.6,0,TAU);c.fill();c.shadowBlur=0}
  signY(c,x+w/2,y+h,58,'PASAR MALAM','#ff8c42','#fff',8)};
BART.bandar=(c,b)=>{const {x,y,w,h}=b;box(c,x-.1,y-.1,0,w+.2,h+.2,5,'#b9a58a');box(c,x,y,5,w,h,38,'#d49a62');planks(c,x,x+w,y+h,8,42,'#d49a62','y');planks(c,y,y+h,x+w,8,42,'#b88050','x');
  doorY(c,x+w*.5,y+h,.7,28,'#6b4426',{glass:1});winY(c,x+w*.2,y+h,14,34,.6,{frame:'#fff'});winY(c,x+w*.82,y+h,14,34,.6,{frame:'#fff'});winRowX(c,x+w,y,y+h,14,34,2,{});
  awningY(c,x+.1,x+w-.1,y+h,44,.6,12,['#e5484d','#ffffff']);box(c,x,y,44,w,h,30,'#fbf1dc');winRowY(c,x,x+w,y+h,52,68,4,{shut:'#3d6fb6',box:1});winRowX(c,x+w,y,y+h,52,68,3,{shut:'#3d6fb6'});
  hipRoof(c,x,y,74,w,h,38,.35,b.c||'#3d6fb6');signY(c,x+w*.5,y+h,48,'KEDAI MAMAK','#fff','#c8102e',8)};
BART.medan=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,4,'#e8d8c0');for(const [px,py] of [[x+.2,y+.2],[x+w-.2,y+.2],[x+.2,y+h-.2],[x+w-.2,y+h-.2]])post(c,px,py,4,42,'#6b4426',.15);
  for(let i=0;i<2;i++)for(let j=0;j<2;j++){const tx=x+.8+i*1.3,ty=y+.8+j*1.2;cyl(c,tx,ty,.35,4,14,'#c8925a',{top:'#e8c08a'});for(const [dx,dy] of [[-.45,0],[.45,0],[0,.45]])cyl(c,tx+dx,ty+dy,.12,4,9,'#e5484d')}
  hipRoof(c,x,y,42,w,h,30,.35,'#f29b0c');signY(c,x+w/2,y+h+.35,34,'MEDAN SELERA','#c8102e','#fff',8)};
BART.jetihut=(c,b)=>{const {x,y,w,h}=b;for(const [px,py] of [[x+.1,y+.1],[x+w-.1,y+.1],[x+.1,y+h-.1],[x+w-.1,y+h-.1]])post(c,px,py,0,10,'#5a3a20',.14);box(c,x,y,10,w,h,28,'#d8a878');planks(c,x,x+w,y+h,12,38,'#d8a878','y');planks(c,y,y+h,x+w,12,38,'#c09060','x');doorY(c,x+w*.5,y+h,.45,24,'#6b4426');winX(c,x+w,y+h/2,22,32,.45,{frame:'#fff'});gableRoof(c,x,y,38,w,h,26,.3,'#3a86ff','x','#d8a878');signY(c,x+w/2,y+h,44,'JETI','#3a86ff','#fff',8)};
BART.beachhut=(c,b)=>{const {x,y,w,h}=b;for(const [px,py] of [[x+.15,y+.15],[x+w-.15,y+.15],[x+.15,y+h-.15],[x+w-.15,y+h-.15]])post(c,px,py,0,34,'#8a5a33',.12);box(c,x+.2,y+.2,0,w-.4,h-.4,14,'#e8c890');hipRoof(c,x,y,34,w,h,30,.3,'#d8b070','thatch');signY(c,x+w/2,y+h,24,'PANTAI','#2ec4b6','#fff',8)};
BART.lighthouse=(c,b)=>{const cx=b.x+.5,cy=b.y+.5;cyl(c,cx,cy,.75,0,10,'#8a8478',{top:'#a8a298'});cyl(c,cx,cy,.48,10,170,'#ffffff',{stripes:[[10,40,'#e5484d'],[70,100,'#e5484d'],[130,160,'#e5484d']],notop:1});cyl(c,cx,cy,.62,170,176,'#3a3a4a');
  cyl(c,cx,cy,.36,176,200,'#fff6c0',{top:'#ffe066'});cyl(c,cx,cy,.42,200,206,'#e5484d');const t=IP(cx,cy,206);c.fillStyle='#c8102e';c.beginPath();c.moveTo(t[0]-14,t[1]);c.lineTo(t[0],t[1]-20);c.lineTo(t[0]+14,t[1]);c.fill()};
BART.hospital=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,104,'#f6f9fc');for(let f=0;f<3;f++){const z=12+f*31;box(c,x,y+h,z-2,w,.02,20,'#7fb6e6',{notop:1});winRowY(c,x+.2,x+w-.2,y+h,z,z+17,7,{frame:'#e8f0f8',cross:false});winRowX(c,x+w,y+.2,y+h-.2,z,z+17,5,{frame:'#e8f0f8',cross:false})}
  box(c,x+w*.3,y+h,30,w*.4,.7,6,'#e5484d');post(c,x+w*.32,y+h+.6,0,30,'#ccc',.1);post(c,x+w*.68,y+h+.6,0,30,'#ccc',.1);doorY(c,x+w*.5,y+h,.9,26,'#9fd0ff',{glass:1});
  flatRoof(c,x,y,104,w,h,'#dfe6ee','#e8eef4');{const p=IP(x+w*.45,y+h*.5,104);c.strokeStyle='#e5484d';c.lineWidth=3;c.beginPath();c.ellipse(p[0],p[1],28,14,0,0,TAU);c.stroke();c.fillStyle='#e5484d';c.font='900 16px Nunito';c.textAlign='center';c.textBaseline='middle';c.save();c.translate(p[0],p[1]);c.scale(1,.55);c.fillText('H',0,0);c.restore()}
  box(c,x+w-1.4,y+.5,104,.9,.9,16,'#e8eef4');onFace(c,'y',x+w*.5,y+h,90,()=>{c.fillStyle='#fff';c.fillRect(-26,-9,52,18);c.fillStyle='#e5484d';c.fillRect(-23,-3,8,6);c.fillRect(-21,-6,4,12);c.font='900 9px Nunito';c.fillStyle='#c8102e';c.textBaseline='middle';c.fillText('HOSPITAL',-12,0)});
  onFace(c,'x',x+w,y+h*.5,110,()=>{c.fillStyle='#fff';c.beginPath();c.arc(0,0,13,0,TAU);c.fill();c.fillStyle='#e5484d';c.fillRect(-3.5,-9,7,18);c.fillRect(-9,-3.5,18,7)})};
BART.klinik=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,44,'#ffffff');winRowY(c,x+.2,x+w-.2,y+h,12,32,3,{frame:'#e8f0f8'});winRowX(c,x+w,y,y+h,12,32,2,{});doorY(c,x+w*.5,y+h,.6,26,'#9fd0ff',{glass:1});gableRoof(c,x,y,44,w,h,28,.3,'#4aa3d8','x','#ffffff');
  onFace(c,'y',x+w*.5,y+h,40,()=>{c.fillStyle='#e5484d';c.fillRect(-26,-4,5,10);c.fillRect(-28.5,-1.5,10,5);c.font='900 8px Nunito';c.fillStyle='#c8102e';c.textBaseline='middle';c.fillText('KLINIK',-16,1)})};
BART.gov=(c,b)=>{const {x,y,w,h}=b,wall='#f3e3c3';box(c,x-.15,y-.15,0,w+.3,h+.3,8,'#d8c8a8');box(c,x,y,8,w,h,66,wall);
  for(let i=0;i<6;i++){const xx=x+.4+i*(w-.8)/5;post(c,xx,y+h+.05,8,70,'#fffaf0',.16)}winRowY(c,x+.3,x+w-.3,y+h,18,36,5,{frame:'#fff'});winRowY(c,x+.3,x+w-.3,y+h,46,64,5,{frame:'#fff'});winRowX(c,x+w,y+.2,y+h-.2,18,36,4,{});winRowX(c,x+w,y+.2,y+h-.2,46,64,4,{});
  for(let s=0;s<3;s++)box(c,x+w*.3,y+h+.1+s*.22,8-s*3,w*.4,.24,3,'#e8dcc4');doorY(c,x+w*.5,y+h,.8,30,'#6b4426');
  hipRoof(c,x,y,74,w,h,40,.35,'#c8643a');
  const tx=x+w*.5-.75,ty=y+h*.5-.75;box(c,tx,ty,74,1.5,1.5,70,wall);box(c,tx-.08,ty-.08,144,1.66,1.66,6,'#d8c8a8');
  for(const f of ['y','x']){const p=f==='y'?[tx+.75,ty+1.5]:[tx+1.5,ty+.75];onFace(c,f,p[0],p[1],124,()=>{c.fillStyle='#fffaf0';c.beginPath();c.arc(0,0,10,0,TAU);c.fill();c.strokeStyle='#8a5a33';c.lineWidth=2;c.stroke();c.strokeStyle='#2a1f47';c.lineWidth=1.4;c.beginPath();c.moveTo(0,0);c.lineTo(0,-7);c.moveTo(0,0);c.lineTo(5,2);c.stroke()})}
  winY(c,tx+.75,ty+1.5,90,104,.5,{frame:'#fff'});hipRoof(c,tx,ty,150,1.5,1.5,40,.15,'#c8503a');const tp=IP(tx+.75,ty+.75,190);c.strokeStyle='#888';c.lineWidth=1.4;c.beginPath();c.moveTo(tp[0],tp[1]);c.lineTo(tp[0],tp[1]-22);c.stroke();flagJG(c,tp[0],tp[1]-22,20,1);
  signY(c,x+w*.5,y+h,80,'PEJABAT KERAJAAN','#1f6f8b','#fff',8)};
BART.kerjaya=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,64,'#fff4e0');box(c,x,y+h,26,w,.04,6,'#f29b0c',{notop:1});winRowY(c,x+.2,x+w-.2,y+h,36,56,3,{});winRowX(c,x+w,y,y+h,36,56,3,{});winRowX(c,x+w,y,y+h,8,24,3,{});doorY(c,x+w*.5,y+h,.9,24,'#9fd0ff',{glass:1});flatRoof(c,x,y,64,w,h,'#f2c27a','#f29b0c');signY(c,x+w*.5,y+h,30,'PUSAT KERJAYA','#f29b0c','#fff',8)};
BART.polis=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,48,'#eef3ff');box(c,x,y+h,40,w,.04,8,'#1d2d55',{notop:1});winRowY(c,x+.2,x+w-.2,y+h,14,32,3,{});winRowX(c,x+w,y,y+h,14,32,2,{});doorY(c,x+w*.5,y+h,.6,26,'#1d2d55');hipRoof(c,x,y,48,w,h,26,.3,'#1d2d55');signY(c,x+w*.5,y+h,44,'POLIS','#1d2d55','#fff',8);const p=IP(x+w*.5,y+h*.5,70);c.fillStyle='#3a86ff';c.fillRect(p[0]-7,p[1]-4,7,4);c.fillStyle='#e5484d';c.fillRect(p[0],p[1]-4,7,4)};
BART.bomba=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,54,'#fff0f0');for(let i=0;i<2;i++){const xc=x+w*(i?.72:.3);ipoly(c,[IP(xc-.55,y+h,0),IP(xc+.55,y+h,0),IP(xc+.55,y+h,32),IP(xc-.55,y+h,32)],'#e5484d','#8a1a1a',.8);for(let k=1;k<6;k++){const a=IP(xc-.55,y+h,k*5.5),q=IP(xc+.55,y+h,k*5.5);c.strokeStyle='rgba(255,255,255,.45)';c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(q[0],q[1]);c.stroke()}}
  winRowX(c,x+w,y,y+h,14,32,2,{});box(c,x+w-1,y+.2,54,.8,.8,40,'#e5484d');hipRoof(c,x,y,54,w,h,24,.3,'#c8102e');signY(c,x+w*.5,y+h,44,'BOMBA','#c8102e','#fff',8)};
BART.mall=(c,b)=>{const {x,y,w,h}=b;box(c,x-.1,y-.1,0,w+.2,h+.2,6,'#d8d0e8');box(c,x,y,6,w,h,74,'#f7f2ff');
  for(const [z0,z1] of [[12,36],[46,70]]){box(c,x,y+h,z0,w,.02,z1-z0,'#8fc3f0',{notop:1});box(c,x+w,y,z0,.02,h,z1-z0,'#6aa0d8',{notop:1});for(let i=1;i<w*2;i++){const a=IP(x+i/2,y+h,z0),q=IP(x+i/2,y+h,z1);c.strokeStyle='#fff';c.lineWidth=1;c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(q[0],q[1]);c.stroke()}for(let i=1;i<h*2;i++){const a=IP(x+w,y+i/2,z0),q=IP(x+w,y+i/2,z1);c.strokeStyle='#e8e0f8';c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(q[0],q[1]);c.stroke()}}
  box(c,x,y+h,38,w,.03,6,'#8c5cf2',{notop:1});box(c,x+w,y,38,.03,h,6,'#7a4ad8',{notop:1});
  box(c,x+w*.3,y+h,34,w*.4,.8,4,'#c8b8f0');doorY(c,x+w*.5,y+h,1.1,28,'#a8d0ff',{glass:1});
  hipRoof(c,x,y,80,w,h,44,.35,'#8a5ad8');{const a=IP(x+1.4,y+h*.5,104),q=IP(x+w-1.4,y+h*.5,104);c.strokeStyle='#bfe6ff';c.lineWidth=9;c.lineCap='round';c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(q[0],q[1]);c.stroke();c.strokeStyle='#ffffff';c.lineWidth=2;c.stroke();c.lineCap='butt'}
  onFace(c,'y',x+w*.18,y+h,58,()=>{c.fillStyle='#ff5ea8';const p=new Path2D();rrp(p,-9,-8,18,16,3);c.fill(p);c.strokeStyle='#fff';c.lineWidth=1.6;c.beginPath();c.arc(0,-8,4.5,Math.PI,TAU);c.stroke()});
  signY(c,x+w*.55,y+h,90,'ASIA MALL','#6a3fd0','#fff',11)};
BART.cinema=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,60,'#3a1f2b');box(c,x,y+h,40,w,.05,14,'#c8102e',{notop:1});for(let i=0;i<14;i++){const p=IP(x+.1+i*(w-.2)/13,y+h+.05,41);c.fillStyle=i%2?'#ffd23f':'#fff6c0';c.beginPath();c.arc(p[0],p[1],1.8,0,TAU);c.fill();const q=IP(x+.1+i*(w-.2)/13,y+h+.05,53);c.beginPath();c.arc(q[0],q[1],1.8,0,TAU);c.fill()}
  for(let i=0;i<2;i++){const xc=x+w*(i?.78:.22);ipoly(c,[IP(xc-.35,y+h,10),IP(xc+.35,y+h,10),IP(xc+.35,y+h,34),IP(xc-.35,y+h,34)],['#3a86ff','#ff5ea8'][i],'#fff',.8)}doorY(c,x+w*.5,y+h,.7,26,'#5a1a24');winRowX(c,x+w,y,y+h,24,44,2,{lit:1});flatRoof(c,x,y,60,w,h,'#4a2a3a','#c8102e');signY(c,x+w*.5,y+h,47,'PAWAGAM','#c8102e','#ffd23f',9)};
BART.bank=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,80,'#6aa0d8');for(let f=0;f<4;f++){box(c,x,y+h,f*20+18,w,.03,2,'#fff',{notop:1});box(c,x+w,y,f*20+18,.03,h,2,'#e8eef8',{notop:1})}doorY(c,x+w*.5,y+h,.6,22,'#bfe3ff',{glass:1});flatRoof(c,x,y,80,w,h,'#4a7ab0','#3a6aa0');signY(c,x+w*.5,y+h,30,'BANK','#1f4fb0','#fff',8)};
BART.gazebo=(c,b)=>{const {x,y,w,h}=b;ipoly(c,isoEll(x+w/2,y+h/2,1.05,0),'#d8c8a8','#a8987a');ipoly(c,isoEll(x+w/2,y+h/2,1.05,5),'#e8d8b8','#a8987a');for(let i=0;i<6;i++){const a=i/6*TAU+.5;post(c,x+w/2+Math.cos(a)*.82,y+h/2+Math.sin(a)*.82,5,40,'#f4efe6',.11)}
  hipRoof(c,x+.1,y+.1,40,w-.2,h-.2,36,.25,'#d9583f');const t=IP(x+w/2,y+h/2,76);c.fillStyle='#f2c230';c.beginPath();c.arc(t[0],t[1]-3,3,0,TAU);c.fill()};
BART.port=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,56,'#c8d4e0');c.strokeStyle='rgba(60,80,100,.3)';c.lineWidth=1;for(let i=1;i<w*5;i++){const a=IP(x+i/5,y+h,0),q=IP(x+i/5,y+h,56);c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(q[0],q[1]);c.stroke()}
  ipoly(c,[IP(x+w*.25,y+h,0),IP(x+w*.6,y+h,0),IP(x+w*.6,y+h,38),IP(x+w*.25,y+h,38)],'#7a8a9a','#4a5a6a');doorY(c,x+w*.82,y+h,.5,24,'#3a5a7a');winRowX(c,x+w,y,y+h,30,44,3,{});gableRoof(c,x,y,56,w,h,30,.25,'#4a7ab0','x','#c8d4e0');signY(c,x+w*.42,y+h,46,'PELABUHAN','#1f6f8b','#fff',8)};
BART.factory=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,60,'#b8c0cc');winRowY(c,x,x+w,y+h,30,46,5,{frame:'#d8dee8'});winRowX(c,x+w,y,y+h,30,46,4,{frame:'#d8dee8'});ipoly(c,[IP(x+w*.2,y+h,0),IP(x+w*.5,y+h,0),IP(x+w*.5,y+h,24),IP(x+w*.2,y+h,24)],'#6a7a8a');
  for(let i=0;i<w;i++)gableRoof(c,x+i,y,60,1,h,16,.05,'#8a96a8','y','#b8c0cc');cyl(c,x+.7,y+.7,.32,60,170,'#d8d0c8',{stripes:[[150,170,'#e5484d']]});cyl(c,x+1.6,y+.6,.26,60,140,'#d8d0c8',{stripes:[[124,140,'#e5484d']]});
  box(c,x+w,y+h*.3,10,.6,.2,6,'#8a96a8');cyl(c,x+w+.9,y+h*.4,.5,0,70,'#c8d0d8')};
BART.school=(c,b)=>{const {x,y,w,h}=b;box(c,x-.1,y-.1,0,w+.2,h+.2,6,'#d8c8b0');box(c,x,y,6,w,h,64,'#fdf3d8');winRowY(c,x+.2,x+w-.2,y+h,14,30,5,{frame:'#fff'});winRowY(c,x+.2,x+w-.2,y+h,42,60,5,{frame:'#fff'});winRowX(c,x+w,y,y+h,14,30,3,{});winRowX(c,x+w,y,y+h,42,60,3,{});
  box(c,x,y+h,36,w,.05,4,'#7a4fd8',{notop:1});doorY(c,x+w*.5,y+h,.7,26,'#6a3fd0');gableRoof(c,x,y,70,w,h,40,.35,'#7a4fd8','x','#fdf3d8');
  onFace(c,'x',x+w,y+h*.5,92,()=>{c.fillStyle='#2a1f47';c.beginPath();c.moveTo(-10,0);c.lineTo(0,-5);c.lineTo(10,0);c.lineTo(0,5);c.fill();c.fillRect(-5,1,10,6)});signY(c,x+w*.5,y+h,36,'SMK KOTA KITA','#7a4fd8','#fff',8)};
BART.uni=(c,b)=>{const {x,y,w,h}=b;box(c,x-.15,y-.15,0,w+.3,h+.3,8,'#d8c8a8');box(c,x,y,8,w,h,74,'#f4ead6');for(let i=0;i<8;i++)post(c,x+.3+i*(w-.6)/7,y+h+.06,8,72,'#fffaf0',.15);winRowY(c,x+.3,x+w-.3,y+h,46,66,6,{frame:'#fff'});winRowX(c,x+w,y,y+h,18,36,4,{});winRowX(c,x+w,y,y+h,46,66,4,{});doorY(c,x+w*.5,y+h,.9,30,'#6b4a2b');
  flatRoof(c,x,y,82,w,h,'#d8c8a0','#c8b890');cyl(c,x+w/2,y+h/2,1,82,100,'#f4ead6');dome(c,x+w/2,y+h/2,1,100,44,'#3a6ab0');const t=IP(x+w/2,y+h/2,144);c.fillStyle='#f2c230';c.fillRect(t[0]-1.5,t[1]-12,3,12);signY(c,x+w*.5,y+h,78,'UNIVERSITI KOTA KITA','#1f3a6b','#fff',8)};
BART.library=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,50,'#f6efe2');for(let i=0;i<5;i++)post(c,x+.3+i*(w-.6)/4,y+h+.05,0,46,'#fffaf0',.14);winRowX(c,x+w,y,y+h,14,36,2,{});doorY(c,x+w*.5,y+h,.6,28,'#6b4426');gableRoof(c,x,y,50,w,h,28,.3,'#7a5ac8','x','#f6efe2');signY(c,x+w*.5,y+h,42,'PERPUSTAKAAN','#7a5ac8','#fff',7)};
BART.stadium=(c,b)=>{const {x,y,w,h}=b,cx=x+w/2,cy=y+h/2,rx=w/2,ry=h/2;
  const ring=(sx,sy,z)=>isoEll2(cx,cy,rx*sx,ry*sy,z,60);const o0=ring(1,1,0),o1=ring(1,1,34);
  ipoly(c,o0,'#6a5a8a');// wall band (front half)
  c.beginPath();const n=o0.length;for(let i=0;i<n;i++){const p=o1[i];i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1])}c.closePath();
  {const g=vgrad(c,[0,IP(cx,cy+ry,34)[1]],[0,IP(cx,cy+ry,0)[1]],'#9a8ac8','#5a4a7a');ipoly(c,o0,g);}
  // stands
  ipoly(c,o1,'#d8d4e8','#5a4a7a',1.2);const cols=['#e5484d','#3a86ff','#f2c230','#38b84a'];for(let r=0;r<4;r++){ipoly(c,ring(.96-r*.07,.95-r*.07,32-r*4),cols[r])}
  for(let i=0;i<24;i++){const a=i/24*TAU,p=IP(cx+Math.cos(a)*rx*.97,cy+Math.sin(a)*ry*.97,33),q=IP(cx+Math.cos(a)*rx*.69,cy+Math.sin(a)*ry*.69,18);c.strokeStyle='rgba(255,255,255,.5)';c.lineWidth=1;c.beginPath();c.moveTo(p[0],p[1]);c.lineTo(q[0],q[1]);c.stroke()}
  ipoly(c,ring(.68,.66,14),'#c8643a');ipoly(c,ring(.56,.52,14),'#4fb84a');
  const pr=[IP(cx-rx*.42,cy-ry*.3,14),IP(cx+rx*.42,cy-ry*.3,14),IP(cx+rx*.42,cy+ry*.3,14),IP(cx-rx*.42,cy+ry*.3,14)];ipoly(c,pr,'#5cc84f','#ffffff',1.4);{const a=IP(cx,cy-ry*.3,14),q=IP(cx,cy+ry*.3,14);c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(q[0],q[1]);c.stroke();ipoly(c,isoEll(cx,cy,.45,14,24),null,'#fff',1.2)}
  for(const [dx,dy] of [[-1,-1],[1,-1],[1,1],[-1,1]]){const px=cx+dx*rx*.85,py=cy+dy*ry*.85;post(c,px,py,30,100,'#9aa4b2',.12);const t=IP(px,py,100);c.fillStyle='#e8eef8';c.fillRect(t[0]-8,t[1]-8,16,8);c.fillStyle='#fff6c0';c.fillRect(t[0]-6,t[1]-6,12,4)}
  signY(c,cx,y+h,20,'STADIUM KOTA KITA','#e5484d','#fff',8)};
BART.lrt=(c,b)=>{const {x,y,w,h}=b;for(let i=0;i<=3;i++)for(const yy of [y+.4,y+h-.4])post(c,x+.3+i*(w-.6)/3,yy,0,40,'#c8c0d8',.3);box(c,x-.2,y,40,w+.4,h,8,'#d8d0e8');box(c,x-1.5,y+h*.35,38,w+3,1,4,'#a8a0b8');
  box(c,x+.2,y+h*.38,48,w-.4,.9,24,'#ffffff',{l:'#f4f0ff'});for(let i=0;i<5;i++)winY(c,x+.6+i*(w-1.2)/4,y+h*.38+.9,56,66,.4,{frame:'#6a3fd0',cross:false});box(c,x+.2,y+h*.38+.9,50,w-.4,.02,3,'#6a3fd0',{notop:1});
  // arched canopy (barrel along x)
  const seg=10,z0=72,rr=h/2+.2;for(let i=0;i<seg;i++){const a0=Math.PI*i/seg,a1=Math.PI*(i+1)/seg;const y0=y+h/2-Math.cos(a0)*rr,y1=y+h/2-Math.cos(a1)*rr,zA=z0+Math.sin(a0)*26,zB=z0+Math.sin(a1)*26;ipoly(c,[IP(x-.3,y0,zA),IP(x+w+.3,y0,zA),IP(x+w+.3,y1,zB),IP(x-.3,y1,zB)],i<seg/2?'#9a86e8':'#b8a8ff','#6a3fd0',.6)}
  for(let s=0;s<6;s++)box(c,x+w*.55,y+h+.1+s*.3,40-s*7,.6,.3,3,'#c8c0d8');signY(c,x+w*.5,y+h,30,'LRT / MRT','#6a3fd0','#fff',9)};
BART.keretapi=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,60,'#fffaf0');for(let i=0;i<5;i++){const xc=x+.5+i*(w-1)/4;ipoly(c,[IP(xc-.25,y+h,0),IP(xc+.25,y+h,0),IP(xc+.25,y+h,30),IP(xc,y+h,40),IP(xc-.25,y+h,30)],'#9fd0f0','#c8b888',.8)}winRowX(c,x+w,y,y+h,14,40,3,{});flatRoof(c,x,y,60,w,h,'#f0e6d0','#e8dcc4');
  for(const [dx,dy] of [[.6,.6],[w-.6,.6],[.6,h-.6],[w-.6,h-.6]]){cyl(c,x+dx,y+dy,.42,60,72,'#fffaf0');dome(c,x+dx,y+dy,.42,72,20,'#f4ece0');const t=IP(x+dx,y+dy,92);c.fillStyle='#e2b44a';c.fillRect(t[0]-1,t[1]-8,2,8)}cyl(c,x+w/2,y+h/2,.8,60,74,'#fffaf0');dome(c,x+w/2,y+h/2,.8,74,30,'#f4ece0');signY(c,x+w*.5,y+h,50,'STESEN KERETA API','#1f3a6b','#fff',7)};
BART.bas=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,4,'#c8c0b0');box(c,x+.2,y+.2,4,w-.4,1,40,'#fff6e6');winRowY(c,x+.3,x+w-.3,y+1.2,14,32,4,{});for(let i=0;i<=4;i++)post(c,x+.2+i*(w-.4)/4,y+h-.25,4,42,'#8a96a8',.12);
  flatRoof(c,x-.2,y-.1,44,w+.4,h+.2,'#2ec4b6');box(c,x-.2,y+h+.1,40,w+.4,.04,4,'#1f9a8e',{notop:1});box(c,x+w+.2,y-.1,40,.04,h+.2,4,'#1a8a7e',{notop:1});signY(c,x+w*.5,y+h+.1,36,'TERMINAL BAS','#f29b0c','#fff',8);
  drawBus(c,x+.6,y+h+.9,'x','#3a86ff')};
function drawBus(c,x,y,ax,col){const L=2.6,W=.9;if(ax==='x'){box(c,x,y,4,L,W,26,col,{t:'#e8eef8'});for(let i=0;i<5;i++)winY(c,x+.3+i*.5,y+W,14,24,.36,{frame:col,cross:false});winX(c,x+L,y+W/2,12,24,.6,{frame:col,cross:false})}else{box(c,x,y,4,W,L,26,col,{t:'#e8eef8'});for(let i=0;i<5;i++)winX(c,x+W,y+.3+i*.5,14,24,.36,{frame:col,cross:false})}
  for(const [dx,dy] of ax==='x'?[[.4,W],[L-.4,W]]:[[W,.4],[W,L-.4]]){const p=IP(x+dx,y+dy,4);c.fillStyle='#222';c.beginPath();c.ellipse(p[0],p[1],5,4,0,0,TAU);c.fill()}}
BART.airport=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,56,'#eaf4ff');box(c,x,y+h,6,w,.03,44,'#7fb8ec',{notop:1});box(c,x+w,y,6,.03,h,44,'#5f98cc',{notop:1});for(let i=1;i<w*2;i++){const a=IP(x+i/2,y+h,6),q=IP(x+i/2,y+h,50);c.strokeStyle='#fff';c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(q[0],q[1]);c.stroke()}
  doorY(c,x+w*.5,y+h,1,26,'#bfe3ff',{glass:1});const seg=8;for(let i=0;i<seg;i++){const a0=Math.PI*i/seg,a1=Math.PI*(i+1)/seg,rr=h/2+.3;const y0=y+h/2-Math.cos(a0)*rr,y1=y+h/2-Math.cos(a1)*rr;ipoly(c,[IP(x-.3,y0,56+Math.sin(a0)*22),IP(x+w+.3,y0,56+Math.sin(a0)*22),IP(x+w+.3,y1,56+Math.sin(a1)*22),IP(x-.3,y1,56+Math.sin(a1)*22)],i<seg/2?'#dfe8f4':'#ffffff','#9aaabb',.6)}
  signY(c,x+w*.5,y+h,52,'LAPANGAN TERBANG','#1f3a6b','#fff',8)};
BART.barn=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,44,'#b8323a');ipoly(c,[IP(x+w*.3,y+h,0),IP(x+w*.7,y+h,0),IP(x+w*.7,y+h,30),IP(x+w*.3,y+h,30)],'#8a1a22','#fff',2);{const a=IP(x+w*.3,y+h,0),q=IP(x+w*.7,y+h,30),r=IP(x+w*.7,y+h,0),s=IP(x+w*.3,y+h,30);c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(q[0],q[1]);c.moveTo(r[0],r[1]);c.lineTo(s[0],s[1]);c.stroke()}
  gableRoof(c,x,y,44,w,h,34,.3,'#6a2a2a','x','#b8323a');cyl(c,x+w+.7,y+.8,.55,0,80,'#c8ccd4');dome(c,x+w+.7,y+.8,.55,80,16,'#9aa4b2');signY(c,x+w*.5,y+h,38,'LADANG','#2a9a3a','#fff',8)};
BART.resort=(c,b)=>{const {x,y,w,h}=b;for(const [px,py] of [[x+.1,y+.1],[x+w-.1,y+.1],[x+.1,y+h-.1],[x+w-.1,y+h-.1]])post(c,px,py,0,10,'#6b4426',.14);box(c,x,y,10,w,h,28,'#e8d0a0');winRowY(c,x+.3,x+w-.3,y+h,18,32,2,{});doorY(c,x+w*.5,y+h,.5,26,'#8a5a33');hipRoof(c,x,y,38,w,h,30,.35,'#c8a060','thatch');signY(c,x+w/2,y+h,46,'RESORT PULAU','#2ec4b6','#fff',7)};
BART.cinema2=BART.cinema;

// ---------------- PROPS ----------------
function treeArt(c,kind,s){const sz=.85+s*.4;
  c.fillStyle='rgba(20,60,20,.28)';c.beginPath();c.ellipse(8,2,30*sz,12*sz,0,0,TAU);c.fill();
  if(kind==='palm'){c.strokeStyle='#8a6a42';c.lineWidth=6;c.lineCap='round';c.beginPath();c.moveTo(0,0);c.quadraticCurveTo(12,-40,4,-86);c.stroke();c.strokeStyle='rgba(255,255,255,.2)';c.lineWidth=2;c.stroke();
    const tx=4,ty=-86;for(let i=0;i<8;i++){const a=i/8*TAU+s*3;c.fillStyle=i%2?'#2f8a35':'#4fb84a';c.beginPath();c.moveTo(tx,ty);c.quadraticCurveTo(tx+Math.cos(a)*30,ty+Math.sin(a)*12-14,tx+Math.cos(a)*44,ty+Math.sin(a)*18+10);c.quadraticCurveTo(tx+Math.cos(a)*24,ty+Math.sin(a)*12,tx,ty);c.fill()}
    c.fillStyle='#7a5a2a';for(const [dx,dy] of [[-3,3],[3,3],[0,6]]){c.beginPath();c.arc(tx+dx,ty+dy,3.4,0,TAU);c.fill()}return}
  if(kind==='pine'){c.fillStyle='#6b4426';c.fillRect(-3,-16,6,16);for(let i=0;i<4;i++){const y0=-16-i*18,wd=(32-i*6)*sz;const g=c.createLinearGradient(-wd,0,wd,0);g.addColorStop(0,'#3f8a45');g.addColorStop(1,'#1f5a2a');c.fillStyle=g;c.beginPath();c.moveTo(-wd,y0);c.lineTo(0,y0-34*sz);c.lineTo(wd,y0);c.closePath();c.fill()}return}
  {const tg=c.createLinearGradient(-4,0,4,0);tg.addColorStop(0,'#9a6a40');tg.addColorStop(1,'#5e3e22');c.fillStyle=tg;c.beginPath();c.moveTo(-5,0);c.lineTo(-3,-34*sz);c.lineTo(3,-34*sz);c.lineTo(5,0);c.fill()}
  const P=kind==='pink'?['#d0508a','#f27ab0','#ffc8e0']:kind==='forest'?['#245e2a','#3a8a3a','#6cbc58']:['#2e7a32','#4cab42','#9ae070'];
  const R=seeded(Math.floor(s*1000)+7);const blobs=[];for(let i=0;i<9;i++){const a=R()*TAU,d=R()*20;blobs.push([Math.cos(a)*d*1.25,-52+Math.sin(a)*d*.8-R()*10,13+R()*9])}blobs.sort((a,b)=>a[1]-b[1]);
  c.fillStyle=shade(P[0],-.25);c.beginPath();for(const [bx,by,br] of blobs){c.moveTo((bx)*sz+br*sz+2,by*sz+3);c.arc(bx*sz,by*sz+3,br*sz+2,0,TAU)}c.fill();
  for(const [bx,by,br] of blobs){const g=c.createRadialGradient((bx-br*.4)*sz,(by-br*.5)*sz,1,bx*sz,by*sz,br*sz);g.addColorStop(0,P[2]);g.addColorStop(.5,P[1]);g.addColorStop(1,P[0]);c.fillStyle=g;c.beginPath();c.arc(bx*sz,by*sz,br*sz,0,TAU);c.fill()}
  c.fillStyle=kind==='pink'?'rgba(255,255,255,.75)':'rgba(255,255,210,.4)';for(let i=0;i<(kind==='pink'?18:7);i++){c.beginPath();c.arc((R()-.5)*44*sz,(-52-R()*30+10)*sz,kind==='pink'?1.8:2.2,0,TAU);c.fill()}
  if(kind==='round'&&s>.6){c.fillStyle='#ff6ea8';for(let i=0;i<6;i++){c.beginPath();c.arc((R()-.5)*40*sz,(-48-R()*20)*sz,2,0,TAU);c.fill()}}}
function propArt(c,o,t){const ax=o.ax,ay=o.ay;c.save();c.translate(ax,ay);
  switch(o.t){
  case 'lamp':{c.fillStyle='rgba(30,20,60,.25)';c.beginPath();c.ellipse(3,0,7,3,0,0,TAU);c.fill();c.fillStyle='#2a2a3a';c.beginPath();c.moveTo(-5,0);c.lineTo(5,0);c.lineTo(3,-6);c.lineTo(-3,-6);c.fill();const g=c.createLinearGradient(-2,0,2,0);g.addColorStop(0,'#5a5a72');g.addColorStop(1,'#1a1a2a');c.fillStyle=g;c.fillRect(-1.8,-52,3.6,48);c.fillStyle='#2a2a3a';c.fillRect(-6,-56,12,4);
    c.fillStyle='#fff3b0';c.shadowColor='#ffe680';c.shadowBlur=12;c.beginPath();c.moveTo(-5,-56);c.lineTo(5,-56);c.lineTo(4,-66);c.lineTo(-4,-66);c.fill();c.shadowBlur=0;c.fillStyle='#2a2a3a';c.beginPath();c.moveTo(-7,-66);c.lineTo(7,-66);c.lineTo(0,-72);c.fill();break}
  case 'stall':{c.restore();c.save();const cx0=(o.wb[0]+o.wb[2])/2/TS,cy0=(o.wb[1]+o.wb[3])/2/TS;const x=cx0-.3,y=cy0-.2;box(c,x-.4,y-.3,0,1.4,1,14,'#c8925a');for(let k=0;k<6;k++){const p=IP(x-.25+k*.22,y+.6,16);c.fillStyle=['#e5484d','#f2c230','#38b84a','#ff8c42','#8c5cf2','#ffd23f'][k];c.beginPath();c.arc(p[0],p[1],3.2,0,TAU);c.fill()}for(const [px,py] of [[x-.35,y-.25],[x+.95,y-.25],[x-.35,y+.65],[x+.95,y+.65]])post(c,px,py,0,40,'#6b4426',.08);
    const cols=[o.c,'#ffffff'];for(let i=0;i<6;i++){const a=x-.5+i*.27,bb=a+.27;ipoly(c,[IP(a,y-.4,52),IP(bb,y-.4,52),IP(bb,y+.25,42),IP(a,y+.25,42)],shade(cols[i%2],-.15));ipoly(c,[IP(a,y+.25,42),IP(bb,y+.25,42),IP(bb,y+.9,36),IP(a,y+.9,36)],cols[i%2],shade(o.c,-.4),.4)}break}
  case 'table':{c.fillStyle='rgba(0,0,0,.18)';c.beginPath();c.ellipse(4,2,22,9,0,0,TAU);c.fill();c.fillStyle='#8a5a33';c.fillRect(-1.5,-16,3,16);c.fillStyle='#e8c08a';c.beginPath();c.ellipse(0,-16,12,6,0,0,TAU);c.fill();for(const dx of [-14,14]){c.fillStyle='#c8102e';c.fillRect(dx-3,-8,6,8)}c.fillStyle='#ddd';c.fillRect(-1,-48,2,32);for(let i=0;i<8;i++){c.fillStyle=i%2?'#fff':o.c;c.beginPath();c.moveTo(0,-52);c.ellipse(0,-42,26,11,0,Math.PI+i/8*Math.PI,Math.PI+(i+1)/8*Math.PI);c.fill()}break}
  case 'umbrella':{c.fillStyle='rgba(0,0,0,.15)';c.beginPath();c.ellipse(8,2,24,9,0,0,TAU);c.fill();c.fillStyle='#ddd';c.fillRect(-1,-46,2,46);for(let i=0;i<8;i++){c.fillStyle=i%2?'#fff':o.c;c.beginPath();c.moveTo(0,-52);c.ellipse(0,-40,28,12,0,Math.PI+i/8*Math.PI,Math.PI+(i+1)/8*Math.PI);c.fill()}c.fillStyle='#f4f4f4';const p=new Path2D();rrp(p,8,-6,24,8,3);c.fill(p);c.fillStyle=o.c;c.fillRect(10,-5,20,2);break}
  case 'boat':{const b=Math.sin(t*1.5+(o.v||0))*1.5;c.translate(0,b);c.fillStyle='rgba(255,255,255,.4)';c.beginPath();c.ellipse(0,6,40,10,0,0,TAU);c.fill();const hc=['#ffffff','#e5484d','#3a86ff'][o.v||0];c.fillStyle=shade(hc,-.2);c.beginPath();c.moveTo(-38,-6);c.lineTo(30,-14);c.lineTo(40,-10);c.lineTo(28,4);c.lineTo(-30,8);c.closePath();c.fill();c.fillStyle=hc;c.beginPath();c.moveTo(-38,-6);c.lineTo(30,-14);c.lineTo(40,-10);c.lineTo(-30,-2);c.closePath();c.fill();c.fillStyle='#8a5a33';c.beginPath();c.moveTo(-30,-4);c.lineTo(28,-12);c.lineTo(26,-8);c.lineTo(-28,0);c.fill();
    if((o.v||0)!==2){c.fillStyle='#f4f8ff';c.fillRect(-12,-28,20,16);c.fillStyle='#8fc0f0';c.fillRect(-9,-25,6,6);c.fillRect(0,-25,6,6);c.fillStyle='#3a86ff';c.fillRect(-14,-32,24,5)}else{c.strokeStyle='#6b4426';c.lineWidth=2;c.beginPath();c.moveTo(0,-8);c.lineTo(0,-50);c.stroke();c.fillStyle='#fff6e6';c.beginPath();c.moveTo(2,-48);c.lineTo(26,-14);c.lineTo(2,-12);c.fill()}break}
  case 'container':{c.restore();c.save();const cx0=(o.wb[0]+o.wb[2])/2/TS,cy0=(o.wb[1]+o.wb[3])/2/TS;const x=cx0-.8,y=cy0-.4;box(c,x,y,0,1.6,.8,22,o.c);for(let i=1;i<8;i++){const a=IP(x+i*.2,y+.8,1),q=IP(x+i*.2,y+.8,21);c.strokeStyle=shade(o.c,-.25);c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(q[0],q[1]);c.stroke()}break}
  case 'crane':{c.strokeStyle='#f2a20c';c.lineWidth=5;c.beginPath();c.moveTo(-14,0);c.lineTo(-14,-180);c.moveTo(14,0);c.lineTo(14,-180);c.stroke();c.lineWidth=2;for(let i=0;i<9;i++){c.beginPath();c.moveTo(-14,-i*20);c.lineTo(14,-i*20-20);c.stroke()}c.lineWidth=5;c.beginPath();c.moveTo(-60,-176);c.lineTo(110,-196);c.stroke();c.lineWidth=2;c.beginPath();c.moveTo(0,-206);c.lineTo(-60,-176);c.moveTo(0,-206);c.lineTo(110,-196);c.stroke();c.strokeStyle='#444';c.lineWidth=1.2;c.beginPath();c.moveTo(80,-193);c.lineTo(80,-110);c.stroke();c.fillStyle='#3a86ff';c.fillRect(64,-110,32,14);c.fillStyle='#e5484d';c.fillRect(-10,-196,24,18);break}
  case 'tank':{c.restore();c.save();const cx0=(o.wb[0]+o.wb[2])/2/TS,cy0=(o.wb[1]+o.wb[3])/2/TS;const x=cx0,y=cy0;cyl(c,x,y,.9,0,70,'#e8eef4',{stripes:[[50,56,'#3a86ff']]});break}
  case 'plane':{c.fillStyle='rgba(0,0,0,.15)';c.beginPath();c.ellipse(10,6,90,22,-.45,0,TAU);c.fill();c.save();c.rotate(-.46);c.fillStyle='#f4f8ff';c.strokeStyle='#8a9ab0';c.lineWidth=1.5;c.beginPath();c.ellipse(0,-14,86,12,0,0,TAU);c.fill();c.stroke();c.beginPath();c.moveTo(-12,-14);c.lineTo(-30,-64);c.lineTo(-16,-64);c.lineTo(22,-14);c.lineTo(-16,36);c.lineTo(-30,36);c.closePath();c.fill();c.stroke();c.fillStyle='#6a3fd0';c.beginPath();c.moveTo(-76,-14);c.lineTo(-90,-46);c.lineTo(-76,-46);c.lineTo(-60,-14);c.fill();c.fillStyle='#8fc0f0';for(let i=0;i<9;i++)c.fillRect(-44+i*11,-18,5,4);c.restore();break}
  case 'tower':{c.restore();c.save();const cx0=(o.wb[0]+o.wb[2])/2/TS,cy0=(o.wb[1]+o.wb[3])/2/TS;const x=cx0,y=cy0;cyl(c,x,y,.35,0,150,'#eef2f8');cyl(c,x,y,.7,150,176,'#7fb8ec',{top:'#dfe8f4'});cyl(c,x,y,.75,176,182,'#e8eef4');const p=IP(x,y,182);c.fillStyle='#e5484d';c.fillRect(p[0]-1,p[1]-16,2,16);break}
  case 'flag':{c.fillStyle='rgba(0,0,0,.2)';c.beginPath();c.ellipse(3,1,8,3,0,0,TAU);c.fill();c.fillStyle='#d8d8e0';c.fillRect(-1.5,-130,3,130);c.fillStyle='#f2c230';c.beginPath();c.arc(0,-131,3,0,TAU);c.fill();flagJG(c,1,-128,40,t*3+ax*.01);break}
  case 'bench':{c.restore();c.save();const cx0=(o.wb[0]+o.wb[2])/2/TS,cy0=(o.wb[1]+o.wb[3])/2/TS;const x=cx0-.45,y=cy0-.15;box(c,x,y,8,.9,.3,3,'#c8925a');box(c,x,y,11,.9,.06,9,'#a87040');post(c,x+.08,y+.15,0,8,'#3a3a4a',.06);post(c,x+.82,y+.15,0,8,'#3a3a4a',.06);break}
  case 'waterfall':{c.fillStyle='#8a8478';for(const [dx,dy,r] of [[-40,-20,20],[40,-24,22],[-20,-60,18],[30,-70,16],[0,-90,20]]){c.beginPath();c.arc(dx,dy,r,0,TAU);c.fill()}const g=c.createLinearGradient(0,-100,0,0);g.addColorStop(0,'#e8fbff');g.addColorStop(1,'rgba(160,220,240,.6)');c.fillStyle=g;c.fillRect(-16,-100,32,100);c.fillStyle='rgba(255,255,255,.7)';for(let i=0;i<6;i++){c.fillRect(-14+i*5,-100+((t*60+i*17)%100),2,10)}break}
  case 'animal':{if(o.k==='cow'){c.fillStyle='#fff';c.beginPath();c.ellipse(0,-10,14,8,0,0,TAU);c.fill();c.fillStyle='#333';c.beginPath();c.arc(-4,-12,3,0,TAU);c.arc(5,-8,2.5,0,TAU);c.fill();c.fillStyle='#f4c8b0';c.beginPath();c.ellipse(13,-14,5,4,0,0,TAU);c.fill();c.fillStyle='#333';for(const dx of [-8,-3,4,9])c.fillRect(dx,-4,2,5)}else if(o.k==='goat'){c.fillStyle='#e8e0d0';c.beginPath();c.ellipse(0,-9,11,6,0,0,TAU);c.fill();c.beginPath();c.arc(11,-14,4,0,TAU);c.fill();c.fillStyle='#666';for(const dx of [-6,-2,4,7])c.fillRect(dx,-4,1.6,5)}else{c.fillStyle='#fff';c.beginPath();c.arc(0,-6,6,0,TAU);c.fill();c.fillStyle='#e5484d';c.fillRect(3,-14,3,3);c.fillStyle='#f2a20c';c.fillRect(6,-9,3,2)}break}
  case 'fountain':{c.restore();c.save();const [cx,cy]=s2w(ax,ay).map(v=>v/TS);ipoly(c,isoEll(cx,cy,1.55,0),'#cdbda6','#9a8a72',1.2);ipoly(c,isoEll(cx,cy,1.55,8),'#e8dcc8','#9a8a72',1);{const g=c.createLinearGradient(0,IP(cx,cy,8)[1]-30,0,IP(cx,cy,8)[1]+30);g.addColorStop(0,'#7fd8f8');g.addColorStop(1,'#3aa6de');ipoly(c,isoEll(cx,cy,1.32,8),g)}
    for(let i=0;i<8;i++){const a=t*.8+i/8*TAU,p=IP(cx+Math.cos(a)*.9,cy+Math.sin(a)*.9,8);c.fillStyle='rgba(255,255,255,.75)';c.beginPath();c.ellipse(p[0],p[1],4,1.6,0,0,TAU);c.fill()}
    cyl(c,cx,cy,.32,8,40,'#e8dcc8');ipoly(c,isoEll(cx,cy,.75,40),'#e8dcc8','#9a8a72');ipoly(c,isoEll(cx,cy,.6,40),'#6fd0f0');cyl(c,cx,cy,.16,40,62,'#e8dcc8');ipoly(c,isoEll(cx,cy,.36,62),'#e8dcc8','#9a8a72');
    const top=IP(cx,cy,64);for(let i=0;i<10;i++){const a=i/10*TAU,ph=(t*1.2+i*.1)%1;c.strokeStyle=`rgba(220,245,255,${.85-ph*.4})`;c.lineWidth=1.6;c.beginPath();c.moveTo(top[0],top[1]);const ex=Math.cos(a)*30,ey=Math.sin(a)*14;c.quadraticCurveTo(top[0]+ex*.5,top[1]-26,top[0]+ex,top[1]+ey+20);c.stroke()}
    c.fillStyle='rgba(235,250,255,.95)';c.beginPath();c.moveTo(top[0]-3,top[1]);c.quadraticCurveTo(top[0],top[1]-34-Math.sin(t*6)*3,top[0]+3,top[1]);c.fill();break}
  }
  c.restore()}
