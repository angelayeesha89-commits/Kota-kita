// ===================== ISO 2.5D MAP — LAYOUT (matches reference composition) =====================
// World = 72x72 tiles (32px). Iso projection: X = wx-wy, Y = (wx+wy)/2  (world px -> iso px)
// UV(u,v) maps the reference picture (u,v in 0..1 across the 1672x941 image) onto world tiles.
const ISO={a:33.9,b:19.1,CH:512,ZL:[.34,.44,.56,.7,.86,1.06],zi:3};
function UV(u,v){const X=(u-.5)*2*ISO.a,Y=MW/2+(v-.5)*2*ISO.b;return[Y+X/2,Y-X/2]}
const w2s=(wx,wy)=>[wx-wy,(wx+wy)/2];
const s2w=(sx,sy)=>[sy+sx/2,sy-sx/2];
const tw=(x,y)=>[(x-y)*TS,(x+y)*TS/2];
const GND={sh:[],dc:[]},STAT=[],PATHS=[],VEHS=[],ROADS=[];
let ISLAND=null,RAILP=null;const MAP_HOOKS=[];
function isIsland(px,py){return !!ISLAND&&Math.hypot(px/TS-ISLAND.x,py/TS-ISLAND.y)<ISLAND.r+2}

// ---- geometry helpers (tile units)
function crs(P,closed,n){n=n||6;const L=P.length;if(L<3)return P.map(p=>p.slice());const out=[];const g=i=>closed?P[(i+L)%L]:P[Math.max(0,Math.min(L-1,i))];const m=closed?L:L-1;
  for(let i=0;i<m;i++){const p0=g(i-1),p1=g(i),p2=g(i+1),p3=g(i+2);for(let j=0;j<n;j++){const t=j/n,t2=t*t,t3=t2*t;const f=a=>.5*(2*p1[a]+(-p0[a]+p2[a])*t+(2*p0[a]-5*p1[a]+4*p2[a]-p3[a])*t2+(-p0[a]+3*p1[a]-3*p2[a]+p3[a])*t3);out.push([f(0),f(1)])}}
  if(!closed)out.push(P[L-1].slice());return out}
function ribbon(P,hw){const L=[],R=[];for(let i=0;i<P.length;i++){const a=P[Math.max(0,i-1)],b=P[Math.min(P.length-1,i+1)];let dx=b[0]-a[0],dy=b[1]-a[1];const d=Math.hypot(dx,dy)||1;dx/=d;dy/=d;L.push([P[i][0]-dy*hw,P[i][1]+dx*hw]);R.push([P[i][0]+dy*hw,P[i][1]-dx*hw])}return L.concat(R.reverse())}
function pip(x,y,poly){let c=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const a=poly[i],b=poly[j];if((a[1]>y)!==(b[1]>y)&&x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0])c=!c}return c}
function dSeg(px,py,a,b){const dx=b[0]-a[0],dy=b[1]-a[1],l=dx*dx+dy*dy;let t=l?((px-a[0])*dx+(py-a[1])*dy)/l:0;t=Math.max(0,Math.min(1,t));return Math.hypot(px-a[0]-t*dx,py-a[1]-t*dy)}
function dLine(px,py,P){let m=1e9;for(let i=0;i<P.length-1;i++){const d=dSeg(px,py,P[i],P[i+1]);if(d<m)m=d}return m}
function blob(cx,cy,rx,ry,seed,n){const R=seeded(seed);const out=[];n=n||14;for(let i=0;i<n;i++){const a=i/n*TAU,f=.82+R()*.3;out.push([cx+Math.cos(a)*rx*f,cy+Math.sin(a)*ry*f])}return crs(out,true,4)}
function circ(cx,cy,r,n){n=n||40;const o=[];for(let i=0;i<n;i++){const a=i/n*TAU;o.push([cx+Math.cos(a)*r,cy+Math.sin(a)*r])}return o}
function rectP(x,y,w,h){return[[x,y],[x+w,y],[x+w,y+h],[x,y+h]]}
function shp(k,ptsT,o){o=o||{};const pts=ptsT.map(p=>tw(p[0],p[1]));let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;for(const [x,y] of pts){if(x<x0)x0=x;if(y<y0)y0=y;if(x>x1)x1=x;if(y>y1)y1=y}const pad=o.pad||60;const s=Object.assign({k,pts,tp:ptsT,bb:[x0-pad,y0-pad,x1+pad,y1+pad]},o);GND.sh.push(s);return s}
const uvp=a=>a.map(p=>UV(p[0],p[1]));

// ---- static sprite registry (sorted with entities each frame)
function addStat(o){// o.t kind; o.wb world box (px) ; o.ib iso bbox ; o.ax,ay iso anchor
  STAT.push(o);return o}
function bldTop(b){return b.top||110}
function bldIB(b){const m=26,top=bldTop(b)+(b.ext||0);return[(b.x-(b.y+b.h))*TS-m,(b.x+b.y)*TS/2-top-m,((b.x+b.w)-b.y)*TS+m,(b.x+b.w+b.y+b.h)*TS/2+m]}

function isoGen(){
  T.fill(G);SOL.fill(0);OBJS.length=0;LAMPS.length=0;BLDS.length=0;SPOTS.length=0;SPECIAL.length=0;
  GND.sh.length=0;GND.dc.length=0;STAT.length=0;PATHS.length=0;VEHS.length=0;ROADS.length=0;
  const R=seeded(77);
  // ---------- SEA (top-right) + coastline
  const coastUV=[[.64,-.6],[.66,-.2],[.67,-.04],[.70,.08],[.73,.2],[.76,.30],[.82,.345],[.88,.35],[.93,.33],[.99,.35],[1.04,.40],[1.08,.47],[1.12,.56],[1.2,.62],[1.7,.62],[1.7,-.6]];
  const coast=crs(uvp(coastUV),false,8);const seaPoly=coast;
  // lighthouse rock islet + resort island
  const isl=UV(1.17,.28);ISLAND={x:isl[0],y:isl[1],r:4.2};const islP=blob(isl[0],isl[1],4.6,4.2,5,12);
  const rock=UV(.975,.205);const rockP=blob(rock[0],rock[1],1.7,1.5,9,9);
  for(let y=0;y<MH;y++)for(let x=0;x<MW;x++){const cx=x+.5,cy=y+.5;if(pip(cx,cy,seaPoly)&&!pip(cx,cy,islP)&&!pip(cx,cy,rockP))T[ti(x,y)]=SEA}
  for(let y=0;y<MH;y++)for(let x=0;x<MW;x++){if(T[ti(x,y)]!==G)continue;let near=false;for(let dy=-2;dy<=2&&!near;dy++)for(let dx=-2;dx<=2;dx++)if(tget(x+dx,y+dy)===SEA&&Math.hypot(dx,dy)<=2.3){near=true;break}if(near)T[ti(x,y)]=SAND}
  shp('sea',seaPoly,{pad:200});
  shp('sand',islP);shp('isl',blob(isl[0],isl[1],3.3,3,6,12));shp('rock',rockP);
  // ---------- RIVER (forest, top) to the sea + waterfall
  const riv=crs(uvp([[.16,-.42],[.2,-.3],[.28,-.24],[.36,-.16],[.44,-.15],[.52,-.08],[.6,-.07],[.68,-.06]]),false,8);
  const rivP=ribbon(riv,1.15);shp('water',rivP,{rim:1});
  for(let y=0;y<MH;y++)for(let x=0;x<MW;x++)if(T[ti(x,y)]!==SEA&&dLine(x+.5,y+.5,riv)<1.15)T[ti(x,y)]=FW;
  // park pond + forest lake
  const pc=UV(.815,.535);const pondP=blob(pc[0],pc[1],2.6,2.2,3,14);shp('water',pondP,{rim:1,pond:1});
  for(let y=0;y<MH;y++)for(let x=0;x<MW;x++)if(pip(x+.5,y+.5,pondP))T[ti(x,y)]=FW;
  // ---------- FIELDS / RUNWAY / ROADS / RAIL
  const lad=UV(.06,.97);for(const [dx,dy,w,h] of [[-6,-1,4,3],[-6,3,4,3],[-1,4,4,3],[3,4,3,3],[-1,-5,3,3]]){shp('field',rectP(lad[0]+dx,lad[1]+dy,w,h));for(let j=0;j<h;j++)for(let i=0;i<w;i++){const xx=Math.floor(lad[0]+dx+i),yy=Math.floor(lad[1]+dy+j);if(tget(xx,yy)===G)T[ti(xx,yy)]=SOIL}}
  const rw=UV(.74,1.04);shp('runway',rectP(rw[0]-6,rw[1]-1.6,20,3.2),{pad:80});
  const road=crs(uvp([[-.5,.9],[-.1,.88],[.2,.865],[.42,.875],[.6,.905],[.8,.86],[.95,.78],[1.06,.7],[1.18,.64]]),false,8);
  ROADS.push(road);shp('road',ribbon(road,1.05),{line:road});
  const rail=crs(uvp([[-.55,.66],[-.2,.69],[.05,.73],[.2,.79],[.3,.9],[.36,1.1],[.4,1.45]]),false,8);RAILP=rail;shp('rail',ribbon(rail,.55),{line:rail});
  // ---------- PLAZA + PATH NETWORK (cobblestone)
  const pz=UV(.48,.5);shp('plaza',circ(pz[0],pz[1],3.6,48),{pad:60,ring:1});
  const net=[
    [[.48,.5],[.45,.43],[.40,.36],[.34,.29],[.28,.245],[.2,.2],[.12,.16]],
    [[.48,.5],[.495,.40],[.50,.31],[.505,.22],[.52,.12],[.56,.04]],
    [[.48,.5],[.56,.42],[.62,.355],[.70,.31],[.78,.305],[.86,.29]],
    [[.48,.5],[.58,.535],[.69,.545],[.77,.585],[.86,.60],[.97,.585],[1.04,.52]],
    [[.48,.5],[.56,.6],[.63,.69],[.66,.76],[.61,.83]],
    [[.48,.5],[.47,.62],[.45,.72],[.43,.82]],
    [[.48,.5],[.39,.56],[.31,.64],[.25,.70],[.16,.77],[.06,.83]],
    [[.48,.5],[.37,.46],[.27,.47],[.16,.52],[.04,.55],[-.1,.56]],
    [[.12,.16],[.06,.28],[.04,.42],[-.04,.55]],
    [[.56,.04],[.66,.12],[.74,.22],[.78,.305]],
    [[.86,.6],[.85,.72],[.74,.79],[.66,.76]],
    [[.06,.83],[.0,.92],[.04,1.02]],
    [[.12,.16],[.16,.04],[.22,-.1],[.30,-.2],[.36,-.3]],
    [[.12,.16],[.02,.1],[-.12,.12],[-.28,.2]],
    [[.97,.585],[1.0,.66]],
  ];
  for(const p of net){const P=crs(uvp(p),false,8);PATHS.push({P,hw:.95});}
  // ---------- BUILDINGS ----------
  const B=(kind,u,v,w,h,loc,label,o)=>{o=o||{};const c=UV(u,v);const x=Math.round(c[0]-w/2),y=Math.round(c[1]-h/2);return BT(kind,x,y,w,h,loc,label,o)};
  const BT=(kind,x,y,w,h,loc,label,o)=>{o=o||{};const b=Object.assign({kind,x,y,w,h,loc,label},o);BLDS.push(b);solidRect(x,y,w,h);
    if(loc){const d=o.door==='x'?[x+w,y+Math.floor(h/2)]:[x+Math.floor(w/2),y+h];LOC[loc].door=d;b.door=d}
    b.top=o.top||({hospital:150,gov:190,mall:150,apartment:200,uni:150,airport:170,lighthouse:230,stadium:120,factory:170,port:120,keretapi:150,lrt:150}[kind]||120);
    addStat({t:'bld',b,wb:[x*TS,y*TS,(x+w)*TS,(y+h)*TS],ib:bldIB(b)});return b};
  // Kawasan Kediaman (top-left)
  B('myhome',.27,.255,3,3,'perumahan','RUMAH ANDA',{c:'#7a4fd8'});
  B('house',.20,.13,3,3,null,'',{c:'#3d6fb6',v:0});B('house',.315,.15,3,3,null,'',{c:'#c8503a',v:1});B('house',.13,.235,3,3,null,'',{c:'#2a9a8a',v:2});
  B('house',.43,.10,3,2,null,'',{c:'#d07a2a',v:1});B('house',.40,.19,3,3,null,'',{c:'#3d6fb6',v:2});B('apartment',.06,.33,3,3,null,'APARTMEN SERI',{});
  // Pasar Tradisional (top-centre)
  B('pasar',.505,.205,4,3,'pasar','PASAR TANI');B('pasarmalam',.585,.12,3,3,'pasarmalam','PASAR MALAM');
  // Kafe & Restoran
  B('bandar',.655,.20,4,3,'bandar','KEDAI MAMAK',{c:'#3d6fb6'});B('medan',.625,.30,3,3,'medan','MEDAN SELERA');
  // Pantai & Jeti
  B('jetihut',.805,.318,2,2,'jeti','JETI MEMANCING');B('beachhut',.725,.29,2,2,'pantai','PONDOK PANTAI');
  B('lighthouse',.975,.205,1,1,null,'');
  // Hospital & Klinik (left)
  B('hospital',.14,.44,5,4,'hospital','HOSPITAL KOTA KITA');B('klinik',.235,.405,3,3,'klinik','KLINIK KESIHATAN');
  // Pejabat Kerajaan + civic
  B('gov',.385,.335,5,4,'pejabat','PEJABAT KERAJAAN');B('kerjaya',.44,.245,3,3,'kerjaya','PUSAT KERJAYA');
  B('polis',.53,.63,3,2,'polis','BALAI POLIS');B('bomba',.05,.525,3,3,'bomba','BALAI BOMBA');
  // Mall (centre-right)
  B('mall',.635,.465,5,5,'mall','ASIA MALL');B('cinema',.70,.375,3,3,'pawagam','PAWAGAM');B('bank',.565,.395,2,2,null,'BANK');
  // Taman Awam (right)
  B('gazebo',.81,.43,2,2,'taman','TAMAN AWAM');
  // Kawasan Industri (far right)
  B('port',.955,.47,4,3,'pelabuhan','PELABUHAN');B('factory',.945,.63,4,3,null,'');B('factory',1.04,.58,3,3,null,'',{v:1});
  // Sekolah / Kolej / Universiti (lower-left)
  B('school',.325,.575,4,3,'sekolah','SMK KOTA KITA');B('uni',.17,.615,5,4,'uni','UNIVERSITI KOTA KITA');B('library',.385,.665,3,2,'perpustakaan','PERPUSTAKAAN');
  // Stadium (lower-right)
  B('stadium',.735,.655,6,5,'stadium','STADIUM KOTA KITA');
  // Transit (bottom)
  B('lrt',.225,.745,4,3,'lrt','STESEN LRT / MRT');B('keretapi',.06,.715,4,3,'keretapi','STESEN KERETA API');
  B('bas',.445,.785,4,3,'bas','TERMINAL BAS');B('airport',.585,.835,5,4,'airport','LAPANGAN TERBANG');
  // Outskirts: kampung / hutan / ladang / pulau
  B('balai',.02,.17,3,3,'kampung','BALAI RAYA');for(const [u,v] of [[-.08,.12],[-.06,.24],[.06,.06],[-.14,.2],[.0,.30]])B('kampung',u,v,2,2,null,'');
  B('ranger',.33,-.24,2,2,'hutan','PONDOK RENJER');
  B('barn',.03,.935,3,3,'ladang','LADANG KOTA KITA');
  {const x=Math.round(isl[0]-1),y=Math.round(isl[1]-1.5);BT('resort',x,y,3,2,'pulau','RESORT PULAU')}
  for(const f of MAP_HOOKS)try{f(B,BT)}catch(e){console.warn('maphook',e)}
  // ---------- connector paths from each door to the network
  const netPts=[];for(const p of PATHS)for(const q of p.P)netPts.push(q);
  for(const b of BLDS){if(!b.door)continue;const d=b.door,front=b.door===undefined?null:(d[0]===b.x+b.w?[d[0]+1.4,d[1]+.5]:[d[0]+.5,d[1]+1.4]);const st=[d[0]+.5,d[1]+.5];
    let best=null,bd=1e9;for(const q of netPts){const dd=Math.hypot(q[0]-front[0],q[1]-front[1]);if(dd<bd){bd=dd;best=q}}
    if(b.kind==='resort'||b.kind==='lighthouse')continue;
    const pts=bd<1.2?[st,front]:[st,front,[(front[0]+best[0])/2,(front[1]+best[1])/2],best];PATHS.push({P:crs(pts,false,6),hw:.7,conn:1})}
  // jetty pier into the sea + island dock
  const jb=LOC.jeti.door;const pier=[];for(let i=0;i<9;i++)pier.push([jb[0]+1+i*.1,jb[1]-1-i]);
  {const x0=jb[0]+1,y1=jb[1]-1;for(let j=-1;j<9;j++)for(let i=0;i<2;i++){const xx=x0+i,yy=y1-j;if(xx>=0&&yy>=0&&xx<MW&&yy<MH&&!SOL[ti(xx,yy)])T[ti(xx,yy)]=DOCK}
    shp('dock',[[x0,y1+1],[x0+2,y1+1],[x0+2,y1-8],[x0,y1-8]],{pad:60})}
  {const dx=Math.round(isl[0]-5),dy=Math.round(isl[1]+.5);for(let i=0;i<3;i++){if(tget(dx+i,dy)===SEA)T[ti(dx+i,dy)]=DOCK}shp('dock',[[dx,dy],[dx+3,dy],[dx+3,dy+1],[dx,dy+1]])}
  // rasterize paths -> walkable plaza tiles (+ bridges over river)
  for(const p of PATHS){const P=p.P;let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;for(const q of P){x0=Math.min(x0,q[0]);y0=Math.min(y0,q[1]);x1=Math.max(x1,q[0]);y1=Math.max(y1,q[1])}
    for(let y=Math.floor(y0-2);y<=y1+2;y++)for(let x=Math.floor(x0-2);x<=x1+2;x++){if(x<0||y<0||x>=MW||y>=MH)continue;if(dLine(x+.5,y+.5,P)>p.hw+.15)continue;const t=T[ti(x,y)];if(t===FW){T[ti(x,y)]=BRG;SOL[ti(x,y)]=0}else if(t===G||t===SAND||t===SOIL)T[ti(x,y)]=PL}
    shp('path',ribbon(P,p.hw),{pad:60,conn:p.conn})}
  for(let y=0;y<MH;y++)for(let x=0;x<MW;x++)if(Math.hypot(x+.5-pz[0],y+.5-pz[1])<3.6&&T[ti(x,y)]!==SEA)T[ti(x,y)]=PL;
  // bridges as shapes
  for(let y=0;y<MH;y++)for(let x=0;x<MW;x++)if(T[ti(x,y)]===BRG)shp('bridge',rectP(x,y,1,1),{pad:30});
  // ---------- fountain + plaza props
  solidRect(Math.floor(pz[0])-1,Math.floor(pz[1])-1,3,3);
  addStat({t:'fountain',wb:[(pz[0]-1.4)*TS,(pz[1]-1.4)*TS,(pz[0]+1.4)*TS,(pz[1]+1.4)*TS],ax:tw(pz[0],pz[1])[0],ay:tw(pz[0],pz[1])[1],ib:(()=>{const a=tw(pz[0],pz[1]);return[a[0]-120,a[1]-150,a[0]+120,a[1]+60]})()});
  // ---------- props helpers
  const prop=(t,x,y,o)=>{o=o||{};const a=tw(x,y),r=(o.r||.3)*TS,hh=o.hh||80,ww=o.ww||40;const s=Object.assign({t,wb:[x*TS-r,y*TS-r,x*TS+r,y*TS+r],ax:a[0],ay:a[1],ib:[a[0]-ww,a[1]-hh,a[0]+ww,a[1]+20]},o);STAT.push(s);if(o.solid)SOL[ti(Math.floor(x),Math.floor(y))]=1;return s};
  // flags, lamps around plaza
  for(let i=0;i<10;i++){const a=i/10*TAU+.3,x=pz[0]+Math.cos(a)*3.9,y=pz[1]+Math.sin(a)*3.9;if(T[ti(Math.floor(x),Math.floor(y))]===PL||T[ti(Math.floor(x),Math.floor(y))]===G){prop('lamp',x,y,{hh:70,ww:14});LAMPS.push([x,y])}}
  // lamps along paths
  for(const p of PATHS){if(p.conn)continue;let acc=0;for(let i=1;i<p.P.length;i++){const a=p.P[i-1],b=p.P[i];acc+=Math.hypot(b[0]-a[0],b[1]-a[1]);if(acc>5.5){acc=0;const dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1,sd=(i%2?1:-1)*(p.hw+.45);const x=b[0]-dy/d*sd,y=b[1]+dx/d*sd;
    if(x>1&&y>1&&x<MW-1&&y<MH-1&&!SOL[ti(Math.floor(x),Math.floor(y))]&&[G,PL,SAND].includes(T[ti(Math.floor(x),Math.floor(y))])&&Math.hypot(x-pz[0],y-pz[1])>5){prop('lamp',x,y,{hh:70,ww:14});LAMPS.push([x,y])}}}}
  // market stalls, cafe tables, beach umbrellas, boats, containers, crane, plane, bus, train, flags, benches
  {const m=UV(.505,.205);for(const [dx,dy,c] of [[-3.2,-.6,'#e5484d'],[-3.2,1.8,'#3a86ff'],[4.6,-.8,'#38b84a'],[4.6,1.6,'#e5484d'],[.5,3.9,'#f29b0c'],[2.6,3.9,'#3a86ff']]){const x=m[0]+dx,y=m[1]+dy;if(!SOL[ti(Math.floor(x),Math.floor(y))])prop('stall',x,y,{c,r:.9,hh:80,ww:46,solid:1})}}
  {const m=UV(.625,.30);for(const [dx,dy,c] of [[2.6,0,'#e5484d'],[2.6,2,'#f2c230'],[-2.4,2.4,'#3a86ff']]){const x=m[0]+dx,y=m[1]+dy;if(!SOL[ti(Math.floor(x),Math.floor(y))])prop('table',x,y,{c,r:.6,hh:60,ww:30,solid:1})}}
  {const m=UV(.655,.20);for(const [dx,dy,c] of [[0,2.6,'#e5484d'],[2,2.6,'#e5484d']]){const x=m[0]+dx,y=m[1]+dy;prop('table',x,y,{c,r:.6,hh:60,ww:30,solid:1})}}
  for(let i=0;i<7;i++){const p=crs(uvp([[.70,.215],[.73,.29],[.79,.325],[.87,.335],[.92,.325]]),false,6),q=p[Math.floor((i+.5)/7*p.length)];const x=q[0]-.3,y=q[1]+.9;if(T[ti(Math.floor(x),Math.floor(y))]===SAND)prop('umbrella',x,y,{c:['#e5484d','#3a86ff','#f2c230','#38b84a','#ff5ea8'][i%5],hh:70,ww:34})}
  {const b1=UV(.86,.17);prop('boat',b1[0],b1[1],{hh:60,ww:60,water:1});const b2=UV(.90,.27);prop('boat',b2[0],b2[1],{hh:60,ww:60,water:1,v:1});const b3=UV(.79,.13);prop('boat',b3[0],b3[1],{hh:60,ww:60,water:1,v:2})}
  {const p=LOC.pelabuhan.door;for(const [dx,dy,c] of [[-4,2,'#e5484d'],[-4,3,'#3a86ff'],[-2,3.4,'#f2c230'],[2.6,-3,'#38b84a'],[2.6,-2,'#e5484d'],[3.6,-2.5,'#6a3fd0']]){const x=p[0]+dx,y=p[1]+dy;if(tget(Math.floor(x),Math.floor(y))!==SEA&&!SOL[ti(Math.floor(x),Math.floor(y))])prop('container',x,y,{c,r:.8,hh:50,ww:50,solid:1})}
    const cr=[p[0]+4.5,p[1]-5];if(tget(Math.floor(cr[0]),Math.floor(cr[1]))!==SEA)prop('crane',cr[0],cr[1],{hh:220,ww:120,solid:1});
    for(const [u,v] of [[1.0,.66],[.89,.69]]){const t=UV(u,v);if(!SOL[ti(Math.floor(t[0]),Math.floor(t[1]))])prop('tank',t[0],t[1],{r:.9,hh:100,ww:50,solid:1})}}
  {const a=LOC.airport.door,b=UV(.74,1.04);prop('plane',b[0]+2,b[1],{hh:90,ww:150,r:1.2});const tw2=UV(.665,.86);prop('tower',tw2[0],tw2[1],{hh:200,ww:30,solid:1})}
  // flags (Jalur Gemilang) at gov + school + stadium
  {const g=LOC.pejabat.door;prop('flag',g[0]+2.4,g[1]+1.6,{hh:140,ww:40,solid:1});const s=LOC.sekolah.door;prop('flag',s[0]-2.2,s[1]+.8,{hh:140,ww:40,solid:1})}
  // benches around plaza & park
  for(const [u,v] of [[.43,.47],[.53,.47],[.43,.535],[.53,.54],[.79,.49],[.84,.47],[.78,.58]]){const t=UV(u,v);if(!SOL[ti(Math.floor(t[0]),Math.floor(t[1]))]&&tget(Math.floor(t[0]),Math.floor(t[1]))!==FW)prop('bench',t[0],t[1],{hh:30,ww:30})}
  // ---------- fishing spots + specials
  const spot=(id,x,y)=>SPOTS.push({id,x:Math.floor(x),y:Math.floor(y)});
  spot('jeti',jb[0]+1,jb[1]-8);{const t=UV(.755,.305);spot('teluk',t[0],t[1]-.6)}spot('manukan',isl[0]-4,isl[1]+.5);
  {const t=riv[riv.length-4];spot('muara',t[0],t[1]+1.6)}spot('tasik',pc[0]-2.4,pc[1]+2.8);{const t=riv[Math.floor(riv.length*.35)];spot('sungai',t[0],t[1]+1.8)}
  for(const s of SPOTS){if(isSolidTile(s.x,s.y)){const f=findFree(s.x,s.y);s.x=Math.floor(f[0]/TS);s.y=Math.floor(f[1]/TS)}}
  SPECIAL.push({id:'feri',x:Math.round(isl[0]-4),y:Math.round(isl[1]+.5),label:'Feri ke Pelabuhan'});
  SPECIAL.push({id:'fountain',x:Math.floor(pz[0]),y:Math.floor(pz[1])+2,label:'Pancutan Dataran'});
  // waterfall near river source
  {const t=riv[2];prop('waterfall',t[0]-1,t[1]-1.5,{hh:120,ww:80,solid:1})}
  // farm animals
  {for(const [dx,dy,k] of [[-3,-3,'cow'],[1,-2,'chicken'],[4,1,'goat'],[2,-3,'chicken']])prop('animal',lad[0]+dx,lad[1]+dy,{k,hh:30,ww:20})}
  // ---------- TREES (dense tropical greenery)
  const okTree=(x,y,gap)=>{const X=Math.floor(x),Y=Math.floor(y);if(X<-6||Y<-6||X>MW+5||Y>MH+5)return false;const t=tget(X,Y);if(X>=0&&Y>=0&&X<MW&&Y<MH){if(SOL[ti(X,Y)]||[SEA,FW,PL,DOCK,BRG,SOIL].includes(t))return false}else if(t===SEA)return false;
    for(const p of PATHS)if(dLine(x,y,p.P)<p.hw+(gap||.55))return false;if(dLine(x,y,road)<1.6||dLine(x,y,rail)<1.1)return false;
    for(const b of BLDS){if(x>b.x-1.1&&x<b.x+b.w+1.1&&y>b.y-1.1&&y<b.y+b.h+1.1)return false;if(b.door){if(Math.hypot(x-b.door[0]-.5,y-b.door[1]-.5)<1.8)return false;const dsx=(x-y)-(b.door[0]-b.door[1]),ahead=(x+y)-(b.door[0]+b.door[1]);if(Math.abs(dsx)<2.6&&ahead>-1&&ahead<7)return false}}
    if(Math.hypot(x-pz[0],y-pz[1])<4.4)return false;if(Math.hypot(x-rw[0]-4,y-rw[1])<11&&Math.abs(y-rw[1])<3.5)return false;return true};
  const trees=[];const tree=(x,y,kind,s)=>{if(!okTree(x,y))return;for(const q of trees)if(Math.abs(q[0]-x)<.9&&Math.abs(q[1]-y)<.9)return;trees.push([x,y]);const a=tw(x,y);const sz=kind==='palm'?1:(.85+s*.4);
    STAT.push({t:'tree',kind,s,wb:[x*TS-6,y*TS-6,x*TS+6,y*TS+6],ax:a[0],ay:a[1],ib:[a[0]-60*sz,a[1]-140*sz,a[0]+60*sz,a[1]+16]});const X=Math.floor(x),Y=Math.floor(y);if(X>=0&&Y>=0&&X<MW&&Y<MH)SOL[ti(X,Y)]=1};
  const zone=(x,y)=>{const X=x-y,Yv=(x+y)/2;const u=.5+X/(2*ISO.a),v=.5+(Yv-MW/2)/(2*ISO.b);return[u,v]};
  for(let y=-4;y<MH+4;y+=.85)for(let x=-4;x<MW+4;x+=.85){const jx=x+(R()-.5)*.7,jy=y+(R()-.5)*.7;const [u,v]=zone(jx,jy);
    let dens=.16;if(v<.06||u<.04||v>.96||u>1.08)dens=.78;if(v<-.05)dens=.92;if(u>.76&&u<.9&&v>.38&&v<.62)dens=.4;if(u<.1&&v>.86)dens=.25;
    if(R()>dens)continue;const r=R();let kind='round';
    if(T[ti(Math.max(0,Math.min(MW-1,Math.floor(jx))),Math.max(0,Math.min(MH-1,Math.floor(jy))))]===SAND)kind='palm';else if(v<-.02||u<-.02)kind=r<.75?'forest':'pine';else kind=r<.22?'pink':r<.32?'palm':'round';
    tree(jx,jy,kind,R())}
  // pink blossom accents near paths (like reference)
  for(let i=0;i<90;i++){const p=PATHS[Math.floor(R()*PATHS.length)];if(p.conn)continue;const q=p.P[Math.floor(R()*p.P.length)];const a=R()*TAU,d=p.hw+1+R()*1.2;tree(q[0]+Math.cos(a)*d,q[1]+Math.sin(a)*d,R()<.55?'pink':'round',R())}
  // ---------- ground decals: flower beds / bushes / hibiscus / tufts
  const dec=(k,x,y,o)=>{const a=tw(x,y);GND.dc.push(Object.assign({k,x:a[0],y:a[1],s:R(),bb:[a[0]-30,a[1]-30,a[0]+30,a[1]+20]},o||{}))};
  for(let i=0;i<5200;i++){const x=R()*(MW+8)-4,y=R()*(MH+8)-4;const X=Math.floor(x),Y=Math.floor(y);const t=tget(X,Y);if(t!==G)continue;if(X>=0&&Y>=0&&X<MW&&Y<MH&&SOL[ti(X,Y)])continue;let np=1e9;for(const p of PATHS){const d=dLine(x,y,p.P)-p.hw;if(d<np)np=d}if(np<.25)continue;
    const r=R();if(np<1.3&&r<.55)dec(r<.3?'hib':'bed',x,y);else if(r<.12)dec('bush',x,y);else if(r<.2)dec('flw',x,y);else if(r<.5)dec('tuft',x,y);else if(r<.53)dec('rock',x,y)}
  for(const b of BLDS){if(b.kind==='lighthouse')continue;for(let i=0;i<b.w+b.h;i++){const t=R();const x=t<.5?b.x+R()*b.w:b.x+b.w+.35,y=t<.5?b.y+b.h+.35:b.y+R()*b.h;if(b.door&&Math.hypot(x-b.door[0]-.5,y-b.door[1]-.5)<1.3)continue;if(tget(Math.floor(x),Math.floor(y))===G)dec(R()<.5?'hib':'bed',x,y)}}
  // shadows for buildings
  for(const b of BLDS)shp('bshadow',[[b.x,b.y],[b.x+b.w+(b.top/80),b.y-(b.top/160)],[b.x+b.w+b.top/80,b.y+b.h-b.top/160],[b.x+b.w,b.y+b.h],[b.x,b.y+b.h]],{pad:20});
  // ---------- vehicles on the road + train on rail
  const pl=P=>{let L=0;const cum=[0];for(let i=1;i<P.length;i++){L+=Math.hypot(P[i][0]-P[i-1][0],P[i][1]-P[i-1][1]);cum.push(L)}return{P,L,cum}};
  const rd=pl(road),rl=pl(rail);
  const cc=['#e5484d','#3a86ff','#f2c230','#ffffff','#38b84a','#ff8c42','#8c5cf2'];
  for(let i=0;i<7;i++)VEHS.push({path:rd,t:R()*rd.L,v:(i%2?1:-1)*(2.6+R()*1.2),lane:i%2?.45:-.45,c:cc[i%cc.length],kind:i===0||i===3?'bus':'car'});
  VEHS.push({path:rl,t:rl.L*.3,v:3.2,lane:0,c:'#6a3fd0',kind:'train'});
  OBJS.length=0;
}
