// ===================== REFERENCE HUD BEHAVIOUR =====================
ICON.utama='<svg viewBox="0 0 24 24"><path d="M3 11l9-7 9 7" fill="none" stroke="#ff9f43" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M5.5 10v10h13V10" fill="#fff4dc" stroke="#c8641a" stroke-width="1.6"/><rect x="10" y="14" width="4" height="6" fill="#c8641a"/><rect x="15.5" y="5" width="2.4" height="4" fill="#c8641a"/></svg>';
ICON.belanja='<svg viewBox="0 0 24 24"><path d="M2 4h3l2.4 10.5h11L21 7H6.2" fill="none" stroke="#ff6eb4" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M7 14.5h11.4l1.8-6H6" fill="#ffd0e8"/><circle cx="9" cy="19" r="1.8" fill="#ff6eb4"/><circle cx="17" cy="19" r="1.8" fill="#ff6eb4"/></svg>';
ICON.acara='<svg viewBox="0 0 24 24"><path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.5l1.2-6.5L2.5 9.4l6.6-.9z" fill="#ffd23f" stroke="#c88a1a" stroke-width="1.4" stroke-linejoin="round"/></svg>';
NAV.length=0;NAV.push(['utama','Utama'],['peta','Peta'],['rumah','Rumah'],['kerjaya','Kerjaya'],['pendidikan','Belajar'],['almari','Pakaian'],['belanja','Belanja'],['inventori','Inventori'],['sosial','Sosial'],['pencapaian','Ranking'],['acara','Acara']);
if(!MORE.some(m=>m[0]==='memancing'))MORE.splice(1,0,['memancing','Memancing']);
{const nv=ACT.nav;ACT.nav=v=>{if(v==='utama')return doLagi();if(v==='belanja')return nv('kedai');if(v==='acara')return openPanel('sosial','acara');return nv(v)}}
ACT.hudSave=()=>{if(!S)return;save();toast('Permainan disimpan ✓','g');try{sfx('coin')}catch(e){}};
ACT.enPlus=()=>openPanel('rumah','rehat');
const NAVMAP={kedai:'belanja',sosial:'sosial',pendidikan:'pendidikan',almari:'almari',rumah:'rumah',kerjaya:'kerjaya',inventori:'inventori',pencapaian:'pencapaian',peta:'peta'};
let EVKEY='';
const FEST_NPC={kaamatan:'joanna',gawai:'dayang',raya:'siti',cny:'meiling',deepavali:'kavitha',krismas:'joanna',merdeka:'danial',malaysia:'joanna',makanan:'lim',cuti:'haziq'};
function nextFest(){const t=dateOf(dayIdx());const today=t.m*100+t.d;const list=FESTS.map(f=>({f,k:f[0]*100+f[1]})).sort((a,b)=>a.k-b.k);let n=list.find(x=>x.k>=today)||list[0];const same=list.filter(x=>x.f[2]===n.f[2]&&x.f[0]===n.f[0]&&Math.abs(x.f[1]-n.f[1])<=3);const d0=Math.min(...same.map(x=>x.f[1])),d1=Math.max(...same.map(x=>x.f[1]));const y=n.k>=today?t.y:t.y+1;return{f:n.f,d0,d1,m:n.f[0],y,now:n.k===today}}
function updEvent(){const e=nextFest();const key=e.f[2]+e.m+e.d0+e.y;if(key===EVKEY)return;EVKEY=key;const nm=e.f[3].replace(/ \(Hari \d\)/,'');const mon=MONTHS[e.m-1].slice(0,3);$('#evName').textContent=nm;$('#evDate').textContent=(e.d0===e.d1?`${e.d0} ${mon}`:`${e.d0} – ${e.d1} ${mon}`)+(e.now?' · HARI INI':'');
  const id=FEST_NPC[e.f[2]]||'joanna';const n=RT.npcs.find(x=>x.id===id);const C=n?n.C:S.look;try{$('#evImg').src=headImg(C)}catch(_){}}
{const h1=hud;hud=function(){h1();if(!S)return;const mx=maxEnergy();const eb=$('#hEnBar');if(eb)eb.style.width=Math.max(0,Math.min(100,S.energy/mx*100))+'%';
  const xp=$('#hXpt');if(xp)xp.textContent=`EXP ${S.xp.toLocaleString('en')} / ${xpNeed(S.lvl).toLocaleString('en')}`;
  const lv=$('#hLv');if(lv)lv.innerHTML=`Lv. ${S.lvl}${S.age!=null?` · ${S.age} thn`:''} ${S.state?flagTag(S.state,8):''}`;
  updEvent();const cur=SH.id?(NAVMAP[SH.id]||''):'peta';for(const b of document.querySelectorAll('#nav .nb'))b.classList.toggle('on',b.dataset.v===cur)}}
{const mc=document.getElementById('miniCv');if(mc)mc.addEventListener('click',()=>{if(S&&!RT.paused)openPanel('peta')})}
