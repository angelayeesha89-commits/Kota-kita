// ===================== ISO RENDERER / CAMERA / INPUT =====================
const ICK={chunks:new Map(),spr:new Map(),tree:new Map(),lbl:new Map(),pat:null,blobs:null,mini:null};
function clearIsoCaches(){ICK.chunks.clear();ICK.spr.clear();ICK.tree.clear();ICK.lbl.clear();ICK.pat=null}
RT.pan={x:0,y:0};const XENTS=[],GHOOKS=[],POSTHOOKS=[],SCRHOOKS=[];let LAMPDECOR=null;
function isoPatterns(k){if(ICK.pat&&ICK.pat.k===k)return ICK.pat;
  const mk=(w,h,fn)=>{const cv=document.createElement('canvas');cv.width=Math.ceil(w*k);cv.height=Math.ceil(h*k);const c=cv.getContext('2d');c.scale(cv.width/w,cv.height/h);fn(c,w,h);const p=ctx.createPattern(cv,'repeat');p.setTransform(new DOMMatrix().scale(w/cv.width,h/cv.height));return p};
  const grass=mk(160,80,(c,w,h)=>{c.fillStyle='#7cc64a';c.fillRect(0,0,w,h);const R=seeded(3);for(let i=0;i<26;i++){c.fillStyle=R()<.5?'rgba(70,150,40,.22)':'rgba(170,225,110,.25)';const x=R()*w,y=R()*h,a=8+R()*14;for(const ox of [-w,0,w])for(const oy of [-h,0,h]){c.beginPath();c.ellipse(x+ox,y+oy,a,a*.5,0,0,TAU);c.fill()}}
    for(let i=0;i<200;i++){const x=R()*w,y=R()*h;c.strokeStyle=R()<.5?'#5aa83a':'#a6e070';c.lineWidth=1.1;c.beginPath();c.moveTo(x,y);c.lineTo(x+(R()-.5)*3,y-2.5-R()*3);c.stroke()}});
  const cob=mk(48,24,(c,w,h)=>{c.fillStyle='#b8a07a';c.fillRect(0,0,w,h);const cols=['#efe1c2','#e3cfa6','#d8c29a','#eadabb','#d2bc92'];const R=seeded(8);for(let j=0;j<4;j++)for(let i=-1;i<5;i++){const x=i*12+(j%2?6:0),y=j*6;const p=new Path2D();rrp(p,x+.8,y+.7,10.4,4.8,2.2);c.fillStyle=cols[Math.floor(R()*cols.length)];c.fill(p);c.fillStyle='rgba(255,255,255,.35)';c.fillRect(x+2,y+1.2,6,1)}});
  const plz=mk(64,32,(c,w,h)=>{c.fillStyle='#b9a483';c.fillRect(0,0,w,h);const cols=['#f1e4c8','#e8d6b2','#ddc7a0'];for(let j=0;j<4;j++)for(let i=-1;i<5;i++){const x=i*16+(j%2?8:0),y=j*8;c.fillStyle=cols[(i+j*2+3)%3];c.beginPath();c.moveTo(x+8,y+.8);c.lineTo(x+15.2,y+4);c.lineTo(x+8,y+7.2);c.lineTo(x+.8,y+4);c.closePath();c.fill()}});
  const sea=mk(128,64,(c,w,h)=>{c.clearRect(0,0,w,h);const R=seeded(12);c.strokeStyle='rgba(255,255,255,.45)';c.lineWidth=1.4;for(let i=0;i<10;i++){const x=R()*w,y=R()*h;c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x+5,y-3,x+10,y);c.stroke()}c.fillStyle='rgba(255,255,255,.7)';for(let i=0;i<6;i++){c.fillRect(R()*w,R()*h,2,1)}});
  const soil=mk(40,20,(c,w,h)=>{c.fillStyle='#8a5a33';c.fillRect(0,0,w,h);c.fillStyle='#6f4526';for(let j=0;j<h;j+=5)c.fillRect(0,j,w,2);c.fillStyle='#5cb85c';for(let j=1;j<h;j+=5)for(let i=2;i<w;i+=8){c.fillRect(i,j,3,3)}});
  ICK.pat={k,grass,cob,plz,sea,soil};return ICK.pat}
function blobsG(){if(ICK.blobs)return ICK.blobs;const R=seeded(41),o=[];for(let i=0;i<420;i++){const X=(R()*2-1)*MW*TS,Y=R()*MW*TS,r=70+R()*150;o.push({X,Y,r,c:R()<.55?'rgba(255,240,140,.17)':'rgba(30,110,40,.15)'})}ICK.blobs=o;return o}
function shapePath(c,pts){c.beginPath();c.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)c.lineTo(pts[i][0],pts[i][1]);c.closePath()}
function linePath(c,ptsT){c.beginPath();ptsT.forEach((p,i)=>{const q=tw(p[0],p[1]);i?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1])})}
function drawDecal(c,d){const x=d.x,y=d.y,s=d.s;switch(d.k){
  case 'hib':{c.fillStyle='rgba(20,60,20,.25)';c.beginPath();c.ellipse(x+3,y+2,13,6,0,0,TAU);c.fill();const g=c.createRadialGradient(x-3,y-8,1,x,y-4,13);g.addColorStop(0,'#6cc858');g.addColorStop(1,'#2a7a30');c.fillStyle=g;c.beginPath();c.ellipse(x,y-5,12,8,0,0,TAU);c.fill();
    for(let i=0;i<3;i++){const fx=x-6+i*6+(s-.5)*4,fy=y-8+((i*7+s*10)%5);c.fillStyle=s<.33?'#ff5ea8':s<.66?'#e5302f':'#ff8a3d';for(let p=0;p<5;p++){const a=p/5*TAU;c.beginPath();c.ellipse(fx+Math.cos(a)*2.4,fy+Math.sin(a)*1.6,2,1.4,a,0,TAU);c.fill()}c.fillStyle='#ffe066';c.beginPath();c.arc(fx,fy,1,0,TAU);c.fill()}break}
  case 'bed':{const cols=[['#ff7ab8','#ffd23f'],['#c79bff','#ffffff'],['#ff5e5e','#ffd23f'],['#ff9ad0','#ffffff']][Math.floor(s*4)];c.fillStyle='#3f9a3f';c.beginPath();c.ellipse(x,y-2,14,6,0,0,TAU);c.fill();const R=seeded(Math.floor(s*999));for(let i=0;i<14;i++){c.fillStyle=cols[i%2];c.beginPath();c.arc(x+(R()-.5)*24,y-2+(R()-.5)*9,1.7,0,TAU);c.fill()}break}
  case 'bush':{c.fillStyle='rgba(20,60,20,.25)';c.beginPath();c.ellipse(x+3,y+2,15,6,0,0,TAU);c.fill();const g=c.createRadialGradient(x-4,y-10,1,x,y-6,15);g.addColorStop(0,'#8ad870');g.addColorStop(.6,'#3f9a3f');g.addColorStop(1,'#2a6e2e');c.fillStyle=g;c.beginPath();c.ellipse(x-5,y-6,9,7,0,0,TAU);c.ellipse(x+5,y-6,9,7,0,0,TAU);c.ellipse(x,y-10,9,7,0,0,TAU);c.fill();break}
  case 'flw':{for(let i=0;i<4;i++){c.fillStyle=['#ffffff','#ffd23f','#ff7ab8','#c79bff'][(i+Math.floor(s*4))%4];c.beginPath();c.arc(x+(i-1.5)*4,y+(i%2)*2,1.6,0,TAU);c.fill()}break}
  case 'tuft':{c.strokeStyle=s<.5?'#4f9a35':'#9ad864';c.lineWidth=1.2;c.beginPath();for(let i=-2;i<=2;i++){c.moveTo(x+i*2,y);c.lineTo(x+i*3,y-5-Math.abs(i))}c.stroke();break}
  case 'rock':{c.fillStyle='#9a968c';c.beginPath();c.ellipse(x,y-2,5,3,0,0,TAU);c.fill();c.fillStyle='#c8c4b8';c.beginPath();c.ellipse(x-1,y-3,2.4,1.4,0,0,TAU);c.fill();break}}}
const LAYERS=['field','sea','sand','isl','rock','water','runway','road','rail','bshadow','PS','bridge','dock'];
function drawChunk(ci,cj,k){const CH=ISO.CH,X0=ci*CH,Y0=cj*CH;const cvs=document.createElement('canvas');cvs.width=Math.ceil(CH*k)+1;cvs.height=Math.ceil(CH*k)+1;const c=cvs.getContext('2d');c.setTransform(k,0,0,k,-X0*k,-Y0*k);const pt=isoPatterns(k);const tm=0;
  c.fillStyle=pt.grass;c.fillRect(X0,Y0,CH+2,CH+2);
  for(const b of blobsG()){if(b.X+b.r<X0||b.X-b.r>X0+CH||b.Y+b.r<Y0||b.Y-b.r>Y0+CH)continue;const g=c.createRadialGradient(b.X,b.Y,0,b.X,b.Y,b.r);g.addColorStop(0,b.c);g.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=g;c.fillRect(b.X-b.r,b.Y-b.r*.6,b.r*2,b.r*1.2)}
  const inC=s=>!(s.bb[2]<X0||s.bb[0]>X0+CH||s.bb[3]<Y0||s.bb[1]>Y0+CH);
  const vis=GND.sh.filter(inC);const by=k2=>vis.filter(s=>s.k===k2);
  for(const s of by('field')){shapePath(c,s.pts);c.fillStyle=pt.soil;c.fill();c.strokeStyle='#6b4426';c.lineWidth=2;c.stroke()}
  for(const s of by('sea')){shapePath(c,s.pts);c.lineJoin='round';c.strokeStyle='#f1dc9e';c.lineWidth=78;c.stroke();c.strokeStyle='#e8cc86';c.lineWidth=40;c.stroke();c.fillStyle='#38afe0';c.fill();c.save();c.clip();
    c.strokeStyle='rgba(120,220,235,.75)';c.lineWidth=120;c.stroke();c.strokeStyle='rgba(170,240,240,.8)';c.lineWidth=40;c.stroke();c.strokeStyle='rgba(255,255,255,.95)';c.lineWidth=6;c.stroke();c.fillStyle=pt.sea;c.fillRect(X0,Y0,CH,CH);c.restore()}
  for(const s of by('sand')){shapePath(c,s.pts);c.fillStyle='#f1dc9e';c.fill();c.strokeStyle='rgba(255,255,255,.9)';c.lineWidth=5;c.stroke()}
  for(const s of by('isl')){shapePath(c,s.pts);c.fillStyle=pt.grass;c.fill()}
  for(const s of by('rock')){shapePath(c,s.pts);c.fillStyle='#8a847a';c.fill();c.strokeStyle='rgba(255,255,255,.8)';c.lineWidth=4;c.stroke()}
  for(const s of by('water')){shapePath(c,s.pts);c.lineJoin='round';c.strokeStyle=s.pond?'#cdbda6':'#a89a72';c.lineWidth=12;c.stroke();const g=c.createLinearGradient(s.bb[0],s.bb[1],s.bb[2],s.bb[3]);g.addColorStop(0,'#6fd0f0');g.addColorStop(1,'#2f9ad0');c.fillStyle=g;c.fill();c.save();c.clip();c.strokeStyle='rgba(255,255,255,.35)';c.lineWidth=10;c.stroke();c.fillStyle=pt.sea;c.fillRect(X0,Y0,CH,CH);c.restore();
    if(s.pond){const R=seeded(5);for(let i=0;i<7;i++){const p=s.pts[Math.floor(R()*s.pts.length)];const cx=s.bb[0]+(s.bb[2]-s.bb[0])/2,cy=s.bb[1]+(s.bb[3]-s.bb[1])/2;const x=p[0]+(cx-p[0])*.25,y=p[1]+(cy-p[1])*.25;c.fillStyle='#4fae46';c.beginPath();c.ellipse(x,y,7,3.5,0,0,TAU);c.fill();c.fillStyle='#ff9ad0';c.beginPath();c.arc(x+2,y-1,2,0,TAU);c.fill()}}}
  for(const s of by('runway')){shapePath(c,s.pts);c.fillStyle='#55596a';c.fill();c.strokeStyle='#f4f4f4';c.lineWidth=3;c.stroke();const a=s.tp;const m0=[(a[0][0]+a[3][0])/2,(a[0][1]+a[3][1])/2],m1=[(a[1][0]+a[2][0])/2,(a[1][1]+a[2][1])/2];c.setLineDash([16,14]);linePath(c,[m0,m1]);c.lineWidth=3;c.stroke();c.setLineDash([])}
  for(const s of by('road')){shapePath(c,s.pts);c.lineJoin='round';c.strokeStyle='#d8d0c4';c.lineWidth=10;c.stroke();c.fillStyle='#5d6172';c.fill();linePath(c,s.line);c.setLineDash([12,12]);c.strokeStyle='#f2c230';c.lineWidth=2;c.stroke();c.setLineDash([])}
  for(const s of by('rail')){shapePath(c,s.pts);c.fillStyle='#a49a88';c.fill();const L=s.line;for(let i=0;i<L.length-1;i++){const a=L[i],b=L[i+1],dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1;for(let t=0;t<d;t+=.35){const px=a[0]+dx*t/d,py=a[1]+dy*t/d;const p=tw(px-dy/d*.42,py+dx/d*.42),q=tw(px+dy/d*.42,py-dx/d*.42);c.strokeStyle='#6b5a48';c.lineWidth=3;c.beginPath();c.moveTo(p[0],p[1]);c.lineTo(q[0],q[1]);c.stroke()}}
    for(const off of [-.24,.24]){c.beginPath();L.forEach((p,i)=>{const a=L[Math.max(0,i-1)],b=L[Math.min(L.length-1,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1;const q=tw(p[0]-dy/d*off,p[1]+dx/d*off);i?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1])});c.strokeStyle='#c8ccd4';c.lineWidth=2.2;c.stroke()}}
  for(const s of by('bshadow')){shapePath(c,s.pts);c.fillStyle='rgba(30,40,70,.16)';c.fill()}
  // cobblestone network: borders first, then fills (so junctions merge)
  const ps=vis.filter(s=>s.k==='path'||s.k==='plaza');c.lineJoin='round';
  for(const s of ps){shapePath(c,s.pts);c.strokeStyle='#8a7656';c.lineWidth=9;c.stroke()}
  for(const s of ps){shapePath(c,s.pts);c.strokeStyle='#cdb892';c.lineWidth=4;c.stroke()}
  for(const s of ps){shapePath(c,s.pts);c.fillStyle=s.k==='plaza'?pt.plz:pt.cob;c.fill()}
  for(const s of ps.filter(s=>s.ring)){const ctr=s.tp.reduce((a,p)=>[a[0]+p[0]/s.tp.length,a[1]+p[1]/s.tp.length],[0,0]);for(const [r,col,lw] of [[3.1,'#c8a878',3],[2.4,'#d8bc8a',6],[1.9,'#b9a483',2]]){shapePath(c,circ(ctr[0],ctr[1],r,48).map(p=>tw(p[0],p[1])));c.strokeStyle=col;c.lineWidth=lw;c.stroke()}
    for(let i=0;i<36;i++){const a=i/36*TAU,p=tw(ctr[0]+Math.cos(a)*2.05,ctr[1]+Math.sin(a)*2.05);c.fillStyle=['#ff5ea8','#e5302f','#ffd23f','#c79bff','#ff8a3d','#ffffff'][i%6];c.beginPath();c.arc(p[0],p[1],3,0,TAU);c.fill()}}
  for(const s of by('bridge')){shapePath(c,s.pts);c.fillStyle='#b88a55';c.fill();c.strokeStyle='#7a5530';c.lineWidth=1;c.stroke()}
  for(const s of by('dock')){shapePath(c,s.pts);c.fillStyle='#c08a55';c.fill();c.strokeStyle='#7a5530';c.lineWidth=2;c.stroke();c.save();c.clip();c.strokeStyle='rgba(90,55,30,.5)';c.lineWidth=1;for(let i=-60;i<60;i++){const a=s.tp[0];const p=tw(a[0]-5+i*.25,a[1]-10),q=tw(a[0]-5+i*.25,a[1]+10);c.beginPath();c.moveTo(p[0],p[1]);c.lineTo(q[0],q[1]);c.stroke()}c.restore();for(const q of s.pts){c.fillStyle='#6b4426';c.fillRect(q[0]-2,q[1]-2,4,8)}}
  for(const d of GND.dc){if(d.bb[2]<X0||d.bb[0]>X0+CH||d.bb[3]<Y0||d.bb[1]>Y0+CH)continue;drawDecal(c,d)}
  return cvs}
// ---------- cached sprites
function sprOf(o,k){let s=ICK.spr.get(o);if(s)return s;const pad=40,ib=o.ib,X0=ib[0]-pad,Y0=ib[1]-pad,w=ib[2]-ib[0]+pad*2,h=ib[3]-ib[1]+pad*2;const cvs=document.createElement('canvas');cvs.width=Math.ceil(w*k);cvs.height=Math.ceil(h*k);const c=cvs.getContext('2d');c.setTransform(k,0,0,k,-X0*k,-Y0*k);
  try{if(o.t==='bld'){(BART[o.b.kind]||BART.house)(c,o.b)}else propArt(c,o,0)}catch(e){console.warn('art',o.t,o.b&&o.b.kind,e)}
  s={cv:cvs,x:X0,y:Y0,w,h};ICK.spr.set(o,s);return s}
function treeSpr(kind,s,k){const v=Math.floor(s*6),key=kind+v;let t=ICK.tree.get(key);if(t)return t;const W=150,H=176;const cvs=document.createElement('canvas');cvs.width=Math.ceil(W*k);cvs.height=Math.ceil(H*k);const c=cvs.getContext('2d');c.setTransform(k,0,0,k,W/2*k,(H-22)*k);treeArt(c,kind,v/6+.08);t={cv:cvs,ox:W/2,oy:H-22,w:W,h:H};ICK.tree.set(key,t);return t}
const LIVE={boat:1,flag:1,waterfall:1,fountain:1};
// ---------- labels (reference style pills)
const DISTRICT={perumahan:'Kawasan Kediaman',pasar:'Pasar Tradisional',bandar:'Kafe & Restoran',jeti:'Pantai & Jeti',hospital:'Hospital & Klinik',pejabat:'Pejabat Kerajaan',mall:'Mall',taman:'Taman Awam',pelabuhan:'Kawasan Industri',sekolah:'Sekolah / Kolej / Universiti',stadium:'Stadium & Kompleks Sukan',lrt:'Stesen LRT / MRT',bas:'Terminal BAS',airport:'Lapangan Terbang'};
const LBLCOL={perumahan:'#e8892a',pasar:'#b5651d',bandar:'#8a4a1a',jeti:'#2a9a5a',hospital:'#e5484d',pejabat:'#8a5a33',mall:'#a43ad8',taman:'#3a9a3a',pelabuhan:'#4a6a8a',sekolah:'#6a3fd0',stadium:'#c03a7a',lrt:'#8a5a33',bas:'#c8102e',airport:'#1f3a6b'};
function lblGlyph(c,id,r){c.save();c.fillStyle='#fff';c.strokeStyle='#fff';c.lineWidth=r*.16;c.lineJoin='round';c.lineCap='round';const s=r/10;c.scale(s,s);
  switch(id){case 'perumahan':c.beginPath();c.moveTo(-6,0);c.lineTo(0,-6);c.lineTo(6,0);c.lineTo(4,0);c.lineTo(4,6);c.lineTo(-4,6);c.lineTo(-4,0);c.closePath();c.fill();break;
  case 'pasar':for(let i=0;i<4;i++){c.fillStyle=i%2?'#fff':'#ffd0c0';c.fillRect(-7+i*3.5,-5,3.5,4)}c.fillStyle='#fff';c.fillRect(-6,1,12,5);break;
  case 'bandar':c.beginPath();c.moveTo(-6,-3);c.lineTo(4,-3);c.lineTo(3,5);c.lineTo(-5,5);c.closePath();c.fill();c.lineWidth=1.6;c.beginPath();c.arc(5,0,2.6,-1.3,1.3);c.stroke();break;
  case 'jeti':c.lineWidth=1.8;c.beginPath();c.moveTo(0,6);c.quadraticCurveTo(1,0,0,-4);c.stroke();for(const a of [-2.6,-1.6,-.6,.6]){c.beginPath();c.moveTo(0,-4);c.quadraticCurveTo(Math.cos(a)*5,-4+Math.sin(a)*3-2,Math.cos(a)*8,-4+Math.sin(a)*5+2);c.stroke()}break;
  case 'hospital':c.fillRect(-2.2,-6,4.4,12);c.fillRect(-6,-2.2,12,4.4);break;
  case 'pejabat':c.beginPath();c.moveTo(-7,-2);c.lineTo(0,-7);c.lineTo(7,-2);c.closePath();c.fill();for(const x of [-5,-1.6,1.8,5])c.fillRect(x-.9,-1,1.8,6);c.fillRect(-7,5,14,1.8);break;
  case 'mall':{const p=new Path2D();rrp(p,-5.5,-3,11,9,1.5);c.fill(p);c.lineWidth=1.6;c.beginPath();c.arc(0,-3,3,Math.PI,TAU);c.stroke();break}
  case 'taman':c.beginPath();c.arc(0,-2,5.5,0,TAU);c.fill();c.fillRect(-1,2,2,5);break;
  case 'pelabuhan':c.fillRect(-7,0,14,6);c.beginPath();c.moveTo(-7,0);c.lineTo(-7,-4);c.lineTo(-3,-1);c.lineTo(-3,-4);c.lineTo(1,-1);c.lineTo(1,-4);c.lineTo(5,-1);c.lineTo(5,-7);c.lineTo(7,-7);c.lineTo(7,0);c.fill();break;
  case 'sekolah':c.beginPath();c.moveTo(-8,-2);c.lineTo(0,-6);c.lineTo(8,-2);c.lineTo(0,2);c.closePath();c.fill();c.beginPath();c.moveTo(-4,0);c.lineTo(-4,4);c.quadraticCurveTo(0,7,4,4);c.lineTo(4,0);c.fill();break;
  case 'stadium':c.lineWidth=1.8;c.beginPath();c.ellipse(0,1,7,4.5,0,0,TAU);c.stroke();c.beginPath();c.ellipse(0,1,3.5,2,0,0,TAU);c.fill();c.fillRect(-6,-6,1.4,4);c.fillRect(4.6,-6,1.4,4);break;
  case 'lrt':{const p=new Path2D();rrp(p,-5,-6,10,10,2.5);c.fill(p);c.fillStyle=LBLCOL.lrt;c.fillRect(-3.4,-4.4,6.8,3.6);c.beginPath();c.arc(-2.4,1.8,1,0,TAU);c.arc(2.4,1.8,1,0,TAU);c.fill();c.fillStyle='#fff';c.fillRect(-4,5,1.6,2);c.fillRect(2.4,5,1.6,2);break}
  case 'bas':{const p=new Path2D();rrp(p,-6,-6,12,11,2);c.fill(p);c.fillStyle=LBLCOL.bas;c.fillRect(-4.4,-4.4,8.8,4);c.beginPath();c.arc(-3,2.4,1.1,0,TAU);c.arc(3,2.4,1.1,0,TAU);c.fill();c.fillStyle='#fff';c.fillRect(-5,5,2,2);c.fillRect(3,5,2,2);break}
  case 'airport':c.rotate(-.7);c.beginPath();c.ellipse(0,0,8,1.6,0,0,TAU);c.fill();c.beginPath();c.moveTo(-1,0);c.lineTo(-3,-6);c.lineTo(-1,-6);c.lineTo(3,0);c.lineTo(-1,6);c.lineTo(-3,6);c.closePath();c.fill();c.beginPath();c.moveTo(-7,0);c.lineTo(-8,-3);c.lineTo(-6.6,-3);c.lineTo(-5,0);c.fill();break;
  default:c.font='900 10px Nunito,sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText((LOC[id]?LOC[id].short:'?')[0],0,.5)}
  c.restore()}
function lblSprite(id,text,dpr){const key=id+'|'+text+'|'+dpr;let s=ICK.lbl.get(key);if(s)return s;const main=!!DISTRICT[id];const fs=main?10.5:9.5;const cvs=document.createElement('canvas');const c=cvs.getContext('2d');c.font=`900 ${fs}px Nunito,sans-serif`;
  const words=text.split(' ');let lines=[text];if(c.measureText(text).width>86&&words.length>1){let best=null;for(let i=1;i<words.length;i++){const a=words.slice(0,i).join(' '),b=words.slice(i).join(' ');const m=Math.max(c.measureText(a).width,c.measureText(b).width);if(!best||m<best[0])best=[m,[a,b]]}lines=best[1]}
  const tw2=Math.max(...lines.map(l=>c.measureText(l).width)),ih=main?26:20,h=lines.length>1?(main?30:26):(main?22:18),ir=ih/2,w=tw2+ir+16,W=w+ir+6,H=Math.max(h,ih)+6;
  cvs.width=Math.ceil(W*dpr);cvs.height=Math.ceil(H*dpr);c.scale(dpr,dpr);c.font=`900 ${fs}px Nunito,sans-serif`;
  const bx=ir+2,by=(H-h)/2;c.shadowColor='rgba(40,20,10,.35)';c.shadowBlur=4;c.shadowOffsetY=2;const p=new Path2D();rrp(p,bx,by,w,h,8);const g=c.createLinearGradient(0,by,0,by+h);g.addColorStop(0,'#fffaf0');g.addColorStop(1,'#f1e2c2');c.fillStyle=g;c.fill(p);c.shadowColor='transparent';c.strokeStyle='#6b3a1a';c.lineWidth=2;c.stroke(p);const p2=new Path2D();rrp(p2,bx+2.2,by+2.2,w-4.4,h-4.4,6);c.strokeStyle='rgba(232,182,74,.7)';c.lineWidth=1;c.stroke(p2);
  c.fillStyle='#4a2410';c.textAlign='center';c.textBaseline='middle';const tx=bx+ir+(w-ir)/2+2;lines.forEach((l,i)=>c.fillText(l,tx,H/2+(i-(lines.length-1)/2)*(fs+1)+.5));
  const cx=ir+2,cy=H/2;const rg=c.createLinearGradient(0,cy-ir,0,cy+ir);rg.addColorStop(0,'#ffe58a');rg.addColorStop(1,'#c88a1a');c.fillStyle=rg;c.beginPath();c.arc(cx,cy,ir,0,TAU);c.fill();c.strokeStyle='#6b3a1a';c.lineWidth=1.4;c.stroke();
  const col=LBLCOL[id]||(LOC[id]&&LOC[id].col)||'#6a3fd0';const ig=c.createLinearGradient(0,cy-ir,0,cy+ir);ig.addColorStop(0,shade(col,.25));ig.addColorStop(1,shade(col,-.2));c.fillStyle=ig;c.beginPath();c.arc(cx,cy,ir-3,0,TAU);c.fill();c.translate(cx,cy);lblGlyph(c,id,ir-3);
  s={cv:cvs,w:W,h:H};ICK.lbl.set(key,s);return s}
// ---------- vehicles
function vehAt(v,off){const P=v.path;let t=((v.t+(off||0))%P.L+P.L)%P.L;let i=1;while(i<P.cum.length-1&&P.cum[i]<t)i++;const a=P.P[i-1],b=P.P[i],seg=P.cum[i]-P.cum[i-1]||1,f=(t-P.cum[i-1])/seg;let dx=b[0]-a[0],dy=b[1]-a[1];const d=Math.hypot(dx,dy)||1;dx/=d;dy/=d;if(v.v<0){dx=-dx;dy=-dy}const px=a[0]+(b[0]-a[0])*f,py=a[1]+(b[1]-a[1])*f;return{x:px-dy*v.lane,y:py+dx*v.lane,dx,dy}}
function drawVeh(c,v,p){const L=v.kind==='bus'?2.6:v.kind==='train'?3:1.5,W=v.kind==='car'?.75:.95,H=v.kind==='car'?16:26;const hx=p.dx*L/2,hy=p.dy*L/2,nx=-p.dy*W/2,ny=p.dx*W/2;const C=[[p.x-hx-nx,p.y-hy-ny],[p.x+hx-nx,p.y+hy-ny],[p.x+hx+nx,p.y+hy+ny],[p.x-hx+nx,p.y-hy+ny]];
  ipoly(c,C.map(q=>IP(q[0]+.15,q[1]+.15,0)),'rgba(20,20,40,.25)');
  for(let i=0;i<4;i++){const a=C[i],b=C[(i+1)%4];const nxx=(b[1]-a[1]),nyy=-(b[0]-a[0]);if(nxx+nyy<=0)continue;const lit=(nyy>Math.abs(nxx))?.0:-.18;ipoly(c,[IP(a[0],a[1],3),IP(b[0],b[1],3),IP(b[0],b[1],H),IP(a[0],a[1],H)],shade(v.c,lit),shade(v.c,-.5),.6);
    if(v.kind!=='car'){const n=v.kind==='train'?6:5;for(let j=0;j<n;j++){const t0=(j+.2)/n,t1=(j+.8)/n;const q0=[a[0]+(b[0]-a[0])*t0,a[1]+(b[1]-a[1])*t0],q1=[a[0]+(b[0]-a[0])*t1,a[1]+(b[1]-a[1])*t1];ipoly(c,[IP(q0[0],q0[1],H*.5),IP(q1[0],q1[1],H*.5),IP(q1[0],q1[1],H*.85),IP(q0[0],q0[1],H*.85)],'#bfe3ff')}}}
  ipoly(c,C.map(q=>IP(q[0],q[1],H)),v.kind==='car'?shade(v.c,.2):'#eef2f8',shade(v.c,-.5),.6);
  if(v.kind==='car'){const f=.15,r=.55;const Q=(s,t)=>{const a=[p.x+p.dx*L*(s-.5),p.y+p.dy*L*(s-.5)];return[a[0]+(-p.dy)*W*(t-.5)*.9,a[1]+p.dx*W*(t-.5)*.9]};ipoly(c,[Q(f+.1,0),Q(r+.1,0),Q(r+.1,1),Q(f+.1,1)].map(q=>IP(q[0],q[1],H+.5)),'#9fd0f0','#2a2a3a',.5)}}
// ---------- main render
function isoRender(){
  const k=RT.k,cx=RT.cam.x,cy=RT.cam.y,vw=viewW(),vh=viewH(),tm=performance.now()/1000;const PF=RT.prof||(RT.prof={c:0,s:0,d:0,o:0,n:0});let pt0=performance.now();
  ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#38afe0';ctx.fillRect(0,0,cv.width,cv.height);
  const CHs=ISO.CH,c0=Math.floor(cx/CHs),c1=Math.floor((cx+vw)/CHs),r0=Math.floor(cy/CHs),r1=Math.floor((cy+vh)/CHs);let made=0;const t0=performance.now();
  const cxk=Math.round(cx*k),cyk=Math.round(cy*k);const blit=(im,X,Y)=>ctx.drawImage(im,Math.round(X*k)-cxk,Math.round(Y*k)-cyk);const WT=()=>ctx.setTransform(k,0,0,k,-cxk,-cyk),ID=()=>ctx.setTransform(1,0,0,1,0,0);
  for(let j=r0;j<=r1;j++)for(let i=c0;i<=c1;i++){const key=i+','+j;let ch=ICK.chunks.get(key);if(!ch&&(made<1||performance.now()-t0<14)){ch=drawChunk(i,j,k);ICK.chunks.set(key,ch);made++}
    if(ch)ctx.drawImage(ch,Math.round(i*CHs*k)-cxk,Math.round(j*CHs*k)-cyk);else{ctx.fillStyle='#7cc64a';ctx.fillRect(Math.round((i*CHs-cx)*k),Math.round((j*CHs-cy)*k),Math.ceil(CHs*k)+1,Math.ceil(CHs*k)+1)}}
  if(ICK.chunks.size>(RT.chunkLimit||40)){for(const key of [...ICK.chunks.keys()]){const [i,j]=key.split(',').map(Number);if(i<c0-1||i>c1+1||j<r0-1||j>r1+1)ICK.chunks.delete(key);if(ICK.chunks.size<=(RT.chunkLimit||40))break}}
  PF.c+=performance.now()-pt0;pt0=performance.now();WT();
  const vx0=cx-80,vx1=cx+vw+80,vy0=cy-60,vy1=cy+vh+200;const inV=ib=>!(ib[2]<vx0||ib[0]>vx1||ib[3]<vy0||ib[1]>vy1);
  // spot rings
  for(const s of SPOTS){const a=tw(s.x+.5,s.y+.5);if(a[0]<vx0||a[0]>vx1||a[1]<vy0||a[1]>vy1)continue;ctx.strokeStyle='rgba(255,255,255,.85)';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(a[0],a[1],16+Math.sin(tm*3)*3,8+Math.sin(tm*3)*1.5,0,0,TAU);ctx.stroke()}
  for(const f of GHOOKS)try{f(ctx,tm)}catch(e){}
  if(RT.fest){const pz=SPECIAL.find(s=>s.id==='fountain');if(pz){const cols=['#e5484d','#f2c230','#3a86ff','#38b84a','#ff5ea8'];for(let r=0;r<2;r++){const a0=r?Math.PI*.25:Math.PI*1.25;const pts=[];for(let i=0;i<=20;i++){const a=a0+i/20*Math.PI*.5;pts.push(IP(pz.x+Math.cos(a)*3.6,pz.y-1.5+Math.sin(a)*3.6,60+Math.sin(i/20*Math.PI)*-14))}ctx.strokeStyle='#777';ctx.lineWidth=1;ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.stroke();pts.forEach((p,i)=>{ctx.fillStyle=cols[i%5];ctx.beginPath();ctx.moveTo(p[0]-4,p[1]);ctx.lineTo(p[0]+4,p[1]);ctx.lineTo(p[0],p[1]+8);ctx.fill()})}}}
  // drawables
  const L=[];for(const o of STAT)if(inV(o.ib))L.push(o);
  const ent=e=>{const a=w2s(e.x,e.y);return{t:'ent',e,wb:[e.x-8,e.y-8,e.x+8,e.y+8],ib:[a[0]-24,a[1]-74,a[0]+24,a[1]+6],ax:a[0],ay:a[1]}};
  for(const n of RT.npcs){const a=w2s(n.x,n.y);if(a[0]>vx0&&a[0]<vx1&&a[1]>vy0&&a[1]<vy1)L.push(ent(n))}const pe=ent(P);L.push(pe);
  for(const v of VEHS){const segs=v.kind==='train'?[0,-3.2,-6.4]:[0];for(const off of segs){const p=vehAt(v,off*(v.v<0?-1:1));const a=tw(p.x,p.y);if(a[0]<vx0-100||a[0]>vx1+100||a[1]<vy0||a[1]>vy1)continue;const r=v.kind==='car'?.8:1.4;L.push({t:'veh',v,p,wb:[(p.x-r)*TS,(p.y-r)*TS,(p.x+r)*TS,(p.y+r)*TS],ib:[a[0]-70,a[1]-60,a[0]+70,a[1]+30]})}}
  for(const xe of XENTS){if(xe.hide)continue;const a=w2s(xe.x,xe.y);if(a[0]<vx0-60||a[0]>vx1+60||a[1]<vy0||a[1]>vy1)continue;const r=xe.r||8;L.push({t:'xent',xe,wb:[xe.x-r,xe.y-r,xe.x+r,xe.y+r],ib:[a[0]-(xe.w||30),a[1]-(xe.h||60),a[0]+(xe.w||30),a[1]+12],ax:a[0],ay:a[1]})}
  // depth sort (topological on overlapping pairs)
  const n=L.length;for(const o of L){o._b=null;o._v=0}
  for(let i=0;i<n;i++){const a=L[i],ai=a.ib;for(let j=i+1;j<n;j++){const b=L[j],bi=b.ib;if(ai[2]<bi[0]||bi[2]<ai[0]||ai[3]<bi[1]||bi[3]<ai[1])continue;if(a.t==='tree'&&b.t==='tree'){if(a.ay<b.ay)(b._b||(b._b=[])).push(a);else(a._b||(a._b=[])).push(b);continue}
    const A=a.wb,Bw=b.wb;let aBehind;if(A[2]<=Bw[0]+.5||A[3]<=Bw[1]+.5)aBehind=true;else if(Bw[2]<=A[0]+.5||Bw[3]<=A[1]+.5)aBehind=false;else aBehind=(A[0]+A[2]+A[1]+A[3])<(Bw[0]+Bw[2]+Bw[1]+Bw[3]);
    if(aBehind)(b._b||(b._b=[])).push(a);else(a._b||(a._b=[])).push(b)}}
  L.sort((a,b)=>(a.wb[0]+a.wb[2]+a.wb[1]+a.wb[3])-(b.wb[0]+b.wb[2]+b.wb[1]+b.wb[3]));
  const out=[];const visit=o=>{if(o._v)return;o._v=1;if(o._b)for(const q of o._b)visit(q);out.push(o)};for(const o of L)visit(o);
  PF.s+=performance.now()-pt0;pt0=performance.now();const s=1/k;let pIdx=-1,occl=false;let spent=0;
  for(let i=0;i<out.length;i++){const o=out[i];
    if(o.t==='ent'){const e=o.e;if(e===P){pIdx=i;const veh=RT.ride&&S.ride?VEH[S.ride]:null;ctx.fillStyle='rgba(30,30,60,.25)';ctx.beginPath();ctx.ellipse(o.ax,o.ay,13,5,0,0,TAU);ctx.fill();if(veh&&veh.kind==='car'){drawVeh(ctx,{kind:'car',c:'#8c5cf2'},{x:P.x/TS,y:P.y/TS,dx:P.dir===1||P.dir===3?-.7:.7,dy:P.dir===1||P.dir===0?.7:-.7})}else if(veh)drawVehicleUnder(ctx,o.ax,o.ay,veh.kind,P.dir);
        const sp=charSprite('player',S.look,P.dir,veh?0:P.frame);ID();blit(sp,o.ax-sp.width*s/2,o.ay-sp.height*s+(veh?-6:2));WT()}
      else{ctx.fillStyle='rgba(30,30,60,.22)';ctx.beginPath();ctx.ellipse(o.ax,o.ay,12,4.5,0,0,TAU);ctx.fill();const sp=charSprite(e.id,e.C,e.dir,e.frame);ID();blit(sp,o.ax-sp.width*s/2,o.ay-sp.height*s+2);WT()}continue}
    if(pIdx>=0&&!occl&&o.t!=='veh'){const pi=pe.ib;if(!(o.ib[2]<pi[0]+10||o.ib[0]>pi[2]-10||o.ib[3]<pi[1]+20||o.ib[1]>pi[3]-6))occl=true}
    if(o.t==='veh'){drawVeh(ctx,o.v,o.p);continue}
    if(o.t==='xent'){try{o.xe.draw(ctx,o.ax,o.ay,tm)}catch(e){}continue}
    if(o.t==='tree'){const t=treeSpr(o.kind,o.s,k);ID();blit(t.cv,o.ax-t.ox,o.ay-t.oy);WT();continue}
    if(LIVE[o.t]){propArt(ctx,o,tm);continue}
    let sp=ICK.spr.get(o);if(!sp&&(spent<18||!RT.sprWarm)){const q=performance.now();sp=sprOf(o,k);spent+=performance.now()-q}if(sp){ID();blit(sp.cv,sp.x,sp.y);WT();if(o.t==='lamp'&&LAMPDECOR)try{LAMPDECOR(ctx,o.ax,o.ay,tm)}catch(e){}}}
  RT.sprWarm=true;PF.d+=performance.now()-pt0;pt0=performance.now();
  // ghost the player when hidden behind buildings/trees
  if(occl){ctx.globalAlpha=.42;const sp=charSprite('player',S.look,P.dir,P.frame);ID();blit(sp,pe.ax-sp.width*s/2,pe.ay-sp.height*s+2);WT();ctx.globalAlpha=1}
  if(RT.target){const tg=RT.path&&RT.path.length?RT.path[RT.path.length-1]:RT.target;const a=w2s(tg.x,tg.y);ctx.strokeStyle='#ffd23f';ctx.lineWidth=2.5;ctx.beginPath();ctx.ellipse(a[0],a[1],12,6,0,0,TAU);ctx.stroke()}
  if(RT.near){const nn=RT.near;const wx=nn.kind==='npc'?nn.npc.x:nn.x,wy=nn.kind==='npc'?nn.npc.y:nn.y;const a=w2s(wx,wy);const y=a[1]-(nn.kind==='npc'?84:nn.kind==='loc'?40:30)+Math.sin(tm*6)*2;ctx.fillStyle='#ffd23f';ctx.strokeStyle='#6b3a1a';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(a[0]-8,y-10);ctx.lineTo(a[0]+8,y-10);ctx.lineTo(a[0],y);ctx.closePath();ctx.fill();ctx.stroke()}
  for(const f of POSTHOOKS)try{f(ctx,tm)}catch(e){}
  // ---- screen-space overlays: labels, name tags
  const d=RT.dpr,z=RT.zoom;ctx.setTransform(d,0,0,d,0,0);const toS=(X,Y)=>[(X-cx)*z,(Y-cy)*z];
  const few=ISO.zi<=1;const shown=new Set();
  for(const b of BLDS){if(!b.loc)continue;const main=!!DISTRICT[b.loc];if(few&&!main)continue;if(!main&&!b.label)continue;const ctr=tw(b.x+b.w/2,b.y+b.h/2);const [sx,sy]=toS(ctr[0],ctr[1]-bldTop(b)*.62);if(sx<-120||sx>RT.W+120||sy<-40||sy>RT.H+40)continue;
    const txt=main?DISTRICT[b.loc]:LOC[b.loc].name;const sp=lblSprite(b.loc,txt,d);const lx=sx-sp.w/2+(main?18:10)*1,ly=sy-sp.h/2;ctx.drawImage(sp.cv,lx,ly,sp.w,sp.h);shown.add(b.loc)}
  ctx.font='800 10px Nunito,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';
  for(const nn of RT.npcs){if(!nn.named||few)continue;const dd=Math.hypot(nn.x-P.x,nn.y-P.y);if(dd>200)continue;const a=w2s(nn.x,nn.y);const [sx,sy]=toS(a[0],a[1]-78);const w=ctx.measureText(nn.name).width+10;ctx.fillStyle='rgba(42,31,71,.78)';const p=new Path2D();rrp(p,sx-w/2,sy-7.5,w,15,7);ctx.fill(p);ctx.fillStyle='#fff';ctx.fillText(nn.name,sx,sy+.5);const f=S.friends[nn.id]||0;if(f>0){ctx.fillStyle='#ff5ea8';ctx.fillText('♥'.repeat(Math.min(4,1+Math.floor(f/25))),sx,sy-14)}}
  for(const s2 of SPOTS){const a=tw(s2.x+.5,s2.y+.5);const [sx,sy]=toS(a[0],a[1]-26);if(sx<-80||sx>RT.W+80||sy<-20||sy>RT.H+20)continue;if(ISO.zi<=1)continue;const fs=FISHSPOTS.find(f=>f.id===s2.id);const t='🎣 '+fs.name,w=ctx.measureText(t).width+14;const p=new Path2D();rrp(p,sx-w/2,sy-9,w,18,9);ctx.fillStyle='rgba(31,95,160,.9)';ctx.fill(p);ctx.fillStyle='#fff';ctx.fillText(t,sx,sy+.5)}
  // ---- day/night + weather (screen space, device px)
  ctx.setTransform(1,0,0,1,0,0);
  const hr=(S.time%1440)/60;let dark=0;if(hr>=19.5||hr<5)dark=.5;else if(hr>=18)dark=(hr-18)/1.5*.5;else if(hr<6.5)dark=(6.5-hr)/1.5*.5;
  if(S.weather==='hujan')dark=Math.max(dark,.12);if(S.weather==='ribut')dark=Math.max(dark,.22);else if(S.weather==='mendung')dark=Math.max(dark,.06);
  if(dark>0){ctx.fillStyle=`rgba(14,18,66,${dark})`;ctx.fillRect(0,0,cv.width,cv.height);if(dark>.2){ctx.globalCompositeOperation='lighter';for(const [lx,ly] of LAMPS){const a=tw(lx,ly);const x=(a[0]-cx)*k,y=(a[1]-64-cy)*k;if(x<-100||y<-100||x>cv.width+100||y>cv.height+100)continue;const g=ctx.createRadialGradient(x,y,2,x,y,80*k);g.addColorStop(0,`rgba(255,220,140,${dark*.85})`);g.addColorStop(1,'rgba(255,200,100,0)');ctx.fillStyle=g;ctx.fillRect(x-80*k,y-80*k,160*k,160*k)}ctx.globalCompositeOperation='source-over'}}
  if(S.weather==='ribut'){RT.flT=(RT.flT||0)-1;if(RT.flT<=0){RT.fl=1;RT.flT=180+Math.random()*420}if(RT.fl>0){ctx.fillStyle=`rgba(255,255,240,${RT.fl*.55})`;ctx.fillRect(0,0,cv.width,cv.height);RT.fl-=.08}}
  if(RT.rain.length){ctx.strokeStyle='rgba(200,220,255,.55)';ctx.lineWidth=1.2*RT.dpr;ctx.beginPath();for(const r of RT.rain){ctx.moveTo(r.x*RT.dpr,r.y*RT.dpr);ctx.lineTo((r.x-3)*RT.dpr,(r.y+14)*RT.dpr)}ctx.stroke()}
  for(const f of SCRHOOKS)try{f(ctx,tm,k,cx,cy)}catch(e){}
  if(RT.miniT===undefined||tm-RT.miniT>.4){RT.miniT=tm;drawHudMini()}
  PF.o+=performance.now()-pt0;PF.n++;PF.items=out.length}

// ---------- A* pathfinding for tap-to-walk
function isoPath(sx,sy,tx,ty){const W=MW,H=MH;const free=(x,y)=>x>=0&&y>=0&&x<W&&y<H&&!isSolidTile(x,y);
  if(!free(tx,ty)){let best=null,bd=1e9;for(let r=1;r<5&&!best;r++)for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++){const x=tx+dx,y=ty+dy;if(free(x,y)){const d=Math.hypot(dx,dy);if(d<bd){bd=d;best=[x,y]}}}if(!best)return null;[tx,ty]=best}
  if(!free(sx,sy))return null;const N=W*H,g=new Float32Array(N).fill(1e9),from=new Int32Array(N).fill(-1),closed=new Uint8Array(N);const open=[[0,sx,sy]];g[sy*W+sx]=0;let it=0;
  const push=n=>{open.push(n);let i=open.length-1;while(i>0){const p=(i-1)>>1;if(open[p][0]<=open[i][0])break;[open[p],open[i]]=[open[i],open[p]];i=p}};
  const pop=()=>{const top=open[0],last=open.pop();if(open.length){open[0]=last;let i=0;for(;;){const l=i*2+1,r=l+1;let m=i;if(l<open.length&&open[l][0]<open[m][0])m=l;if(r<open.length&&open[r][0]<open[m][0])m=r;if(m===i)break;[open[m],open[i]]=[open[i],open[m]];i=m}}return top};
  while(open.length&&it++<9000){const [,x,y]=pop();const id=y*W+x;if(closed[id])continue;closed[id]=1;if(x===tx&&y===ty){const out=[];let c=id;while(c!==-1){out.push([c%W,Math.floor(c/W)]);c=from[c]}out.reverse();return out}
    for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]){const nx=x+dx,ny=y+dy;if(!free(nx,ny))continue;if(dx&&dy&&(!free(x+dx,y)||!free(x,y+dy)))continue;const nid=ny*W+nx;const ng=g[id]+(dx&&dy?1.414:1);if(ng<g[nid]){g[nid]=ng;from[nid]=id;push([ng+Math.hypot(tx-nx,ty-ny),nx,ny])}}}
  return null}
function walkTo(wx,wy){const sx=Math.floor(P.x/TS),sy=Math.floor(P.y/TS),tx=Math.floor(wx/TS),ty=Math.floor(wy/TS);const path=isoPath(sx,sy,tx,ty);
  if(path&&path.length>1){const pts=path.slice(1).map(([x,y])=>({x:x*TS+16,y:y*TS+16}));const last=pts[pts.length-1];if(Math.floor(wx/TS)===Math.floor(last.x/TS)&&Math.floor(wy/TS)===Math.floor(last.y/TS)&&!isBlocked(wx,wy))pts[pts.length-1]={x:wx,y:wy};RT.path=pts;RT.target=pts[0]}else{RT.path=null;RT.target={x:wx,y:wy}}}
// ---------- update (movement in world, input in screen space)
function scr2world(ix,iy){return[iy+ix/2,iy-ix/2]}
function isoUpdate(dt){
  let ix=0,iy=0;const K=RT.keys;
  if(K.ArrowLeft||K.KeyA)ix-=1;if(K.ArrowRight||K.KeyD)ix+=1;if(K.ArrowUp||K.KeyW)iy-=1;if(K.ArrowDown||K.KeyS)iy+=1;
  if(RT.joy.on){ix=RT.joy.x;iy=RT.joy.y}
  let wx=0,wy=0;
  if(ix||iy){RT.target=null;RT.path=null;[wx,wy]=scr2world(ix,iy)}
  else if(RT.target){let dx=RT.target.x-P.x,dy=RT.target.y-P.y,d=Math.hypot(dx,dy);if(d<(RT.path&&RT.path.length>1?10:6)){if(RT.path&&RT.path.length>1){RT.path.shift();RT.target=RT.path[0];dx=RT.target.x-P.x;dy=RT.target.y-P.y;d=Math.hypot(dx,dy)}else{RT.target=null;RT.path=null}}if(RT.target&&d>0){wx=dx/d;wy=dy/d;ix=wx-wy;iy=(wx+wy)/2}}
  const mag=Math.hypot(wx,wy);let spd=118*(RT.run?1.55:1);if(RT.ride&&S.ride){const v=VEH[S.ride];if(v&&v.spd)spd=118*v.spd}if(S.energy<=0)spd*=.6;
  if(mag>0){wx/=mag;wy/=mag;const sc=Math.min(1,Math.hypot(ix,iy)||1);const ox=P.x,oy=P.y;const moved=moveEnt(P,wx*spd*dt*Math.max(.35,sc),wy*spd*dt*Math.max(.35,sc));setDir(P,ix,iy);P.moving=true;S.cnt.walk=(S.cnt.walk||0)+Math.hypot(P.x-ox,P.y-oy)/16;
    if(!moved&&RT.target){RT.stuck+=dt;if(RT.stuck>.6){RT.target=null;RT.path=null;RT.stuck=0}}else RT.stuck=0;P.ft+=dt*(RT.ride?6:9);P.frame=Math.floor(P.ft)%4;if(RT.run&&!RT.ride)S.energy=Math.max(0,S.energy-dt*.35);
    RT.pan.x*=Math.max(0,1-dt*4);RT.pan.y*=Math.max(0,1-dt*4)}else{P.moving=false;P.frame=0}
  for(const n of RT.npcs){if(n.talk>0){n.talk-=dt;n.frame=0;continue}
    if(n.wait>0){n.wait-=dt;n.frame=0;if(n.wait<=0){const a=Math.random()*TAU,r=(1+Math.random()*3.5)*TS;n.tx=n.home[0]*TS+16+Math.cos(a)*r;n.ty=n.home[1]*TS+16+Math.sin(a)*r}continue}
    const dx=n.tx-n.x,dy=n.ty-n.y,d=Math.hypot(dx,dy);if(d<4||n.tx==null){n.wait=1+Math.random()*4;continue}
    const s=38*dt;if(!moveEnt(n,dx/d*s,dy/d*s)){n.wait=.5+Math.random()*2}setDir(n,dx-dy,(dx+dy)/2);n.ft+=dt*7;n.frame=Math.floor(n.ft)%4}
  for(const v of VEHS)v.t=((v.t+v.v*dt)%v.path.L+v.path.L)%v.path.L;
  const vw=viewW(),vh=viewH();const a=w2s(P.x,P.y);let tx=a[0]-vw/2+RT.pan.x,ty=a[1]-vh/2-14+RT.pan.y;
  const X0=-MW*TS+40,X1=MW*TS-40,Y0=-40,Y1=MW*TS+40;tx=Math.max(X0,Math.min(X1-vw,tx));ty=Math.max(Y0,Math.min(Y1-vh,ty));if(vw>X1-X0)tx=(X0+X1-vw)/2;if(vh>Y1-Y0)ty=(Y0+Y1-vh)/2;
  if(!RT.camInit||Math.hypot(tx-RT.cam.x,ty-RT.cam.y)>600){RT.cam.x=tx;RT.cam.y=ty;RT.camInit=true}else{const f=Math.min(1,dt*9);RT.cam.x+=(tx-RT.cam.x)*f;RT.cam.y+=(ty-RT.cam.y)*f}
  RT.near=findNear();
  if(S.weather==='hujan'||S.weather==='ribut'){const nr=S.weather==='ribut'?240:140;while(RT.rain.length<nr)RT.rain.push({x:Math.random()*RT.W,y:Math.random()*RT.H,v:500+Math.random()*300});for(const r of RT.rain){r.y+=r.v*dt;r.x-=r.v*dt*.15;if(r.y>RT.H){r.y=-10;r.x=Math.random()*(RT.W+100)}}}else RT.rain.length=0}
function isoResize(){RT.dpr=Math.min(2,pxr());RT.W=STG.w;RT.H=STG.h;const zz=ISO.ZL[ISO.zi]*RT.H/480;const k=Math.max(.25,Math.round(zz*RT.dpr*8)/8);if(k!==RT.k){RT.k=k;clearIsoCaches();spriteCache.clear();RT.sprWarm=false}RT.zoom=RT.k/RT.dpr;cv.width=Math.round(RT.W*RT.dpr);cv.height=Math.round(RT.H*RT.dpr);RT.chunkLimit=Math.max(16,Math.ceil((RT.W/RT.zoom/ISO.CH+2)*(RT.H/RT.zoom/ISO.CH+2)*1.4))}
function setZoom(i){i=Math.max(0,Math.min(ISO.ZL.length-1,i));if(i===ISO.zi)return;ISO.zi=i;if(S)S.zoomI=i;resize();RT.camInit=false;const el=$('#zoomLv');if(el)el.textContent=Math.round(ISO.ZL[i]/ISO.ZL[3]*100)+'%'}
ACT.zoomIn=()=>setZoom(ISO.zi+1);ACT.zoomOut=()=>setZoom(ISO.zi-1);ACT.zoomHome=()=>{RT.pan.x=RT.pan.y=0;RT.camInit=false};
function isoSetupInput(){
  addEventListener('keydown',e=>{if(e.target.tagName==='INPUT'||e.target.tagName==='TEXTAREA'||e.target.tagName==='SELECT')return;RT.keys[e.code]=true;if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].includes(e.code))e.preventDefault();
    if(e.code==='Escape'){if(!$('#dlg').classList.contains('hide'))closeDlg();else if(!$('#sheet').classList.contains('hide'))closeSheet();else if(S&&!$('#game').classList.contains('hide'))ACT.settings();return}
    if(RT.paused)return;if(e.code==='KeyE'||e.code==='Space'||e.code==='Enter')doInteract();if(e.code==='ShiftLeft'||e.code==='ShiftRight')RT.run=true;if(e.code==='KeyM')openPanel('peta');if(e.code==='KeyR')toggleRide();if(e.code==='KeyI')openPanel('inventori');if(e.code==='KeyF')openPanel('memancing');if(e.code==='KeyH')openPanel('rumah');
    if(e.code==='Equal'||e.code==='NumpadAdd')setZoom(ISO.zi+1);if(e.code==='Minus'||e.code==='NumpadSubtract')setZoom(ISO.zi-1)});
  addEventListener('keyup',e=>{RT.keys[e.code]=false;if(e.code==='ShiftLeft'||e.code==='ShiftRight')RT.run=false});addEventListener('blur',()=>{RT.keys={}});
  const joy=$('#joy'),knob=joy.querySelector('i');let jid=null;
  const jmove=e=>{const r=joy.getBoundingClientRect(),sc=r.width/joy.offsetWidth,ccx=r.left+r.width/2,ccy=r.top+r.height/2;let dx=(e.clientX-ccx)/sc,dy=(e.clientY-ccy)/sc;const m=joy.offsetWidth/2-14,dd=Math.hypot(dx,dy);if(dd>m){dx=dx/dd*m;dy=dy/dd*m}knob.style.transform=`translate(${dx}px,${dy}px)`;RT.joy.x=dx/m;RT.joy.y=dy/m;RT.joy.on=Math.hypot(RT.joy.x,RT.joy.y)>.15;RT.run=Math.hypot(RT.joy.x,RT.joy.y)>.95};
  joy.addEventListener('pointerdown',e=>{jid=e.pointerId;joy.setPointerCapture(jid);jmove(e)});joy.addEventListener('pointermove',e=>{if(e.pointerId===jid)jmove(e)});
  const jend=e=>{if(e.pointerId!==jid)return;jid=null;knob.style.transform='';RT.joy.on=false;RT.joy.x=RT.joy.y=0;RT.run=false};joy.addEventListener('pointerup',jend);joy.addEventListener('pointercancel',jend);
  const ptrs=new Map();let down=null,pinch0=0,panStart=null;
  const loc=e=>{const r=cv.getBoundingClientRect();return[(e.clientX-r.left)*RT.W/r.width,(e.clientY-r.top)*RT.H/r.height]};
  cv.addEventListener('pointerdown',e=>{ptrs.set(e.pointerId,loc(e));if(ptrs.size===2){const [a,b]=[...ptrs.values()];pinch0=Math.hypot(a[0]-b[0],a[1]-b[1]);down=null;return}down={x:e.clientX,y:e.clientY,l:loc(e),t:performance.now()};panStart={x:RT.pan.x,y:RT.pan.y};try{cv.setPointerCapture(e.pointerId)}catch(_){}});
  cv.addEventListener('pointermove',e=>{if(!ptrs.has(e.pointerId))return;ptrs.set(e.pointerId,loc(e));if(ptrs.size===2&&pinch0){const [a,b]=[...ptrs.values()];const d=Math.hypot(a[0]-b[0],a[1]-b[1]);if(d/pinch0>1.3){setZoom(ISO.zi+1);pinch0=d}else if(d/pinch0<.77){setZoom(ISO.zi-1);pinch0=d}return}
    if(down&&!RT.paused){const l=loc(e),mx=l[0]-down.l[0],my=l[1]-down.l[1];if(Math.hypot(mx,my)>12){down.drag=true;RT.pan.x=panStart.x-mx/RT.zoom;RT.pan.y=panStart.y-my/RT.zoom;const lim=600;RT.pan.x=Math.max(-lim,Math.min(lim,RT.pan.x));RT.pan.y=Math.max(-lim,Math.min(lim,RT.pan.y))}}});
  const pend=e=>{ptrs.delete(e.pointerId);if(ptrs.size<2)pinch0=0};
  cv.addEventListener('pointercancel',e=>{pend(e);down=null});
  cv.addEventListener('pointerup',e=>{pend(e);if(!down||RT.paused){down=null;return}const dd=down;down=null;if(dd.drag)return;
    const [lx,ly]=loc(e);const X=RT.cam.x+lx/RT.zoom,Y=RT.cam.y+ly/RT.zoom;const [wx,wy]=s2w(X,Y);
    let hit=null,hd=1e9;for(const it of IA){const x=it.kind==='npc'?it.npc.x:it.x,y=it.kind==='npc'?it.npc.y:it.y;const a=w2s(x,y);const dy=it.kind==='npc'?a[1]-30:a[1]-8;const d=Math.hypot(a[0]-X,dy-Y);if(d<40&&d<hd){hd=d;hit=it}}
    if(hit){const x=hit.kind==='npc'?hit.npc.x:hit.x,y=hit.kind==='npc'?hit.npc.y:hit.y;if(Math.hypot(x-P.x,y-P.y)<70){RT.near=hit;doInteract();return}walkTo(x,y+(hit.kind==='npc'?0:14));return}
    walkTo(wx,wy)});
  cv.addEventListener('wheel',e=>{e.preventDefault();if(RT.paused)return;RT.wAcc=(RT.wAcc||0)+e.deltaY;if(RT.wAcc>60){setZoom(ISO.zi-1);RT.wAcc=0}else if(RT.wAcc<-60){setZoom(ISO.zi+1);RT.wAcc=0}},{passive:false})}
// ---------- minimap (HUD + full map panel)
function miniBase(){if(ICK.mini)return ICK.mini;const W=480,H=240;const cvs=document.createElement('canvas');cvs.width=W;cvs.height=H;const c=cvs.getContext('2d');const sc=W/(2*MW*TS);c.setTransform(sc,0,0,sc,W/2,0);
  c.fillStyle='#2f9ad6';c.fillRect(-MW*TS,0,2*MW*TS,MW*TS);const col={[G]:'#78c24a',[SEA]:'#3aa6de',[SAND]:'#f1dc9e',[FW]:'#5cc4e8',[PL]:'#e8d8b4',[SOIL]:'#8a5a33',[DOCK]:'#b47b4a',[BRG]:'#b47b4a'};
  c.lineWidth=1.2/sc;for(let y=0;y<MH;y++)for(let x=0;x<MW;x++){const t=T[ti(x,y)];const cc=col[t]||'#78c24a';ipoly(c,[IP(x,y),IP(x+1,y),IP(x+1,y+1),IP(x,y+1)],cc,cc,1.2/sc)}
  for(const o of STAT)if(o.t==='tree'){c.fillStyle=o.kind==='pink'?'#e07ab0':'#3f8a3a';c.beginPath();c.arc(o.ax,o.ay-10,22,0,TAU);c.fill()}
  for(const b of BLDS){const cc=b.loc?LOC[b.loc].col:'#c8b8a8';ipoly(c,[IP(b.x,b.y),IP(b.x+b.w,b.y),IP(b.x+b.w,b.y+b.h),IP(b.x,b.y+b.h)],cc,'#ffffff',8)}
  ICK.mini={cv:cvs,W,H,sc};return ICK.mini}
function miniView(){const a=UV(-.12,-.18),b=UV(1.12,1.12);const ta=tw(a[0],a[1]),tb=tw(b[0],b[1]);return{X0:-ISO.a*TS*1.25,X1:ISO.a*TS*1.25,Y0:(MW/2-ISO.b*1.35)*TS,Y1:(MW/2+ISO.b*1.35)*TS}}
function drawIsoMap(c,W,H,o){o=o||{};const mb=miniBase(),v=o.full?{X0:-MW*TS*.98,X1:MW*TS*.98,Y0:0,Y1:MW*TS}:miniView();const sx=W/(v.X1-v.X0),sy=H/(v.Y1-v.Y0),s=Math.min(sx,sy);const ox=(W-(v.X1-v.X0)*s)/2-v.X0*s,oy=(H-(v.Y1-v.Y0)*s)/2-v.Y0*s;
  c.fillStyle='#2f9ad6';c.fillRect(0,0,W,H);c.save();c.translate(ox,oy);c.scale(s,s);c.drawImage(mb.cv,-MW*TS,0,2*MW*TS,MW*TS);c.restore();
  const toM=(wx,wy)=>{const a=w2s(wx,wy);return[ox+a[0]*s,oy+a[1]*s]};
  if(o.labels){c.font=`800 ${o.fs||9}px Nunito,sans-serif`;c.textAlign='center';c.textBaseline='middle';for(const l of LOCS){const L=LOC[l[0]];const [px,py]=toM((L.door[0]+.5)*TS,(L.door[1]+.5)*TS);c.fillStyle='#fff';c.beginPath();c.arc(px,py,4.5,0,TAU);c.fill();c.fillStyle=L.col;c.beginPath();c.arc(px,py,3,0,TAU);c.fill();c.lineWidth=3;c.strokeStyle='rgba(255,255,255,.92)';c.strokeText(L.short,px,py-9);c.fillStyle='#2a1f47';c.fillText(L.short,px,py-9)}}
  const [px,py]=toM(P.x,P.y);c.fillStyle='#ffd23f';c.strokeStyle='#6b3a1a';c.lineWidth=2;c.beginPath();c.arc(px,py,o.labels?6:4.2,0,TAU);c.fill();c.stroke();
  if(!o.labels){const vw=viewW(),vh=viewH();c.strokeStyle='rgba(255,255,255,.9)';c.lineWidth=1.2;c.strokeRect(ox+RT.cam.x*s,oy+RT.cam.y*s,vw*s,vh*s)}
  return{s,ox,oy}}
function drawHudMini(){const c=$('#miniCv');if(!c||!S||$('#game').classList.contains('hide'))return;const W=c.clientWidth,H=c.clientHeight;if(!W)return;const d=Math.min(2,pxr());if(c.width!==Math.round(W*d)){c.width=Math.round(W*d);c.height=Math.round(H*d)}const x=c.getContext('2d');x.setTransform(d,0,0,d,0,0);drawIsoMap(x,W,H)}
PANELS.peta.after=function(t){if(t!=='peta')return;const c=$('#mm');const W=c.clientWidth,H=Math.round(W*.56),d=pxr();c.style.height=H+'px';c.width=W*d;c.height=H*d;const x=c.getContext('2d');x.setTransform(d,0,0,d,0,0);const m=drawIsoMap(x,W,H,{labels:1,fs:10});
  c.onclick=e=>{const r=c.getBoundingClientRect(),mx=(e.clientX-r.left)*W/r.width,my=(e.clientY-r.top)*H/r.height;let best=null,bd=22;for(const l of LOCS){const L=LOC[l[0]];const a=w2s((L.door[0]+.5)*TS,(L.door[1]+.5)*TS);const dd=Math.hypot(m.ox+a[0]*m.s-mx,m.oy+a[1]*m.s-my);if(dd<bd){bd=dd;best=L.id}}if(best)openTravel(best)}};
// ---------- building portrait for location scenes / property view
function drawBldPortrait(x,b,cx,baseY,maxW,maxH){const ib=bldIB(b);const w=ib[2]-ib[0],h=ib[3]-ib[1];const s=Math.min(maxW/w,maxH/h);x.save();x.translate(cx-(ib[0]+w/2)*s,baseY-ib[3]*s);x.scale(s,s);try{(BART[b.kind]||BART.house)(x,b)}catch(e){}x.restore();return w*s}
// ---------- NPC remap to new layout + save migration
function remapHome(h){let best=null,bd=1e9;for(const l of LOCS){const d=Math.hypot(h[0]-l[3][0],h[1]-l[3][1]);if(d<bd){bd=d;best=l}}const nd=LOC[best[0]].door;const ox=Math.max(-2.5,Math.min(2.5,h[0]-best[3][0])),oy=Math.max(-1,Math.min(3,h[1]-best[3][1]));return[Math.round(nd[0]+ox),Math.round(nd[1]+1+oy)]}
function isoInitEntities(){RT.npcs=NPCS.map((n,i)=>{const h=remapHome(n[9]);return{id:n[0],name:n[1],role:n[8],C:npcLook(n,i),home:h,x:h[0]*TS+16,y:h[1]*TS+16,dir:0,frame:0,ft:0,wait:Math.random()*3,tx:null,ty:null,line:n[11],likes:n[10],named:1}});
  FOLK.forEach((f,i)=>{const z=remapHome(FOLK_ZONES[i]);RT.npcs.push({id:'folk'+i,name:'Penduduk',role:'Penduduk Kota Kita',C:npcLook([0,'',f[0],f[1],f[2],f[3],f[4],f[5]],i+3),home:z,x:z[0]*TS+16,y:z[1]*TS+16,dir:0,frame:0,ft:0,wait:Math.random()*3,line:FOLK_LINES[i%FOLK_LINES.length],named:0})});
  for(const n of RT.npcs){if(isBlocked(n.x,n.y)){const f=findFree(Math.floor(n.x/TS),Math.floor(n.y/TS));n.x=f[0];n.y=f[1];n.home=[Math.floor(f[0]/TS),Math.floor(f[1]/TS)]}}RT.cars=[]}
genWorld=isoGen;render=isoRender;update=isoUpdate;resize=isoResize;setupInput=isoSetupInput;initEntities=isoInitEntities;
{const sg=startGame;startGame=function(fresh){if(S&&S.zoomI!=null)ISO.zi=Math.max(0,Math.min(ISO.ZL.length-1,S.zoomI));sg(fresh);if(S&&S.mapV!==2){S.mapV=2;placePlayerAt(homeLoc());save()}RT.camInit=false;resize();const el=$('#zoomLv');if(el)el.textContent=Math.round(ISO.ZL[ISO.zi]/ISO.ZL[3]*100)+'%'}}
