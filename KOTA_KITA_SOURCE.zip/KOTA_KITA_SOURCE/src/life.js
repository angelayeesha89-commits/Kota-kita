// ===================== AGE · STATE · EDUCATION BACKGROUND · ADULT CAREERS =====================
const AGE_GROUPS=[['13–17','Pelajar Sekolah Menengah',13,17],['18–20','Pelajar Kolej / Asasi',18,20],['21–25','Pelajar Universiti / Dewasa Muda',21,25],['26–35','Dewasa',26,35],['36–45','Dewasa Matang',36,45],['46–60','Dewasa Senior',46,60]];
const ageGroup=a=>AGE_GROUPS.findIndex(g=>a>=g[2]&&a<=g[3]);
// id,name,towns,food,outfit[m,f],culture,event[m,d,name]
const STATES=[
['johor','Johor',['Johor Bahru','Muar','Batu Pahat','Kluang','Segamat','Pontian','Kota Tinggi','Mersing','Kulai','Tangkak'],'Laksa Johor',['t2','t3'],'Zapin & kuda kepang',[4,22,'Pesta Zapin Johor']],
['kedah','Kedah',['Alor Setar','Sungai Petani','Kulim','Langkawi','Jitra','Baling','Pendang','Yan','Kuala Kedah'],'Laksa Kedah',['t1','t7'],'Jelapang padi negara',[3,5,'Pesta Menuai Padi Kedah']],
['kelantan','Kelantan',['Kota Bharu','Pasir Mas','Tanah Merah','Machang','Kuala Krai','Gua Musang','Tumpat','Bachok','Pasir Puteh'],'Nasi Kerabu',['t5','t6'],'Wau, dikir barat & songket',[6,18,'Pesta Wau Kelantan']],
['melaka','Melaka',['Bandar Melaka','Alor Gajah','Jasin','Masjid Tanah','Ayer Keroh','Merlimau'],'Asam Pedas Melaka',['t38','t11'],'Warisan Peranakan & dondang sayang',[4,18,'Pesta Warisan Melaka']],
['nsembilan','Negeri Sembilan',['Seremban','Port Dickson','Kuala Pilah','Nilai','Rembau','Tampin','Bahau','Jelebu'],'Masak Lemak Cili Api',['t40','t39'],'Adat Perpatih & seni bina Minangkabau',[7,7,'Pesta Adat Perpatih']],
['pahang','Pahang',['Kuantan','Temerloh','Bentong','Raub','Pekan','Jerantut','Kuala Lipis','Cameron Highlands','Rompin'],'Gulai Tempoyak Ikan Patin',['t1','t3'],'Tasik & hutan hujan',[5,12,'Pesta Gulai Tempoyak Pahang']],
['perak','Perak',['Ipoh','Taiping','Teluk Intan','Kuala Kangsar','Lumut','Sitiawan','Batu Gajah','Kampar','Tanjung Malim'],'Rendang Tok',['t1','t3'],'Labu sayong & kopi putih Ipoh',[9,5,'Pesta Labu Sayong Perak']],
['perlis','Perlis',['Kangar','Arau','Padang Besar','Kuala Perlis','Simpang Empat'],'Pulut Mangga Harumanis',['t1','t3'],'Mangga harumanis',[5,5,'Pesta Harumanis Perlis']],
['penang','Pulau Pinang',['George Town','Butterworth','Bukit Mertajam','Balik Pulau','Bayan Lepas','Nibong Tebal','Kepala Batas'],'Asam Laksa Pulau Pinang',['t10','t9'],'Warisan George Town & chingay',[2,25,'Perarakan Chingay Pulau Pinang']],
['sabah','Sabah',['Kota Kinabalu','Penampang','Sandakan','Tawau','Lahad Datu','Keningau','Papar','Ranau','Tuaran','Kota Belud','Kudat','Beaufort','Semporna','Sipitang','Tenom'],'Hinava',['t19','t20'],'Kaamatan & Regatta Lepa',[4,27,'Regatta Lepa Sabah']],
['sarawak','Sarawak',['Kuching','Miri','Sibu','Bintulu','Kapit','Sri Aman','Limbang','Sarikei','Mukah','Betong','Lawas'],'Laksa Sarawak',['t27','t28'],'Gawai & rumah panjang',[7,10,'Pesta Muzik Hutan Hujan Sarawak']],
['selangor','Selangor',['Shah Alam','Petaling Jaya','Klang','Kajang','Subang Jaya','Rawang','Sepang','Kuala Selangor','Banting'],'Satay Kajang',['t1','t3'],'Kelip-kelip Kuala Selangor',[8,8,'Festival Kelip-kelip Selangor']],
['terengganu','Terengganu',['Kuala Terengganu','Kemaman','Dungun','Besut','Marang','Setiu','Hulu Terengganu'],'Keropok Lekor & Nasi Dagang',['t5','t6'],'Songket & batik Terengganu',[6,25,'Pesta Songket Terengganu']],
['kl','Kuala Lumpur',['Bukit Bintang','Kepong','Cheras','Setapak','Bangsar','Wangsa Maju','Sentul','Titiwangsa'],'Nasi Lemak',['t1','t3'],'Bandar raya pelbagai budaya',[10,3,'Festival Seni Kuala Lumpur']],
['putrajaya','Putrajaya',['Presint 1','Presint 8','Presint 9','Presint 11','Presint 14','Presint 16'],'Nasi Lemak Kukus',['t1','t3'],'Taman & festival bunga',[6,10,'Floria Putrajaya']],
['labuan','Labuan',['Bandar Labuan','Layang-Layangan','Kiansam','Rancha-Rancha','Sungai Lada'],'Ambuyat',['t1','t3'],'Pulau maritim',[8,20,'Pesta Laut Labuan']],
].map(s=>({id:s[0],name:s[1],towns:s[2],food:s[3],outfit:s[4],culture:s[5],ev:s[6]}));
const STATE=Object.fromEntries(STATES.map(s=>[s.id,s]));
const STATE_NAMES={johor:['Ahmad Faiz','Nur Aina','Kamal','Siti Hajar','Tan Boon Huat','Rosli'],kedah:['Che Mat','Mek Yam','Azlan','Nor Fazila','Lim Chee Keong','Shuib'],kelantan:['Wan Hafiz','Nik Aisyah','Che Su','Tengku Amir','Mek Nab','Ku Faris'],melaka:['Baba Kenneth','Nyonya Lily','Hamid','Mariam','Joseph de Costa','Azura'],nsembilan:['Nizam','Rabiah','Hj. Kassim','Suhaila','Ravi','Ong Mei Fen'],pahang:['Zulkifli','Hamidah','Saring','Noraini','Wong Kah Wai','Jamil'],perak:['Raja Azman','Puteri Hani','Lee Siew Mei','Muthu','Kamarul','Zaleha'],perlis:['Syed Hakim','Sharifah Nora','Ismail','Rohana','Chong Wei','Hairul'],penang:['Ah Seng','Mei Yee','Mohd Arif','Saraswathy','Teoh Kok Leong','Nadia'],sabah:['Jefferson','Juliana','Awang','Siti Rahmah','Clarence','Aini'],sarawak:['Jugah','Linda Ngau','Dayang Salmah','Awang Rahman','Wong Siew Ling','Mering'],selangor:['Hafizuddin','Amira','Kumar','Jessica Tan','Izzat','Farah'],terengganu:['Mat Ali','Wan Nor','Ku Zul','Asma','Pak Long Hassan','Rohaya'],kl:['Daniel','Sarah Lim','Haikal','Priya Nair','Marcus','Liyana'],putrajaya:['Aqil','Dahlia','Firdaus','Hanis','Jeremy','Nabila'],labuan:['Pengiran Hamid','Dayang Rosnah','Awang Kassim','Sabrina','Kelvin','Norhayati']};
const PERSONAS=['Peramah','Pendiam','Kelakar','Rajin','Kreatif','Kaki sukan','Penyayang','Bercita-cita tinggi','Tenang','Suka menolong'];

// ---- official state & federal territory flags (2:1), drawn procedurally
function drawStateFlag(c,id,w,h){
  const RED='#d71920',YEL='#ffcc00',BLU='#0b2d8c',WHT='#ffffff',BLK='#111111';
  const R=(x,y,ww,hh,col)=>{c.fillStyle=col;c.fillRect(x,y,ww,hh)};
  const star=(cx,cy,ro,ri,n,col,rot)=>{c.fillStyle=col;c.beginPath();for(let k=0;k<n*2;k++){const a=(rot==null?-Math.PI/2:rot)+k*Math.PI/n,r=k%2?ri:ro;c.lineTo(cx+Math.cos(a)*r,cy+Math.sin(a)*r)}c.closePath();c.fill()};
  // crescent opening towards the fly (dir 1) or upwards (dir 'up')
  const cres=(cx,cy,r,col,dir)=>{const ox=dir==='up'?0:r*.38,oy=dir==='up'?-r*.38:0;c.save();c.beginPath();c.arc(cx,cy,r,0,TAU);c.clip();c.beginPath();c.arc(cx,cy,r,0,TAU);c.arc(cx+ox,cy+oy,r*.84,0,TAU,true);c.fillStyle=col;c.fill('evenodd');c.restore()};
  const cresStar=(cx,cy,r,col,n)=>{cres(cx,cy,r,col);star(cx+r*.72,cy,r*.58,r*(n>5?.3:.24),n||5,col)};
  switch(id){
  case 'johor':R(0,0,w,h,'#0d1f6e');R(0,0,w/2,h/2,RED);cresStar(w*.21,h*.25,h*.17,WHT,5);break;
  case 'kedah':{R(0,0,w,h,RED);const cx=w*.22,cy=h*.27,r=h*.2;
    c.strokeStyle=YEL;c.lineWidth=h*.035;for(const s of [-1,1]){c.beginPath();c.arc(cx,cy,r,Math.PI*(s<0?.6:.4),Math.PI*(s<0?1.45:-.45),s>0);c.stroke();
      for(let i=0;i<5;i++){const a=Math.PI*(s<0?.65+i*.17:.35-i*.17);c.fillStyle=YEL;c.beginPath();c.ellipse(cx+Math.cos(a)*r,cy+Math.sin(a)*r,h*.035,h*.016,a+Math.PI/2+s*.5,0,TAU);c.fill()}}
    cres(cx,cy+r*.45,r*.42,'#2a9a3a','up');
    c.fillStyle=YEL;c.beginPath();c.moveTo(cx-r*.42,cy-r*.6);c.lineTo(cx+r*.42,cy-r*.6);c.lineTo(cx+r*.42,cy-r*.05);c.quadraticCurveTo(cx+r*.42,cy+r*.35,cx,cy+r*.45);c.quadraticCurveTo(cx-r*.42,cy+r*.35,cx-r*.42,cy-r*.05);c.closePath();c.fill();break}
  case 'kelantan':{R(0,0,w,h,RED);const cx=w/2,cy=h*.55;c.strokeStyle=WHT;c.lineCap='round';
    c.lineWidth=h*.03;for(const s of [-1,1]){c.beginPath();c.moveTo(cx-s*h*.34,cy+h*.3);c.lineTo(cx+s*h*.3,cy-h*.34);c.stroke();star(cx+s*h*.32,cy-h*.36,h*.06,h*.025,4,WHT,Math.PI/4*(s>0?1:-1)-Math.PI/2)}
    c.lineWidth=h*.045;for(const s of [-1,1]){c.beginPath();c.moveTo(cx-s*h*.26,cy+h*.3);for(let t=0;t<=1;t+=.1){const x=cx-s*h*.26+s*h*.42*t,y=cy+h*.3-h*.52*t;c.lineTo(x+Math.sin(t*18)*h*.018,y)}c.stroke();c.fillStyle=WHT;c.fillRect(cx-s*h*.3-h*.03,cy+h*.26,h*.06,h*.08)}
    cres(cx,cy-h*.02,h*.16,WHT,'up');star(cx,cy-h*.24,h*.075,h*.032,5,WHT);break}
  case 'melaka':R(0,0,w,h/2,RED);R(0,h/2,w,h/2,WHT);R(0,0,w/2,h/2,'#0d1f6e');cresStar(w*.21,h*.25,h*.16,YEL,5);break;
  case 'nsembilan':R(0,0,w,h,YEL);c.fillStyle=RED;c.beginPath();c.moveTo(0,0);c.lineTo(w/2,0);c.lineTo(w/2,h/2);c.closePath();c.fill();c.fillStyle=BLK;c.beginPath();c.moveTo(0,0);c.lineTo(w/2,h/2);c.lineTo(0,h/2);c.closePath();c.fill();break;
  case 'pahang':R(0,0,w,h/2,WHT);R(0,h/2,w,h/2+1,BLK);break;
  case 'perak':R(0,0,w,h/3,WHT);R(0,h/3,w,h/3,YEL);R(0,h*2/3,w,h/3+1,BLK);break;
  case 'perlis':R(0,0,w,h/2,YEL);R(0,h/2,w,h/2+1,'#1c3f94');break;
  case 'penang':{R(0,0,w/3,h,'#79c1ea');R(w/3,0,w/3,h,WHT);R(w*2/3,0,w/3+1,h,YEL);const cx=w/2,by=h*.86;
    c.fillStyle='#2e8b3a';c.beginPath();c.ellipse(cx,by,w*.1,h*.06,0,Math.PI,TAU);c.fill();
    c.strokeStyle='#3f7a2a';c.lineWidth=h*.045;c.beginPath();c.moveTo(cx,by-h*.02);c.quadraticCurveTo(cx+h*.03,h*.5,cx,h*.26);c.stroke();
    c.fillStyle='#2e8b3a';for(let i=0;i<7;i++){const a=Math.PI*(1.05+i*.15);c.save();c.translate(cx,h*.26);c.rotate(a);c.beginPath();c.ellipse(h*.15,0,h*.16,h*.035,0,0,TAU);c.fill();c.restore()}
    c.fillStyle='#e8a317';for(const dx of [-1,1]){c.beginPath();c.arc(cx+dx*h*.03,h*.31,h*.022,0,TAU);c.fill()}break}
  case 'sabah':{R(0,0,w,h/3,'#2f86c8');R(0,h/3,w,h/3,WHT);R(0,h*2/3,w,h/3+1,'#cf1f2e');R(0,0,w/2,h*2/3,'#a5d8f3');
    c.fillStyle='#1b3f9a';c.beginPath();c.moveTo(w*.02,h*.62);c.lineTo(w*.1,h*.5);c.lineTo(w*.15,h*.47);c.lineTo(w*.19,h*.38);c.lineTo(w*.215,h*.41);c.lineTo(w*.24,h*.33);c.lineTo(w*.265,h*.39);c.lineTo(w*.29,h*.35);c.lineTo(w*.31,h*.4);c.lineTo(w*.34,h*.38);c.lineTo(w*.38,h*.47);c.lineTo(w*.43,h*.52);c.lineTo(w*.48,h*.62);c.closePath();c.fill();break}
  case 'sarawak':{R(0,0,w,h,YEL);const L=Math.hypot(w,h),ux=w/L,uy=h/L,nx=-uy,ny=ux,t=h*.21;
    const band=(o0,o1,col)=>{c.fillStyle=col;c.beginPath();c.moveTo(nx*o0,ny*o0);c.lineTo(w+nx*o0,h+ny*o0);c.lineTo(w+nx*o1,h+ny*o1);c.lineTo(nx*o1,ny*o1);c.closePath();c.fill()};
    band(-t,0,RED);band(0,t,BLK);star(w*.26,h*.26,h*.19,h*.095,9,YEL,Math.atan2(-h,-w));break}
  case 'selangor':R(0,0,w/2,h/2,RED);R(w/2,0,w/2,h/2,YEL);R(0,h/2,w/2,h/2,YEL);R(w/2,h/2,w/2,h/2,RED);cresStar(w*.21,h*.25,h*.16,WHT,5);break;
  case 'terengganu':R(0,0,w,h,WHT);R(h*.1,h*.1,w-h*.2,h*.8,BLK);cresStar(w*.46,h*.5,h*.2,WHT,5);break;
  case 'kl':{const s=h/3/7;for(let i=0;i<7;i++){R(0,i*s,w,s+.5,i%2?RED:WHT);R(0,h*2/3+i*s,w,s+.5,i%2?RED:WHT)}R(0,h/3,w,h/3,'#10287e');cresStar(w*.18,h/2,h*.13,YEL,14);break}
  case 'labuan':R(0,0,w,h/3,RED);R(0,h/3,w,h/3,WHT);R(0,h*2/3,w,h/3+1,'#0b3a86');cresStar(w*.46,h/2,h*.13,YEL,14);break;
  case 'putrajaya':{R(0,0,w,h,'#11206b');R(w/4,0,w/2,h,YEL);const cx=w/2,cy=h*.55,s=h*.16;
    cres(cx-s*.1,cy-s*2.05,s*.5,'#d4a20c');star(cx+s*.38,cy-s*2.05,s*.32,s*.15,14,'#d4a20c');
    const sh=new Path2D();sh.moveTo(cx-s,cy-s*1.3);sh.lineTo(cx+s,cy-s*1.3);sh.lineTo(cx+s,cy+s*.3);sh.quadraticCurveTo(cx+s,cy+s*1.2,cx,cy+s*1.4);sh.quadraticCurveTo(cx-s,cy+s*1.2,cx-s,cy+s*.3);sh.closePath();
    c.save();c.clip(sh);R(cx-s,cy-s*1.3,s*2,s*.6,'#c8102e');R(cx-s,cy-s*.7,s,s*1.2,'#1c3f94');R(cx,cy-s*.7,s,s*1.2,WHT);R(cx-s,cy+s*.5,s*2,s,YEL);c.restore();c.strokeStyle='#7a5a00';c.lineWidth=h*.012;c.stroke(sh);
    for(const d of [-1,1]){c.fillStyle='#e07b1a';c.beginPath();c.ellipse(cx+d*s*1.45,cy-s*.2,s*.32,s*.95,d*.25,0,TAU);c.fill();c.beginPath();c.arc(cx+d*s*1.55,cy-s*1.15,s*.3,0,TAU);c.fill();c.strokeStyle=BLK;c.lineWidth=h*.012;for(let k=0;k<3;k++){c.beginPath();c.moveTo(cx+d*s*1.2,cy-s*(.7-k*.45));c.lineTo(cx+d*s*1.7,cy-s*(.6-k*.45));c.stroke()}}
    c.fillStyle='#d4a20c';c.fillRect(cx-s*1.5,cy+s*1.45,s*3,s*.25);break}
  }
}
function flagImg(id){const k='flag2'+id;let u=imgCache.get(k);if(u)return u;const c=document.createElement('canvas');c.width=160;c.height=80;const x=c.getContext('2d');drawStateFlag(x,id,160,80);x.strokeStyle='rgba(0,0,0,.18)';x.lineWidth=2;x.strokeRect(1,1,158,78);u=c.toDataURL();imgCache.set(k,u);return u}
const flagTag=(id,h)=>id?`<img src="${flagImg(id)}" alt="" style="height:${h||16}px;width:auto;aspect-ratio:2;border-radius:3px;vertical-align:middle;box-shadow:0 0 0 1px rgba(0,0,0,.12)">`:'';

// ---- extra qualification types
LEVEL.stpm={id:'stpm',name:'STPM',rank:2};LEVEL.tvet={id:'tvet',name:'Sijil Kemahiran (TVET)',rank:2};QRANK.stpm=2;QRANK.tvet=2;
COURSE.stpm='Tingkatan Enam';
INST.t6={id:'t6',name:'Kolej Tingkatan Enam',abbr:'T6',tier:'awam',courses:[],levels:[],col:'#5a5a6a',em:'6'};
INST.ikk={id:'ikk',name:'Institut Kemahiran Kota Kita',abbr:'IKK',tier:'awam',courses:[],levels:[],col:'#7a4a22',em:'IK'};
const QUAL_NAME={none:'Persekolahan asas (tiada SPM)',spm:'SPM',stpm:'STPM',sijil:'Sijil',tvet:'Sijil Kemahiran (TVET)',diploma:'Diploma',ijazah:'Ijazah Sarjana Muda',sarjana:'Sarjana',phd:'PhD'};
const degName=d=>`${LEVEL[d.level].name}${d.level==='stpm'?'':' '+(COURSE[d.course]||'')}`;
const instName=id=>(INST[id]&&INST[id].name)||'—';

// ---- random, age-appropriate education background
const OTHER_JOBS=['Juruwang','Pembantu Kedai','Operator Kilang','Pengawal Keselamatan','Pemandu Penghantaran','Kerani','Pembantu Restoran','Eksekutif Jualan','Pembantu Tadbir','Pekerja Ladang'];
const EMP_GENERIC=['Syarikat Niaga Kita','Kilang Elektronik Harmoni','Pasar Raya Segar','Restoran Selera Kita','Harmoni Holdings','Logistik Nusantara'];
function wpick(list){let t=list.reduce((a,b)=>a+b[1],0),r=Math.random()*t;for(const x of list){if((r-=x[1])<0)return x[0]}return list[0][0]}
function genBg(age){
  const opts=age<=18?[['spm',85],['none',15]]:age<=20?[['spm',45],['none',8],['stpm',20],['sijil',12],['tvet',15]]:age<=25?[['none',5],['spm',22],['stpm',8],['sijil',10],['tvet',12],['diploma',23],['ijazah',age>=22?20:0]]:age<=35?[['none',5],['spm',18],['stpm',6],['sijil',8],['tvet',12],['diploma',20],['ijazah',22],['sarjana',age>=26?7:0],['phd',age>=30?2:0]]:[['none',8],['spm',22],['stpm',5],['sijil',8],['tvet',12],['diploma',18],['ijazah',18],['sarjana',7],['phd',2]];
  const top=wpick(opts.filter(o=>o[1]>0));
  const spm=top==='none'?null:wpick([[3,1],[4,2],[5,3],[6,3],[7,3],[8,2],[9,1],[10,.4]]);
  const degrees=[],cg=()=>Math.round(rnd(2.3,3.9)*100)/100;
  const crs=['bus','acc','it','cs','eng','edu','com','tour','hosp','art','agri','env','law','nurse','ai','arch','sport','fish','culi'];
  const instFor=(lv,c)=>{const ok=INSTS.filter(i=>i.levels.includes(lv)&&i.courses.includes(c));if(!ok.length)return 'ukk';return wpick(ok.map(i=>[i.id,i.tier==='awam'?6:i.tier==='tajaan'?3:1.5]))};
  let gradAge=17;
  if(top==='stpm'){degrees.push({level:'stpm',course:'stpm',inst:'t6',cgpa:cg()});gradAge=19}
  if(top==='sijil'||top==='tvet'){const c=pick(top==='tvet'?['eng','it','hosp','culi','agri','art']:['bus','it','hosp','acc','tour']);degrees.push({level:top,course:c,inst:top==='tvet'?'ikk':'kkk',cgpa:cg()});gradAge=19}
  let field=pick(crs);
  if(['diploma','ijazah','sarjana','phd'].includes(top)){
    if(top==='diploma'||Math.random()<.35){const c=field==='med'?'nurse':field;degrees.push({level:'diploma',course:c,inst:instFor('diploma',c),cgpa:cg()});gradAge=20}
    if(['ijazah','sarjana','phd'].includes(top)){if(Math.random()<.08)field='med';degrees.push({level:'ijazah',course:field,inst:instFor('ijazah',field),cgpa:cg()});gradAge=field==='med'?24:23}
    if(['sarjana','phd'].includes(top)){degrees.push({level:'sarjana',course:field,inst:instFor('sarjana',field),cgpa:Math.max(3,cg())});gradAge=25}
    if(top==='phd'){degrees.push({level:'phd',course:field,inst:instFor('phd',field),cgpa:Math.max(3.3,cg())});gradAge=29}
  }
  const expYears=Math.max(0,Math.round((age-gradAge)*rnd(.4,.95)*10)/10);
  const history=[];let left=expYears;
  if(left>=.5){const n=Math.min(3,1+Math.floor(left/5));for(let i=0;i<n&&left>.2;i++){const yrs=i===n-1?left:Math.round(left*rnd(.3,.6)*10)/10;left=Math.round((left-yrs)*10)/10;
    const fit=FT_JOBS.filter(J=>QRANK[J[2]]<=(top==='none'?0:QRANK[top]||1)&&(!J[3]||degrees.some(d=>J[3].includes(d.course))));
    const J=fit.length&&Math.random()<.7?pick(fit):null;history.push({title:J?J[8][Math.min(3,Math.floor(yrs/4))]:pick(OTHER_JOBS),emp:J?pick(EMPLOYERS[J[0]]||EMP_GENERIC):pick(EMP_GENERIC),years:yrs,type:'Sepenuh masa'})}}
  return{top,spm,degrees,expYears,history};
}
function bgSummary(bg){const hi=bg.degrees.length?degName(bg.degrees[bg.degrees.length-1]):bg.spm!=null?`SPM (${bg.spm}A)`:QUAL_NAME.none;
  return`<div class="kv"><span>Kelayakan tertinggi</span><b>${esc(hi)}</b>${bg.spm!=null?`<span>SPM</span><b>${bg.spm}A</b>`:''}${bg.degrees.map(d=>`<span>${esc(LEVEL[d.level].name)}</span><b>${d.level==='stpm'?'':esc(COURSE[d.course]||'')+' · '}${esc(INST[d.inst]?INST[d.inst].abbr:'')} · ${d.level==='stpm'?'PNGK':'CGPA'} ${d.cgpa.toFixed(2)}</b>`).join('')}<span>Pengalaman kerja</span><b>${bg.expYears} tahun</b></div>${bg.history.length?`<p style="font-size:12px;margin:6px 0 0">${bg.history.map(h=>`${esc(h.title)} — ${esc(h.emp)} (${h.years} thn)`).join('<br>')}</p>`:''}`}

// ---- new jobs & meta
FT_JOBS.push(['sales','Eksekutif Jualan','spm',null,2200,6000,'9:00–18:00','mall',['Eksekutif Jualan','Eksekutif Kanan','Pengurus Jualan','Pengarah Jualan'],'📈🤝📞💼🛍️📊'],
 ['hr','Pegawai Sumber Manusia','ijazah',['bus','com'],3000,8000,'9:00–18:00','kerjaya',['Pegawai HR','Eksekutif HR Kanan','Pengurus HR','Pengarah HR'],'🗂️🤝📝📅💼📞'],
 ['tech','Juruteknik','sijil',['eng','it'],2000,4500,'8:00–17:00','pelabuhan',['Juruteknik','Juruteknik Kanan','Penyelia Teknikal','Ketua Juruteknik'],'🔧⚙️🔩🛠️⚡🔌'],
 ['officeast','Pembantu Pejabat','spm',null,1700,2800,'8:00–17:00','pejabat',['Pembantu Pejabat','Pembantu Tadbir','Kerani Kanan','Penyelia Pejabat'],'📁🖨️📞📋✉️🗂️']);
PT_JOBS.push(['cservice','Pembantu Khidmat Pelanggan',9,14,'mall','','📞💬🧾🙂📦🛍️'],['seller','Penjual Online',10,30,'any','phone','📦🛒📱💬🧾🚚']);
PT_JOBS.find(j=>j[0]==='waiter')[1]='Krew Restoran';PT_JOBS.find(j=>j[0]==='photo')[1]='Jurugambar Bebas';
const PTMETA={barista:[16,'7:00 pg – 11:00 mlm','Pagi / Petang'],cashier:[16,'10:00 pg – 10:00 mlm','Pagi / Malam'],retail:[16,'10:00 pg – 10:00 mlm','Syif 4 jam'],waiter:[16,'11:00 pg – 11:00 mlm','Tengah hari / Malam'],kitchen:[18,'10:00 pg – 10:00 mlm','Syif dapur'],event:[16,'Hujung minggu','Ikut acara'],promoter:[16,'10:00 pg – 9:00 mlm','Hujung minggu'],tutor:[15,'3:00 ptg – 9:00 mlm','Selepas sekolah'],ridefood:[18,'Fleksibel','Bila-bila masa'],rideparcel:[18,'8:00 pg – 8:00 mlm','Fleksibel'],creator:[16,'Fleksibel','Fleksibel'],photo:[16,'Fleksibel','Ikut tempahan'],library:[15,'9:00 pg – 6:00 ptg','Pagi / Petang'],cinema:[16,'11:00 pg – 12:00 mlm','Petang / Malam'],hotelast:[18,'Syif 24 jam','Pagi / Malam'],market:[16,'8:00 pg – 10:00 mlm','Pagi / Petang'],cafe:[16,'7:00 pg – 6:00 ptg','Pagi'],stallast:[16,'5:00 ptg – 12:00 mlm','Malam'],cservice:[18,'9:00 pg – 9:00 mlm','Syif 4 jam'],seller:[16,'Fleksibel','Dari rumah']};
const FTAGE={doctor:[23,60],lawyer:[23,60],architect:[23,60],pilot:[21,55],police:[18,40],fire:[18,40],teacher:[22,60],default:[18,60]};
const ftAge=id=>FTAGE[id]||FTAGE.default;
const EMPLOYERS={nurse:['Hospital Kota Kita','Klinik Kesihatan Kota Kita','Pusat Perubatan Harmoni'],doctor:['Hospital Kota Kita','Pusat Perubatan Harmoni'],teacher:['SMK Kota Kita','SK Taman Harmoni','Sekolah Antarabangsa Rivermere'],police:['Polis Diraja Malaysia'],fire:['Jabatan Bomba dan Penyelamat'],ptd:['Pejabat Daerah Kota Kita','Majlis Bandaraya Kota Kita'],civil:['Majlis Bandaraya Kota Kita','Jabatan Pendidikan Negeri','Pejabat Tanah Kota Kita'],officeast:['Pejabat Daerah Kota Kita','Harmoni Holdings'],bank:['Bank Kota Kita','Bank Nusantara Berhad'],hotel:['Resort Pulau Peranginan','Hotel Seri Kota'],hotelmgr:['Resort Pulau Peranginan','Hotel Seri Kota'],chef:['Restoran Selera Kita','Resort Pulau Peranginan','Dewan Makan Asia Mall'],accountant:['Firma Audit Tan & Rakan','Harmoni Holdings'],engineer:['Pelabuhan Kota Kita','Kejuruteraan Borneo Sdn Bhd'],tech:['Pelabuhan Kota Kita','Kejuruteraan Borneo Sdn Bhd','Kota Kita Digital'],it:['Harmoni Tech Solutions','Kota Kita Digital Sdn Bhd'],designer:['Studio Kreatif Kita','Pemasaran Asia Mall'],journalist:['Berita Kota Kita','Suara Borneo'],pharma:['Farmasi Sihat','Hospital Kota Kita'],vet:['Jabatan Perkhidmatan Veterinar','Klinik Haiwan Kita'],lawyer:['Tetuan Rahman & Wong','Tetuan Kumar & Rakan'],architect:['Arkitek Nusantara','Reka Bina Sdn Bhd'],pilot:['Kota Air','Borneo Wings'],bizmgr:['Harmoni Holdings','Asia Mall Sdn Bhd'],sales:['Asia Mall Sdn Bhd','Syarikat Niaga Kita','Kenderaan Jaya Motor'],hr:['Harmoni Holdings','Kota Kita Digital Sdn Bhd']};
const ENTRY=['officeast','sales','civil','police','fire','hotel','chef','tech'];

// ---- NPC profiles
const NPC_PROF={aiman:[21,'selangor','SPM (8A)','Pelajar Ijazah Sains Komputer, UKK',['Barista sambilan (1 tahun)'],'Kelakar'],siti:[20,'kelantan','SPM (9A)','Pelajar Diploma Pendidikan, SBSU',['Tutor sambilan'],'Rajin'],meiling:[27,'penang','Ijazah Seni Reka, AGU','Pereka grafik sepenuh masa',['Pereka pelatih (2 tahun)'],'Kreatif'],arjun:[26,'perak','Ijazah Kejuruteraan, UKK','Jurutera muda sepenuh masa',['Jurutera pelatih (1 tahun)'],'Bercita-cita tinggi'],priya:[31,'selangor','Ijazah Perubatan','Doktor sepenuh masa',['Pegawai perubatan siswazah (2 tahun)'],'Penyayang'],jason:[34,'johor','Diploma Perniagaan','Bekerja sendiri — kedai online',['Eksekutif jualan (5 tahun)'],'Peramah'],nurul:[29,'terengganu','Ijazah Pendidikan, SBSU','Guru sepenuh masa',['Guru sandaran (1 tahun)'],'Rajin'],danial:[28,'kedah','SPM (6A)','Pegawai polis sepenuh masa',['Konstabel (6 tahun)'],'Tenang'],kavitha:[30,'nsembilan','Ijazah Farmasi','Ahli farmasi sepenuh masa',['Pembantu farmasi (2 tahun)'],'Penyayang'],ahkeong:[58,'melaka','Persekolahan asas','Nelayan — bekerja sendiri',['Nelayan pantai (35 tahun)'],'Pendiam'],joanna:[25,'sabah','Diploma Pelancongan, USN','Pemandu pelancong sambilan, sedang mencari kerja tetap',['Krew acara (2 tahun)'],'Peramah'],mering:[45,'sarawak','SPM (4A)','Petani — bekerja sendiri',['Pekerja ladang (15 tahun)'],'Rajin'],faridah:[52,'kedah','SPM (5A)','Peniaga pasar — bekerja sendiri',['Tukang masak kantin (10 tahun)'],'Penyayang'],haziq:[17,'perak','Tingkatan 5','Pelajar sekolah',[],'Kaki sukan'],lim:[33,'penang','Sijil Kulinari (TVET)','Chef sepenuh masa',['Pembantu dapur (4 tahun)'],'Kreatif'],rajesh:[36,'perak','SPM (5A)','Ahli bomba sepenuh masa',['Pengawal keselamatan (3 tahun)'],'Tenang'],aisyah:[28,'johor','Diploma Seni Reka Fesyen','Pemilik butik',['Pembantu kedai (3 tahun)'],'Bercita-cita tinggi'],farhan:[24,'pahang','Ijazah Sains Sukan','Jurulatih sambilan, menganggur (mencari kerja tetap)',['Jurulatih gim sambilan'],'Kaki sukan'],dayang:[23,'sarawak','Diploma Seni Persembahan','Penari budaya separuh masa',['Krew acara'],'Kreatif'],ken:[39,'sabah','Diploma Perhutanan','Renjer hutan sepenuh masa',['Pemandu pelancong (5 tahun)'],'Pendiam'],mei:[22,'kl','STPM','Pempengaruh media — bekerja sendiri',['Promoter sambilan'],'Peramah'],hafiz:[60,'melaka','SPM','Pesara & ketua kampung',['Kerani kerajaan (30 tahun)'],'Penyayang'],siew:[47,'melaka','SPM','Pemilik kedai',['Juruwang (8 tahun)'],'Peramah'],amir:[26,'selangor','SPM (5A)','Rider sambilan, sedang memohon kerja tetap',['Rider penghantaran (3 tahun)'],'Rajin']};
function folkProfile(i){const r=seeded(i*77+3);const age=18+Math.floor(r()*44);const st=STATES[Math.floor(r()*STATES.length)].id;const ed=pick2(r,age<20?['SPM','SPM','STPM']:['SPM','SPM','Diploma','Ijazah','Sijil Kemahiran (TVET)','Persekolahan asas','STPM','Sarjana']);
  const stt=age>=58?'Pesara':pick2(r,['Menganggur, mencari kerja','Pekerja sambilan','Pemilik perniagaan kecil','Profesional sepenuh masa','Pekerja kilang sepenuh masa','Pelajar IPT','Penjawat awam']);
  return[age,st,ed,stt,[pick2(r,OTHER_JOBS)+` (${1+Math.floor(r()*8)} tahun)`],pick2(r,PERSONAS)]}
function pick2(r,a){return a[Math.floor(r()*a.length)]}
function npcProfile(n){return NPC_PROF[n.id]||n.prof}
function assignFolk(){const st=S&&S.state||'selangor';const names=[...(STATE_NAMES[st]||[]),...STATE_NAMES.kl,...STATE_NAMES.sabah];RT.npcs.filter(n=>!n.named).forEach((n,i)=>{n.name=names[i%names.length];n.prof=folkProfile(i+(st.length*13));if(i<4)n.prof[1]=st});IA=interactables()}
function profileHTML(n){const p=npcProfile(n);if(!p)return'';return`<details style="margin-top:8px"><summary style="cursor:pointer;font-weight:800;color:var(--pur3)">Profil ${esc(n.name)}</summary><div class="kv" style="margin-top:6px"><span>Umur</span><b>${p[0]} tahun</b><span>Negeri</span><b>${flagTag(p[1],13)} ${esc(STATE[p[1]].name)}</b><span>Pendidikan</span><b>${esc(p[2])}</b><span>Status</span><b>${esc(p[3])}</b><span>Personaliti</span><b>${esc(p[5])}</b><span>Kerjaya lalu</span><b>${esc(p[4].join(', ')||'—')}</b></div></details>`}

// ---- player helpers
function expYears(){let y=(S.exp||[]).reduce((a,e)=>a+(+e.years||0),0)+(S.job?S.job.shifts/250:0);for(const k in S.ptSkill)y+=S.ptSkill[k]/2000;return Math.round(y*10)/10}
function empStatus(){if(S.age!=null&&S.age<18)return'Pelajar sekolah';const st=[];if(S.job)st.push('Bekerja sepenuh masa');else if(Object.keys(S.biz).length)st.push('Bekerja sendiri');else if((S.lastPT!=null&&S.lastPT>=dayIdx()-7)||Object.keys(S.ptHired||{}).length)st.push('Bekerja sambilan');if(!S.job&&(S.japps||[]).some(a=>['dihantar','semakan','senarai','temuduga','tawaran'].includes(a.status)))st.push('Mencari kerja');if(!st.length)st.push(S.edu?'Pelajar':'Menganggur');if(S.edu&&!st.includes('Pelajar'))st.push('Belajar');return st.join(' · ')}
function occupation(){if(S.job){const J=FT_JOBS.find(j=>j[0]===S.job.id);return`${J[8][S.job.lvl]} — ${S.job.emp||EMPLOYERS[J[0]]&&EMPLOYERS[J[0]][0]||J[1]}`}const b=Object.keys(S.biz);if(b.length)return'Usahawan: '+b.map(x=>BIZ.find(y=>y[0]===x)[1]).join(', ');const h=Object.keys(S.ptHired||{});if(h.length)return'Sambilan: '+h.map(x=>PT_JOBS.find(y=>y[0]===x)[1]).join(', ');return S.edu?'Pelajar':'—'}
function trackInc(k,n){const t=dateOf(dayIdx()),key=t.y+'-'+t.m;if(!S.incM||S.incM.k!==key){if(S.incM)S.incLast=S.incM;S.incM={k:key,pt:0,ft:0,biz:0}}S.incM[k]+=n}
function topQualText(){const q=bestQual();if(!q.q)return S.age<18?`Tingkatan ${S.school.form||5}`:QUAL_NAME.none;if(q.q==='spm')return`SPM (${S.spm}A)`;const d=S.degrees.filter(x=>x.level===q.q).pop();return d?degName(d):QUAL_NAME[q.q]}
const isMinor=()=>S&&S.age!=null&&S.age<18;

// ---- apply profile at creation
const MAINQ_TEEN=[['Masuk ke Rumah Anda',s=>s.visited.perumahan,100,3],['Bercakap dengan seorang penduduk',s=>(s.cnt.talk||0)>=1,80,2],['Hadiri 3 kelas di sekolah',s=>s.cnt.classes>=3,120,3],['Cuba aktiviti memancing',s=>s.cnt.fish>=1,120,3],['Kerja ringan (15+) atau bersukan sekali',s=>s.cnt.shifts>=1||(s.cnt.sport||0)>=1,120,3],['Naik tingkatan atau duduki SPM',s=>(s.school.form||5)>(s.school.form0||5)||s.spm!=null,200,5],['Masak satu hidangan',s=>s.cnt.cook>=1,120,3],['Lawati 10 lokasi',s=>Object.keys(s.visited).length>=10,250,5],['Dapat keputusan SPM',s=>s.spm!=null,400,10],['Mohon ke universiti atau kolej',s=>s.apps.length>0,300,8],['Capai Tahap 10',s=>s.lvl>=10,600,12]];
const MAINQ_ADULT=[['Masuk ke Rumah Anda',s=>s.visited.perumahan,100,3],['Lengkapkan resume di Pusat Kerjaya',s=>s.resume&&s.resume.done,120,3],['Mohon 2 jawatan kosong',s=>(s.cnt.apply||0)>=2,150,4],['Siapkan kerja sambilan pertama',s=>s.cnt.shifts>=1,150,3],['Hadiri temu duga',s=>(s.cnt.interview||0)>=1,200,5],['Dapat kerja sepenuh masa',s=>!!s.job,400,10],['Simpan RM5,000 di bank',s=>s.bank>=5000,400,8],['Capai Tahap 5',s=>s.lvl>=5,300,8],['Miliki kenderaan atau rumah',s=>s.vehicles.length>0||s.home.owned,500,10],['Naik pangkat',s=>s.job&&s.job.lvl>=1,600,12],['Buka perniagaan sendiri',s=>Object.keys(s.biz).length>0,600,12],['Capai Tahap 15',s=>s.lvl>=15,1000,20]];
function mainQ(){return S&&S.mqSet==='teen'?MAINQ_TEEN:S&&S.mqSet==='adult'?MAINQ_ADULT:MAINQ}
function applyProfile(P0){
  S.age=P0.age;S.state=P0.state;S.town=P0.town;S.resState=P0.state;S.japps=[];S.exp=[];S.ptHired={};S.resume={obj:'',langs:['Bahasa Melayu'],done:false};S.profileSet=1;S.msgs=[];
  if(P0.age<18){S.stage='sekolah';S.school={classes:0,form:clamp(P0.age-12,1,5)};S.school.form0=S.school.form;S.spm=null;S.money=250;S.mqSet='teen';
    addMsg('Mak','Selamat datang ke Kota Kita!',`Assalamualaikum ${S.name}! Rajin-rajin ke sekolah ya. Kamu di Tingkatan ${S.school.form}. Kerja ringan seperti tutor atau pembantu perpustakaan dibenarkan selepas sekolah, maksimum 4 jam pada waktu siang.`);}
  else{const bg=P0.bg;S.spm=bg.spm;S.degrees=bg.degrees.map(d=>Object.assign({day:dayIdx()},d));S.exp=bg.history.map(h=>Object.assign({},h));S.bgTop=bg.top;S.stage='dewasa';
    const a=P0.age;S.money=a<=20?600:a<=25?1200:a<=35?1800:3000;S.bank=a<=25?0:a<=35?2500:a<=45?8000:15000;S.mqSet=a<=25?'young':'adult';
    stat('karisma',Math.min(25,Math.floor((a-18)/2)));if(a>=46)stat('cergas',-5);
    addMsg('Pusat Kerjaya','Selamat datang, pencari kerja!',`Anda belum mempunyai kerja tetap. Kemas kini resume, semak Jawatan Kosong di Pusat Kerjaya dan hantar permohonan. Sementara menunggu, anda boleh bekerja sambilan.`);
    addMsg('Keluarga','Selamat datang ke Kota Kita!',`Semoga dimurahkan rezeki di bandar baharu, ${S.name}. Kami di ${P0.town}, ${STATE[P0.state].name} sentiasa doakan kamu.`);
    if(S.spm==null)addMsg('SMK Kota Kita','Calon Persendirian SPM','Anda boleh mendaftar sebagai calon persendirian SPM di Sekolah Menengah untuk meningkatkan kelayakan.')}
  rollVacancies(dayIdx());rollMissions(dayIdx());
}

// ---- creator: profile tab
function crInitProfile(){CR.age=21;CR.state=CR.state||'selangor';CR.town=STATE[CR.state].towns[0];CR.bg=genBg(21)}
function profilEditor(){
  const gi=ageGroup(CR.age),g=AGE_GROUPS[gi];const ages=[];for(let a=g[2];a<=g[3];a++)ages.push(a);
  return`<div class="chead">Kumpulan Umur</div><div class="list stagebox">${AGE_GROUPS.map((x,i)=>`<button class="opt ${gi===i?'on':''}" data-a="crAgeG" data-v="${i}"><b>${x[0]} tahun</b><span style="font-weight:600;color:var(--mut)">${x[1]}</span></button>`).join('')}</div>
  <div class="chead">Umur Tepat</div><div class="opts">${ages.map(a=>`<button class="opt ${CR.age===a?'on':''}" data-a="crAge" data-v="${a}">${a}</button>`).join('')}</div>
  <div class="chead">Negeri Asal</div><div class="opts">${STATES.map(s=>`<button class="opt ${CR.state===s.id?'on':''}" data-a="crState" data-v="${s.id}" style="display:flex;gap:6px">${flagTag(s.id,14)}${esc(s.name)}</button>`).join('')}</div>
  <div class="chead">Kampung Halaman</div><div class="opts">${STATE[CR.state].towns.map(t=>`<button class="opt ${CR.town===t?'on':''}" data-a="crTown" data-v="${esc(t)}">${esc(t)}</button>`).join('')}</div>
  <div class="note" style="margin-top:8px">${flagTag(CR.state,18)} <b>${esc(STATE[CR.state].name)}</b> · Makanan: ${esc(STATE[CR.state].food)} · Budaya: ${esc(STATE[CR.state].culture)}</div>
  ${CR.age<18?`<div class="chead">Pendidikan</div><div class="note">Bermula sebagai pelajar <b>Tingkatan ${clamp(CR.age-12,1,5)}</b> di SMK Kota Kita. Kerja dewasa tidak dibenarkan untuk bawah 18 tahun.</div>`:`<div class="chead">Latar Pendidikan (Rawak)</div><div class="card">${bgSummary(CR.bg)}<button class="btn w" data-a="crBg">Jana Semula Latar</button></div><p style="font-size:12px;color:var(--mut)">Watak dewasa bermula tanpa kerja tetap — mohon melalui Pusat Kerjaya.</p>`}`;
}
{const le=lookEditor;lookEditor=function(L,tab,ctxName){if(tab==='profil')return ctxName==='creator'?profilEditor():'';return le(L,tab,ctxName)}}
ACT.crAgeG=v=>{const g=AGE_GROUPS[+v];CR.age=g[2]+Math.floor((g[3]-g[2])/2);if(CR.age>=18)CR.bg=genBg(CR.age);renderCreator()};
ACT.crAge=v=>{CR.age=+v;if(CR.age>=18)CR.bg=genBg(CR.age);renderCreator()};
ACT.crState=v=>{CR.state=v;CR.town=STATE[v].towns[0];renderCreator()};
ACT.crTown=v=>{CR.town=v;renderCreator()};
ACT.crBg=()=>{CR.bg=genBg(CR.age);renderCreator()};
ACT.crStart=()=>{const n=($('#cName').value||'').trim()||pick(CR.look.g==='m'?NAMES_M:NAMES_F);CR.name=n.slice(0,18);newSave(Object.assign({},CR.look),CR.name,CR.age<18?'sekolah':'dewasa');applyProfile({age:CR.age,state:CR.state,town:CR.town,bg:CR.bg});startGame(true)};

// ---- one-time profile setup for older saves
const PS={};
function needsProfile(){return S&&(S.age==null||!S.state)}
function showProfileSetup(){
  if(PS.age==null){const minor=S.stage==='sekolah';PS.age=minor?17:(S.degrees.some(d=>d.level==='ijazah')?24:21);PS.state='selangor';PS.town='Shah Alam'}
  const minor=S.stage==='sekolah';const groups=AGE_GROUPS.map((g,i)=>[g,i]).filter(([g])=>minor?g[2]<18:g[2]>=18);const gi=ageGroup(PS.age),g=AGE_GROUPS[gi];const ages=[];for(let a=g[2];a<=g[3];a++)ages.push(a);
  showDlg({wide:true,title:'Lengkapkan Profil Watak',body:`<p style="margin-top:0">Kemas kini baharu: watak kini mempunyai umur, negeri asal dan kampung halaman. Kemajuan anda tidak akan dipadam.</p>
   <div class="stat">Kumpulan umur<div class="opts">${groups.map(([x,i])=>`<button class="opt ${gi===i?'on':''}" data-a="psSet" data-v="g:${i}">${x[0]}</button>`).join('')}</div></div>
   <div class="stat" style="margin-top:6px">Umur<div class="opts">${ages.map(a=>`<button class="opt ${PS.age===a?'on':''}" data-a="psSet" data-v="a:${a}">${a}</button>`).join('')}</div></div>
   <div class="stat" style="margin-top:6px">Negeri asal<div class="opts">${STATES.map(s=>`<button class="opt ${PS.state===s.id?'on':''}" data-a="psSet" data-v="s:${s.id}" style="display:flex;gap:5px">${flagTag(s.id,12)}${esc(s.name)}</button>`).join('')}</div></div>
   <div class="stat" style="margin-top:6px">Kampung halaman<div class="opts">${STATE[PS.state].towns.map(t=>`<button class="opt ${PS.town===t?'on':''}" data-a="psSet" data-v="t:${esc(t)}">${esc(t)}</button>`).join('')}</div></div>`,
   buttons:[{label:'Simpan Profil',cls:'g',a:'psSave'}]});
}
ACT.psSet=v=>{const [k,...r]=v.split(':'),x=r.join(':');if(k==='g'){const g=AGE_GROUPS[+x];PS.age=g[2]+Math.floor((g[3]-g[2])/2)}if(k==='a')PS.age=+x;if(k==='s'){PS.state=x;PS.town=STATE[x].towns[0]}if(k==='t')PS.town=x;showProfileSetup()};
ACT.psSave=()=>{S.age=PS.age;S.state=PS.state;S.town=PS.town;S.resState=PS.state;S.profileSet=1;
  if(S.age>=18&&S.spm==null&&!S.degrees.length&&S.stage!=='sekolah'){const bg=genBg(S.age);S.spm=bg.spm;S.degrees=bg.degrees;S.exp=bg.history}
  if(S.age<18&&S.stage==='sekolah'&&!S.school.form)S.school.form=5;
  if(S.job&&!S.job.emp){const J=FT_JOBS.find(j=>j[0]===S.job.id);S.job.emp=(EMPLOYERS[J[0]]||EMP_GENERIC)[0]}
  assignFolk();closeDlg();save();toast('Profil disimpan!','g');hud()};
function migrateLife(){const d={japps:[],exp:[],ptHired:{},resume:{obj:'',langs:['Bahasa Melayu'],done:false}};for(const k in d)if(S[k]==null)S[k]=d[k];
  for(const k in S.ptSkill)if(S.ptSkill[k]>0)S.ptHired[k]=1;if(S.school&&S.stage==='sekolah'&&!S.school.form)S.school.form=5;if(!S.mqSet)S.mqSet='young';if(S.stage==='lepasan'&&S.age!=null&&S.age>=18&&!S.edu)S.stage='dewasa'}
{const cont=ACT.cont;ACT.cont=()=>{const s=loadSave();if(!s)return;S=s;migrate();migrateLife();startGame(false);if(needsProfile())setTimeout(showProfileSetup,350)}}
{const sg=startGame;startGame=function(f){sg(f);assignFolk()}}

// ---- age restrictions
{const w=(name,fn)=>{const o=ACT[name];ACT[name]=(v,el)=>fn(o,v,el)};
 w('bizStart',(o,v)=>{if(isMinor()){toast('Perniagaan hanya untuk 18 tahun ke atas.','r');return}o(v)});
 w('moveHouse',(o,v)=>{if(isMinor()&&!v.startsWith('keluarga')){toast('Sewa/beli rumah untuk 18 tahun ke atas.','r');return}o(v)});
 w('buyVeh',(o,v)=>{const need={moto:16,kompak:17,suv:17,mewah:17,bot:18}[v]||0;if(S.age!=null&&S.age<need){toast(`Perlu berumur ${need} tahun (lesen) untuk ${VEH[v].name}.`,'r');return}o(v)});
 w('applyInst',(o,v)=>{if(S.age!=null&&S.age<17){toast('Permohonan IPT dibuka selepas SPM.','r');return}o(v)});
 w('applyLoan',(o,v)=>{if(isMinor()){toast('Pinjaman untuk 18 tahun ke atas.','r');return}o(v)});
 w('quitJob',()=>confirmDlg('Letak jawatan?','<p>Pengalaman kerja akan direkodkan dalam resume anda.</p>','Letak Jawatan',()=>{const J=FT_JOBS.find(j=>j[0]===S.job.id);S.exp.push({title:J[8][S.job.lvl]+' ('+J[1]+')',emp:S.job.emp||'—',years:Math.round(S.job.shifts/250*10)/10,type:'Sepenuh masa'});S.job=null;rerender()},'r'));
}
// part-time: hiring, vacancies, minors' limits
function rollPtVac(){const w=Math.floor(dayIdx()/7);if(!S.ptVac||S.ptVac.w!==w){S.ptVac={w,n:Object.fromEntries(PT_JOBS.map(j=>[j[0],Math.floor(rnd(0,5))]))}}}
{const pw=ACT.ptWork;ACT.ptWork=v=>{const [id,h]=v.split(':'),hrs=+h,m=PTMETA[id]||[18];
  if(S.age!=null&&S.age<m[0]){toast(`Kerja ini untuk ${m[0]} tahun ke atas.`,'r');return}
  if(!(S.ptHired||{})[id]){toast('Mohon kerja sambilan ini dahulu.','y');return}
  if(isMinor()){const hr=hourNow(),used=(S.workLog[dayIdx()]||{}).pt||0;if(used+hrs>4){toast('Remaja: maksimum 4 jam kerja sehari.','r');return}if(hr<8||hr+hrs>18){toast('Remaja hanya boleh bekerja antara 8 pg – 6 ptg.','r');return}}
  pw(v)}}
ACT.ptApply=id=>{rollPtVac();const j=PT_JOBS.find(x=>x[0]===id),m=PTMETA[id]||[18];
  if(S.age!=null&&S.age<m[0]){toast(`Kerja ini untuk ${m[0]} tahun ke atas.`,'r');return}
  if(!ptReqOK(j[5])){toast('Keperluan belum dipenuhi: '+reqName[j[5]],'r');return}
  if(S.ptVac.n[id]<=0){toast('Tiada kekosongan minggu ini. Cuba minggu depan.','y');return}
  if((S.ptTried||{})[id]===dayIdx()){toast('Sudah memohon hari ini — cuba esok.','y');return}
  S.ptTried=S.ptTried||{};S.ptTried[id]=dayIdx();advance(30);
  if(Math.random()<clamp(.7+S.stats.karisma/300+expYears()*.01,0,.97)){S.ptHired[id]=1;S.ptVac.n[id]--;addXP(10);showDlg({title:'Diterima bekerja sambilan!',body:`<p>Anda diterima sebagai <b>${esc(j[1])}</b>. Waktu kerja: ${esc(m[1])}. Pilih syif 2 atau 4 jam bila-bila masa — tidak menjejaskan permohonan kerja tetap anda.</p>`,buttons:[{label:'Mula Kerja',cls:'g',a:'closeDlg'}]})}
  else showDlg({title:'Belum berjaya',body:'<p>Majikan memilih calon lain. Cuba lagi esok atau mohon kerja sambilan lain.</p>',buttons:[{label:'Okey',cls:'w',a:'closeDlg'}]});rerender()};
ACT.ptQuit=id=>{delete S.ptHired[id];toast('Berhenti kerja sambilan.');rerender()};

// ---- vacancies & applications
const JSTAT={draf:['Draf',''],dihantar:['Dihantar','y'],semakan:['Dalam Semakan','y'],senarai:['Disenarai Pendek','r'],temuduga:['Temu Duga Dijadual','e'],tawaran:['Diterima — Tawaran Kerja','u'],diterima:['Tawaran Diterima','u'],ditolak:['Ditolak','p'],ditarik:['Ditarik Balik',''],luput:['Tawaran Luput','']};
function rollVacancies(d){const w=Math.floor(d/7);if(S.vacW===w&&S.vac)return;S.vacW=w;S.vac=(S.vac||[]).filter(v=>v.deadline>=d);let id=S.vacN||1;
  for(const J of FT_JOBS){const n=(ENTRY.includes(J[0])?1.5:.65)+(S.karnival===d?.5:0);let k=Math.random()<n%1?Math.ceil(n):Math.floor(n);if(S.vac.some(v=>v.job===J[0]))k=Math.max(0,k-1);
    for(let i=0;i<k;i++){const exp=QRANK[J[2]]<=1?wpick([[0,5],[1,2],[2,1]]):wpick([[0,4],[1,3],[2,2],[3,1],[5,.5]]);const sm=Math.round(J[4]*(1+exp*.05)/100)*100;
      S.vac.push({id:'v'+(id++),job:J[0],emp:pick(EMPLOYERS[J[0]]||EMP_GENERIC),smin:sm,smax:Math.max(sm+500,Math.round(Math.min(J[5],J[4]*(1.6+exp*.1))/100)*100),exp,slots:1+Math.floor(Math.random()*4),deadline:d+4+Math.floor(Math.random()*8)})}}
  S.vacN=id}
function vacCheck(v){const J=FT_JOBS.find(j=>j[0]===v.job),[amin,amax]=ftAge(v.job);return{J,qual:ftQualOK(J),exp:expYears()>=v.exp,age:S.age==null||(S.age>=amin&&S.age<=amax),amin,amax,resume:!!(S.resume&&S.resume.done)}}
function appScore(a){const v=a.v,c=vacCheck(v);if(!c.qual)return{s:-1,why:'Tidak memenuhi kelayakan minimum'};if(!c.age)return{s:-1,why:`Had umur jawatan ${c.amin}–${c.amax} tahun`};
  const q=bestQual(),d=S.degrees.filter(x=>QRANK[x.level]>=QRANK[c.J[2]]).sort((x,y)=>y.cgpa-x.cgpa)[0];
  let s=.3+(c.exp?.18:-.18*(v.exp-expYears()))+Math.max(0,q.r-QRANK[c.J[2]])*.05+(d&&d.cgpa>=3.5?.08:0)+(d&&INST[d.inst]&&INST[d.inst].tier==='elite'?.05:0)+skillLv('career')*.02+certBonus(v.job,.08)+S.stats.karisma/400+((S.resume.obj||'').length>15?.05:0)+(S.resume.langs.includes('Bahasa Inggeris')&&['hotel','hotelmgr','pilot','bizmgr','hr','lawyer','journalist'].includes(v.job)?.06:0)-(5-v.slots)*.02+(S.karnB>=dayIdx()?.1:0);
  return{s,why:c.exp?'':'Pengalaman kurang daripada keperluan'}}
function jappNewDay(d){for(const a of S.japps||[]){
  if(a.status==='dihantar'&&d>a.day){a.status='semakan';a.next=d+1;notify(`${a.title} (${a.emp}): permohonan dalam semakan`)}
  else if(a.status==='semakan'&&d>=a.next){const r=appScore(a);a.score=r.s;if(r.s<0||r.s+rnd(-.12,.12)<.42){a.status='ditolak';a.note=r.why||'Calon lain lebih sesuai';addMsg(a.emp,'Keputusan Permohonan',`Terima kasih atas permohonan jawatan ${a.title}. Dukacita dimaklumkan permohonan anda tidak berjaya. ${a.note}.`)}
    else{a.status='temuduga';a.iday=d+1+Math.floor(Math.random()*2);a.note='';addMsg(a.emp,'Disenarai Pendek — Temu Duga',`Tahniah! Anda disenarai pendek untuk jawatan ${a.title}. Temu duga pada ${dateStr(a.iday)}, 9:00 pg – 5:00 ptg di ${LOC[a.loc].name}. Pakai pakaian kemas.`);notify(`Temu duga dijadual: ${a.title}, ${dateStr(a.iday)}`)}}
  else if(a.status==='temuduga'&&d>a.iday+1){a.status='ditolak';a.note='Tidak hadir temu duga'}
  else if(a.status==='tawaran'&&d>a.until){a.status='luput';a.note='Tawaran tidak dijawab'}}
  if(dateOf(d).d===5&&!isMinor()){S.karnival=d;addMsg('Pusat Kerjaya','Karnival Kerjaya Hari Ini!','Lebih banyak jawatan kosong diiklankan. Hadir ke Pusat Kerjaya untuk bonus temu duga minggu ini.')}
  if(dateOf(d).d===10&&isMinor())notify('Hari Sukan Sekolah hari ini di SMK Kota Kita!');
  rollVacancies(d);rollPtVac()}
{const nd=newDay;newDay=function(){nd();jappNewDay(dayIdx())}}
ACT.vApply=vid=>{if(isMinor()){toast('Jawatan sepenuh masa untuk 18 tahun ke atas.','r');return}const v=S.vac.find(x=>x.id===vid);if(!v)return;
  let a=S.japps.find(x=>x.vid===vid);if(!a){const J=FT_JOBS.find(j=>j[0]===v.job);a={id:'a'+Date.now().toString(36),vid,v,job:v.job,title:J[1],emp:v.emp,loc:J[7],status:'draf',created:dayIdx()};S.japps.unshift(a)}
  appDialog(a)};
function appDialog(a){const c=vacCheck(a.v),ok=x=>x?'<b style="color:var(--grn2)">✓</b>':'<b style="color:var(--red)">✗</b>';const v=a.v,dl=v.deadline-dayIdx();
  showDlg({wide:true,title:'Permohonan: '+a.title,body:`<p style="margin-top:0">${esc(a.emp)} · ${fmt(v.smin)}–${fmt(v.smax)} sebulan · ${LOC[a.loc].name}</p>
  <div class="list"><div class="li"><div class="t"><b>Kelayakan minimum</b><span>${c.J[2]==='spm'?'SPM':LEVEL[c.J[2]].name}${c.J[3]?' ('+c.J[3].map(x=>COURSE[x]).join('/')+')':''} · anda: ${esc(topQualText())}</span></div>${ok(c.qual)}</div>
  <div class="li"><div class="t"><b>Pengalaman</b><span>Perlu ${v.exp} tahun · anda: ${expYears()} tahun</span></div>${ok(c.exp)}</div>
  <div class="li"><div class="t"><b>Had umur</b><span>${c.amin}–${c.amax} tahun · anda: ${S.age}</span></div>${ok(c.age)}</div>
  <div class="li"><div class="t"><b>Resume</b><span>${c.resume?'Lengkap':'Belum lengkap — kemas kini di tab Resume'}</span></div>${ok(c.resume)}</div></div>
  <p style="font-size:13px;color:var(--mut)">Tarikh tutup: ${dateStr(v.deadline)} (${dl} hari lagi). Permohonan dihantar di Pusat Kerjaya. Kerja sambilan anda tidak terjejas.</p>`,
  buttons:[{label:'Simpan Draf',cls:'w',a:'closeDlg'},...(c.resume?[]:[{label:'Kemas Kini Resume',cls:'y',a:'goPanel',v:'kerjaya:resume'}]),{label:'Hantar Permohonan',cls:'g',a:'jSubmit',v:a.id,dis:!c.resume||dl<0}]})}
ACT.jSubmit=id=>{const a=S.japps.find(x=>x.id===id);if(!a||a.status!=='draf')return;if(a.v.deadline<dayIdx()){toast('Tarikh tutup telah lepas.','r');return}
  const go=()=>{if((S.japps||[]).filter(x=>['dihantar','semakan','temuduga'].includes(x.status)).length>=6){toast('Maksimum 6 permohonan aktif.','r');return}a.status='dihantar';a.day=dayIdx();advance(30);S.cnt.apply=(S.cnt.apply||0)+1;addXP(10);closeDlg();toast('Permohonan dihantar! Tunggu maklum balas majikan.','g');SH.tab='apps';rerender()};
  if(atLoc('kerjaya'))go();else{closeDlg();needAt('kerjaya',go,'Hantar permohonan di')}};
ACT.jOpen=id=>{const a=S.japps.find(x=>x.id===id);if(a)appDialog(a)};
ACT.jDel=id=>{S.japps=S.japps.filter(x=>x.id!==id);rerender()};
ACT.jWithdraw=id=>{const a=S.japps.find(x=>x.id===id);confirmDlg('Tarik balik permohonan?',`<p>${esc(a.title)} — ${esc(a.emp)}</p>`,'Tarik Balik',()=>{a.status='ditarik';rerender()},'r')};
ACT.jInterview=id=>{const a=S.japps.find(x=>x.id===id),d=dayIdx(),h=hourNow();if(!a||a.status!=='temuduga')return;
  if(d<a.iday){toast(`Temu duga pada ${dateStr(a.iday)}.`,'y');return}if(h<9||h>=17){toast('Temu duga antara 9:00 pg – 5:00 ptg.','y');return}
  needAt(a.loc,()=>{startQuiz(`Temu Duga: ${a.title} (${a.emp})`,4,sc=>{advance(90);S.cnt.interview=(S.cnt.interview||0)+1;const formal=['formal','kerja'].includes(OUT[S.look.outfit].cat);
    const p=clamp(.2+sc*.5+(a.score||.4)*.35+(formal?.07:0),.05,.95);a.iscore=Math.round(sc*100);
    if(Math.random()<p){a.status='tawaran';a.until=dayIdx()+3;addMsg(a.emp,'Surat Tawaran Kerja',`Tahniah! Anda ditawarkan jawatan ${a.title}. Sila terima tawaran dalam tempoh 3 hari melalui Pusat Kerjaya → Permohonan Saya.`);
      showDlg({title:'Tawaran Kerja!',body:`<p>Skor temu duga: <b>${a.iscore}%</b>${formal?' · berpakaian kemas ✓':''}</p><p>${esc(a.emp)} menawarkan jawatan <b>${esc(a.title)}</b>. Terima dalam 3 hari.</p>`,buttons:[{label:'Nanti',cls:'w',a:'closeDlg'},{label:'Terima Tawaran',cls:'g',a:'jAccept',v:a.id}]})}
    else{a.status='ditolak';a.note=`Skor temu duga ${a.iscore}%`;showDlg({title:'Keputusan Temu Duga',body:`<p>Skor temu duga ${a.iscore}%. Majikan memilih calon lain. Tip: pakai pakaian formal, tingkatkan karisma, sijil dan pengalaman.</p>`,buttons:[{label:'Okey',cls:'w',a:'closeDlg'}]})}rerender()},INTERVIEW)},'Pergi temu duga di')};
ACT.jAccept=id=>{const a=S.japps.find(x=>x.id===id);if(!a||a.status!=='tawaran')return;
  const go=()=>{if(S.job){const J=FT_JOBS.find(j=>j[0]===S.job.id);S.exp.push({title:J[8][S.job.lvl]+' ('+J[1]+')',emp:S.job.emp||'—',years:Math.round(S.job.shifts/250*10)/10,type:'Sepenuh masa'})}
    S.job={id:a.job,lvl:0,shifts:0,perfSum:0,start:dayIdx(),inc:0,emp:a.emp};a.status='diterima';addXP(100);closeDlg();addMsg(a.emp,'Selamat Datang!',`Anda kini ${FT_JOBS.find(j=>j[0]===a.job)[8][0]} di ${a.emp}. Gaji ${fmt(ftSalary())} sebulan. Mula syif di ${LOC[a.loc].name}.`);toast('Tahniah! Anda kini bekerja sepenuh masa.','g');checkAch();rerender()};
  if(S.job)confirmDlg('Tukar kerja?','<p>Anda akan meletak jawatan semasa. Pengalaman akan direkodkan dalam resume.</p>','Terima',go);else go()};
ACT.jDecline=id=>{const a=S.japps.find(x=>x.id===id);a.status='ditarik';a.note='Tawaran ditolak';rerender()};
ACT.karnival=()=>needAt('kerjaya',()=>{if(S.karnival!==dayIdx()||S.daily.karn)return;S.daily.karn=1;S.karnB=dayIdx()+7;advance(120);addXP(30);stat('karisma',2);toast('Karnival Kerjaya: bonus saringan & temu duga minggu ini!','g');rerender()},'Pergi ke');
ACT.sukanSekolah=()=>needAt('sekolah',()=>{if(S.daily.sukan)return;S.daily.sukan=1;if(!useEnergy(15))return;advance(180);stat('cergas',5);stat('gembira',10);bump('sport');addXP(40);toast('Hari Sukan Sekolah: rumah sukan anda menang!','g');rerender()},'Pergi ke');

// ---- Kerjaya panel (new structure)
PANELS.kerjaya.tabs=[['pt','Kerja Sambilan'],['vac','Jawatan Kosong'],['apps','Permohonan Saya'],['status','Status & Jadual'],['resume','Resume Saya'],['latihan','Latihan & Sijil'],['biz','Usahawan']];
{const r0=PANELS.kerjaya.render;PANELS.kerjaya.render=t=>{
  const d=dayIdx();
  if(t==='pt'){rollPtVac();const used=(S.workLog[d]||{}).pt||0;return`<div class="note" style="margin-bottom:10px">${isMinor()?'<b>Remaja:</b> hanya kerja ringan, maksimum 4 jam sehari antara 8 pg – 6 ptg.':'Kerja sambilan boleh dibuat sambil memohon kerja tetap, menghadiri temu duga atau belajar — permohonan anda tidak terbatal.'} Hari ini: ${used} jam.</div>
    <div class="grid w">${PT_JOBS.map(j=>{const m=PTMETA[j[0]]||[18,'Fleksibel','Fleksibel'],okAge=S.age==null||S.age>=m[0],ok=ptReqOK(j[5])&&okAge,h=(S.ptHired||{})[j[0]];return`<div class="card ${h?'on':ok?'':'dim'}"><div class="row"><span class="emo">${[...new Intl.Segmenter().segment(j[6])][0].segment}</span><div><h4>${esc(j[1])}</h4><p>${j[4]==='any'?'Di mana-mana / dari rumah':esc(LOC[j[4]].name)}</p></div></div>
    <div class="kv"><span>Kadar</span><b>RM ${j[2]}–${j[3]} / jam</b><span>Kadar anda</span><b>${fmt2(ptWage(j))} / jam</b><span>Waktu kerja</span><b>${esc(m[1])}</b><span>Syif</span><b>${esc(m[2])}</b><span>Syarat</span><b>${m[0]}+ tahun${j[5]?' · '+reqName[j[5]]:''}</b><span>Kekosongan</span><b>${h?'—':S.ptVac.n[j[0]]+' minggu ini'}</b></div>
    <div class="row">${h?B('Kerja 2 jam','ptWork',j[0]+':2','g',used>(isMinor()?2:6))+B('4 jam','ptWork',j[0]+':4','',used>(isMinor()?0:4))+B('Berhenti','ptQuit',j[0],'w'):B('Mohon','ptApply',j[0],'y',!ok)}</div></div>`}).join('')}</div>`}
  if(t==='vac'){if(isMinor())return'<div class="note y">Jawatan sepenuh masa dibuka apabila anda berumur 18 tahun. Cuba kerja sambilan ringan dahulu.</div>';rollVacancies(d);const list=S.vac.filter(v=>v.deadline>=d).sort((a,b)=>(vacCheck(b).qual-vacCheck(a).qual)||a.deadline-b.deadline);
    return`<div class="row" style="margin-bottom:10px"><span class="tagx">${list.length} jawatan kosong</span><span class="tagx">Kelayakan anda: ${esc(topQualText())}</span><span class="tagx">Pengalaman: ${expYears()} tahun</span>${S.karnival===d?B('Hadiri Karnival Kerjaya','karnival','','y',S.daily.karn):''}</div>
    <div class="grid w">${list.map(v=>{const c=vacCheck(v),a=S.japps.find(x=>x.vid===v.id);const tk=x=>x?'✓':'✗';return`<div class="card ${c.qual&&c.age?'':'dim'}"><div class="row"><span class="emo">${[...new Intl.Segmenter().segment(c.J[9])][0].segment}</span><div><h4>${esc(c.J[1])}</h4><p>${esc(v.emp)}</p></div></div>
    <div class="kv"><span>Gaji</span><b>${fmt(v.smin)} – ${fmt(v.smax)}</b><span>Kelayakan ${tk(c.qual)}</span><b>${c.J[2]==='spm'?'SPM':LEVEL[c.J[2]].name}${c.J[3]?' ('+c.J[3].map(x=>COURSE[x]).join('/')+')':''}</b><span>Pengalaman ${tk(c.exp)}</span><b>${v.exp?v.exp+' tahun':'Tiada (graduan baharu dialu-alukan)'}</b><span>Umur ${tk(c.age)}</span><b>${c.amin}–${c.amax} tahun</b><span>Lokasi</span><b>${esc(LOC[c.J[7]].name)}</b><span>Waktu</span><b>${esc(c.J[6])}</b><span>Kekosongan</span><b>${v.slots}</b><span>Tarikh tutup</span><b>${dateStr(v.deadline)}</b></div>
    ${a?`<div class="row"><span class="tagx ${JSTAT[a.status][1]}">${JSTAT[a.status][0]}</span>${B('Lihat','goPanel','kerjaya:apps','w')}</div>`:B('Mohon','vApply',v.id,'g')}</div>`}).join('')||'<div class="note">Tiada jawatan kosong minggu ini.</div>'}</div>`}
  if(t==='apps'){const L=S.japps||[];if(!L.length)return'<div class="note">Belum ada permohonan. Pilih jawatan di tab Jawatan Kosong.</div>';const steps=['draf','dihantar','semakan','senarai','temuduga','tawaran','diterima'];
    return`<div class="list">${L.map(a=>{const si=a.status==='temuduga'?4:steps.indexOf(a.status);const prog=a.status==='ditolak'||a.status==='ditarik'||a.status==='luput'?'':`<div class="row" style="gap:3px;margin-top:6px">${steps.map((s,i)=>`<span style="flex:1;height:6px;border-radius:9px;background:${i<=si?'var(--grn)':'var(--lil2)'}" title="${JSTAT[s][0]}"></span>`).join('')}</div>`;
      const info={draf:'Belum dihantar',dihantar:'Keputusan saringan dalam 1–2 hari',semakan:'Majikan sedang menilai resume anda',temuduga:`Temu duga: ${dateStr(a.iday)}, 9 pg – 5 ptg, ${LOC[a.loc].name}`,tawaran:`Jawab sebelum ${dateStr(a.until)}`,diterima:'Anda bekerja di sini',ditolak:a.note||'',ditarik:a.note||'',luput:a.note||''}[a.status]||'';
      const btn={draf:B('Sambung','jOpen',a.id,'g')+B('Padam','jDel',a.id,'w'),dihantar:B('Tarik Balik','jWithdraw',a.id,'w'),semakan:B('Tarik Balik','jWithdraw',a.id,'w'),temuduga:B('Hadiri Temu Duga','jInterview',a.id,'g',d<a.iday)+B('Tarik Balik','jWithdraw',a.id,'w'),tawaran:B('Terima Tawaran','jAccept',a.id,'g')+B('Tolak','jDecline',a.id,'w')}[a.status]||'';
      return`<div class="li" style="display:block"><div class="row"><div class="t"><b>${esc(a.title)}</b><span>${esc(a.emp)}</span></div><span class="tagx ${JSTAT[a.status][1]}">${JSTAT[a.status][0]}</span></div>${prog}<p style="font-size:13px;margin:6px 0">${esc(info)}${a.iscore!=null?` · Skor temu duga ${a.iscore}%`:''}</p><div class="row">${btn}</div></div>`}).join('')}</div>`}
  if(t==='resume'){const R=S.resume,LANGS=['Bahasa Melayu','Bahasa Inggeris','Mandarin','Tamil','Kadazandusun','Iban','Bahasa Arab','Bahasa Jepun'];const OBJ=['Mencari peluang untuk berkembang dan menyumbang kepada organisasi yang dinamik.','Graduan bersemangat yang ingin membina kerjaya dalam bidang pengkhususan saya.','Pekerja berpengalaman yang mahu memikul tanggungjawab lebih besar.','Ingin menimba pengalaman kerja sambil terus belajar dan meningkatkan kemahiran.'];
    return`<div class="grid w" style="align-items:start"><div class="card"><h4>Bina Resume</h4><div class="stat">Objektif kerjaya<textarea id="resObj" maxlength="160" rows="3" style="width:100%;border:2px solid var(--lil2);border-radius:12px;padding:8px;font:inherit;font-size:16px">${esc(R.obj||'')}</textarea></div>
      <div class="opts">${OBJ.map((o,i)=>`<button class="opt" data-a="resTpl" data-v="${i}" style="font-size:11px;text-align:left">${esc(o.slice(0,38))}…</button>`).join('')}</div>
      <div class="stat" style="margin-top:6px">Bahasa<div class="opts">${LANGS.map(l=>`<button class="opt ${R.langs.includes(l)?'on':''}" data-a="resLang" data-v="${l}">${l}</button>`).join('')}</div></div>
      ${B(R.done?'Kemas Kini Resume':'Simpan Resume','resSave','','g')}${R.done?'<span class="tagx u">Resume lengkap</span>':''}</div>
    <div class="card"><div class="row"><img src="${headImg(S.look)}" style="width:64px;border-radius:50%;background:var(--lil)" alt=""><div><h4 style="font-size:19px">${esc(S.name)}</h4><p>${S.age} tahun · ${flagTag(S.state,12)} ${esc(S.town||'')}, ${esc(STATE[S.state]?STATE[S.state].name:'')}</p></div></div>
      <div class="sec">Objektif</div><p style="font-size:13px">${esc(R.obj||'—')}</p>
      <div class="sec">Pendidikan</div><p style="font-size:13px">${S.spm!=null?`SPM — ${S.spm}A<br>`:S.age<18?`Tingkatan ${S.school.form||5}<br>`:'Persekolahan asas<br>'}${S.degrees.map(x=>`${esc(degName(x))} — ${esc(instName(x.inst))}, ${x.level==='stpm'?'PNGK':'CGPA'} ${x.cgpa.toFixed(2)}`).join('<br>')}${S.edu?`<br>Sedang belajar: ${LEVEL[S.edu.level].name} ${COURSE[S.edu.course]} (${INST[S.edu.inst].abbr})`:''}</p>
      <div class="sec">Pengalaman kerja · ${expYears()} tahun</div><p style="font-size:13px">${[...(S.exp||[]).map(e=>`${esc(e.title)} — ${esc(e.emp)} (${e.years} thn)`),...(S.job?[`${esc(occupation())} (semasa)`]:[]),...Object.entries(S.ptSkill).map(([k,h])=>`${esc(PT_JOBS.find(j=>j[0]===k)[1])} sambilan — ${h} jam`)].join('<br>')||'—'}</p>
      <div class="sec">Sijil</div><p style="font-size:13px">${(S.certs||[]).map(c=>CERTS.find(x=>x[0]===c)[1]).join(', ')||'—'}</p>
      <div class="sec">Kemahiran & Bahasa</div><div class="row">${SKILLS.map(k=>`<span class="tagx">${k[1]} ${skillLv(k[0])}</span>`).join('')}${R.langs.map(l=>`<span class="tagx u">${l}</span>`).join('')}</div></div></div>`}
  if(t==='status'){const ints=(S.japps||[]).filter(a=>a.status==='temuduga'),offs=(S.japps||[]).filter(a=>a.status==='tawaran');const e=S.edu;
    const sched=[...ints.map(a=>`<div class="li"><span class="emo">🤝</span><div class="t"><b>Temu duga: ${esc(a.title)}</b><span>${dateStr(a.iday)} · 9 pg – 5 ptg · ${LOC[a.loc].name}</span></div>${B('Hadiri','jInterview',a.id,'g',d<a.iday)}</div>`),...offs.map(a=>`<div class="li"><span class="emo">📄</span><div class="t"><b>Tawaran: ${esc(a.title)}</b><span>Jawab sebelum ${dateStr(a.until)}</span></div>${B('Terima','jAccept',a.id,'g')}</div>`),
      ...(S.job?[`<div class="li"><span class="emo">💼</span><div class="t"><b>Syif sepenuh masa</b><span>${esc(FT_JOBS.find(j=>j[0]===S.job.id)[6])} · ${LOC[FT_JOBS.find(j=>j[0]===S.job.id)[7]].name}</span></div></div>`]:[]),
      ...(e&&e.sched?[`<div class="li"><span class="emo">🎓</span><div class="t"><b>Kuliah ${COURSE[e.course]}</b><span>${e.sched.map(i=>WEEK[i]).join(', ')} · 9 pg – 5 ptg</span></div></div>`]:[]),
      ...Object.keys(S.ptHired||{}).map(k=>`<div class="li"><span class="emo">⏱️</span><div class="t"><b>Sambilan: ${esc(PT_JOBS.find(j=>j[0]===k)[1])}</b><span>${esc((PTMETA[k]||[0,'Fleksibel'])[1])} · pilih syif bila lapang</span></div></div>`)];
    return`<div class="grid w"><div class="card"><h4>Status Pekerjaan</h4><div class="kv"><span>Status</span><b>${esc(empStatus())}</b><span>Pekerjaan</span><b>${esc(occupation())}</b><span>Kelayakan</span><b>${esc(topQualText())}</b><span>Pengalaman</span><b>${expYears()} tahun</b><span>Pendapatan bulan ini</span><b>${fmt(S.incM?S.incM.ft+S.incM.pt+S.incM.biz:0)}</b><span>Sambilan bulan ini</span><b>${fmt(S.incM?S.incM.pt:0)}</b></div></div>
    <div class="card"><h4>Jadual Saya</h4><div class="list">${sched.join('')||'<p>Tiada temu duga atau syif dijadualkan.</p>'}</div></div></div>`+(S.job?r0('status'):'')}
  return r0(t)}}
ACT.resTpl=v=>{const OBJ=['Mencari peluang untuk berkembang dan menyumbang kepada organisasi yang dinamik.','Graduan bersemangat yang ingin membina kerjaya dalam bidang pengkhususan saya.','Pekerja berpengalaman yang mahu memikul tanggungjawab lebih besar.','Ingin menimba pengalaman kerja sambil terus belajar dan meningkatkan kemahiran.'];$('#resObj').value=OBJ[+v]};
ACT.resLang=v=>{const o=$('#resObj');S.resume.obj=o?o.value:S.resume.obj;const L=S.resume.langs;const i=L.indexOf(v);if(i>=0)L.splice(i,1);else L.push(v);rerender()};
ACT.resSave=()=>{const o=$('#resObj');S.resume.obj=(o?o.value:'').trim().slice(0,160);if(S.resume.obj.length<10){toast('Tulis objektif kerjaya (sekurang-kurangnya 10 aksara).','r');return}if(!S.resume.langs.length){toast('Pilih sekurang-kurangnya satu bahasa.','r');return}S.resume.done=true;addXP(15);toast('Resume disimpan ✓','g');rerender()};

// ---- education by age & private SPM
{const r=PANELS.pendidikan.render;PANELS.pendidikan.render=t=>{
  if(t==='sekolah'){if(S.stage==='sekolah'){const f=S.school.form||5,c=S.school.classes;return`<div class="card on"><h4>SMK Kota Kita — Tingkatan ${f}</h4><p>${f<5?'Hadiri 10 kelas untuk naik ke tingkatan seterusnya.':'Hadiri 10 kelas untuk melayakkan diri ke peperiksaan SPM.'}</p><div class="stat">Kelas: ${c}/10<div class="bar"><i style="width:${pct(c,10)}%"></i></div></div><div class="kv"><span>Akademik</span><b>${S.stats.akademik}/100</b></div>
      <div class="row">${B('Hadiri Kelas (2 jam)','schClass','','g',(S.daily.sch||0)>=2)}${f<5?B('Naik Tingkatan '+(f+1),'nextForm','','y',c<10):B('Duduki SPM','spm','','y',c<10)}${dateOf(dayIdx()).d===10?B('Hari Sukan Sekolah','sukanSekolah','','w',S.daily.sukan):''}</div></div>`}
    if(S.spm==null&&!isMinor())return`<div class="card"><h4>Calon Persendirian SPM</h4><p>Anda belum memiliki SPM. Hadiri 10 kelas persediaan malam di Sekolah Menengah dan duduki SPM untuk membuka peluang IPT dan kerja.</p><div class="stat">Kelas: ${S.school.classes||0}/10<div class="bar"><i style="width:${pct(S.school.classes||0,10)}%"></i></div></div><div class="row">${B('Kelas Persediaan (2 jam)','privClass','','g',(S.daily.sch||0)>=2)}${B('Duduki SPM','spm','','y',(S.school.classes||0)<10)}</div></div>`}
  return r(t)}}
ACT.nextForm=()=>{if(S.school.classes<10)return;S.school.form++;S.school.classes=0;addXP(80);stat('gembira',8);showDlg({title:`Naik ke Tingkatan ${S.school.form}!`,body:'<p>Tahniah! Teruskan usaha.</p>',buttons:[{label:'Yeay!',cls:'g',a:'closeDlg'}]});rerender()};
ACT.privClass=()=>needAt('sekolah',()=>{if((S.daily.sch||0)>=2)return;if(!useEnergy(10))return;advance(120);S.school.classes=(S.school.classes||0)+1;S.daily.sch=(S.daily.sch||0)+1;stat('akademik',2);S.cnt.classes++;addXP(12);toast('Kelas persediaan SPM selesai','g');rerender()},'Pergi ke');
{const sp=ACT.spm;ACT.spm=()=>{if(S.stage==='sekolah'&&(S.school.form||5)<5){toast('SPM diduduki di Tingkatan 5.','y');return}const wasAdult=!isMinor();sp();if(wasAdult)setTimeout(()=>{if(S.spm!=null&&S.stage==='lepasan')S.stage='dewasa'},500)}}
// eligibility with STPM / TVET
{const el=eligible;eligible=function(inst,level){if(['ijazah'].includes(level)&&S.degrees.some(d=>d.level==='stpm'))return{ok:1};if(level==='diploma'&&S.degrees.some(d=>['sijil','tvet'].includes(d.level)))return{ok:1};return el(inst,level)}}
{const da=decideApp;decideApp=function(a){if(a.level==='ijazah'&&S.degrees.some(d=>d.level==='stpm')&&!S.degrees.some(d=>d.level==='diploma')){const st=S.degrees.find(d=>d.level==='stpm');S.degrees.push({level:'diploma',course:'bus',inst:'ukk',cgpa:st.cgpa,_tmp:1});da(a);S.degrees=S.degrees.filter(d=>!d._tmp);return}da(a)}}

// ---- NPC dialog: age-aware greeting + profile
function greet(n){const p=npcProfile(n),h=hourNow(),tod=h<12?'Selamat pagi':h<19?'Selamat petang':'Selamat malam';if(S.age<18)return p&&p[0]>=30?`${tod}, adik!`:'Hai!';if(S.age>=26)return`${tod}, ${S.look.g==='m'?'Encik':'Cik'} ${S.name.split(' ')[0]}!`;return`${tod}!`}
const AGE_LINES={teen:['Belajar rajin-rajin, SPM tak lama lagi!','Jangan lupa siapkan kerja sekolah ya.','Tutor sambilan di sekolah tu bagus untuk duit poket.'],young:['Dah mohon universiti? Banyak tajaan tahun ni.','Kerja sambilan sambil belajar memang penat tapi berbaloi.','Pusat Kerjaya ada jawatan kosong baharu.'],adult:['Dah hantar resume ke Pusat Kerjaya?','Karnival Kerjaya setiap 5 haribulan — jangan lepas peluang!','Kerja tetap memang stabil, tapi jangan lupa simpan duit.','Ramai yang sambung belajar sambil bekerja sekarang.']};
{const nd=npcDialog;npcDialog=function(n){nd(n);const ln=$('#npcLine');if(ln&&!RT.fest){const set=S.age<18?'teen':S.age<=25?'young':'adult';if(Math.random()<.45)ln.textContent=`"${pick(AGE_LINES[set])}"`;ln.textContent=greet(n)+' '+ln.textContent}const box=$('#dlg .dbox>div');if(box)box.insertAdjacentHTML('beforeend',profileHTML(n))}}

// ---- state: food, outfit, events, profile, move
{const ft=festToday;festToday=function(d){const f=ft(d);if(f||!S||!S.state)return f;const t=dateOf(d===undefined?dayIdx():d),ev=STATE[S.state].ev;if(ev[0]===t.m&&ev[1]===t.d)return{id:'negeri_'+S.state,name:ev[2],desc:`Sambutan budaya negeri asal anda, ${STATE[S.state].name}: ${STATE[S.state].culture}.`};return null}}
{const op=outfitPrice;outfitPrice=function(o){const p=op(o);return S&&S.state&&STATE[S.state].outfit.includes(o.id)?Math.round(p*.8):p}}
{const oc=outfitCard;outfitCard=function(o){let h=oc(o);if(S&&S.state&&STATE[S.state].outfit.includes(o.id))h=h.replace('<h4>',`<span class="tagx l" style="justify-self:start">${flagTag(S.state,11)} Pakaian negeri anda −20%</span><h4>`);return h}}
{const lc=locCards;locCards=function(id){let h=lc(id);const st=S.state&&STATE[S.state];if(id==='medan'&&st)h=card(`${flagTag(st.id,16)} Juadah ${esc(st.name)}`,`${esc(st.food)} — rasa kampung halaman di ${esc(S.town||'')}!`,B(`Makan ${fmt(12)}`,'eat',JSON.stringify([st.food,12,45,14]),'g'),'on')+h;
  if(id==='kerjaya'&&!isMinor()&&S.karnival===dayIdx())h=card('🎪 Karnival Kerjaya','Lebih banyak jawatan & bonus temu duga minggu ini.',B(S.daily.karn?'Sudah hadir':'Hadir (2 jam)','karnival','','y',S.daily.karn),'on')+h;
  if(id==='sekolah'&&isMinor()&&dateOf(dayIdx()).d===10)h=card('🏅 Hari Sukan Sekolah','Sertai acara sukan antara rumah.',B(S.daily.sukan?'Selesai':'Sertai','sukanSekolah','','g',S.daily.sukan),'on')+h;
  if(id==='sekolah'&&!isMinor()&&S.spm==null)h=card('📝 Calon Persendirian SPM','Kelas persediaan malam untuk dewasa.',B('Kelas Persediaan','privClass','','g'),'on')+h;
  if(id==='airport'||id==='bas')h+=card('🧳 Pindah Negeri','Tukar negeri kediaman anda (tiket & kos pindah).',B('Pindah Negeri','goPanel','rumah:hartanah','w'));return h}}
{const r=PANELS.rumah.render;PANELS.rumah.render=t=>{let h=r(t);if(t==='hartanah'){const rs=STATE[S.resState||S.state];h=`<div class="card" style="margin-bottom:10px"><div class="row">${flagTag(rs&&rs.id,22)}<div><h4>Negeri kediaman: ${esc(rs?rs.name:'—')}</h4><p>Negeri asal: ${esc(STATE[S.state]?STATE[S.state].name:'—')} · Kampung halaman: ${esc(S.town||'—')}</p></div><span class="sp"></span>${B('Pindah Negeri','moveState','','y',isMinor())}</div></div>`+h}return h}}
ACT.moveState=()=>{if(isMinor()){toast('Untuk 18 tahun ke atas.','r');return}showDlg({wide:true,title:'Pindah Negeri',body:`<p>Pilih negeri kediaman baharu. Kos: tiket bas/penerbangan + pengangkutan barang <b>${fmt(650)}</b>. Kota Kita kekal sebagai bandar tempat anda tinggal.</p><div class="opts">${STATES.map(s=>`<button class="opt ${(S.resState||S.state)===s.id?'on':''}" data-a="moveStateGo" data-v="${s.id}" style="display:flex;gap:5px">${flagTag(s.id,12)}${esc(s.name)}</button>`).join('')}</div>`,buttons:[{label:'Batal',cls:'w',a:'closeDlg'}]})};
ACT.moveStateGo=v=>{if((S.resState||S.state)===v)return;if(!spend(650,'Kos pindah negeri'))return;S.resState=v;advance(600);addXP(30);closeDlg();addMsg('Kota Kita','Pindah Negeri',`Selamat datang ke kehidupan baharu di ${STATE[v].name}!`);toast('Negeri kediaman kini '+STATE[v].name,'g');rerender()};

// ---- Sosial: hometown & residents directory
PANELS.sosial.tabs.splice(2,0,['kampung','Kampung Halaman'],['penduduk','Direktori Penduduk']);
{const r=PANELS.sosial.render;PANELS.sosial.render=t=>{
  if(t==='kampung'){const st=STATE[S.state];if(!st)return'<div class="note">Lengkapkan profil dahulu.</div>';const ev=st.ev;return`<div class="card on"><div class="row"><img src="${flagImg(st.id)}" style="height:44px;border-radius:6px" alt=""><div><h4 style="font-size:20px">${esc(S.town)}, ${esc(st.name)}</h4><p>${esc(st.culture)}</p></div></div>
    <div class="kv"><span>Makanan tradisi</span><b>${esc(st.food)}</b><span>Pakaian negeri</span><b>${st.outfit.map(o=>esc(OUT[o].name)).join(' / ')} (−20%)</b><span>Acara negeri</span><b>${esc(ev[2])} — ${ev[1]} ${MONTHS[ev[0]-1]}</b><span>Negeri kediaman</span><b>${esc(STATE[S.resState||S.state].name)}</b></div>
    <div class="row">${B('Telefon keluarga di kampung','callHome','','g',S.daily.call)}${B('Juadah negeri di Medan Selera','travel','medan','')}</div></div>
    <div class="sec">Rakan sekampung di Kota Kita</div><div class="list">${RT.npcs.filter(n=>!n.named&&n.prof&&n.prof[1]===S.state).map(n=>`<div class="li"><img src="${headImg(n.C)}" alt=""><div class="t"><b>${esc(n.name)}</b><span>${n.prof[0]} thn · ${esc(n.prof[3])}</span></div>${B('Cari','findNpc',n.id,'')}</div>`).join('')||'<p>Tiada.</p>'}</div>`}
  if(t==='penduduk')return`<div class="note" style="margin-bottom:8px">Setiap penduduk ada umur, negeri, pendidikan, status kerja dan personaliti tersendiri.</div><div class="grid w">${RT.npcs.map(n=>{const p=npcProfile(n);if(!p)return'';return`<div class="card"><div class="row"><img src="${headImg(n.C)}" style="width:48px;border-radius:50%;background:var(--lil)" alt=""><div><h4>${esc(n.name)}</h4><p>${p[0]} thn · ${flagTag(p[1],11)} ${esc(STATE[p[1]].name)} · ${esc(p[5])}</p></div></div><p><b>${esc(p[2])}</b><br>${esc(p[3])}</p>${B('Cari','findNpc',n.id,'w')}</div>`}).join('')}</div>`;
  return r(t)}}
ACT.callHome=()=>{if(S.daily.call)return;S.daily.call=1;advance(20);stat('gembira',8);const f=RT.fest;if(f&&['raya','cny','deepavali','krismas','kaamatan','gawai'].includes(f.id)){S.money+=100;toast('Keluarga kirim duit raya/ang pow RM100!','g')}else toast(pick(['Mak: "Bila nak balik kampung?"','Ayah: "Jaga kesihatan di bandar."','Adik: "Rindu! Bawa ole-ole nanti."']),'g');rerender()};

// ---- Player profile tab
PANELS.pencapaian.title='Profil & Pencapaian';PANELS.pencapaian.tabs.unshift(['profil','Profil Pemain']);
{const r=PANELS.pencapaian.render;PANELS.pencapaian.render=t=>{if(t!=='profil')return r(t);const st=STATE[S.state],e=S.edu,inc=S.incM||{pt:0,ft:0,biz:0};
  return`<div class="grid w" style="align-items:start"><div class="card on"><div class="row"><img src="${headImg(S.look)}" style="width:84px;border-radius:50%;background:var(--lil)" alt=""><div><h4 style="font-size:22px">${esc(S.name)}</h4><p>${S.look.g==='m'?'Lelaki':'Perempuan'} · ${S.age!=null?S.age+' tahun':'—'} · Tahap ${S.lvl}</p><p>${flagTag(S.state,14)} ${esc(S.town||'—')}, ${esc(st?st.name:'—')}</p></div></div>
    <div class="kv"><span>Negeri asal</span><b>${esc(st?st.name:'—')}</b><span>Kampung halaman</span><b>${esc(S.town||'—')}</b><span>Negeri kediaman</span><b>${esc(STATE[S.resState||S.state]?STATE[S.resState||S.state].name:'—')}</b><span>Tahap pendidikan</span><b>${esc(topQualText())}</b><span>Program semasa</span><b>${e?esc(LEVEL[e.level].name+' '+COURSE[e.course]+' — '+INST[e.inst].abbr+' (Sem '+e.sem+'/'+e.sems+')'):S.stage==='sekolah'?'Tingkatan '+(S.school.form||5):'—'}</b></div></div>
    <div class="card"><h4>Kerjaya & Pendapatan</h4><div class="kv"><span>Status</span><b>${esc(empStatus())}</b><span>Pekerjaan</span><b>${esc(occupation())}</b><span>Gaji bulanan</span><b>${S.job?fmt(ftSalary()):'—'}</b><span>Pendapatan bulan ini</span><b>${fmt(inc.ft+inc.pt+inc.biz)}</b><span>Sambilan bulan ini</span><b>${fmt(inc.pt)}</b><span>Perniagaan bulan ini</span><b>${fmt(inc.biz)}</b><span>Pengalaman kerja</span><b>${expYears()} tahun</b><span>Permohonan aktif</span><b>${(S.japps||[]).filter(a=>['dihantar','semakan','temuduga','tawaran'].includes(a.status)).length}</b></div>
    <div class="row">${B('Resume','goPanel','kerjaya:resume','')}${B('Permohonan','goPanel','kerjaya:apps','w')}${needsProfile()?B('Lengkapkan Profil','profileSetup','','y'):''}</div></div></div>`}}
ACT.profileSetup=()=>{closeSheet();showProfileSetup()};
ACT.hudProfile=()=>openPanel('pencapaian','profil');

// ---- HUD: age & state
{const h0=hud;hud=function(){h0();if(!S)return;const x=$('#hXpt');if(x)x.innerHTML=`XP ${S.xp}/${xpNeed(S.lvl)}${S.age!=null?` · ${S.age} thn`:''} ${S.state?flagTag(S.state,10):''}`}}
