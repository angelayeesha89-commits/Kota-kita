// ===================== LOCATIONS / NPC / EVENTS =====================
const ACTV={
 jog:{n:'Jogging keliling tasik',d:'Kecergasan +3',time:60,en:15,st:{cergas:3},hap:5,xp:10,loc:'taman'},
 piknik:{n:'Piknik di taman',d:'Tenaga +10, gembira +12',time:90,cost:20,gain:10,hap:12,xp:8,loc:'taman'},
 rehat:{n:'Berehat di tepi pantai',d:'Tenaga +8, gembira +10',time:60,gain:8,hap:10,xp:5,loc:'pantai'},
 voli:{n:'Bola tampar pantai',d:'Kecergasan +4',time:60,en:18,st:{cergas:4},hap:8,xp:12,loc:'pantai'},
 snorkel:{n:'Snorkeling terumbu karang',d:'Gembira +18',time:120,cost:30,hap:18,xp:15,loc:'pulau'},
 resort:{n:'Bermalam di resort',d:'Tidur mewah: tenaga penuh, gembira +15',cost:250,sleep:999,hap:15,xp:10,loc:'pulau'},
 mendaki:{n:'Mendaki denai hutan',d:'Kecergasan +6',time:180,en:25,st:{cergas:6},hap:10,xp:20,loc:'hutan'},
 khemah:{n:'Berkhemah semalaman',d:'Tidur di bawah bintang (tenaga 75)',sleep:75,hap:10,xp:10,loc:'hutan'},
 derma:{n:'Derma darah',d:'Karisma +5, sekali sehari',time:60,en:10,st:{karisma:5},xp:30,once:1,loc:'hospital'},
 rawatan:{n:'Rawatan kesihatan',d:'Tenaga dipulihkan sepenuhnya',time:60,cost:30,full:1,loc:'hospital'},
 klinik:{n:'Pemeriksaan kesihatan',d:'Tenaga +25 (sekali sehari)',time:30,cost:1,gain:25,once:1,loc:'klinik'},
 bomba:{n:'Latihan keselamatan kebakaran',d:'Kecergasan +2',time:60,xp:15,st:{cergas:2},once:1,loc:'bomba'},
 polis:{n:'Program polis komuniti',d:'Karisma +2',time:60,st:{karisma:2},xp:12,once:1,loc:'polis'},
 kraf:{n:'Bengkel kraf tangan',d:'Anyaman & tekat: karisma +1',time:120,cost:25,st:{karisma:1},hap:6,xp:15,loc:'kampung'},
 tokwan:{n:'Lawat rumah Tok Wan',d:'Tenaga +15, dapat kuih',time:90,gain:15,hap:12,xp:10,once:1,give:['kuih',2],loc:'kampung'},
 jiran:{n:'Bersembang dengan jiran',d:'Gembira +4, karisma +1',time:30,hap:4,st:{karisma:1},xp:5,once:1,loc:'perumahan'},
 percutian:{n:'Percutian 1 hari ke Langkawi',d:'Gembira +40, tenaga +60',time:1440,cost:800,hap:40,gain:60,xp:60,loc:'airport'},
 dataran:{n:'Bersiar-siar di dataran',d:'Gembira +6',time:45,hap:6,xp:5,loc:'bandar'},
 kerjayatalk:{n:'Sesi kaunseling kerjaya',d:'Karisma +2, tips kerjaya',time:60,st:{karisma:2},xp:10,once:1,loc:'kerjaya'},
 perpustakaan:{n:'Belajar di perpustakaan',d:'Akademik +2',time:120,en:10,st:{akademik:2},xp:12,loc:'uni'},
 baca:{n:'Membaca buku',d:'Akademik +2, kreativiti',time:90,en:5,st:{akademik:2},hap:4,xp:12,loc:'perpustakaan',creative:1},
 ulangkaji:{n:'Ulang kaji di bilik bacaan',d:'Akademik +3',time:150,en:12,st:{akademik:3},xp:15,loc:'perpustakaan'},
 renang:{n:'Berenang di pantai',d:'Kecergasan +4, gembira +8',time:60,en:15,st:{cergas:4},hap:8,xp:12,loc:'pantai',out:1,sport:1},
 bersih:{n:'Gotong-royong bersih pantai',d:'XP pemuliharaan +15, karisma +2',time:90,en:12,st:{karisma:2},hap:5,xp:25,loc:'pantai',out:1,cons:15},
 fotografi:{n:'Fotografi alam',d:'Perlu telefon/kamera · kreativiti, jual gambar',time:60,en:5,hap:6,xp:12,loc:'taman',out:1,creative:1,photo:1},
 fotopantai:{n:'Fotografi matahari terbenam',d:'Perlu telefon/kamera · kreativiti',time:60,en:5,hap:8,xp:12,loc:'pantai',out:1,creative:1,photo:1},
 berbasikal:{n:'Berbasikal keliling taman',d:'Perlu basikal · kecergasan +4',time:60,en:12,st:{cergas:4},hap:8,xp:12,loc:'taman',out:1,sport:1,bike:1},
 gim:{n:'Senaman di gimnasium',d:'Kecergasan +4',time:60,cost:10,en:18,st:{cergas:4},xp:12,loc:'stadium',sport:1},
 lukis:{n:'Kelas melukis & muzik',d:'Kreativiti, gembira +8',time:120,cost:30,hap:8,xp:15,loc:'kampung',creative:1},
};
ACT.act=v=>{const a=ACTV[v];needAt(a.loc,()=>{
  if(a.once&&S.daily['a'+v]){toast('Sudah dilakukan hari ini.');return}
  if(a.out&&!outdoorOK()){toast('Ribut petir! Aktiviti luar ditangguhkan.','r');return}
  if(a.photo&&!S.inv.phone&&!S.inv.camera){toast('Perlu telefon pintar atau kamera (Elektronik, Asia Mall).','r');return}
  if(a.bike&&!S.vehicles.some(x=>['basikal','moto'].includes(x))){toast('Perlu basikal (Rumah → Kenderaan).','r');return}
  if(a.cost&&!spend(a.cost))return;if(a.en&&!useEnergy(a.en))return;
  if(a.sleep){const now=S.time%1440;advance(now<7*60?7*60-now:1440-now+7*60);S.energy=Math.max(S.energy,Math.min(maxEnergy(),a.sleep))}else advance(a.time);
  if(a.sport)bump('sport');if(a.creative)bump('creative');if(a.cons){S.consXP+=a.cons;S.cnt.clean=(S.cnt.clean||0)+1}if(a.photo&&S.inv.camera){const m=Math.round(rnd(20,60)*(1+skillLv('creative')*.1));S.money+=m;toast(`Gambar dijual ke agensi: +${fmt(m)}`,'g')}
  if(a.gain)gainEnergy(a.gain);if(a.full)S.energy=maxEnergy();if(a.st)for(const k in a.st)stat(k,a.st[k]);if(a.hap)stat('gembira',a.hap);if(a.xp)addXP(a.xp);if(a.give)inv(a.give[0],a.give[1]);if(a.once)S.daily['a'+v]=1;
  if(v==='kerjayatalk')addMsg('Pusat Kerjaya','Tips Kerjaya','Ijazah dari universiti elite dan CGPA tinggi menaikkan gaji permulaan. Karisma membantu temu duga & kenaikan pangkat.');
  toast(`${a.n} ✓`,'g');rerender()},'Pergi ke')};

function actCard(k){const a=ACTV[k];return`<div class="card"><h4>${esc(a.n)}</h4><p>${esc(a.d)}${a.cost?` · ${fmt(a.cost)}`:''}${a.time?` · ${a.time>=60?a.time/60+' jam':a.time+' minit'}`:''}</p>${B(a.once&&S.daily['a'+k]?'Selesai hari ini':'Lakukan','act',k,'g',a.once&&S.daily['a'+k])}</div>`}
const card=(t,d,btns,cls)=>`<div class="card ${cls||''}"><h4>${t}</h4><p>${d}</p><div class="row">${btns}</div></div>`;
function locCards(id){
  const c=[];const d=dayIdx(),w=dateOf(d).w,hr=hourNow();
  if(homeLoc()===id)c.push(card('🏠 '+esc(HOUSE[S.home.type].name),'Rumah anda. Tidur, hias bilik dan masak.',B('Masuk Rumah','goPanel','rumah:rumah','g')+B('Tidur','sleep','','')+B('Dapur','goPanel','masak:resepi','w'),'on'));
  if(S.job){const J=FT_JOBS.find(j=>j[0]===S.job.id);if(J[7]===id)c.push(card('💼 Kerja: '+esc(J[8][S.job.lvl]),`${esc(J[6])} · ${fmt(ftSalary())}/bulan`,B((S.workLog[d]||{}).ft?'Syif selesai':'Mula Syif','ftWork','','g',(S.workLog[d]||{}).ft),'on'))}
  for(const j of PT_JOBS)if(j[4]===id)c.push(card('⏱️ Part-time: '+esc(j[1]),`RM ${j[2]}–${j[3]}/jam`,B('Kerja 2 jam','ptWork',j[0]+':2','')+B('4 jam','ptWork',j[0]+':4','w')));
  const f=festToday();
  switch(id){
  case 'bandar':
    if(f)c.unshift(card('🎉 '+esc(f.name),esc(f.desc),B(S.festDone[f.id+d]?'Sudah disertai':'Sertai Sambutan','joinFest','','g',S.festDone[f.id+d]),'on'));
    if(S.events.wedding&&S.events.wedding.day===d)c.unshift(card('💐 Majlis Kahwin '+esc(S.events.wedding.names),'Pakai baju tradisional atau formal untuk bonus.',B(S.daily.wed?'Sudah hadir':'Hadir','wedding','','g',S.daily.wed),'on'));
    c.push(card('🏮 Pasar Malam & Medan Selera','Di sudut dataran — pasar malam dibuka setiap malam.',B('Pasar Malam','travel','pasarmalam','')+B('Medan Selera','travel','medan','w')));
    c.push(card('🍛 Kedai Mamak','Makan bersama kawan, buka 24 jam.',MEALS.slice(0,3).map(m=>B(`${m[1]} ${fmt(m[2])}`,'eat',JSON.stringify([m[0],m[2],m[3],m[4]]),'')).join('')));
    c.push(card('🏦 Bank Kota Kita',`Dompet ${fmt(S.money)} · Bank ${fmt(S.bank)}`,B('Perbankan','goPanel','pencapaian:kewangan','')));
    c.push(actCard('dataran'));break;
  case 'mall':c.unshift(card('🛍️ Direktori Asia Mall','4 tingkat: fesyen, warisan, hijab, kasut, pasar raya, elektronik, medan selera, pawagam, karaoke, arked & salon.',B('Tingkat G','goPanel','kedai:g','g')+B('Tingkat 1','goPanel','kedai:1','')+B('Tingkat 2','goPanel','kedai:2','')+B('Tingkat 3','goPanel','kedai:3',''),'on'));break;
  case 'sekolah':
    if(S.stage==='sekolah')c.unshift(card('📚 Kelas Tingkatan 5',`Kelas ${S.school.classes}/10 · Akademik ${S.stats.akademik}`,B('Hadiri Kelas','schClass','','g',(S.daily.sch||0)>=2)+B('Duduki SPM','spm','','y',S.school.classes<10),'on'));
    else c.push(card('🏫 Bekas sekolah anda',S.spm!=null?`Keputusan SPM: ${S.spm}A`:'',B('Pendidikan','goPanel','pendidikan:sekolah','')));
    if(dateOf(d).m===12&&dateOf(d).d===1&&S.spm!=null)c.unshift(card('🎊 Reunion Sekolah','Jumpa rakan lama!',B('Hadir','reunion','','g',S.daily.reunion),'on'));break;
  case 'uni':c.unshift(card('🎓 Pusat Pendidikan Tinggi','12 universiti & kolej: elite, tajaan dan awam.',B('Institusi','goPanel','pendidikan:inst','g')+(S.edu?B('Kuliah','goPanel','pendidikan:kuliah','')+B('Kelab','goPanel','pendidikan:kampus','w'):''),'on'));c.push(actCard('perpustakaan'));break;
  case 'hospital':c.push(actCard('rawatan'),actCard('derma'));break;
  case 'klinik':c.push(actCard('klinik'));break;
  case 'pejabat':c.push(card('🏛️ Kaunter Perkhidmatan','Pinjaman pendidikan, lesen perniagaan & jawatan kerajaan.',B('Jawatan Kerajaan','goPanel','kerjaya:vac','')+B('Lesen Perniagaan','goPanel','kerjaya:biz','w')+(S.debt>0?B('Bayar Pinjaman','goPanel','pencapaian:kewangan','y'):'')));break;
  case 'kerjaya':c.unshift(card('💼 Pilihan Pekerjaan','Part-time, sepenuh masa & keusahawanan.',B('Kerja Sambilan','goPanel','kerjaya:pt','g')+B('Jawatan Kosong','goPanel','kerjaya:vac','')+B('Permohonan Saya','goPanel','kerjaya:apps','w')+B('Usahawan','goPanel','kerjaya:biz','w'),'on'));c.push(actCard('kerjayatalk'));break;
  case 'perumahan':c.push(card('🏘️ Ejen Hartanah','Sewa atau beli rumah teres, apartmen, semi-D & banglo.',B('Lihat Hartanah','goPanel','rumah:hartanah','')),card('👨‍👩‍👧 Keluarga','Mak, Ayah & Adik tinggal di sini.',B('Keluarga','goPanel','sosial:keluarga','')),actCard('jiran'));break;
  case 'kampung':c.push(actCard('lukis'));if(w===5)c.unshift(card('🧹 Gotong-royong','Sabtu: bersihkan kampung bersama penduduk.',B(S.daily.gotong?'Selesai':'Sertai','gotong','','g',S.daily.gotong),'on'));c.push(actCard('tokwan'),actCard('kraf'),card('🏡 Rumah Kampung','Sewa RM300 / beli RM85,000.',B('Hartanah','goPanel','rumah:hartanah','')));break;
  case 'ladang':c.unshift(card('🌾 Ladang Anda',`${S.farm.size} petak · ${S.farm.animals.length} haiwan`,B('Kebun','goPanel','ladang:kebun','g')+B('Ternakan','goPanel','ladang:ternakan','')+B('Siram Semua','waterAll','','w'),'on'));break;
  case 'pasar':c.unshift(card('🥬 Pasar Tani','Jual hasil ladang & tangkapan, beli bahan segar.',B('Jual Hasil Ladang','goPanel','ladang:hasil','g')+B('Jual Ikan','goPanel','memancing:tangkapan','y')+B('Beli Bahan','goPanel','kedai:g',''),'on'));c.push(card('🎣 Muara Sungai Pitas','Spot memancing di paya bakau berdekatan.',B('Memancing','goFish','muara','')));break;
  case 'jeti':c.unshift(card('🎣 Jeti Kota Kita','Spot memancing pesisir. Kedai pancing & pasar ikan.',B('Memancing','goFish','jeti','g')+B('Kedai Pancing','goPanel','memancing:alat','')+B('Pasar Ikan','goPanel','memancing:tangkapan','y'),'on'));if(w===6)c.unshift(card('🏆 Pertandingan Memancing','Ahad ini! Yuran RM20.',B(S.daily.tour?'Sudah sertai':'Sertai','tourJoin','','g',S.daily.tour),'on'));break;
  case 'pantai':c.push(actCard('rehat'),actCard('voli'),actCard('renang'),actCard('bersih'),actCard('fotopantai'),card('🎣 Teluk Tanjung Aru','Spot memancing pantai berbatu.',B('Memancing','goFish','teluk','')));break;
  case 'pulau':c.push(actCard('snorkel'),actCard('resort'),card('🎣 Pulau Manukan','Terumbu karang — hati-hati hidupan dilindungi!',B('Memancing','goFish','manukan','g')),card('⛴️ Feri ke Pelabuhan','RM15 · 40 minit',B('Naik Feri','travel','pelabuhan','')));break;
  case 'hutan':c.push(actCard('mendaki'),actCard('khemah'),card('🎣 Sungai Hutan Kinabalu','Ikan kelah legenda menanti!',B('Memancing','goFish','sungai','g')));break;
  case 'lrt':case 'bas':case 'keretapi':c.unshift(card('🚉 '+esc(LOC[id].name),'Pilih destinasi anda.',B('Buka Peta','goPanel','peta:lokasi','g'),'on'));break;
  case 'airport':c.push(card('✈️ Penerbangan ke Labuan','Memancing laut dalam: tuna, marlin & kerapu besar. RM160.',B('Terbang & Memancing','labuan','terbang','g')),actCard('percutian'));break;
  case 'pelabuhan':c.push(card('⛴️ Feri ke Pulau Pelancongan','RM15 · 40 minit.',B('Naik Feri','travel','pulau','g')),card('🚤 Sewa Bot ke Laut Dalam Labuan','RM80. Ikan besar & haiwan dilindungi.',B('Sewa Bot','labuan','sewa','y')+(S.vehicles.includes('bot')?B('Bot Sendiri','labuan','bot',''):'')),card('🐟 Pasar Ikan Pelabuhan','Jual tangkapan anda.',B('Jual','goPanel','memancing:tangkapan','')));break;
  case 'taman':c.push(actCard('jog'),actCard('piknik'),actCard('berbasikal'),actCard('fotografi'),card('🎣 Tasik Danau Harmoni','Ikan air tawar: patin, toman & lain-lain.',B('Memancing','goFish','tasik','g')));break;
  case 'polis':c.push(actCard('polis'));break;
  case 'perpustakaan':c.push(actCard('baca'),actCard('ulangkaji'),card('📜 Kursus MUET','Sijil Bahasa Inggeris untuk resume.',B('Latihan & Sijil','goPanel','kerjaya:latihan','')));break;
  case 'stadium':c.push(card('⚽ Bola Sepak','Perlawanan persahabatan 15 saat (mini-game). Sukan & kecergasan.',B('Main','sportGame','bola','g')),card('🏸 Badminton','Main badminton di dewan (mini-game).',B('Main','sportGame','badminton','g')),actCard('gim'),
    card('🎤 Konsert Malam Minggu','Jumaat & Sabtu, 8–11 malam. Tiket RM40.',B('Beli Tiket','concert','','y',!([4,5].includes(w)&&hr>=20&&hr<23))));break;
  case 'pawagam':c.unshift(card('🎬 Wayang Hari Ini','Tiket RM18 · 2 jam · gembira +20',MOVIES.map(m=>B(m,'movie',m,'')).join(''),'on'));break;
  case 'medan':c.unshift(card('🍜 Gerai Medan Selera','Juadah dari seluruh Malaysia.',MEALS.map(m=>B(`${m[0]} ${fmt(m[2])}`,'eat',JSON.stringify([m[0],m[2],m[3],m[4]]),'')).join(''),'on'));if(f&&f.id==='makanan')c.unshift(card('🎉 Pesta Makanan','Rasa juadah negeri — ganjaran XP & kuih!',B(S.festDone[f.id+d]?'Sudah disertai':'Sertai','joinFest','','g',S.festDone[f.id+d]),'on'));break;
  case 'pasarmalam':c.unshift(card('🏮 Pasar Malam',hr>=18&&hr<23?'Sedang dibuka! Apam balik, air tebu, satay & ayam percik.':'Dibuka setiap malam 6 ptg – 11 mlm.',B('Jalan-jalan (RM10)','pasarMalam','','g',!(hr>=18&&hr<23))+B('Beli Bahan Murah','goPanel','kedai:g','w'),'on'));break;
  case 'bomba':c.push(actCard('bomba'));break;
  }
  const near=RT.npcs.filter(n=>n.named&&Math.hypot(n.home[0]-LOC[id].door[0],n.home[1]-LOC[id].door[1])<9);
  if(near.length)c.push(`<div class="card"><h4>Orang di sini</h4><div class="list">${near.map(n=>`<div class="li"><img src="${headImg(n.C)}" alt=""><div class="t"><b>${esc(n.name)}</b><span>${esc(n.role)} · ${friendLvl(S.friends[n.id]||0)}</span></div>${B('Borak','talkTo',n.id,'',S.talked[n.id])}</div>`).join('')}</div></div>`);
  if(typeof XLOC!=='undefined')for(const f of XLOC)try{f(id,c)}catch(e){console.warn(e)}
  return c.join('');
}
function drawScene(cv,id){
  const W=cv.clientWidth,H=cv.clientHeight,d=pxr();cv.width=W*d;cv.height=H*d;const x=cv.getContext('2d');x.setTransform(d,0,0,d,0,0);
  const hr=hourNow(),night=hr>=19||hr<6,dusk=hr>=17&&hr<19;const g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,night?'#151a48':dusk?'#7b5bd6':'#6cbcff');g.addColorStop(.6,night?'#3a3a88':dusk?'#f6a8c4':'#bfe4ff');g.addColorStop(1,night?'#4a4a90':dusk?'#ffd6b0':'#f2fbff');x.fillStyle=g;x.fillRect(0,0,W,H);
  if(night){x.fillStyle='#fff';const rs=seeded(3);for(let i=0;i<40;i++){x.globalAlpha=.4+rs()*.6;x.fillRect(rs()*W,rs()*H*.6,1.6,1.6)}x.globalAlpha=1;x.fillStyle='#fff6c0';x.beginPath();x.arc(W*.85,H*.15,12,0,TAU);x.fill()}
  else{x.fillStyle=dusk?'#ffd27a':'#fff3b0';x.shadowColor='#ffe680';x.shadowBlur=30;x.beginPath();x.arc(W*.86,H*.16,16,0,TAU);x.fill();x.shadowBlur=0;x.fillStyle='rgba(255,255,255,.85)';for(const [cx,cy,r] of [[.14,.14,.07],[.22,.11,.05],[.5,.2,.08],[.6,.17,.05]]){x.beginPath();x.ellipse(W*cx,H*cy,W*r,H*.03,0,0,TAU);x.fill()}}
  const gy=H*.8;
  x.fillStyle=night?'rgba(70,60,140,.6)':'rgba(150,140,220,.45)';const rk=seeded(7);for(let i=0;i<24;i++){const bw=W*.045,bh=H*(.06+rk()*.16);x.fillRect(i*W*.043,gy-bh,bw,bh)}
  const water=['jeti','pantai','pulau','pelabuhan'].includes(id),green=['hutan','kampung','ladang','taman'].includes(id);
  {const gg=x.createLinearGradient(0,gy,0,H);gg.addColorStop(0,water?'#46b4e6':green?'#8fd46e':'#ecdfcd');gg.addColorStop(1,water?'#2f8fcf':green?'#6cbf55':'#d9c7ad');x.fillStyle=gg;x.fillRect(0,gy,W,H-gy)}
  if(water){x.fillStyle='#f3dda2';x.fillRect(0,gy,W*.82,H-gy);x.fillStyle='rgba(255,255,255,.7)';x.fillRect(W*.82,gy,4,H-gy);x.strokeStyle='rgba(200,160,90,.35)';for(let i=0;i<4;i++){const yy=gy+8+i*8;x.beginPath();x.moveTo(0,yy);x.quadraticCurveTo(W*.4,yy-3,W*.8,yy);x.stroke()}}
  else if(green){const rf=seeded(11);for(let i=0;i<40;i++){x.fillStyle=['#ff7ab8','#fff','#ffd23f','#c79bff'][i%4];x.beginPath();x.arc(rf()*W,gy+rf()*(H-gy),1.4+rf(),0,TAU);x.fill()}}
  else{x.strokeStyle='rgba(150,120,90,.25)';x.lineWidth=1;for(let yy=gy+6;yy<H;yy+=8){x.beginPath();x.moveTo(0,yy);x.lineTo(W,yy);x.stroke()}for(let xx=0;xx<W;xx+=16){x.beginPath();x.moveTo(xx,gy);x.lineTo(xx-(xx-W/2)*.15,H);x.stroke()}}
  const bl=BLDS.filter(b=>b.loc===id||(id==='bandar'&&b.kind==='shop'));
  bl.slice(0,3).forEach((b,i,arr)=>{const n=arr.length;drawBldPortrait(x,b,W*(.06+(.54/n)*(i+.5)),gy+H*.12,W*.58/n,gy*1.12)});
  if(id==='bandar'){x.save();x.translate(W*.74,gy-30);x.scale(.7,.7);drawObj(x,{type:'fountain',x:-80,y:-80,w:160,h:160});x.restore()}
  if(['pantai','pulau','hutan','kampung','taman'].includes(id))for(let i=0;i<4;i++){x.save();x.translate(W*(.62+i*.1)-(i*3)*TS*.6,gy-(5*TS*.6));x.scale(.6,.6);drawTree(x,{tx:i*3,ty:4,kind:id==='hutan'?'forest':id==='taman'?'round':'palm',s:i*.2});x.restore()}
  const near=RT.npcs.filter(n=>n.named&&Math.hypot(n.home[0]-LOC[id].door[0],n.home[1]-LOC[id].door[1])<9).slice(0,2);
  const sc=Math.min(1.05,H/150);drawChibi(x,W*.6,H-6,sc,S.look,0,0);near.forEach((n,i)=>drawChibi(x,W*(.7+i*.09),H-10,sc*.92,n.C,1,0));
  if(night){x.fillStyle='rgba(14,18,66,.25)';x.fillRect(0,0,W,H)}
}
PANELS.loc={title:()=>LOC[SH.arg].name,tabs:null,render:(t,id)=>`<canvas class="scene" id="scv"></canvas><div class="row" style="margin:8px 0"><span class="tagx">${dateStr()} · ${timeStr()}</span><span class="tagx">${{cerah:'Cerah',mendung:'Mendung',hujan:'Hujan'}[S.weather]}</span><span class="tagx u">Tenaga ${Math.round(S.energy)}</span></div><div class="grid w">${locCards(id)}</div>`,after:(t,id)=>drawScene($('#scv'),id)};
function openLoc(id){visit(id);openPanel('loc',null,id)}

// ---------- events
ACT.joinFest=()=>needAt(festToday()&&festToday().id==='makanan'?'medan':'bandar',()=>{const f=festToday(),d=dayIdx();if(!f||S.festDone[f.id+d])return;S.festDone[f.id+d]=1;S.festDone[f.id]=1;S.cnt.fest++;advance(120);
  const trad=OUT[S.look.outfit].cat==='tradisi';let gift='';
  switch(f.id){case 'raya':{const m=Math.round(rnd(50,150));S.money+=m;inv('kuih',3);gift=`Duit raya ${fmt(m)} + kuih raya`;break}
    case 'cny':S.money+=88;inv('angpow',1);gift='Ang pow RM88 + limau mandarin';break;
    case 'deepavali':inv('muruku',3);gift='Muruku & manisan';break;
    case 'kaamatan':inv('kuih',2);gift='Hinava & kuih tradisi';break;
    case 'gawai':inv('kuih',2);gift='Penganan & kuih tradisi';break;
    case 'krismas':inv('coklat',2);gift='Hadiah coklat';break;
    case 'makanan':inv('kuih',3);S.money+=30;gift='Baucar makanan RM30 + kuih';break;
    case 'cuti':S.energy=maxEnergy();gift='Tenaga penuh untuk bercuti';break;
    default:if(f.id.startsWith('negeri')){inv('kuih',2);S.money+=50;gift='Juadah negeri & duit saku RM50'}else gift='Bendera Jalur Gemilang & XP tambahan'}
  addXP(trad?100:60);stat('gembira',20);for(const id in S.friends)addFriend(id,2);
  showDlg({title:'Selamat '+f.name+'!',body:`<p>${esc(f.desc)}</p><div class="note g">Ganjaran: <b>${esc(gift)}</b>, gembira +20, XP +${trad?100:60}</div>${trad?'<div class="note y" style="margin-top:6px">Bonus bergaya tradisional!</div>':'<p style="font-size:13px;color:var(--mut)">Tip: pakai pakaian tradisional untuk XP bonus.</p>'}`,buttons:[{label:'Meriah!',cls:'g',a:'closeDlg'}]});checkAch()},'Pergi ke');
ACT.wedding=()=>needAt('bandar',()=>{if(S.daily.wed)return;const w=S.events.wedding;S.daily.wed=1;advance(120);const cat=OUT[S.look.outfit].cat;const bonus=cat==='tradisi'||cat==='formal';inv('bungatelur',1);addXP(bonus?70:40);stat('gembira',bonus?15:8);addFriend(w.a,5);addFriend(w.b,5);gainEnergy(20);
  showDlg({title:'Walimatul Urus',body:`<p>Majlis ${esc(w.names)} sangat meriah! Anda menikmati nasi minyak dan menerima bunga telur.</p>${bonus?'<div class="note y">Pakaian anda sesuai dengan majlis! Bonus XP & kebahagiaan.</div>':''}`,buttons:[{label:'Tahniah pengantin!',cls:'g',a:'closeDlg'}]})},'Pergi ke');
ACT.gotong=()=>needAt('kampung',()=>{if(S.daily.gotong||!useEnergy(20))return;S.daily.gotong=1;advance(180);addXP(50);stat('karisma',4);stat('gembira',6);addFriend('hafiz',6);addFriend('dayang',3);toast('Kampung bersih! Pak Hafiz berterima kasih.','g');rerender()},'Pergi ke');
ACT.pasarMalam=()=>needAt('pasarmalam',()=>{const h=hourNow();if(h<18||h>=23){toast('Pasar malam buka 6 ptg – 11 mlm.');return}if(S.daily.pm){toast('Sudah ke pasar malam hari ini.');return}if(!spend(10,'Jajan pasar malam'))return;S.daily.pm=1;advance(60);inv('kuih',2);stat('gembira',10);gainEnergy(15);addXP(10);toast('Sedapnya apam balik & air tebu!','g');rerender()},'Pergi ke');
ACT.sportGame=v=>needAt('stadium',()=>{if(!useEnergy(18))return;startRush(v==='bola'?'Bola Sepak: Kejar Bola!':'Badminton: Balas Pukulan!',v==='bola'?'⚽🥅🧤👟🏃🏆':'🏸🎾👟🏃🏅🥤',(p,sc)=>{advance(90);stat('cergas',3+Math.floor(sc/6));stat('gembira',10);bump('sport');addXP(15+sc);toast(`Hebat! Skor ${sc}. Kecergasan meningkat.`,'g');rerender()})},'Pergi ke');
ACT.concert=()=>needAt('stadium',()=>{const w=dateOf(dayIdx()).w,h=hourNow();if(!([4,5].includes(w)&&h>=20&&h<23)){toast('Konsert pada Jumaat & Sabtu, 8–11 malam.');return}if(S.daily.concert)return;if(!spend(40,'Tiket konsert'))return;S.daily.concert=1;advance(150);stat('gembira',25);bump('creative');addXP(30);for(const id in S.friends)addFriend(id,1);showDlg({title:'🎤 Konsert Kota Kita',body:'<p>Lagu-lagu hit dan lampu berwarna-warni! Gembira +25.</p>',buttons:[{label:'Meriah!',cls:'g',a:'closeDlg'}]})},'Pergi ke');
ACT.reunion=()=>needAt('sekolah',()=>{if(S.daily.reunion)return;S.daily.reunion=1;advance(150);stat('gembira',15);addXP(40);['aiman','siti','haziq','nurul'].forEach(i=>addFriend(i,3));toast('Seronok jumpa kawan lama!','g');rerender()},'Pergi ke');

// ---------- NPC chat
const NPC_TALK=['Hari ni cuaca baik untuk memancing.','Dah cuba kuih di Pasar Tani?','Jom lepak Asia Mall hujung minggu!','Rajin betul awak sekarang!','Nanti datang rumah saya, saya masak.','Kawan macam awak susah nak cari.'];
function npcDialog(n){
  n.talk=8;const dx=P.x-n.x,dy=P.y-n.y;setDir(n,dx,dy);
  if(!n.named){stat('gembira',1);showDlg({title:n.name,body:`<div class="row"><img src="${headImg(n.C)}" style="width:70px;border-radius:50%;background:var(--lil)" alt=""><p style="flex:1">"${esc(n.line)}"</p></div>`,buttons:[{label:'Tutup',cls:'w',a:'closeDlg'}]});return}
  const f=S.friends[n.id]||0,fest=RT.fest;
  const line=fest?`Selamat ${fest.name}! Dah pergi sambutan di Pusat Bandar?`:f>=50?pick(NPC_TALK):n.line;
  showDlg({title:n.name,body:`<div class="row" style="align-items:flex-start"><img src="${headImg(n.C)}" style="width:80px;border-radius:50%;background:var(--lil)" alt=""><div style="flex:1"><b>${esc(n.role)}</b><br><span class="tagx" style="background:#ffe1f0;color:#b42a6a">${friendLvl(f)}</span><div class="bar" style="background:#ffe1f0;margin-top:6px"><i style="width:${f}%;background:linear-gradient(90deg,#ff9ec4,#ff5ea8)"></i></div></div></div><div class="note" id="npcLine" style="margin-top:10px">"${esc(line)}"</div>`,
    buttons:[{label:S.talked[n.id]?'Sudah berbual':'Borak',cls:'g',a:'talkTo',v:n.id,dis:S.talked[n.id]},{label:'Hadiah',cls:'y',a:'giftPick',v:n.id,dis:S.gifted[n.id]},{label:'Tutup',cls:'w',a:'closeDlg'}]});
}
ACT.talkTo=v=>{if(S.talked[v])return;S.talked[v]=1;addFriend(v,3);addXP(5);stat('gembira',2);const n=RT.npcs.find(x=>x.id===v);const el=$('#npcLine');if(el){el.textContent='"'+pick(NPC_TALK)+'"';const b=document.querySelector('[data-a="talkTo"]');if(b){b.disabled=true;b.textContent='Sudah berbual'}}toast(`Persahabatan dengan ${n.name} +3`,'g');checkAch();if(SH.id)renderSheet()};
function doInteract(){
  const n=RT.near;if(!n||RT.paused)return;
  if(n.kind==='loc')openLoc(n.id);
  else if(n.kind==='fish'){if(S.energy<3){toast('Tenaga tidak cukup.','r');return}startFishing(n.id)}
  else if(n.kind==='special'){if(n.id==='feri')openTravel('pelabuhan');else openLoc('bandar')}
  else if(n.kind==='npc')npcDialog(n.npc);
}
ACT.act0=()=>doInteract();
ACT.ride=()=>toggleRide();
ACT.runT=()=>{RT.run=!RT.run;$('#btnRun').classList.toggle('hot',RT.run)};
ACT.hudMsg=()=>openPanel('sosial','mesej');ACT.hudNot=()=>openPanel('sosial','notis');ACT.hudEvt=()=>openPanel('sosial','acara');ACT.hudProfile=()=>openPanel('pencapaian','statistik');
ACT.settings=()=>showDlg({title:'Tetapan',body:`<div class="list">
  <div class="li"><div class="t"><b>Simpan permainan</b><span>Simpanan automatik setiap 15 saat pada peranti ini.</span></div>${B('Simpan','saveNow','','g')}</div>
  <div class="li"><div class="t"><b>Joystick skrin</b><span>Untuk skrin sentuh.</span></div>${B($('#joy').style.display==='block'?'Sembunyi':'Tunjuk','joyT','','w')}</div>
  <div class="li"><div class="t"><b>Kawalan</b><span>WASD/anak panah: gerak · E/Space: aksi · Shift: lari · R: naik kenderaan · M: peta · I: almari · Esc: tutup</span></div></div>
  <div class="li"><div class="t"><b>Menu utama</b><span>Simpan dan kembali ke skrin tajuk.</span></div>${B('Keluar','toTitle','','w')}</div>
  <div class="li"><div class="t"><b>Set semula permainan</b><span>Padam semua kemajuan.</span></div>${B('Set Semula','reset','','r')}</div></div>`,buttons:[{label:'Tutup',cls:'w',a:'closeDlg'}]});
ACT.saveNow=()=>{save();toast('Permainan disimpan ✓','g')};
ACT.joyT=()=>{const j=$('#joy');j.style.display=j.style.display==='block'?'none':'block';closeDlg()};
ACT.toTitle=()=>{save();closeDlg();closeSheet();RT.paused=true;showTitle()};
