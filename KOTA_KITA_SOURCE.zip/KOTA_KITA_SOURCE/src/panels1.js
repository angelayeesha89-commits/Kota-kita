// ===================== PANELS (1) =====================
const PANELS={};
const B=(label,a,v,cls,dis)=>`<button class="btn ${cls||''}" data-a="${a}" data-v="${v===undefined?'':esc(v)}" ${dis?'disabled':''}>${label}</button>`;
const pct=(a,b)=>Math.max(0,Math.min(100,a/b*100));
const onIsland=()=>isIsland(P.x,P.y);

// ---------- travel
const MODES={
 jalan:{n:'Jalan Kaki',cost:d=>0,time:d=>Math.round(8+d*1.4),en:d=>Math.round(d/7)},
 sendiri:{n:'Kenderaan Sendiri',cost:d=>Math.round((1+d*.04)*10)/10,time:d=>Math.round(4+d*.3),en:()=>1},
 bas:{n:'Bas Bandar',cost:()=>1.5,time:d=>Math.round(15+d*.55),en:()=>2},
 lrt:{n:'LRT / MRT',cost:()=>2.5,time:d=>Math.round(10+d*.32),en:()=>2},
 keretapi:{n:'Kereta Api',cost:()=>6,time:d=>Math.round(18+d*.25),en:()=>2},
 teksi:{n:'E-hailing',cost:d=>Math.round((5+d*.35)*10)/10,time:d=>Math.round(6+d*.38),en:()=>0},
 feri:{n:'Feri',cost:()=>15,time:()=>40,en:()=>2},
 bot:{n:'Bot Sendiri',cost:()=>3,time:()=>25,en:()=>1},
};
function travelOptions(dest){
  const L=LOC[dest],d=Math.hypot(P.x/TS-L.door[0],P.y/TS-L.door[1]);
  const isl=dest==='pulau'||onIsland();const out=[];
  if(isl){out.push('feri');if(S.vehicles.includes('bot'))out.push('bot');return{d,list:out}}
  out.push('jalan');if(S.vehicles.some(v=>VEH[v].kind!=='boat'))out.push('sendiri');out.push('bas');
  if(!['kampung','ladang','hutan'].includes(dest))out.push('lrt');
  if(['kampung','ladang','hutan','pasar','keretapi','bandar','airport','lrt'].includes(dest))out.push('keretapi');
  out.push('teksi');return{d,list:out};
}
function openTravel(dest,then){
  const L=LOC[dest],o=travelOptions(dest);
  if(o.d<3&&!then){toast('Anda sudah berada di '+L.name);return}
  const rows=o.list.map(m=>{const M=MODES[m];const c=M.cost(o.d);return`<div class="li"><div class="t"><b>${M.n}</b><span>${c?fmt2(c):'Percuma'} · ${M.time(o.d)} minit${M.en(o.d)?` · Tenaga −${M.en(o.d)}`:''}</span></div>${B('Pilih','go',dest+':'+m,'g')}</div>`}).join('');
  showDlg({title:'Pergi ke '+L.name,body:`<p style="margin-top:0;color:var(--mut)">Jarak kira-kira ${(o.d*.12).toFixed(1)} km.</p><div class="list">${rows}</div>`,buttons:[{label:'Batal',cls:'w',a:'closeDlg'}]});
  DLG.then=then;
}
ACT.go=v=>{const [dest,m]=v.split(':');const then=DLG&&DLG.then;const L=LOC[dest],o=travelOptions(dest),M=MODES[m];const c=M.cost(o.d);
  if(c&&!spend(c))return;if(S.energy<M.en(o.d)){toast('Tenaga tidak cukup untuk berjalan sejauh itu.','r');return}
  S.energy-=M.en(o.d);advance(M.time(o.d));placePlayerAt(dest);if(m==='sendiri'&&S.vehicles.some(v=>VEH[v].kind!=='boat')){RT.ride=true;if(!S.ride||VEH[S.ride].kind==='boat')S.ride=S.vehicles.find(v=>VEH[v].kind!=='boat');updateActBtns()}
  closeDlg();toast(`Tiba di ${L.name} (${M.n}, ${M.time(o.d)} minit)`,'g');
  if(then)then();else closeSheet()};
function needAt(loc,fn,why){if(atLoc(loc))return fn();openTravel(loc,()=>{rerender();fn()});const t=$('#dlg h3');if(t)t.textContent=(why||'Perlu ke')+' '+LOC[loc].name}
ACT.travel=v=>openTravel(v);
ACT.goPanel=v=>{const [p,t]=v.split(':');closeDlg();openPanel(p,t)};

// ---------- PETA
PANELS.peta={title:'Peta Kota Kita',tabs:[['peta','Peta'],['lokasi','Senarai Lokasi'],['transit','Pengangkutan']],
render(t){
  if(t==='peta')return`<canvas class="minimap" id="mm"></canvas><p style="font-size:13px;color:var(--mut)">Ketik mana-mana lokasi pada peta untuk pergi. Titik kuning berkelip ialah anda.</p>`;
  if(t==='lokasi')return`<div class="grid w">${LOCS.map(l=>{const L=LOC[l[0]];const d=Math.hypot(P.x/TS-L.door[0],P.y/TS-L.door[1]);return`<div class="card"><div class="row"><span style="width:14px;height:14px;border-radius:50%;background:${L.col}"></span><h4>${esc(L.name)}</h4>${S.visited[L.id]?'':'<span class="tagx y">Baharu</span>'}</div><p>${(d*.12).toFixed(1)} km dari sini</p>${B('Pergi','travel',L.id,'',d<3)}</div>`}).join('')}</div>`;
  const own=S.vehicles.map(v=>VEH[v]);
  return`<div class="sec">Mod pengangkutan</div><div class="list">${Object.values(MODES).map(m=>`<div class="li"><div class="t"><b>${m.n}</b><span>${m.n==='Feri'?'Pelabuhan ⇄ Pulau Pelancongan':m.n==='LRT / MRT'?'Pantas dalam bandar':m.n==='Kereta Api'?'Ke kampung, ladang & hutan':m.n==='Jalan Kaki'?'Percuma tetapi memenatkan':m.n==='Kenderaan Sendiri'?'Perlu basikal, motosikal atau kereta':m.n==='Bot Sendiri'?'Perlu Bot Laju':'Tersedia di seluruh bandar'}</span></div></div>`).join('')}</div>
  <div class="sec">Kenderaan anda</div>${own.length?`<div class="list">${own.map(v=>`<div class="li"><div class="t"><b>${esc(v.name)}</b><span>${v.kind==='boat'?'Untuk ke pulau & laut dalam':'Kelajuan ×'+v.spd}</span></div></div>`).join('')}</div><p>Tekan butang <b>Naik</b> (atau kekunci R) untuk menunggang di peta.</p>`:'<div class="note">Belum ada kenderaan. Beli di Rumah → Kenderaan.</div>'}
  <div class="sec">Ke luar bandar</div><div class="note">Lapangan Terbang & Pelabuhan membawa anda ke <b>Laut Dalam Labuan</b> untuk memancing ikan besar. Lihat menu Memancing.</div>`;
},
after(t){if(t!=='peta')return;const c=$('#mm');const W=c.clientWidth,H=Math.round(W*MH/MW),d=pxr();c.style.height=H+'px';c.width=W*d;c.height=H*d;const x=c.getContext('2d');x.setTransform(d,0,0,d,0,0);const s=W/MW;
  for(let y=0;y<MH;y++)for(let i=0;i<MW;i++){x.fillStyle=TCOL[T[ti(i,y)]];x.fillRect(i*s,y*s,s+.6,s+.6)}
  for(const b of BLDS){x.fillStyle=b.loc?LOC[b.loc].col:'#b8a898';x.globalAlpha=b.loc?.85:.6;x.fillRect(b.x*s,b.y*s,b.w*s,b.h*s);x.globalAlpha=1}
  x.font=`800 ${Math.max(8,Math.min(11,s*3.2))}px Nunito,sans-serif`;x.textAlign='center';
  for(const l of LOCS){const L=LOC[l[0]];const px=(L.door[0]+.5)*s,py=L.door[1]*s;x.fillStyle='#fff';x.beginPath();x.arc(px,py,Math.max(3,s*.9),0,TAU);x.fill();x.fillStyle=L.col;x.beginPath();x.arc(px,py,Math.max(2,s*.6),0,TAU);x.fill();
    x.lineWidth=3;x.strokeStyle='rgba(255,255,255,.9)';x.strokeText(L.short,px,py-5);x.fillStyle='#2a1f47';x.fillText(L.short,px,py-5)}
  x.fillStyle='#ffd23f';x.strokeStyle='#2a1f47';x.lineWidth=2;x.beginPath();x.arc(P.x/TS*s,P.y/TS*s,Math.max(4,s*1.2),0,TAU);x.fill();x.stroke();
  c.onclick=e=>{const r=c.getBoundingClientRect(),mx=(e.clientX-r.left)/s,my=(e.clientY-r.top)/s;let best=null,bd=6;for(const l of LOCS){const L=LOC[l[0]];const dd=Math.hypot(L.door[0]+.5-mx,L.door[1]-my);if(dd<bd){bd=dd;best=L.id}}if(best)openTravel(best)}}};

// ---------- RUMAH
let ROOMSEL='bilik';
function comfort(){const H=HOUSE[S.home.type];let c=H.comfort*3;for(const r in S.home.rooms)for(const it of S.home.rooms[r].items)c+=(FURNI[it]?FURNI[it].comfort:0);return c}
function drawFurn(c,f,x,y,s){
  const col=f.c;c.save();c.translate(x,y);c.scale(s,s);const P2=()=>new Path2D();let p;
  const box=(x0,y0,w,h,cc,r)=>{p=P2();rrp(p,x0,y0,w,h,r||4);fillP(c,p,cc,1.4)};
  switch(f.shape){
  case 'bed':box(-48,-34,96,30,col);box(-48,-58,14,54,shade(col,-.25));box(-42,-44,26,12,'#fff');box(-20,-40,64,18,shade(col,.3));if(f.id==='katil3'){c.strokeStyle='#e2b44a';c.lineWidth=3;c.beginPath();c.moveTo(-48,-58);c.lineTo(-48,-100);c.lineTo(48,-100);c.lineTo(48,-34);c.stroke();c.fillStyle='rgba(255,220,240,.5)';c.fillRect(-48,-100,96,10)}break;
  case 'wardrobe':box(-30,-96,60,96,col);c.strokeStyle=shade(col,-.4);c.beginPath();c.moveTo(0,-94);c.lineTo(0,-2);c.stroke();box(-6,-54,4,10,'#e2b44a',1);box(2,-54,4,10,'#e2b44a',1);break;
  case 'desk':box(-38,-44,76,8,col);box(-36,-36,6,36,shade(col,-.2));box(30,-36,6,36,shade(col,-.2));box(-20,-62,22,18,'#f4f4f4');break;
  case 'pc':box(-38,-44,76,8,'#d8b080');box(-36,-36,6,36,'#b08050');box(30,-36,6,36,'#b08050');box(-22,-74,44,28,'#2b2b33');box(-18,-70,36,20,'#8fc0f0');break;
  case 'lamp':box(-4,-50,8,50,'#c8a060');p=P2();p.moveTo(-16,-50);p.lineTo(16,-50);p.lineTo(10,-72);p.lineTo(-10,-72);p.closePath();fillP(c,p,col);c.fillStyle='rgba(255,230,140,.35)';c.beginPath();c.arc(0,-50,30,0,TAU);c.fill();break;
  case 'ac':box(-36,-120,72,22,col);c.strokeStyle='#bbb';c.beginPath();c.moveTo(-30,-104);c.lineTo(30,-104);c.stroke();break;
  case 'sofa':box(-54,-40,108,28,col);box(-54,-62,108,26,shade(col,-.15));box(-60,-48,14,40,shade(col,-.25));box(46,-48,14,40,shade(col,-.25));box(-40,-56,30,16,shade(col,.3));break;
  case 'tv':box(-46,-96,92,54,'#1d1d24');box(-42,-92,84,46,'#3a5aa0');c.fillStyle='rgba(255,255,255,.2)';c.fillRect(-40,-90,30,42);box(-30,-40,60,40,'#8a5a33');break;
  case 'shelf':box(-30,-92,60,92,col);for(let i=0;i<3;i++){box(-26,-86+i*28,52,4,shade(col,-.3),1);for(let j=0;j<5;j++)box(-24+j*10,-106+i*28+22,7,18,['#e5484d','#3a86ff','#f2c230','#38b84a','#8c5cf2'][j],1)}break;
  case 'rug':c.fillStyle=col;c.beginPath();c.ellipse(0,-6,58,12,0,0,TAU);c.fill();c.strokeStyle='#e2b44a';c.lineWidth=2;c.beginPath();c.ellipse(0,-6,48,9,0,0,TAU);c.stroke();break;
  case 'plant':box(-14,-26,28,26,'#c8603a');c.fillStyle=col;for(const [a,b,r] of [[0,-50,16],[-12,-40,12],[12,-40,12],[0,-66,10]]){c.beginPath();c.arc(a,b,r,0,TAU);c.fill()}break;
  case 'frame':box(-30,-140,60,44,col);box(-24,-134,48,32,'#8fc0f0');c.fillStyle='#5ab84a';c.beginPath();c.moveTo(-24,-102);c.lineTo(-6,-122);c.lineTo(10,-102);c.fill();break;
  case 'deco':c.strokeStyle='#8a6a42';c.beginPath();c.moveTo(0,-150);c.lineTo(0,-120);c.stroke();p=P2();p.moveTo(0,-120);p.lineTo(14,-104);p.lineTo(0,-88);p.lineTo(-14,-104);p.closePath();fillP(c,p,col);break;
  case 'stove':box(-36,-46,72,46,'#e8e8ec');box(-34,-50,68,6,'#555');c.fillStyle='#333';c.beginPath();c.arc(-16,-50,8,0,TAU);c.arc(16,-50,8,0,TAU);c.fill();box(-20,-36,40,24,'#cfcfd8');break;
  case 'fridge':box(-28,-110,56,110,col);c.strokeStyle='#bbb';c.beginPath();c.moveTo(-28,-70);c.lineTo(28,-70);c.stroke();box(18,-100,4,20,'#999',1);box(18,-60,4,24,'#999',1);break;
  case 'table':box(-50,-46,100,10,col);box(-46,-36,6,36,shade(col,-.25));box(40,-36,6,36,shade(col,-.25));c.fillStyle='#fff';c.beginPath();c.ellipse(-16,-48,10,4,0,0,TAU);c.ellipse(16,-48,10,4,0,0,TAU);c.fill();break;
  case 'sink':box(-36,-46,72,46,'#d8c0a0');box(-26,-52,52,8,col);c.strokeStyle='#999';c.lineWidth=3;c.beginPath();c.moveTo(0,-52);c.lineTo(0,-64);c.lineTo(8,-64);c.stroke();break;
  case 'oven':box(-30,-50,60,50,col);box(-24,-40,48,26,'#5a3a2a');c.fillStyle='rgba(255,160,60,.5)';c.fillRect(-22,-38,44,22);break;
  case 'bath':box(-56,-34,112,34,col);c.fillStyle='#8fd0f0';c.fillRect(-50,-32,100,10);c.fillStyle='#fff';for(let i=0;i<5;i++){c.beginPath();c.arc(-40+i*18,-34,6,0,TAU);c.fill()}break;
  case 'shower':box(-4,-140,8,140,'#bbb');c.fillStyle='#999';c.beginPath();c.ellipse(10,-138,14,5,0,0,TAU);c.fill();c.strokeStyle='rgba(100,180,240,.6)';for(let i=-2;i<=2;i++){c.beginPath();c.moveTo(10+i*4,-132);c.lineTo(10+i*6,-60);c.stroke()}break;
  case 'washer':box(-30,-64,60,64,col);c.fillStyle='#8fc0f0';c.beginPath();c.arc(0,-30,18,0,TAU);c.fill();c.strokeStyle='#999';c.lineWidth=3;c.stroke();break;
  case 'mirror':box(-22,-140,44,64,'#e2b44a');box(-18,-136,36,56,col);break;
  case 'swing':c.strokeStyle='#8b5a2b';c.lineWidth=5;c.beginPath();c.moveTo(-40,0);c.lineTo(-30,-120);c.lineTo(30,-120);c.lineTo(40,0);c.stroke();c.lineWidth=2;c.beginPath();c.moveTo(-14,-120);c.lineTo(-14,-40);c.moveTo(14,-120);c.lineTo(14,-40);c.stroke();box(-20,-40,40,8,col);break;
  case 'flower':box(-14,-26,28,26,'#c8603a');for(let i=0;i<5;i++){c.fillStyle=col;c.beginPath();c.arc(-12+i*6,-34-(i%2)*8,6,0,TAU);c.fill()}c.fillStyle='#3a8a3a';c.fillRect(-12,-32,24,6);break;
  case 'bbq':box(-26,-50,52,16,col);c.strokeStyle='#333';c.lineWidth=3;c.beginPath();c.moveTo(-20,-34);c.lineTo(-24,0);c.moveTo(20,-34);c.lineTo(24,0);c.stroke();c.fillStyle='#ff8c42';c.fillRect(-20,-54,40,4);break;
  case 'pond':c.fillStyle='#8a8478';c.beginPath();c.ellipse(0,-12,60,16,0,0,TAU);c.fill();c.fillStyle=col;c.beginPath();c.ellipse(0,-12,52,12,0,0,TAU);c.fill();c.fillStyle='#ff8c42';c.beginPath();c.ellipse(-12,-12,6,3,0,0,TAU);c.ellipse(14,-10,6,3,0,0,TAU);c.fill();break;
  case 'aquarium':box(-46,-26,92,26,'#6b4a2b');box(-44,-86,88,60,'#9fe0f8');c.fillStyle='rgba(30,120,180,.25)';c.fillRect(-42,-70,84,42);
    {const fish=(S.aqua||[]).slice(0,6);fish.forEach((f,i)=>{const fx=-30+(i%3)*28,fy=-70+Math.floor(i/3)*22;c.save();c.translate(fx,fy);drawCreature(c,30,18,f.g,f.col,false);c.restore()})}
    c.strokeStyle='#3a8a3a';c.lineWidth=2;for(const x of [-36,34]){c.beginPath();c.moveTo(x,-28);c.quadraticCurveTo(x+6,-46,x,-60);c.stroke()}break;
  case 'trophy':box(-36,-96,72,96,col);for(let i=0;i<3;i++)box(-32,-90+i*30,64,4,shade(col,-.3),1);
    for(let i=0;i<Math.min(6,1+(S.cnt.champ||0)+Math.floor(Object.keys(S.fishdex).length/10));i++){const tx=-20+(i%3)*20,ty=-66+Math.floor(i/3)*30;c.fillStyle='#ffc531';c.beginPath();c.moveTo(tx-6,ty);c.lineTo(tx+6,ty);c.lineTo(tx+3,ty+10);c.lineTo(tx-3,ty+10);c.fill();c.fillRect(tx-4,ty+11,8,3)}break;
  case 'bench':box(-44,-34,88,8,col);box(-44,-50,88,6,col);box(-40,-26,6,26,'#555');box(34,-26,6,26,'#555');break;
  }
  c.restore();
}
function drawRoom(cv,room){
  const W=cv.clientWidth,H=cv.clientHeight,d=pxr();cv.width=W*d;cv.height=H*d;const c=cv.getContext('2d');c.setTransform(d,0,0,d,0,0);
  const R=S.home.rooms[room],wall=WALLS[R.wall]||WALLS[0],floor=FLOORS[R.floor]||FLOORS[0];const fy=H*.62;const hr=hourNow(),night=hr>=19||hr<6;
  if(room==='laman'){let g=c.createLinearGradient(0,0,0,fy);g.addColorStop(0,night?'#1a2050':'#7cc8ff');g.addColorStop(1,night?'#4a4a90':'#e6f6ff');c.fillStyle=g;c.fillRect(0,0,W,fy);
    if(!night){c.fillStyle='rgba(255,255,255,.85)';for(const [cx,cy,r] of [[.2,.18,.06],[.27,.15,.045],[.7,.12,.07],[.78,.16,.05]]){c.beginPath();c.ellipse(W*cx,H*cy,W*r,H*.035,0,0,TAU);c.fill()}c.fillStyle='#fff3b0';c.shadowColor='#ffe680';c.shadowBlur=24;c.beginPath();c.arc(W*.9,H*.12,16,0,TAU);c.fill();c.shadowBlur=0}
    c.fillStyle='#9ad07a';c.beginPath();c.moveTo(0,fy-30);c.quadraticCurveTo(W*.3,fy-60,W*.6,fy-34);c.quadraticCurveTo(W*.85,fy-14,W,fy-40);c.lineTo(W,fy);c.lineTo(0,fy);c.fill();
    for(let x=0;x<W;x+=22){const pg=c.createLinearGradient(x,0,x+14,0);pg.addColorStop(0,'#ffffff');pg.addColorStop(1,'#e6dcf2');c.fillStyle=pg;c.beginPath();c.moveTo(x,fy);c.lineTo(x,fy-44);c.lineTo(x+7,fy-52);c.lineTo(x+14,fy-44);c.lineTo(x+14,fy);c.fill()}c.fillStyle='#efe8f8';c.fillRect(0,fy-34,W,5);c.fillRect(0,fy-16,W,5);
    g=c.createLinearGradient(0,fy,0,H);g.addColorStop(0,'#8fd46e');g.addColorStop(1,'#6cbf55');c.fillStyle=g;c.fillRect(0,fy,W,H-fy);const rr=seeded(4);for(let i=0;i<70;i++){const fx=rr()*W,fyy=fy+rr()*(H-fy);c.fillStyle=['#ff7ab8','#fff','#ffd23f','#c79bff'][i%4];c.beginPath();c.arc(fx,fyy,1.6+rr()*1.4,0,TAU);c.fill()}}
  else{
    const bx0=W*.07,bx1=W*.93,top=H*.05;
    // ceiling
    c.fillStyle=shade(wall[0].startsWith('pat:')?'#f4ecff':wall[0],.3);c.beginPath();c.moveTo(0,0);c.lineTo(W,0);c.lineTo(bx1,top);c.lineTo(bx0,top);c.closePath();c.fill();
    // back wall
    if(wall[0].startsWith('pat:')){c.fillStyle=wall[0]==='pat:batik'?'#2a6a8a':'#6a1f2b';c.fillRect(bx0,top,bx1-bx0,fy-top);c.save();c.beginPath();c.rect(bx0,top,bx1-bx0,fy-top);c.clip();drawPattern(c,wall[0].slice(4),c.fillStyle,'#f2c230',bx0,top,bx1,fy);c.restore()}
    else{const wg=c.createLinearGradient(0,top,0,fy);wg.addColorStop(0,shade(wall[0],.08));wg.addColorStop(1,shade(wall[0],-.05));c.fillStyle=wg;c.fillRect(bx0,top,bx1-bx0,fy-top);
      c.fillStyle='rgba(255,255,255,.22)';for(let x=bx0+10;x<bx1;x+=22)for(let y=top+12;y<fy-16;y+=22){c.beginPath();c.arc(x+((y/22|0)%2?11:0),y,2,0,TAU);c.fill()}}
    // side walls
    const side=(pts,k)=>{c.fillStyle=shade(wall[0].startsWith('pat:')?'#e6dcf2':wall[0],k);c.beginPath();pts.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.closePath();c.fill()};
    side([[0,0],[bx0,top],[bx0,fy],[0,H]],-.1);side([[W,0],[bx1,top],[bx1,fy],[W,H]],-.17);
    c.strokeStyle='rgba(60,30,90,.18)';c.lineWidth=1.2;c.beginPath();c.moveTo(bx0,top);c.lineTo(bx0,fy);c.moveTo(bx1,top);c.lineTo(bx1,fy);c.moveTo(bx0,top);c.lineTo(bx1,top);c.stroke();
    // floor with perspective planks
    const fg=c.createLinearGradient(0,fy,0,H);fg.addColorStop(0,shade(floor[0],-.08));fg.addColorStop(1,shade(floor[0],.08));c.fillStyle=fg;c.beginPath();c.moveTo(bx0,fy);c.lineTo(bx1,fy);c.lineTo(W,H);c.lineTo(0,H);c.closePath();c.fill();
    c.save();c.clip();const vx=W/2,vy=fy-(H-fy)*1.6;c.strokeStyle='rgba(60,30,20,.14)';c.lineWidth=1;for(let i=-8;i<=8;i++){const xb=W/2+i*W/12;c.beginPath();c.moveTo(vx+(xb-vx)*((fy-vy)/(H-vy)),fy);c.lineTo(xb,H);c.stroke()}
    for(let k=1;k<7;k++){const t=Math.pow(k/7,1.6),yy=fy+(H-fy)*t;c.beginPath();c.moveTo(0,yy);c.lineTo(W,yy);c.stroke()}c.restore();
    // skirting boards
    c.fillStyle='#fffaf4';c.fillRect(bx0,fy-7,bx1-bx0,7);c.fillStyle='rgba(60,30,90,.12)';c.fillRect(bx0,fy,bx1-bx0,2);
    // window with curtains & sunbeam
    const wx=W*.4,ww=W*.2,wy=top+(fy-top)*.12,wh=(fy-top)*.5;
    c.fillStyle='#ffffff';c.fillRect(wx-7,wy-7,ww+14,wh+14);const sg=c.createLinearGradient(0,wy,0,wy+wh);sg.addColorStop(0,night?'#1a2050':'#8fd0ff');sg.addColorStop(1,night?'#3a4080':'#e8f8ff');c.fillStyle=sg;c.fillRect(wx,wy,ww,wh);
    if(!night){c.fillStyle='#9ad07a';c.beginPath();c.moveTo(wx,wy+wh);c.quadraticCurveTo(wx+ww*.4,wy+wh*.7,wx+ww,wy+wh*.82);c.lineTo(wx+ww,wy+wh);c.fill()}else{c.fillStyle='#fff6c0';c.beginPath();c.arc(wx+ww*.72,wy+wh*.3,6,0,TAU);c.fill()}
    c.fillStyle='#fff';c.fillRect(wx+ww/2-2,wy,4,wh);c.fillRect(wx,wy+wh/2-2,ww,4);c.fillStyle='#e8e0f2';c.fillRect(wx-10,wy+wh+6,ww+20,5);
    const cur=['#ffb3d6','#c9a7ff','#ffd27a','#9fd8c8'][(R.wall||0)%4];c.fillStyle='#b9a6d6';c.fillRect(wx-18,wy-12,ww+36,3.4);
    for(const sd of [-1,1]){const cx0=sd<0?wx-16:wx+ww+16;c.fillStyle=cur;c.beginPath();c.moveTo(cx0,wy-10);c.lineTo(cx0+sd*-16,wy-10);c.quadraticCurveTo(cx0+sd*-8,wy+wh*.5,cx0+sd*-12,wy+wh+4);c.lineTo(cx0,wy+wh+4);c.closePath();c.fill();c.strokeStyle=shade(cur,-.2);c.lineWidth=1;for(let k=1;k<4;k++){c.beginPath();c.moveTo(cx0+sd*-4*k,wy-8);c.lineTo(cx0+sd*-3*k,wy+wh+2);c.stroke()}}
    if(!night){c.fillStyle='rgba(255,240,190,.16)';c.beginPath();c.moveTo(wx,wy+wh);c.lineTo(wx+ww,wy+wh);c.lineTo(wx+ww*1.6,H);c.lineTo(wx-ww*.1,H);c.closePath();c.fill()}
    // pendant lamp & picture frame
    const lx=W*.22;c.strokeStyle='#5a4a6a';c.lineWidth=1.4;c.beginPath();c.moveTo(lx,0);c.lineTo(lx,top+18);c.stroke();c.fillStyle='#ffd6e8';c.beginPath();c.moveTo(lx-16,top+34);c.lineTo(lx+16,top+34);c.lineTo(lx+8,top+18);c.lineTo(lx-8,top+18);c.closePath();c.fill();c.fillStyle='#fff3b0';c.shadowColor='#ffe680';c.shadowBlur=night?30:14;c.beginPath();c.ellipse(lx,top+35,9,3.4,0,0,TAU);c.fill();c.shadowBlur=0;
    if(night){const lg=c.createRadialGradient(lx,top+40,4,lx,top+40,W*.35);lg.addColorStop(0,'rgba(255,230,160,.28)');lg.addColorStop(1,'rgba(255,230,160,0)');c.fillStyle=lg;c.fillRect(0,0,W,H)}
    const px=W*.7,py=top+(fy-top)*.18,pw=W*.11,ph=(fy-top)*.3;c.fillStyle='#c8925a';c.fillRect(px-4,py-4,pw+8,ph+8);const pg=c.createLinearGradient(0,py,0,py+ph);pg.addColorStop(0,'#ffd1e3');pg.addColorStop(1,'#c9e8ff');c.fillStyle=pg;c.fillRect(px,py,pw,ph);c.fillStyle='#8d7fd6';c.beginPath();c.moveTo(px,py+ph);c.lineTo(px+pw*.35,py+ph*.45);c.lineTo(px+pw*.6,py+ph*.7);c.lineTo(px+pw*.78,py+ph*.4);c.lineTo(px+pw,py+ph);c.fill();c.fillStyle='#fff3b0';c.beginPath();c.arc(px+pw*.78,py+ph*.25,3,0,TAU);c.fill();
    // rug
    const rx=W*.5,ry=fy+(H-fy)*.56;c.fillStyle='rgba(60,30,90,.12)';c.beginPath();c.ellipse(rx+3,ry+4,W*.24,(H-fy)*.2,0,0,TAU);c.fill();const rc=['#ffc4dd','#d9c8ff','#c8ecd8','#ffe2b0'][(R.floor||0)%4];c.fillStyle=rc;c.beginPath();c.ellipse(rx,ry,W*.24,(H-fy)*.2,0,0,TAU);c.fill();c.strokeStyle='#fff';c.lineWidth=3;c.beginPath();c.ellipse(rx,ry,W*.2,(H-fy)*.16,0,0,TAU);c.stroke();c.strokeStyle=shade(rc,-.15);c.lineWidth=1.5;c.beginPath();c.ellipse(rx,ry,W*.13,(H-fy)*.1,0,0,TAU);c.stroke();
  }
  const n=HOUSE[S.home.type].slots;const sl=[];for(let i=0;i<n;i++){const t=(i+.5)/n;sl.push([W*.06+t*W*.88,fy+(H-fy)*(.45+((i%2)*.3))])}
  const s=Math.min(1.45,H/230,W/(n*105));
  R.items.forEach((it,i)=>{if(FURNI[it]&&sl[i])drawFurn(c,FURNI[it],sl[i][0],sl[i][1],s)});
  for(let i=R.items.length;i<n;i++){const [x,y]=sl[i];c.strokeStyle='rgba(106,63,208,.45)';c.setLineDash([5,4]);c.lineWidth=2;c.strokeRect(x-26*s,y-36*s,52*s,36*s);c.setLineDash([]);c.fillStyle='rgba(106,63,208,.6)';c.font='800 18px Nunito';c.textAlign='center';c.fillText('+',x,y-12*s)}
  {const cs=Math.min(1.25,H/165);c.fillStyle='rgba(40,20,70,.22)';c.beginPath();c.ellipse(W*.9,H*.97,20*cs,5*cs,0,0,TAU);c.fill();drawChibi(c,W*.9,H*.97,cs,S.look,0,0)}
}
PANELS.rumah={title:()=>HOUSE[S.home.type].name,tabs:[['rumah','Rumah Saya'],['rehat','Tidur & Rehat'],['perabot','Kedai Perabot'],['hartanah','Hartanah'],['kenderaan','Kenderaan'],['tetamu','Jemput Tetamu']],
render(t){
  const H=HOUSE[S.home.type];
  if(t==='rumah'){const R=S.home.rooms[ROOMSEL];
    return`<div class="row" style="margin-bottom:8px"><span class="tagx">${S.home.owned?'Milik sendiri':H.rent?'Sewa '+fmt(H.rent)+'/bulan':'Rumah keluarga'}</span><span class="tagx u">Keselesaan: ${comfort()}</span><span class="tagx">${H.slots} slot setiap bilik</span></div>
    <div class="tabs">${ROOMS.map(r=>`<button class="${ROOMSEL===r[0]?'on':''}" data-a="roomSel" data-v="${r[0]}">${r[1]}</button>`).join('')}</div>
    <canvas class="room" id="roomCv"></canvas>
    <div class="sec">Perabot di ${ROOMS.find(r=>r[0]===ROOMSEL)[1]} <small>${R.items.length}/${H.slots}</small></div>
    <div class="list">${R.items.map((it,i)=>`<div class="li"><div class="t"><b>${esc(FURNI[it].name)}</b><span>Keselesaan +${FURNI[it].comfort}</span></div>${B('Simpan','furnOut',i,'w')}</div>`).join('')||'<div class="note">Bilik ini kosong.</div>'}</div>
    ${S.furn.filter(f=>FURNI[f].room===ROOMSEL).length?`<div class="sec">Dalam stor (boleh diletak)</div><div class="list">${S.furn.map((f,i)=>FURNI[f].room===ROOMSEL?`<div class="li"><div class="t"><b>${esc(FURNI[f].name)}</b></div>${B('Letak','furnIn',i,'g',R.items.length>=H.slots)}</div>`:'').join('')}</div>`:''}
    ${ROOMSEL!=='laman'?`<div class="sec">Kertas Dinding</div><div class="opts">${WALLS.map((w,i)=>`<button class="opt ${R.wall===i?'on':''}" data-a="setWall" data-v="${i}">${esc(w[1])}${w[2]&&!(S.paid||{})['w'+i]?` · ${fmt(w[2])}`:''}</button>`).join('')}</div>
    <div class="sec">Lantai</div><div class="opts">${FLOORS.map((w,i)=>`<button class="opt ${R.floor===i?'on':''}" data-a="setFloor" data-v="${i}">${esc(w[1])}${w[2]&&!(S.paid||{})['f'+i]?` · ${fmt(w[2])}`:''}</button>`).join('')}</div>`:''}`}
  if(t==='rehat'){const c=comfort();return`<div class="grid w">
    <div class="card"><h4>Tidur hingga pagi</h4><p>Pulihkan tenaga sehingga ${Math.min(maxEnergy(),60+c*2)} dan kebahagiaan +${Math.round(c/4)}. Masa melompat ke 7:00 pagi.</p>${B('Tidur','sleep','','g')}</div>
    <div class="card"><h4>Lelap sebentar (2 jam)</h4><p>Tenaga +25.</p>${B('Lelap','nap','','')}</div>
    ${S.inv.console?`<div class="card"><h4>Main konsol permainan</h4><p>Kebahagiaan +12 (1 jam).</p>${B('Main','playConsole','','')}</div>`:''}
    ${(S.home.rooms.bilik.items.includes('pc')||S.inv.laptop)?`<div class="card"><h4>Belajar di rumah</h4><p>Akademik +2 (2 jam, tenaga −10).</p>${B('Belajar','studyHome','','')}</div>`:''}
    </div><div class="note" style="margin-top:10px">Keselesaan rumah anda: <b>${c}</b>. Tambah perabot untuk tidur lebih lena.</div>`}
  if(t==='perabot')return ROOMS.map(r=>`<div class="sec">${r[1]}</div><div class="grid">${FURN.filter(f=>f.room===r[0]).map(f=>`<div class="card"><canvas class="im" data-furn="${f.id}" width="180" height="150"></canvas><h4>${esc(f.name)}</h4><p>Keselesaan +${f.comfort}</p><div class="row"><span class="price">${fmt(f.price)}</span><span class="sp"></span>${B('Beli','buyFurn',f.id,'y')}</div></div>`).join('')}</div>`).join('');
  if(t==='hartanah')return`<div class="note" style="margin-bottom:10px">Sewa dibayar setiap 1 haribulan. Beli dengan deposit 10% dan pinjaman perumahan 35 tahun, atau bayar tunai.</div><div class="grid w">${HOUSES.map(h=>`<div class="card ${S.home.type===h.id?'on':''}"><h4>${esc(h.name)}</h4><p>${esc(LOC[h.loc].name)} · ${h.slots} slot perabot/bilik · keselesaan asas ${h.comfort*3}</p>
    ${h.id==='keluarga'?`<p>Percuma — tinggal bersama keluarga.</p>${S.home.type===h.id?'<span class="tagx u">Kediaman semasa</span>':B('Pindah balik','moveHouse','keluarga:sewa','w')}`:
    `<div class="kv"><span>Sewa</span><b>${fmt(h.rent)}/bulan</b><span>Harga beli</span><b>${fmt(h.buy)}</b><span>Ansuran</span><b>${fmt(h.buy*.9/420*1.35)}/bulan</b></div>
    ${S.home.type===h.id?`<span class="tagx u">${S.home.owned?'Milik anda':'Disewa'}</span>`:`<div class="row">${B('Sewa','moveHouse',h.id+':sewa','')}${B('Beli (10% deposit)','moveHouse',h.id+':beli','y')}${B('Tunai','moveHouse',h.id+':tunai','g',!canPay(h.buy))}</div>`}`}</div>`).join('')}</div>`;
  if(t==='kenderaan')return`<div class="grid w">${VEHICLES.map(v=>{const V=VEH[v[0]],own=S.vehicles.includes(V.id);return`<div class="card ${own?'on':''}"><h4>${esc(V.name)}</h4><p>${V.kind==='boat'?'Ke Pulau & Laut Dalam Labuan tanpa tambang':'Kelajuan di peta ×'+V.spd}</p><div class="row"><span class="price">${fmt(V.price)}</span><span class="sp"></span>${own?(V.kind!=='boat'?B(S.ride===V.id?'Sedang digunakan':'Guna','useVeh',V.id,'w',S.ride===V.id):'<span class="tagx u">Dimiliki</span>'):B('Beli','buyVeh',V.id,'y')}</div></div>`}).join('')}</div>`;
  if(t==='tetamu'){const fr=NPCS.filter(n=>(S.friends[n[0]]||0)>=30);return`<div class="note" style="margin-bottom:10px">Jemput kawan rapat (tahap Kawan Rapat ke atas) ke rumah. Anda perlu berada di rumah.</div>${fr.length?`<div class="list">${fr.map(n=>`<div class="li"><img src="${headImg(RT.npcs.find(x=>x.id===n[0]).C)}" alt=""><div class="t"><b>${esc(n[1])}</b><span>${friendLvl(S.friends[n[0]])}</span></div>${B('Jemput','inviteNpc',n[0],'g',S.invited[n[0]])}</div>`).join('')}</div>`:'<div class="note y">Belum ada kawan rapat. Berbual dan beri hadiah kepada penduduk untuk berkawan.</div>'}`}
},
after(t){if(t==='rumah'){const cv=$('#roomCv');drawRoom(cv,ROOMSEL);cv.onclick=()=>{}}
  if(t==='perabot')document.querySelectorAll('canvas[data-furn]').forEach(c=>{const x=c.getContext('2d');x.fillStyle='#f6f1ff';x.fillRect(0,0,180,150);drawFurn(x,FURNI[c.dataset.furn],90,140,.95)})}};
ACT.roomSel=v=>{ROOMSEL=v;renderSheet()};
ACT.furnOut=v=>{const R=S.home.rooms[ROOMSEL];S.furn.push(R.items.splice(+v,1)[0]);rerender()};
ACT.furnIn=v=>{const R=S.home.rooms[ROOMSEL];if(R.items.length>=HOUSE[S.home.type].slots)return;R.items.push(S.furn.splice(+v,1)[0]);addXP(3);rerender()};
ACT.setWall=v=>{S.paid=S.paid||{};const w=WALLS[+v];if(w[2]&&!S.paid['w'+v]){if(!spend(w[2],'Kertas dinding '+w[1]))return;S.paid['w'+v]=1}S.home.rooms[ROOMSEL].wall=+v;rerender()};
ACT.setFloor=v=>{S.paid=S.paid||{};const w=FLOORS[+v];if(w[2]&&!S.paid['f'+v]){if(!spend(w[2],'Lantai '+w[1]))return;S.paid['f'+v]=1}S.home.rooms[ROOMSEL].floor=+v;rerender()};
ACT.buyFurn=v=>{const f=FURNI[v];if(!spend(f.price,f.name))return;S.furn.push(v);addXP(5);toast('Disimpan dalam stor. Letak di Rumah Saya.','g');rerender()};
ACT.sleep=()=>needAt(homeLoc(),()=>{const c=comfort();const now=S.time%1440;let mins=now<7*60?7*60-now:1440-now+7*60;if(mins<180)mins+=1440*0;advance(mins);S.energy=Math.min(maxEnergy(),Math.max(S.energy,60+c*2));stat('gembira',Math.round(c/4));toast(`Selamat pagi! Tenaga ${Math.round(S.energy)}.`,'g');save();rerender()},'Balik ke');
ACT.nap=()=>needAt(homeLoc(),()=>{advance(120);gainEnergy(25);toast('Segar semula! Tenaga +25','g');rerender()},'Balik ke');
ACT.playConsole=()=>needAt(homeLoc(),()=>{advance(60);stat('gembira',12);addXP(5);toast('Seronok main game! Kebahagiaan +12','g');rerender()},'Balik ke');
ACT.studyHome=()=>needAt(homeLoc(),()=>{if(!useEnergy(10))return;advance(120);stat('akademik',2);addXP(10);toast('Akademik +2','g');rerender()},'Balik ke');
ACT.moveHouse=v=>{const [id,m]=v.split(':');const h=HOUSE[id];
  const doMove=()=>{const old=S.home.rooms;S.home={type:id,owned:m!=='sewa',rooms:old};for(const r in old){while(old[r].items.length>h.slots)S.furn.push(old[r].items.pop())}placePlayerAt(h.loc);addXP(30);closeSheet();toast('Selamat berpindah ke '+h.name+'!','g');checkAch()};
  if(id==='keluarga')return confirmDlg('Pindah balik?','<p>Tinggal semula bersama keluarga (percuma).</p>','Pindah',()=>{if(S.mortgage&&S.home.owned){}doMove()});
  if(m==='sewa')return confirmDlg('Sewa '+h.name+'?',`<p>Sewa bulanan <b>${fmt(h.rent)}</b>. Bulan pertama dibayar sekarang.</p>`,'Sewa',()=>{if(!spend(h.rent,'Sewa bulan pertama'))return;doMove()});
  if(m==='tunai')return confirmDlg('Beli tunai '+h.name+'?',`<p>Harga <b>${fmt(h.buy)}</b> dibayar penuh.</p>`,'Beli',()=>{if(!spend(h.buy,'Beli '+h.name))return;doMove()});
  const dep=h.buy*.1,pay=Math.round(h.buy*.9/420*1.35);
  confirmDlg('Beli '+h.name+'?',`<div class="kv"><span>Deposit 10%</span><b>${fmt(dep)}</b><span>Pinjaman</span><b>${fmt(h.buy*.9)}</b><span>Ansuran bulanan</span><b>${fmt(pay)}</b></div><p style="font-size:13px;color:var(--mut)">Ansuran ditolak dari bank setiap 1 haribulan.</p>`,'Beli',()=>{if(S.mortgage&&S.mortgage.left>0){toast('Selesaikan pinjaman perumahan sedia ada dahulu.','r');return}if(!spend(dep,'Deposit rumah'))return;S.mortgage={house:id,left:Math.round(pay*420),pay};doMove()},'y')};
ACT.buyVeh=v=>{const V=VEH[v];confirmDlg('Beli '+V.name+'?',`<p>Harga <b>${fmt(V.price)}</b>.</p>`,'Beli',()=>{if(!spend(V.price,V.name))return;S.vehicles.push(v);if(V.kind!=='boat')S.ride=v;addXP(40);updateActBtns();toast(V.kind==='boat'?'Bot sedia di Pelabuhan!':'Tekan "Naik" untuk menunggang!','g');rerender();checkAch()},'y')};
ACT.useVeh=v=>{S.ride=v;toast('Kenderaan dipilih: '+VEH[v].name);rerender()};
ACT.inviteNpc=v=>needAt(homeLoc(),()=>{if(S.invited[v])return;S.invited[v]=1;advance(120);addFriend(v,8);stat('gembira',8);addXP(20);const n=NPCS.find(x=>x[0]===v);toast(`${n[1]} datang bertandang! Persahabatan +8`,'g');rerender()},'Balik ke');

// ---------- KERJAYA
const BIZ_EMO={stall:'🍢🍜🥤🍗🍚🧋',resto:'🍽️🍛🥘🍤🍹🧾',boutique:'👗👕👖🧕👟👜',online:'📦💻📱🧾🛒✉️',bakery:'🎂🧁🍪🥐🍩🍰',florist:'💐🌹🌻🌷🌸🎀',urban:'🌱🥬🍅🌶️💧🧺',fishbiz:'🐟🦐🦀🦑🧊⚖️',craft:'🧺🪡🎨🧵🪵🎁',freelance:'🖌️💻🎨📐🖼️📝',photobiz:'📸💍🎓🌅🖼️💡',musician:'🎸🎤🎹🥁🎶🎧',stream:'🎥🎮💬❤️🎁📱',content:'🎬📱🎵🍜💄✨'};
function ptReqOK(r){if(!r)return true;if(r==='bike')return S.vehicles.some(v=>['basikal','moto','kompak','suv','mewah'].includes(v));if(r==='moto')return S.vehicles.some(v=>['moto','kompak','suv','mewah'].includes(v));return !!S.inv[r]}
const reqName={bike:'Basikal/Motosikal',moto:'Motosikal',phone:'Telefon Pintar',camera:'Kamera',laptop:'Komputer Riba',farm:'Ladang dibesarkan',rod2:'Joran Gentian ke atas'};
function bizReqOK(r){if(!r)return true;if(r==='farm')return S.farm.size>6;if(r==='rod2')return S.rod>=1;return !!S.inv[r]}
function ptWage(j){const sk=Math.min(1,(S.ptSkill[j[0]]||0)/80);return(j[2]+(j[3]-j[2])*sk)*(1+skillLv('career')*.02+(['creator','photo'].includes(j[0])?skillLv('creative')*.04:0)+certBonus(j[0],.1))}
function ftSalary(){const J=FT_JOBS.find(j=>j[0]===S.job.id);let s=J[4]+(J[5]-J[4])*(S.job.lvl/3)*.85;const q=bestQual();const extra=Math.max(0,q.r-QRANK[J[2]]);s*=1+extra*.06;const d=S.degrees.find(x=>QRANK[x.level]>=QRANK[J[2]]);if(d){if(INST[d.inst]&&INST[d.inst].tier==='elite')s*=1.1;s*=1+Math.max(0,d.cgpa-3)*.08}s*=1+(S.job.inc||0)*.03+skillLv('career')*.02+certBonus(S.job.id,.05);return Math.round(s/10)*10}
function ftQualOK(J){return hasQual(J[2],J[3])}
PANELS.kerjaya={title:'Pusat Kerjaya',tabs:[['pt','Part-Time (Pelajar)'],['ft','Sepenuh Masa'],['biz','Usahawan'],['status','Status Kerja']],
render(t){
  const today=dayIdx();
  if(t==='pt'){const used=(S.workLog[today]||{}).pt||0;return`<div class="note" style="margin-bottom:10px">Kerja sambilan fleksibel untuk pelajar sekolah & universiti — sesiapa pun boleh. Had 8 jam sehari (hari ini: ${used} jam). Gaji meningkat dengan pengalaman.</div>
    <div class="grid w">${PT_JOBS.map(j=>{const ok=ptReqOK(j[5]);const w=ptWage(j);return`<div class="card ${ok?'':'dim'}"><div class="row"><span class="emo">${[...new Intl.Segmenter().segment(j[6])][0].segment}</span><div><h4>${esc(j[1])}</h4><p>${j[4]==='any'?'Di mana-mana':esc(LOC[j[4]].name)}</p></div></div>
    <div class="kv"><span>Kadar</span><b>RM ${j[2]}–${j[3]} / jam</b><span>Kadar anda</span><b>${fmt2(w)} / jam</b><span>Pengalaman</span><b>${S.ptSkill[j[0]]||0} jam</b>${j[5]?`<span>Keperluan</span><b>${reqName[j[5]]}</b>`:''}</div>
    <div class="row">${B('Kerja 2 jam','ptWork',j[0]+':2','g',!ok||used>6)}${B('Kerja 4 jam','ptWork',j[0]+':4','',!ok||used>4)}</div></div>`}).join('')}</div>`}
  if(t==='ft'){const st=isStudent();return`${st?`<div class="note y" style="margin-bottom:10px">Anda masih ${S.stage==='sekolah'?'pelajar sekolah':'pelajar universiti'}. Kerja sepenuh masa dibuka selepas tamat belajar. Cuba kerja sambilan dahulu!</div>`:''}
    <div class="grid w">${FT_JOBS.map(J=>{const ok=ftQualOK(J),cur=S.job&&S.job.id===J[0];return`<div class="card ${cur?'on':ok?'':'dim'}"><div class="row"><span class="emo">${[...new Intl.Segmenter().segment(J[9])][0].segment}</span><div><h4>${esc(J[1])}</h4><p>${esc(LOC[J[7]].name)} · ${esc(J[6])}</p></div></div>
    <div class="kv"><span>Gaji</span><b>${fmt(J[4])} – ${fmt(J[5])}</b><span>Kelayakan</span><b>${J[2]==='spm'?'SPM':LEVEL[J[2]].name}${J[3]?' ('+J[3].map(c=>COURSE[c]).join('/')+')':''}</b><span>Tangga</span><b>${J[8].join(' → ')}</b></div>
    ${cur?'<span class="tagx u">Kerja semasa</span>':B(ok?'Mohon':'Tidak layak','applyFT',J[0],ok?'g':'w',!ok||st)}</div>`}).join('')}</div>`}
  if(t==='biz')return`<div class="note" style="margin-bottom:10px">Pendapatan pasif dimasukkan ke bank setiap hari. Naik taraf & upah pekerja untuk untung lebih. Atau urus sendiri untuk pendapatan segera.</div><div class="grid w">${BIZ.map(b=>{const own=S.biz[b[0]],ok=bizReqOK(b[4]);return`<div class="card ${own?'on':ok?'':'dim'}"><div class="row"><span class="emo">${b[5]}</span><div><h4>${esc(b[1])}</h4><p>${own?`Tahap ${own.lvl} · ${own.staff} pekerja`:`Modal ${fmt(b[2])}`}${b[4]?` · Perlu ${reqName[b[4]]}`:''}</p></div></div>
    ${own?`<div class="kv"><span>Anggaran/hari</span><b>${fmt(b[3]*own.lvl*(1+.45*own.staff)-own.staff*b[6])}</b><span>Semalam</span><b>${own.last!=null?fmt(own.last):'—'}</b><span>Jumlah</span><b>${fmt(own.total||0)}</b></div>
      <div class="row">${B('Urus Sendiri','bizRun',b[0],'g')}${B(`Naik Taraf ${fmt(b[2]*.8*own.lvl)}`,'bizUp',b[0],'y',own.lvl>=5)}${B('Upah Pekerja (RM200)','bizHire',b[0],'w',own.staff>=own.lvl*2)}</div>`:B('Buka Perniagaan','bizStart',b[0],'y',!ok)}</div>`}).join('')}</div>`;
  // status
  const q=bestQual();
  let h=`<div class="grid w"><div class="card"><h4>Kelayakan tertinggi</h4><p>${q.q?(q.q==='spm'?`SPM (${S.spm}A)`:LEVEL[q.q].name):'Belum ada (pelajar sekolah)'}</p>${S.degrees.map(d=>`<p>${LEVEL[d.level].name} ${COURSE[d.course]} — ${INST[d.inst].abbr}, CGPA ${d.cgpa.toFixed(2)}</p>`).join('')}</div>`;
  if(S.job){const J=FT_JOBS.find(j=>j[0]===S.job.id),avg=S.job.shifts?S.job.perfSum/S.job.shifts:0,need=(S.job.lvl+1)*10;const done=(S.workLog[today]||{}).ft;
    h+=`<div class="card on"><h4>${esc(J[8][S.job.lvl])}</h4><p>${esc(J[1])} · ${esc(LOC[J[7]].name)} · ${esc(J[6])}</p><div class="kv"><span>Gaji bulanan</span><b>${fmt(ftSalary())}</b><span>Bayaran sehari</span><b>${fmt(ftSalary()/22)}</b><span>Syif selesai</span><b>${S.job.shifts}</b><span>Prestasi purata</span><b>${Math.round(avg*100)}%</b><span>Kenaikan gaji</span><b>${(S.job.inc||0)*3}%</b></div>
    <div class="stat">Kemajuan naik pangkat<div class="bar g"><i style="width:${pct(S.job.shifts,need)}%"></i></div></div>
    <div class="row">${B(done?'Syif hari ini selesai':'Mula Syif (8 jam)','ftWork','','g',!!done)}${B('Mohon Naik Pangkat','promo','','y',S.job.lvl>=3||S.job.shifts<need)}${B('Berhenti','quitJob','','r')}</div></div>`}
  else h+=`<div class="card"><h4>Tiada kerja sepenuh masa</h4><p>${isStudent()?'Fokus belajar dan cuba kerja sambilan.':'Mohon kerja di tab Sepenuh Masa.'}</p></div>`;
  return h+`</div>`;
}};
function doShift(title,emo,cb){showDlg({title,body:`<p>Main mini-game untuk prestasi lebih tinggi, atau kerja seperti biasa.</p>`,buttons:[{label:'Kerja Biasa',cls:'w',a:'shiftAuto'},{label:'Main Mini-game',cls:'g',a:'shiftGame'}]});DLG.shift={title,emo,cb}}
ACT.shiftAuto=()=>{const s=DLG.shift;closeDlg();s.cb(.92,0)};
ACT.shiftGame=()=>{const s=DLG.shift;closeDlg();startRush(s.title,s.emo,s.cb)};
ACT.ptWork=v=>{const [id,h]=v.split(':'),hrs=+h,j=PT_JOBS.find(x=>x[0]===id);const today=dayIdx();const used=(S.workLog[today]||{}).pt||0;if(used+hrs>8){toast('Had 8 jam kerja sambilan sehari.','r');return}
  const go=()=>{if(!useEnergy(hrs*5))return;doShift(j[1]+' — Syif '+hrs+' jam',j[6],perf=>{const pay=ptWage(j)*hrs*perf;advance(hrs*60);S.money+=pay;trackInc('pt',pay);S.lastPT=dayIdx();S.workLog[today]=Object.assign(S.workLog[today]||{},{pt:used+hrs});S.ptSkill[id]=(S.ptSkill[id]||0)+hrs;S.cnt.shifts++;addXP(hrs*7);stat('karisma',1);
    showDlg({title:'Syif selesai!',body:`<div class="kv"><span>Prestasi</span><b>${Math.round(perf*100)}%</b><span>Gaji</span><b>${fmt2(pay)}</b><span>XP</span><b>+${hrs*7}</b></div>`,buttons:[{label:'Bagus!',cls:'g',a:'closeDlg'}]});checkAch()})};
  if(j[4]==='any')go();else needAt(j[4],go,'Pergi kerja di')};
ACT.applyFT=v=>{const J=FT_JOBS.find(j=>j[0]===v);if(isStudent()){toast('Tamatkan pengajian dahulu.','r');return}
  const go=()=>{const d=S.degrees.find(x=>QRANK[x.level]>=QRANK[J[2]]);const p=clamp(.7+S.stats.karisma/300+(d&&d.cgpa>=3.5?.12:0)+(d&&INST[d.inst].tier==='elite'?.08:0),0,.97);advance(60);
    if(Math.random()<p){S.job={id:v,lvl:0,shifts:0,perfSum:0,start:dayIdx(),inc:0};addXP(80);addMsg(J[1],'Tawaran Kerja',`Tahniah! Anda diterima sebagai ${J[8][0]}. Lapor diri di ${LOC[J[7]].name}. Gaji permulaan ${fmt(ftSalary())} sebulan.`);showDlg({title:'Tahniah! Anda diterima!',body:`<p>Jawatan: <b>${esc(J[8][0])}</b><br>Lokasi: ${esc(LOC[J[7]].name)}<br>Gaji: <b>${fmt(ftSalary())}</b> sebulan</p>`,buttons:[{label:'Yeay!',cls:'g',a:'closeDlg'}]});checkAch()}
    else showDlg({title:'Permohonan tidak berjaya',body:'<p>Temu duga kali ini tidak berjaya. Tingkatkan karisma dan cuba lagi esok.</p>',buttons:[{label:'Okey',cls:'w',a:'closeDlg'}]});rerender()};
  if(S.job)confirmDlg('Tukar kerja?','<p>Anda akan berhenti kerja semasa jika diterima.</p>','Teruskan',go);else go()};
ACT.ftWork=()=>{const J=FT_JOBS.find(j=>j[0]===S.job.id),today=dayIdx();if((S.workLog[today]||{}).ft){toast('Syif hari ini sudah selesai.');return}
  needAt(J[7],()=>{if(!useEnergy(35))return;doShift(J[8][S.job.lvl]+' — Syif',J[9],perf=>{const pay=ftSalary()/22;advance(8*60);S.bank+=pay;trackInc('ft',pay);S.workLog[today]=Object.assign(S.workLog[today]||{},{ft:1});S.job.shifts++;S.job.perfSum+=perf;if(S.job.shifts%20===0){S.job.inc=(S.job.inc||0)+1;addMsg(J[1],'Kenaikan Gaji Tahunan','Tahniah! Gaji anda dinaikkan 3%.')}S.cnt.shifts++;addXP(45);stat('karisma',1);
    showDlg({title:'Syif selesai!',body:`<div class="kv"><span>Prestasi</span><b>${Math.round(perf*100)}%</b><span>Gaji harian (ke bank)</span><b>${fmt2(pay)}</b><span>XP</span><b>+45</b></div>`,buttons:[{label:'Bagus!',cls:'g',a:'closeDlg'}]});checkAch()})},'Pergi kerja di')};
ACT.promo=()=>{const J=FT_JOBS.find(j=>j[0]===S.job.id);const avg=S.job.perfSum/S.job.shifts;advance(60);if(Math.random()<clamp(avg-.1+S.stats.karisma/400,.2,.95)){S.job.lvl++;addXP(150);addMsg(J[1],'Kenaikan Pangkat',`Tahniah! Anda kini ${J[8][S.job.lvl]}. Gaji baharu ${fmt(ftSalary())}.`);showDlg({title:'Naik Pangkat!',body:`<p>Anda kini <b>${esc(J[8][S.job.lvl])}</b>.<br>Gaji baharu: <b>${fmt(ftSalary())}</b></p>`,buttons:[{label:'Syukur!',cls:'g',a:'closeDlg'}]});checkAch()}else{S.job.shifts=Math.max(0,S.job.shifts-3);toast('Belum berjaya. Tingkatkan prestasi dan cuba lagi.','r')}rerender()};
ACT.quitJob=()=>confirmDlg('Berhenti kerja?','<p>Anda akan kehilangan jawatan dan kemajuan pangkat.</p>','Berhenti',()=>{S.job=null;rerender()},'r');
ACT.bizStart=v=>{const b=BIZ.find(x=>x[0]===v);confirmDlg('Buka '+b[1]+'?',`<p>Modal permulaan <b>${fmt(b[2])}</b>. Pendapatan anggaran ${fmt(b[3])} sehari.</p>`,'Buka',()=>{if(!spend(b[2],'Modal '+b[1]))return;S.biz[v]={lvl:1,staff:0,total:0};addXP(80);toast('Perniagaan dibuka!','g');rerender();checkAch()},'y')};
ACT.bizUp=v=>{const b=BIZ.find(x=>x[0]===v),o=S.biz[v];if(!spend(b[2]*.8*o.lvl,'Naik taraf '+b[1]))return;o.lvl++;addXP(40);rerender()};
ACT.bizHire=v=>{const o=S.biz[v];if(!spend(200,'Yuran pengambilan pekerja'))return;o.staff++;addXP(15);toast('Pekerja NPC baharu diupah!','g');rerender()};
ACT.bizRun=v=>{const b=BIZ.find(x=>x[0]===v),o=S.biz[v];if(!useEnergy(20))return;startRush('Urus '+b[1],BIZ_EMO[v]||'💰🧾📦🛍️💳📈',perf=>{const inc=b[3]*o.lvl*.6*perf;advance(240);S.money+=inc;trackInc('biz',inc);o.total=(o.total||0)+inc;addXP(25);showDlg({title:'Hari yang sibuk!',body:`<div class="kv"><span>Prestasi</span><b>${Math.round(perf*100)}%</b><span>Untung</span><b>${fmt2(inc)}</b></div>`,buttons:[{label:'Mantap',cls:'g',a:'closeDlg'}]})})};

// ---------- PENDIDIKAN
let INSTF='all';
function semFee(e){return LEVEL[e.level].fee*TIER[INST[e.inst].tier].mult}
function eligible(inst,level){
  const I=INST[inst],T2=TIER[I.tier];
  if(['sijil','diploma','ijazah'].includes(level)){if(S.spm==null)return{ok:0,why:'Perlu keputusan SPM'};if(level==='ijazah'&&S.degrees.some(d=>d.level==='diploma'))return{ok:1};return S.spm>=T2.min[level]-1?{ok:1}:{ok:0,why:`Minimum ${T2.min[level]}A SPM`}}
  if(level==='sarjana')return S.degrees.some(d=>d.level==='ijazah')?{ok:1}:{ok:0,why:'Perlu Ijazah Sarjana Muda'};
  if(level==='phd')return S.degrees.some(d=>d.level==='sarjana')?{ok:1}:{ok:0,why:'Perlu Sarjana'};
  return{ok:0};
}
function decideApp(a){
  const I=INST[a.inst],T2=TIER[I.tier];let p;
  if(['sijil','diploma','ijazah'].includes(a.level)){const dip=a.level==='ijazah'&&S.degrees.find(d=>d.level==='diploma');if(dip)p=dip.cgpa>=(I.tier==='elite'?3.3:2.75)?.9:.35;else{const diff=S.spm-T2.min[a.level];p=diff>=0?.85+.03*diff:diff===-1?.3:.05}}
  else{const prev=S.degrees.filter(d=>d.level===(a.level==='sarjana'?'ijazah':'sarjana')).sort((x,y)=>y.cgpa-x.cgpa)[0];const mn=I.tier==='elite'?3.3:I.tier==='tajaan'?3:2.75;p=prev&&prev.cgpa>=mn?.88:.25}
  p=clamp(p+(S.stats.akademik-40)/400,.03,.98);
  a.status=Math.random()<p?'diterima':'ditolak';
  addMsg(I.name,a.status==='diterima'?'Tawaran Kemasukan':'Keputusan Permohonan',a.status==='diterima'?`Tahniah! Anda ditawarkan ${LEVEL[a.level].name} ${COURSE[a.course]} di ${I.name}. Terima tawaran di menu Pendidikan → Permohonan.`:`Dukacita dimaklumkan permohonan ${LEVEL[a.level].name} ${COURSE[a.course]} tidak berjaya. Cuba institusi lain.`);
}
PANELS.pendidikan={title:'Pusat Pendidikan Tinggi',tabs:[['sekolah','Sekolah & SPM'],['inst','Institusi (12)'],['mohon','Permohonan'],['biasiswa','Biasiswa & Pinjaman'],['kuliah','Kuliah & Peperiksaan'],['kampus','Aktiviti Kampus'],['transkrip','Transkrip & Graduasi']],
render(t){
  if(t==='sekolah'){if(S.stage==='sekolah'){const c=S.school.classes;return`<div class="card on"><h4>SMK Kota Kita — Tingkatan 5</h4><p>Hadiri 10 kelas untuk melayakkan diri ke peperiksaan SPM. Markah SPM bergantung pada kuiz peperiksaan dan tahap akademik anda.</p><div class="stat">Kelas dihadiri: ${c}/10<div class="bar"><i style="width:${pct(c,10)}%"></i></div></div><div class="kv"><span>Akademik</span><b>${S.stats.akademik}/100</b></div>
    <div class="row">${B('Hadiri Kelas (2 jam)','schClass','','g',(S.daily.sch||0)>=2)}${B('Duduki SPM','spm','','y',c<10)}</div><p style="font-size:12px">Maksimum 2 kelas sehari.</p></div>`}
    return`<div class="card"><h4>Keputusan SPM</h4><p>${S.spm!=null?`<b>${S.spm}A</b> — anda layak memohon ke IPT mengikut syarat institusi.`:'Tiada'}</p></div>`}
  if(t==='inst'){const list=INSTS.filter(i=>INSTF==='all'||i.tier===INSTF);
    return`<div class="tabs">${[['all','Semua (12)'],['elite','Elite (3)'],['tajaan','Tajaan (3)'],['awam','Awam (6)']].map(f=>`<button class="${INSTF===f[0]?'on':''}" data-a="instF" data-v="${f[0]}">${f[1]}</button>`).join('')}</div>
    <div class="grid w">${list.map((I,n)=>`<div class="card"><canvas class="im wide" data-inst="${I.id}" width="480" height="270"></canvas><div class="row"><span style="background:${I.col};color:#fff;border-radius:10px;padding:3px 8px;font-weight:900;font-family:Fredoka">${I.em}</span><h4>${esc(I.name)} (${I.abbr})</h4></div>
    <div class="row"><span class="tagx" style="background:${TIER[I.tier].col};color:#fff">${TIER[I.tier].name}</span>${I.courses.slice(0,4).map(c=>`<span class="tagx">${COURSE[c]}</span>`).join('')}</div>
    <p>${I.levels.map(l=>LEVEL[l].name).join(' · ')}<br>Yuran: dari ${fmt(LEVEL[I.levels[0]].fee*TIER[I.tier].mult)}/semester ${I.tier==='tajaan'?'· peluang tajaan penuh':I.tier==='awam'?'· yuran bersubsidi':'· biasiswa merit'}</p>
    ${B('Mohon','applyInst',I.id,'g',S.spm==null)}</div>`).join('')}</div>
    <div class="sec">Laluan Pengajian</div><div class="row">${LEVELS.map(l=>`<span class="tagx">${l[1]} (${l[2]})</span>`).join('<span>›</span>')}</div>`}
  if(t==='mohon'){if(!S.apps.length)return'<div class="note">Tiada permohonan. Pilih institusi di tab Institusi.</div>';return`<div class="list">${S.apps.map((a,i)=>`<div class="li"><div class="t"><b>${LEVEL[a.level].name} ${COURSE[a.course]}</b><span>${INST[a.inst].name} · ${a.status==='menunggu'?'Keputusan esok':a.status}</span></div>${a.status==='diterima'&&!S.edu?B('Terima & Daftar','acceptOffer',i,'g'):`<span class="tagx ${a.status==='diterima'?'u':a.status==='ditolak'?'p':'y'}">${a.status}</span>`}</div>`).join('')}</div>`}
  if(t==='biasiswa'){const e=S.edu;if(!e)return'<div class="note">Daftar ke institusi dahulu untuk memohon tajaan, biasiswa atau pinjaman.</div>';const I=INST[e.inst];
    return`<div class="grid w"><div class="card ${e.sponsor?'on':''}"><h4>${I.tier==='tajaan'?'Tajaan Penuh '+I.abbr:'Biasiswa Merit'}</h4><p>${I.tier==='tajaan'?'Yuran ditanggung penuh + elaun RM300 setiap semester. Syarat: 7A SPM / CGPA 3.30.':'Yuran ditanggung penuh. Syarat: 9A SPM / CGPA 3.70.'}</p>${e.sponsor?'<span class="tagx u">Diluluskan</span>':e.sponsorTried?'<span class="tagx p">Tidak berjaya</span>':B('Mohon','applySponsor','','g')}</div>
    <div class="card ${e.loan?'on':''}"><h4>Pinjaman Pendidikan Nasional</h4><p>Pinjaman menanggung yuran semester. Bayar balik RM200 sebulan selepas tamat belajar.</p><div class="kv"><span>Hutang semasa</span><b>${fmt(S.debt)}</b></div>${e.loan?'<span class="tagx u">Aktif</span>':B('Mohon Pinjaman','applyLoan','','y',!!e.sponsor)}</div></div>`}
  if(t==='kuliah'){const e=S.edu;if(!e)return'<div class="note">Anda belum mendaftar di mana-mana institusi.</div>';const I=INST[e.inst];
    return`<div class="card on"><h4>${LEVEL[e.level].name} ${COURSE[e.course]}</h4><p>${I.name} · Semester ${e.sem}/${e.sems}${e.sponsor?' · Ditaja':e.loan?' · Pinjaman':''}</p>
    ${!e.feePaid?`<div class="note y">Yuran semester ${fmt(semFee(e))} belum dijelaskan.</div><div class="row">${B('Bayar Yuran','payFee','','y')}</div>`:`
    <div class="stat">Kelas: ${e.classes}/3<div class="bar"><i style="width:${pct(e.classes,3)}%"></i></div></div>
    <div class="stat">Tugasan: ${e.assign!=null?Math.round(e.assign*100)+'%':'belum'}</div>
    <div class="row">${B('Hadiri Kuliah (2 jam)','uniClass','','g',e.classes>=3||(S.daily.uni||0)>=2)}${B('Siapkan Tugasan','uniAssign','','',e.assign!=null)}${B('Peperiksaan Akhir','uniExam','','y',e.classes<3||e.assign==null)}</div>`}
    ${e.gpas.length?`<div class="sec">GPA semester</div><div class="row">${e.gpas.map((g,i)=>`<span class="tagx">S${i+1}: ${g.toFixed(2)}</span>`).join('')}</div>`:''}</div>`}
  if(t==='kampus'){if(!S.edu)return'<div class="note">Aktiviti kampus dibuka apabila anda mendaftar di universiti atau kolej.</div>';return`<div class="grid">${CLUBS.map(c=>{const j=S.clubs.includes(c[0]);return`<div class="card ${j?'on':''}"><h4>${c[0]}</h4><p>Meningkatkan ${{karisma:'karisma',akademik:'akademik',cergas:'kecergasan',gembira:'kebahagiaan'}[c[1]]}</p>${j?B('Sertai Aktiviti','clubAct',c[0],'g',S.daily['club'+c[0]]):B('Sertai Kelab','joinClub',c[0],'')}</div>`}).join('')}</div>`}
  return`<div class="card"><h4>SPM</h4><p>${S.spm!=null?S.spm+'A':'Belum'}</p></div><div class="sec">Ijazah & Sijil</div>${S.degrees.length?`<div class="list">${S.degrees.map(d=>`<div class="li"><span class="emo">🎓</span><div class="t"><b>${LEVEL[d.level].name} ${COURSE[d.course]}</b><span>${INST[d.inst].name} · CGPA ${d.cgpa.toFixed(2)}${d.cgpa>=3.67?' · Kepujian Kelas Pertama':''}</span></div></div>`).join('')}</div>`:'<div class="note">Belum ada graduasi.</div>'}`;
},
after(t){if(t==='inst')document.querySelectorAll('canvas[data-inst]').forEach(c=>drawInstCard(c,INST[c.dataset.inst]))}};
function drawInstCard(c,I){const x=c.getContext('2d'),W=480,H=270;const g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,'#8fd0ff');g.addColorStop(1,'#e8f6ff');x.fillStyle=g;x.fillRect(0,0,W,H);x.fillStyle='#8fd46e';x.fillRect(0,H*.8,W,H*.2);
  const b={kind:I.tier==='elite'?'uni':I.tier==='tajaan'?'gov':'school',x:0,y:0,w:10,h:6,tall:24,label:I.name.length>26?I.abbr:I.name.toUpperCase(),c:I.col};
  const bw=b.w*TS,bh=b.h*TS+b.tall+30,s=Math.min((H*.8-14)/bh,(W*.86)/bw);x.save();x.translate(W/2-bw*s/2,H*.8-b.h*TS*s);x.scale(s,s);drawBuilding(x,b);x.restore();
  for(const [tx,sc] of [[.06,.9],[.9,1],[.18,.7],[.8,.75]]){x.save();x.translate(W*tx-48*sc,H*.84-64*sc);x.scale(sc,sc);drawTree(x,{tx:1,ty:1,kind:I.id==='usn'||I.id==='utj'?'palm':'round',s:tx});x.restore()}
  x.fillStyle=I.col;x.fillRect(0,0,W,8)}
ACT.instF=v=>{INSTF=v;renderSheet()};
ACT.schClass=()=>needAt('sekolah',()=>{if((S.daily.sch||0)>=2){toast('Sudah 2 kelas hari ini.');return}if(!useEnergy(12))return;advance(120);S.school.classes++;S.daily.sch=(S.daily.sch||0)+1;stat('akademik',2);S.cnt.classes++;addXP(12);toast('Kelas selesai! Akademik +2','g');rerender()},'Pergi ke');
ACT.spm=()=>needAt('sekolah',()=>{if(!useEnergy(15))return;startQuiz('Peperiksaan SPM',10,sc=>{advance(240);const a=clamp(Math.round(sc*8+S.stats.akademik/25),1,10);S.spm=a;S.stage='lepasan';addXP(120);stat('gembira',10);addMsg('Lembaga Peperiksaan','Keputusan SPM',`Anda memperoleh ${a}A. ${a>=8?'Cemerlang!':a>=5?'Tahniah!':'Teruskan usaha!'}`);showDlg({title:'Keputusan SPM',body:`<p style="font-size:42px;margin:0;text-align:center;font-family:Fredoka;color:var(--pur)">${a}A</p><p style="text-align:center">${a>=8?'Cemerlang! Universiti Elite menanti.':a>=5?'Tahniah! Banyak pilihan IPT untuk anda.':'Kolej Komuniti dan universiti awam sedia membantu.'}</p>`,buttons:[{label:'Pilih Universiti',cls:'g',a:'goPanel',v:'pendidikan:inst'}]});checkAch()})},'Pergi ke');
ACT.applyInst=v=>{const I=INST[v];showDlg({title:'Mohon ke '+I.abbr,body:`<p>${esc(I.name)}</p><div class="stat">Peringkat<select id="apLv" style="padding:10px;border-radius:12px;border:2px solid var(--lil2)">${I.levels.map(l=>{const e=eligible(v,l);return`<option value="${l}" ${e.ok?'':'disabled'}>${LEVEL[l].name} (${LEVEL[l].dur})${e.ok?'':' — '+e.why}</option>`}).join('')}</select></div>
  <div class="stat" style="margin-top:8px">Kursus<select id="apCo" style="padding:10px;border-radius:12px;border:2px solid var(--lil2)">${I.courses.map(c=>`<option value="${c}">${COURSE[c]}</option>`).join('')}</select></div><p style="font-size:13px;color:var(--mut)">Keputusan dihantar ke peti mesej esok.</p>`,buttons:[{label:'Batal',cls:'w',a:'closeDlg'},{label:'Hantar Permohonan',cls:'g',a:'appSubmit',v}]})};
ACT.appSubmit=v=>{const lv=$('#apLv').value,co=$('#apCo').value;const e=eligible(v,lv);if(!e.ok){toast(e.why||'Tidak layak','r');return}if(S.apps.some(a=>a.inst===v&&a.level===lv&&a.status==='menunggu')){toast('Permohonan sama sedang diproses.');return}
  S.apps.unshift({inst:v,level:lv,course:co,day:dayIdx(),status:'menunggu'});addXP(10);closeDlg();toast('Permohonan dihantar! Keputusan esok.','g');SH.tab='mohon';rerender()};
ACT.acceptOffer=v=>{const a=S.apps[+v];if(S.edu){toast('Anda sedang belajar.','r');return}const L=LEVEL[a.level];let sems=L.sems;if(a.level==='ijazah'&&a.course==='med')sems=5;
  S.edu={inst:a.inst,level:a.level,course:a.course,sem:1,sems,classes:0,assign:null,gpas:[],sponsor:null,loan:false,feePaid:false};a.status='didaftar';S.stage='universiti';
  addXP(50);showDlg({title:'Selamat datang ke '+INST[a.inst].abbr+'!',body:`<p>Anda kini pelajar ${esc(L.name)} ${COURSE[a.course]}. Yuran semester: <b>${fmt(semFee(S.edu))}</b>.</p><div class="note">Mohon tajaan/biasiswa atau pinjaman sebelum membayar yuran.</div>`,buttons:[{label:'Biasiswa & Pinjaman',cls:'g',a:'goPanel',v:'pendidikan:biasiswa'}]});rerender()};
ACT.applySponsor=()=>{const e=S.edu,I=INST[e.inst];if(e.sponsorTried)return;e.sponsorTried=1;const cg=S.degrees.length?Math.max(...S.degrees.map(d=>d.cgpa)):0;let p;
  if(I.tier==='tajaan')p=(S.spm>=7||cg>=3.3)?.9:.3;else p=(S.spm>=9||cg>=3.7)?.8:.08;
  if(Math.random()<p){e.sponsor=I.tier==='tajaan'?'Tajaan '+I.abbr:'Biasiswa Merit';if(e.feePaid&&!e.loan){S.money+=semFee(e)}e.feePaid=true;if(I.tier==='tajaan')S.money+=300;addXP(60);showDlg({title:'Tajaan diluluskan!',body:`<p>${esc(e.sponsor)} menanggung yuran pengajian anda sepenuhnya${I.tier==='tajaan'?' serta elaun RM300 setiap semester':''}.</p>`,buttons:[{label:'Alhamdulillah!',cls:'g',a:'closeDlg'}]})}
  else showDlg({title:'Permohonan tidak berjaya',body:'<p>Cuba mohon Pinjaman Pendidikan Nasional untuk menampung yuran.</p>',buttons:[{label:'Okey',cls:'w',a:'closeDlg'}]});rerender()};
ACT.applyLoan=()=>{S.edu.loan=true;if(!S.edu.feePaid){S.debt+=semFee(S.edu);S.edu.feePaid=true}toast('Pinjaman diluluskan. Yuran ditanggung.','g');rerender()};
ACT.payFee=()=>{const e=S.edu,f=semFee(e);if(e.sponsor){e.feePaid=true;rerender();return}if(e.loan){S.debt+=f;e.feePaid=true;rerender();return}if(!spend(f,'Yuran semester'))return;e.feePaid=true;rerender()};
ACT.uniClass=()=>needAt('uni',()=>{if(!useEnergy(12))return;advance(120);S.edu.classes++;S.daily.uni=(S.daily.uni||0)+1;stat('akademik',1);S.cnt.classes++;addXP(15);if(Math.random()<.3){addFriend(pick(['aiman','siti']),2)}toast('Kuliah selesai!','g');rerender()},'Pergi ke');
ACT.uniAssign=()=>{if(!useEnergy(10))return;startQuiz('Tugasan '+COURSE[S.edu.course],3,sc=>{advance(90);S.edu.assign=sc;addXP(15);toast(`Tugasan dihantar: ${Math.round(sc*100)}%`,'g');rerender()})};
ACT.uniExam=()=>needAt('uni',()=>{if(!useEnergy(15))return;startQuiz('Peperiksaan Akhir Semester '+S.edu.sem,5,sc=>{const e=S.edu;advance(180);const gpa=Math.round(clamp(1.7+sc*1.55+e.assign*.45+S.stats.akademik/100*.5+skillLv('edu')*.03,1,4)*100)/100;e.gpas.push(gpa);addXP(60);stat('akademik',2);
  if(e.sem>=e.sems)return graduate();e.sem++;e.classes=0;e.assign=null;e.feePaid=!!e.sponsor&&(e.fpct||1)>=1;if(e.fund==='gov'||(e.sponsor&&!e.fund&&INST[e.inst].tier==='tajaan'))S.money+=300;if(e.loan&&!e.sponsor){S.debt+=semFee(e);e.feePaid=true}
  showDlg({title:'Keputusan Semester',body:`<p>GPA semester ini: <b style="font-size:26px;color:var(--pur)">${gpa.toFixed(2)}</b></p><p>Teruskan ke semester ${e.sem}/${e.sems}.</p>`,buttons:[{label:'Teruskan',cls:'g',a:'closeDlg'}]});rerender()})},'Pergi ke');
function graduate(){const e=S.edu;const cg=Math.round(e.gpas.reduce((a,b)=>a+b,0)/e.gpas.length*100)/100;S.degrees.push({level:e.level,course:e.course,inst:e.inst,cgpa:cg,day:dayIdx()});S.edu=null;S.stage='graduan';addXP(250);stat('gembira',20);
  const hon=cg>=3.67?'Kepujian Kelas Pertama':cg>=3?'Kepujian Kelas Kedua Atas':cg>=2.5?'Kepujian Kelas Kedua Bawah':'Lulus';
  addMsg(INST[e.inst].name,'Majlis Konvokesyen',`Tahniah atas penganugerahan ${LEVEL[e.level].name} ${COURSE[e.course]} (${hon}), CGPA ${cg.toFixed(2)}.`);
  showDlg({title:'Majlis Konvokesyen 🎓',body:`<img src="${charImg(Object.assign({},S.look,{hat:0}),260,230,1.6,6)}" style="width:150px;display:block;margin:0 auto" alt=""><p style="text-align:center"><b>${esc(LEVEL[e.level].name)} ${COURSE[e.course]}</b><br>${esc(INST[e.inst].name)}<br>CGPA <b>${cg.toFixed(2)}</b> — ${hon}</p><div class="note g">Anda kini layak memohon kerja sepenuh masa di Pusat Kerjaya!</div>`,buttons:[{label:'Cari Kerja',cls:'g',a:'nav',v:'kerjaya'}]});checkAch();rerender()}
ACT.joinClub=v=>{S.clubs.push(v);addXP(10);toast('Selamat menyertai '+v,'g');rerender()};
ACT.clubAct=v=>needAt('uni',()=>{if(!useEnergy(10))return;const c=CLUBS.find(x=>x[0]===v);advance(120);stat(c[1],3);S.daily['club'+v]=1;addXP(15);addFriend(pick(['aiman','siti']),3);toast(`Aktiviti ${v} selesai!`,'g');rerender()},'Pergi ke');
