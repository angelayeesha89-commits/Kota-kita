// ===================== PANELS (2) =====================
// ---------- ALMARI
let WDIR=0,WGRP='Melayu',WALL=false,WSUB='asas';
const thumb=id=>charImg(Object.assign({},S.look,{outfit:id,hat:0}),140,150,1.04,4,'th'+id+S.look.g+S.look.skin+S.look.hair+S.look.hairCol+S.look.hijab+S.look.hijabCol+S.look.hijabSt+S.look.face);
function outfitPrice(o){return RT.fest&&o.cat==='tradisi'?Math.round(o.price*.7):o.price}
function outfitCard(o){const own=S.owned.includes(o.id),on=S.look.outfit===o.id,pr=outfitPrice(o);
  return`<div class="card ${on?'on':''}"><img class="im" src="${thumb(o.id)}" alt="" loading="lazy"><h4>${esc(o.name)}</h4>${o.desc?`<p>${esc(o.desc)}</p>`:''}<div class="row">${own?'':`<span class="price">${pr?fmt(pr):'Percuma'}</span>${pr<o.price?'<span class="tagx l">−30%</span>':''}`}<span class="sp"></span>${own?B(on?'Dipakai':'Pakai','wear',o.id,on?'w':'g',on):B('Beli','buyOutfit',o.id,'y')}</div></div>`}
function outfitList(cats){const g=S.look.g;return OUTFITS.filter(o=>cats.includes(o.cat)&&(WALL||o.g==='u'||o.g===g))}
PANELS.almari={title:'Almari / Pakaian',tabs:()=>[...OUTFIT_CATS,['gaya','Ubah Gaya'],['set','Set Disimpan']],
render(t){
  let right='';
  if(t==='tradisi'){right=`<div class="tabs">${TRAD_GRP.map(g=>`<button class="${WGRP===g[0]?'on':''}" data-a="wgrp" data-v="${g[0]}">${g[1]}</button>`).join('')}</div>${RT.fest?'<div class="note y" style="margin-bottom:8px">Diskaun perayaan 30% untuk pakaian tradisional hari ini!</div>':''}<div class="grid">${outfitList(['tradisi']).filter(o=>o.grp===WGRP).map(outfitCard).join('')}</div>`}
  else if(t==='kasut'){right=`<div class="sec">Kasut</div><div class="grid s">${SHOES.map(s=>{const sh=SHOE[s[0]],own=S.ownedShoes.includes(sh.id),on=S.look.shoes===sh.id;return`<div class="card ${on?'on':''}"><div style="height:40px;border-radius:12px;background:linear-gradient(90deg,${sh.c} 50%,${shade(sh.c,-.25)} 50%);border:2px solid var(--lil2)"></div><h4>${esc(sh.name)}</h4>${own?B(on?'Dipakai':'Pakai','wearShoe',sh.id,on?'w':'g',on):B(fmt(sh.price),'buyShoe',sh.id,'y')}</div>`}).join('')}</div>
    ${accShop('Topi','hat',HATS,'ownedHats')}${accShop('Cermin Mata','glasses',GLASSES,'ownedGlasses')}${accShop('Beg','bag',BAGS,'ownedBags')}${accShop('Fon Kepala & Jam','acc',ACCS,'ownedAccs')}${accShop('Anting-anting','ear',EARS,'ownedEars')}${accShop('Aksesori Leher','neck',NECKS,'ownedNecks')}${S.look.g==='f'?accShop('Gaya Hijab','hijabSt',HIJAB_ST,'ownedHijab'):''}`}
  else if(t==='gaya'){const sub=[['asas','Kulit & Wajah'],['mata','Mata'],['muka','Hidung & Mulut'],['rambut','Rambut'],['hijab','Hijab']];right=`<div class="tabs">${sub.map(s=>`<button class="${WSUB===s[0]?'on':''}" data-a="wsub" data-v="${s[0]}">${s[1]}</button>`).join('')}</div>${WSUB==='rambut'&&!S.daily.salon?`<div class="note">Tukar gaya & warna rambut di <b>Salon Kecantikan, Asia Mall</b> (RM35).</div>${B('Pergi ke Salon','salon','','g')}`:lookEditor(S.look,WSUB,'almari')}`}
  else if(t==='set'){right=`<div class="note" style="margin-bottom:8px">Simpan gabungan pakaian kegemaran anda (maksimum 8).</div>${B('Simpan Gaya Semasa','saveStyle','','g',S.styles.length>=8)}<div class="grid" style="margin-top:10px">${S.styles.map((st,i)=>`<div class="card"><img class="im" src="${charImg(Object.assign({},S.look,st),140,150,1.22,6)}" alt=""><h4>Set ${i+1}</h4><p>${esc(OUT[st.outfit].name)}</p><div class="row">${B('Pakai','wearStyle',i,'g')}${B('Padam','delStyle',i,'w')}</div></div>`).join('')}</div>`}
  else{right=`<div class="row" style="margin-bottom:8px"><label class="tagx" style="cursor:pointer"><input type="checkbox" data-a="wall" ${WALL?'checked':''} style="vertical-align:middle"> Tunjuk pakaian semua jantina</label></div><div class="grid">${outfitList([t]).map(outfitCard).join('')||'<div class="note">Tiada pakaian dalam kategori ini.</div>'}</div>`}
  return`<div class="wardrobe"><div class="wprev"><canvas id="wcv"></canvas><div class="row" style="justify-content:center">${B('⟲','wrot','-1','w')}${B('Simpan Set','saveStyle','','',S.styles.length>=8)}${B('⟳','wrot','1','w')}</div></div><div>${right}</div></div>`;
},
after(){const c=$('#wcv');if(!c)return;const W=c.clientWidth,H=c.clientHeight,d=pxr();c.width=W*d;c.height=H*d;const x=c.getContext('2d');x.setTransform(d,0,0,d,0,0);x.fillStyle='rgba(255,255,255,.6)';x.beginPath();x.ellipse(W/2,H-14,W*.3,12,0,0,TAU);x.fill();drawChibi(x,W/2,H-14,Math.min((H-26)/(animeHeight(S.look)+(S.look.hat?6:0)),W/70),S.look,WDIR,0)}};
function accShop(title,key,list,ownKey){return`<div class="sec">${title}</div><div class="opts">${list.map((a,i)=>{const own=S[ownKey].includes(i)||!a[1];const on=S.look[key]===i;return`<button class="opt ${on?'on':''}" data-a="${own?'wearAcc':'buyAcc'}" data-v="${key}:${i}:${ownKey}">${esc(a[0])}${own?'':` · ${fmt(a[1])}`}</button>`}).join('')}</div>`}
function refreshLook(){clearSprites('player');drawPortrait();rerender()}
ACT.wgrp=v=>{WGRP=v;renderSheet()};ACT.wsub=v=>{WSUB=v;renderSheet()};ACT.wall=()=>{WALL=!WALL;renderSheet()};
ACT.wrot=v=>{WDIR=(WDIR+(+v)+4)%4;PANELS.almari.after()};
ACT.wear=v=>{S.look.outfit=v;refreshLook()};
ACT.buyOutfit=v=>{const o=OUT[v],pr=outfitPrice(o);if(!spend(pr,o.name))return;S.owned.push(v);S.look.outfit=v;addXP(o.cat==='tradisi'?25:10);refreshLook();checkAch()};
ACT.wearShoe=v=>{S.look.shoes=v;refreshLook()};
ACT.buyShoe=v=>{const s=SHOE[v];if(!spend(s.price,s.name))return;S.ownedShoes.push(v);S.look.shoes=v;addXP(5);refreshLook()};
ACT.wearAcc=v=>{const [k,i]=v.split(':');S.look[k]=+i;refreshLook()};
ACT.buyAcc=v=>{const [k,i,ok]=v.split(':');const list={hat:HATS,glasses:GLASSES,acc:ACCS,hijabSt:HIJAB_ST}[k];if(!spend(list[+i][1],list[+i][0]))return;S[ok].push(+i);S.look[k]=+i;addXP(5);refreshLook()};
ACT.saveStyle=()=>{if(S.styles.length>=8)return;const L=S.look;S.styles.push({outfit:L.outfit,shoes:L.shoes,hat:L.hat,glasses:L.glasses,acc:L.acc,hijab:L.hijab,hijabSt:L.hijabSt,hijabCol:L.hijabCol});toast('Gaya disimpan!','g');rerender()};
ACT.wearStyle=v=>{const st=S.styles[+v];if(!S.owned.includes(st.outfit)){toast('Pakaian ini tiada dalam almari.','r');return}Object.assign(S.look,st);refreshLook()};
ACT.delStyle=v=>{S.styles.splice(+v,1);rerender()};

// ---------- KEDAI (ASIA MALL)
const SHOPS={g:[['pasaraya','Pasar Raya','🛒','Barang dapur, makanan haiwan & umpan'],['kosmetik','Kosmetik','💄','Penjagaan diri: +Karisma'],['emas','Barang Kemas','💍','Aksesori & barang kemas'],['kafe','Kafe Kopi','☕','Minuman: +Tenaga']],
 1:[['fesyen','Butik Fesyen','👕','Harian, moden & kampus'],['warisan','Butik Warisan','🌺','Pakaian tradisional Malaysia'],['hijab','Hijab House','🧕','Fesyen muslimah & hijab'],['kasut','Kedai Kasut','👟','Kasut pelbagai gaya'],['sukan','Sukan & Uniform','⚽','Sukan, sekolah & uniform kerja']],
 2:[['buku','Kedai Buku','📚','Buku: +Akademik'],['elektronik','Elektronik','💻','Telefon, laptop, kamera'],['salon','Salon Kecantikan','💇','Tukar gaya rambut'],['restoran','Restoran Selera','🍽️','Hidangan istimewa']],
 3:[['medan','Medan Selera','🍜','Makanan murah & sedap'],['arked','Arked','🕹️','Main mini-game'],['pawagam','Pawagam','🎬','Tonton wayang'],['karaoke','Karaoke','🎤','Nyanyi bersama kawan']]};
const SHOPN=Object.fromEntries(Object.values(SHOPS).flat().map(s=>[s[0],s]));
const COSM=[['Krim Pelembap',25,1],['Set Penjagaan Kulit',45,3],['Set Solekan / Dandanan',90,4],['Minyak Wangi',120,6]];
const BOOKS=[['Buku Rujukan SPM',35,'akademik',4],['Ensiklopedia Sains',80,'akademik',7],['Pengurusan Kewangan Peribadi',45,'akademik',3],['Sejarah Malaysia Bergambar',40,'akademik',3],['Seni Berucap',55,'karisma',4]];
const GADGETS=[['phone','Telefon Pintar',1200,'Content creator, live streaming'],['laptop','Komputer Riba',2800,'Bisnes online, freelance, belajar'],['camera','Kamera DSLR',2200,'Jurugambar, studio foto'],['console','Konsol Permainan',1900,'Kebahagiaan di rumah']];
const DRINKS=[['Kopi Latte','☕',9,18,4],['Teh Tarik','🥤',4,10,3],['Kek Batik','🍰',8,12,6],['Air Kelapa','🥥',5,10,4]];
const RESTO=[['Nasi Kerabu','🍛',15,45,10],['Set Ikan Bakar','🐟',22,50,12],['Roti John','🥖',10,35,8],['Sup Tulang','🍲',18,45,10]];
const MOVIES=['Kapten Borneo','Cinta di Pulau Manukan','Misteri Jeti Lama','Wira Kota Kita'];
PANELS.kedai={title:'Asia Mall',tabs:[['g','Tingkat G'],['1','Tingkat 1'],['2','Tingkat 2'],['3','Tingkat 3']],
render(t,arg){
  if(arg){const s=SHOPN[arg];return`<div class="row" style="margin-bottom:10px">${B('‹ Kembali','shop','','w')}<h4 style="margin:0;font-family:Fredoka;font-size:20px">${s[2]} ${esc(s[1])}</h4></div>${shopBody(arg)}`}
  return`${atLoc('mall')?'':'<div class="note y" style="margin-bottom:10px">Anda membeli-belah dalam talian. Makan, wayang, arked, karaoke & salon perlu datang ke Asia Mall.</div>'}<div class="grid">${SHOPS[t].map(s=>`<button class="card" data-a="shop" data-v="${s[0]}" style="text-align:left"><span class="emo" style="font-size:36px;width:100%;height:80px">${s[2]}</span><h4>${esc(s[1])}</h4><p>${esc(s[3])}</p></button>`).join('')}</div>`;
}};
function shopBody(id){
  const og=c=>`<div class="grid">${outfitList(c).map(outfitCard).join('')}</div>`;
  switch(id){
  case 'fesyen':return`<div class="sec">Harian</div>${og(['harian'])}<div class="sec">Moden & Trend</div>${og(['moden'])}<div class="sec">Kolej / Universiti</div>${og(['kolej'])}<div class="sec">Majlis & Formal</div>${og(['formal'])}`;
  case 'warisan':return TRAD_GRP.map(g=>`<div class="sec">${g[1]}</div><div class="grid">${outfitList(['tradisi']).filter(o=>o.grp===g[0]).map(outfitCard).join('')}</div>`).join('');
  case 'hijab':return`${og(['muslimah'])}${S.look.g==='f'?accShop('Gaya Hijab','hijabSt',HIJAB_ST,'ownedHijab'):''}`;
  case 'sukan':return`<div class="sec">Sukan</div>${og(['sukan'])}<div class="sec">Sekolah</div>${og(['sekolah'])}<div class="sec">Uniform Kerja</div>${og(['kerja'])}`;
  case 'kasut':return`<div class="grid s">${SHOES.map(s=>{const sh=SHOE[s[0]],own=S.ownedShoes.includes(sh.id);return`<div class="card"><div style="height:40px;border-radius:12px;background:${sh.c};border:2px solid var(--lil2)"></div><h4>${esc(sh.name)}</h4>${own?'<span class="tagx u">Dimiliki</span>':B(fmt(sh.price),'buyShoe',sh.id,'y')}</div>`}).join('')}</div>`;
  case 'emas':return accShop('Anting-anting','ear',EARS,'ownedEars')+accShop('Rantai & Kalung','neck',NECKS,'ownedNecks')+accShop('Beg','bag',BAGS,'ownedBags')+accShop('Fon Kepala & Jam','acc',ACCS,'ownedAccs')+accShop('Cermin Mata','glasses',GLASSES,'ownedGlasses')+accShop('Topi','hat',HATS,'ownedHats');
  case 'pasaraya':return`<div class="sec">Barang Dapur</div><div class="list">${GROCERY.map((g,i)=>`<div class="li"><span class="emo">${ITEMS[g[0]]?ITEMS[g[0]][1]:'🛒'}</span><div class="t"><b>${esc(g[1])}</b><span>Ada: ${S.inv[g[0]]||0}</span></div><span class="price">${fmt2(g[2])}</span>${B('Beli','buyGroc',i,'y')}</div>`).join('')}</div>
    <div class="sec">Umpan</div><div class="list">${BAITS.map(b=>`<div class="li"><span class="emo">🪱</span><div class="t"><b>${b[1]}${b[7]?'':' ×10'}</b><span>Ada: ${S.baits[b[0]]||0}</span></div><span class="price">${fmt(b[7]?b[2]:b[2]*10)}</span>${B('Beli','buyBait',b[0],'y',b[7]&&S.baits[b[0]])}</div>`).join('')}</div>`;
  case 'kosmetik':S.bought=S.bought||{};return`<div class="list">${COSM.map((c,i)=>`<div class="li"><span class="emo">💄</span><div class="t"><b>${c[0]}</b><span>Karisma +${c[2]}</span></div><span class="price">${fmt(c[1])}</span>${B('Beli','buyCosm',i,'y')}</div>`).join('')}</div>`;
  case 'buku':S.bought=S.bought||{};return`<div class="list">${BOOKS.map((b,i)=>`<div class="li"><span class="emo">📚</span><div class="t"><b>${b[0]}</b><span>${b[2]==='akademik'?'Akademik':'Karisma'} +${b[3]}</span></div><span class="price">${fmt(b[1])}</span>${B(S.bought['bk'+i]?'Dibaca':'Beli','buyBook',i,'y',S.bought['bk'+i])}</div>`).join('')}<div class="li"><span class="emo">📖</span><div class="t"><b>Novel (hadiah)</b><span>Sesuai dihadiahkan</span></div><span class="price">${fmt(30)}</span>${B('Beli','buyNovel','','y')}</div></div>`;
  case 'elektronik':return`<div class="grid w">${GADGETS.map(g=>`<div class="card ${S.inv[g[0]]?'on':''}"><h4>${g[1]}</h4><p>${g[3]}</p><div class="row"><span class="price">${fmt(g[2])}</span><span class="sp"></span>${S.inv[g[0]]?'<span class="tagx u">Dimiliki</span>':B('Beli','buyGadget',g[0],'y')}</div></div>`).join('')}</div>`;
  case 'salon':return`<div class="grid w"><div class="card"><h4>Gaya & Warna Rambut</h4><p>Tukar gaya dan warna rambut sepanjang hari ini.</p><div class="row"><span class="price">${fmt(35)}</span><span class="sp"></span>${B(S.daily.salon?'Ubah Rambut':'Tempah','salon','','g')}</div></div><div class="card"><h4>Rawatan Muka</h4><p>Karisma +3, kebahagiaan +8.</p><div class="row"><span class="price">${fmt(60)}</span><span class="sp"></span>${B('Tempah','facial','','y')}</div></div></div>`;
  case 'kafe':return foodList(DRINKS);case 'restoran':return foodList(RESTO);case 'medan':return foodList(MEALS);
  case 'arked':return`<div class="card"><h4>Mesin Arked "Kejar Pesanan"</h4><p>Main mini-game pantas. Skor 15+ menang hadiah coklat!</p><div class="row"><span class="price">${fmt(5)}</span><span class="sp"></span>${B('Main','arcade','','g')}</div></div>`;
  case 'pawagam':return`<div class="grid">${MOVIES.map(m=>`<div class="card"><span class="emo" style="width:100%;height:70px">🎬</span><h4>${m}</h4><p>2 jam · Kebahagiaan +20</p>${B('Tonton '+fmt(18),'movie',m,'g')}</div>`).join('')}</div>`;
  case 'karaoke':return`<div class="card"><h4>Bilik Karaoke (1 jam)</h4><p>Kebahagiaan +18, karisma +2.${Object.keys(S.friends).length?' Kawan anda turut serta!':''}</p><div class="row"><span class="price">${fmt(25)}</span><span class="sp"></span>${B('Nyanyi','karaoke','','g')}</div></div>`;
  }
  return'';
}
function foodList(list){return`<div class="list">${list.map((m,i)=>`<div class="li"><span class="emo">${m[1]}</span><div class="t"><b>${esc(m[0])}</b><span>Tenaga +${m[3]} · Gembira +${m[4]}</span></div><span class="price">${fmt(m[2])}</span>${B('Makan','eat',JSON.stringify([m[0],m[2],m[3],m[4]]),'g')}</div>`).join('')}</div>`}
ACT.shop=v=>{SH.arg=v||null;renderSheet(true)};
ACT.eat=v=>{const [n,p,e,h]=JSON.parse(v);const go=()=>{if(!spend(p))return;advance(20);gainEnergy(e);stat('gembira',h);toast(`${n}: Tenaga +${e}`,'g');rerender()};if(atLoc('mall')||atLoc('bandar')||atLoc('pulau'))go();else needAt('mall',go,'Pergi makan di')};
ACT.buyGroc=v=>{const g=GROCERY[+v];if(!spend(g[2],g[1]))return;inv(g[0],g[3]);rerender()};
ACT.buyBait=v=>{const b=BAITS.find(x=>x[0]===v);const c=b[7]?b[2]:b[2]*10;if(!spend(c,b[1]))return;S.baits[v]=(S.baits[v]||0)+(b[7]?1:10);S.bait=v;rerender()};
ACT.buyCosm=v=>{const c=COSM[+v];if(!spend(c[1],c[0]))return;stat('karisma',c[2]);addXP(5);rerender()};
ACT.buyBook=v=>{const b=BOOKS[+v];if(!spend(b[1],b[0]))return;S.bought['bk'+v]=1;advance(60);stat(b[2],b[3]);addXP(15);rerender()};
ACT.buyNovel=()=>{if(!spend(30,'Novel'))return;inv('buku',1);rerender()};
ACT.buyGadget=v=>{const g=GADGETS.find(x=>x[0]===v);if(!spend(g[2],g[1]))return;inv(v,1);if(v==='console')stat('gembira',15);addXP(20);rerender()};
ACT.salon=()=>needAt('mall',()=>{if(!S.daily.salon){if(!spend(35,'Salon rambut'))return;S.daily.salon=1}WSUB='rambut';openPanel('almari','gaya')},'Pergi ke');
ACT.facial=()=>needAt('mall',()=>{if(!spend(60,'Rawatan muka'))return;advance(60);stat('karisma',3);stat('gembira',8);rerender()},'Pergi ke');
ACT.arcade=()=>needAt('mall',()=>{if(!spend(5,'Token arked'))return;startRush('Arked: Kejar Pesanan','🍓🍋🍇🍉🍒🥝',(p,sc)=>{advance(30);stat('gembira',8);if(sc>=15){inv('coklat',1);toast('Skor tinggi! Menang coklat!','g')}else toast('Skor: '+sc,'');rerender()})},'Pergi ke');
ACT.movie=v=>(atLoc('mall')||atLoc('pawagam')?f=>f():f=>needAt('pawagam',f,'Pergi ke'))(()=>{if(!spend(18,'Tiket wayang'))return;advance(120);stat('gembira',20);addXP(10);showDlg({title:'🎬 '+v,body:'<p>Filem yang sangat menghiburkan! Kebahagiaan +20.</p>',buttons:[{label:'Best!',cls:'g',a:'closeDlg'}]})});
ACT.karaoke=()=>needAt('mall',()=>{if(!spend(25,'Karaoke'))return;advance(60);stat('gembira',18);stat('karisma',2);addXP(12);for(const id in S.friends)if(S.friends[id]>=10)addFriend(id,1);toast('Suara sedap! Gembira +18','g');rerender()},'Pergi ke');

// ---------- MEMANCING
let BOOKSPOT='jeti';
function goFish(id){
  const sp=FISHSPOTS.find(s=>s.id===id);
  if(id==='labuan'){showDlg({title:'Ke Laut Dalam Labuan',body:'<p>Pilih cara ke kawasan laut dalam:</p>',buttons:[{label:'Bot Sendiri',cls:'g',a:'labuan',v:'bot',dis:!S.vehicles.includes('bot')},{label:'Sewa Bot RM80',cls:'y',a:'labuan',v:'sewa'},{label:'Terbang RM160',cls:'',a:'labuan',v:'terbang'}]});return}
  const s=SPOTS.find(x=>x.id===id);const near=Math.hypot(P.x-(s.x*TS+16),P.y-(s.y*TS+16))<3*TS;
  const begin=()=>{const f=findFree(s.x,s.y);P.x=f[0];P.y=f[1];closeSheet();setTimeout(()=>startFishing(id),50)};
  if(near)begin();else needAt(sp.loc,begin,'Pergi memancing di')}
ACT.goFish=v=>goFish(v);
ACT.labuan=v=>{closeDlg();const go=()=>{advance(v==='terbang'?90:120);closeSheet();setTimeout(()=>startFishing('labuan'),50)};
  if(v==='bot')needAt('pelabuhan',go,'Pergi ke');else if(v==='sewa')needAt('pelabuhan',()=>{if(spend(80,'Sewa bot ke Labuan'))go()},'Pergi ke');else needAt('airport',()=>{if(spend(160,'Tiket penerbangan ke Labuan'))go()},'Pergi ke')};
PANELS.memancing={title:'Sistem Memancing',tabs:[['lokasi','Peta Lokasi'],['alat','Peralatan & Umpan'],['buku','Buku Ikan'],['tangkapan','Tangkapan & Jual'],['konservasi','Pemuliharaan'],['pertandingan','Pertandingan']],
render(t){
  if(t==='lokasi')return`<div class="note" style="margin-bottom:10px">7 lokasi, 8 jenis tangkapan setiap satu. Keadaan berubah mengikut cuaca dan waktu: <b>${esc(fishSpotConditions({}))}</b></div><div class="grid w">${FISHSPOTS.map((sp,n)=>`<div class="card"><div style="background:linear-gradient(${sp.water},${shade(sp.water,-.4)});border-radius:12px;padding:8px;display:flex;align-items:center;gap:8px"><b style="background:#fff;color:var(--pur3);border-radius:50%;width:30px;height:30px;display:grid;place-items:center;font-family:Fredoka">${n+1}</b><div style="color:#fff"><b style="font-family:Fredoka;font-size:16px">${esc(sp.name)}</b><br><span style="font-size:12px">${esc(sp.sub)} · ${'★'.repeat(sp.stars)}</span></div></div>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:4px">${sp.fish.map((f,i)=>{const c=S.fishdex[sp.id+':'+i];return`<div style="text-align:center;font-size:10px;line-height:1.1"><img src="${creatureImg(f[5],f[6],!c,96,64)}" style="width:100%" alt=""><span>${c?esc(f[0].replace('Ikan ','')):'???'}</span></div>`}).join('')}</div>
    ${B(sp.id==='labuan'?'Ke Laut Dalam':'Pergi Memancing','goFish',sp.id,'g')}</div>`).join('')}</div>`;
  if(t==='alat')return`<div class="sec">Joran</div><div class="grid">${RODS.map((r,i)=>{const own=S.rodsOwned.includes(i);return`<div class="card ${S.rod===i?'on':''}"><h4>${r[0]}</h4><p>Zon tarikan +${r[2]*12}px · Tuah ikan jarang +${Math.round(r[3]*100)}%</p>${own?B(S.rod===i?'Digunakan':'Guna','useRod',i,'w',S.rod===i):B(fmt(r[1]),'buyRod',i,'y')}</div>`}).join('')}</div>
    <div class="sec">Umpan</div><div class="list">${BAITS.map(b=>`<div class="li ${S.bait===b[0]?'':''}"><span class="emo">🪱</span><div class="t"><b>${b[1]}</b><span>${b[4]>b[5]?'Sesuai laut':b[5]>b[4]?'Sesuai air tawar':'Serba guna'}${b[6]?' · tuah ikan jarang':''}${b[7]?' · boleh guna semula':''} · Ada: ${S.baits[b[0]]||0}</span></div>${B(S.bait===b[0]?'Dipilih':'Pilih','useBait',b[0],'w',S.bait===b[0]||!S.baits[b[0]])}${B(fmt(b[7]?b[2]:b[2]*10),'buyBait',b[0],'y',b[7]&&S.baits[b[0]])}</div>`).join('')}</div>`;
  if(t==='buku'){const tot=Object.keys(S.fishdex).length;return`<div class="row" style="margin-bottom:8px"><b>${tot}/56 spesies</b><div class="bar g" style="flex:1"><i style="width:${pct(tot,56)}%"></i></div></div><div class="tabs">${FISHSPOTS.map(sp=>`<button class="${BOOKSPOT===sp.id?'on':''}" data-a="bookSpot" data-v="${sp.id}">${esc(sp.name)}</button>`).join('')}</div>
    <div class="grid s">${FISHSPOTS.find(s=>s.id===BOOKSPOT).fish.map((f,i)=>{const c=S.fishdex[BOOKSPOT+':'+i];return`<div class="card ${c?'':'dim'}"><img class="im wide" src="${creatureImg(f[5],f[6],!c,96,64)}" alt=""><h4>${c?esc(f[0]):'???'}</h4><span class="tagx ${f[1]}">${RARN[f[1]]}</span><p>${c?`Ditangkap ${c.n}× · Terbesar ${c.best} cm`:`Minimum ${f[2]} cm`}</p></div>`}).join('')}</div>`}
  if(t==='tangkapan'){const tot=S.fishInv.reduce((a,f)=>a+f.price,0);return`<div class="row" style="margin-bottom:10px"><b>${S.fishInv.length} tangkapan · ${fmt(tot)}</b><span class="sp"></span>${B('Jual Semua','sellAllFish','','y',!S.fishInv.length)}</div><div class="note" style="margin-bottom:8px">Jual di Pasar Ikan Jeti, Pasar Tani atau Pelabuhan. Simpan beberapa untuk dimasak!</div>
    <div class="list">${S.fishInv.map((f,i)=>`<div class="li"><img src="${creatureImg(f.g,f.col,false,96,64)}" alt=""><div class="t"><b>${esc(f.name)} <span class="tagx ${f.rar}">${RARN[f.rar]}</span></b><span>${f.cm} cm · ${f.kg} kg</span></div><span class="price">${fmt(f.price)}</span>${B('Jual','sellFish',i,'y')}</div>`).join('')||'<div class="note">Tong ikan kosong.</div>'}</div>`}
  if(t==='konservasi')return`<div class="card on"><h4>Peraturan Memancing</h4><p>✓ Guna peralatan yang sesuai.<br>✓ Patuhi saiz tangkapan minimum — ikan kecil mesti dilepaskan.<br>✓ Haiwan dilindungi <b>WAJIB DILEPASKAN SEMULA</b> ke habitat asal.<br>✓ Menyimpan hidupan dilindungi boleh dikenakan denda.<br>✓ Jaga kebersihan laut, sungai dan tasik.</p></div>
    <div class="row" style="margin:10px 0"><span class="tagx u">XP Pemuliharaan: ${S.consXP}</span><span class="tagx">Dilindungi dilepaskan: ${S.cnt.prot}</span><span class="tagx">Ikan dilepaskan: ${S.cnt.released}</span></div>
    <div class="sec">Contoh Haiwan Dilindungi</div><div class="grid s">${[['Penyu','penyu','#5b8a4a'],['Dugong','dugong','#9aa0a8'],['Yu Paus','yupaus','#4a6a8a'],['Kuda Laut','kudalaut','#e8a33a'],['Kima Gergasi','kima','#6ab0c8'],['Terumbu Karang','karang','#ff7a8a'],['Tuntung Sungai','penyu','#6a6a4a'],['Kelesa','arowana','#d8a84a']].map(p=>`<div class="card"><img class="im wide" src="${creatureImg(p[1],p[2],false,96,64)}" alt=""><h4>${p[0]}</h4><span class="tagx p">Dilindungi</span></div>`).join('')}</div>
    <div class="sec">Jurnal Pemuliharaan</div><div class="list">${S.journal.map(j=>`<div class="li"><div class="t"><b>${esc(j.name)}</b><span>${esc(j.spot)} · ${dateStr(j.d)}, ${j.tm}</span></div><span class="tagx ${j.bad?'p':'u'}">${j.bad?'Dirampas':'Dilepaskan'}</span></div>`).join('')||'<div class="note">Belum ada rekod.</div>'}</div>`;
  const sun=dateOf(dayIdx()).w===6;
  return`<div class="card ${sun?'on':''}"><h4>Pertandingan Memancing Mingguan</h4><p>Setiap hari Ahad di Jeti Kota Kita. 3 balingan — jumlah berat tangkapan sah dikira. Yuran RM20.</p><div class="kv"><span>Johan</span><b>RM500 + trofi</b><span>Naib johan</span><b>RM250</b><span>Ketiga</span><b>RM100</b></div>
    ${sun?B(S.daily.tour?'Sudah menyertai hari ini':'Sertai Sekarang','tourJoin','','g',S.daily.tour):`<div class="note">Pertandingan seterusnya: hari Ahad. Hari ini ${WEEK[dateOf(dayIdx()).w]}.</div>`}</div><div class="row" style="margin-top:10px"><span class="tagx l">Kejuaraan: ${S.cnt.champ}</span></div>`;
}};
ACT.bookSpot=v=>{BOOKSPOT=v;renderSheet()};
ACT.useRod=v=>{S.rod=+v;rerender()};
ACT.buyRod=v=>{const r=RODS[+v];if(!spend(r[1],r[0]))return;S.rodsOwned.push(+v);S.rod=+v;addXP(20);rerender()};
ACT.useBait=v=>{S.bait=v;rerender()};
const fishSellOK=()=>atLoc('jeti')||atLoc('pasar')||atLoc('pelabuhan');
ACT.sellFish=v=>{const go=()=>{const f=S.fishInv.splice(+v,1)[0];if(!f)return;S.money+=f.price;toast(`+${fmt(f.price)} · ${f.name}`,'g');rerender()};fishSellOK()?go():needAt('jeti',go,'Pergi jual di')};
ACT.sellAllFish=()=>{const go=()=>{const t=S.fishInv.reduce((a,f)=>a+f.price,0);S.money+=t;S.fishInv=[];addXP(Math.round(t/20));toast(`+${fmt(t)} · Semua tangkapan dijual`,'g');rerender()};fishSellOK()?go():needAt('jeti',go,'Pergi jual di')};
ACT.tourJoin=()=>needAt('jeti',()=>{if(S.daily.tour)return;if(!spend(20,'Yuran pertandingan'))return;S.daily.tour=1;closeSheet();setTimeout(()=>startFishing('jeti',{tour:{left:3,total:0}}),50)},'Pergi ke');

// ---------- LADANG
function plotState(p){if(!p)return'empty';return p.g>=CROP[p.c].grow*60?'ready':'grow'}
PANELS.ladang={title:'Ladang & Pertanian',tabs:[['kebun','Kebun'],['ternakan','Ternakan'],['hasil','Hasil & Jual'],['naiktaraf','Besarkan Ladang']],
render(t){
  const here=atLoc('ladang');const warn=here?'':`<div class="note y" style="margin-bottom:10px">Anda tidak berada di ladang. ${B('Pergi ke Ladang','travel','ladang','g')}</div>`;
  if(t==='kebun'){const P2=S.farm.plots;return`${warn}<div class="row" style="margin-bottom:10px">${B('Siram Semua','waterAll','','')}${B('Tuai Semua','harvestAll','','g')}${B('Guna Baja ('+(S.inv.baja||0)+')','fertAll','','w',!S.inv.baja)}</div>
    <div class="plots">${P2.map((p,i)=>{const st=plotState(p);const C2=p&&CROP[p.c];const wet=p&&p.wet>S.time;return`<button class="plot ${wet?'wet':''}" data-a="plot" data-v="${i}"><span class="lab">${p?esc(C2.name):'Kosong'}</span><span style="font-size:34px">${st==='empty'?'＋':st==='ready'?C2.e:p.g/(C2.grow*60)<.4?'🌱':'🌿'}</span>${p?`<span class="pb"><i style="width:${pct(p.g,C2.grow*60)}%"></i></span>`:''}${p&&!wet&&st!=='ready'?'<span style="position:absolute;bottom:14px;font-size:11px">Perlu air</span>':''}</button>`}).join('')}</div>
    <p style="font-size:13px;color:var(--mut)">Tanaman hanya membesar bila disiram (sekali sehari). Ketik petak untuk menanam, menyiram atau menuai.</p>`}
  if(t==='ternakan'){const cap=S.farm.barn*4;return`${warn}<div class="row" style="margin-bottom:10px"><span class="tagx">${S.farm.animals.length}/${cap} haiwan</span><span class="tagx">Makanan haiwan: ${S.inv.feed||0}</span><span class="sp"></span>${B('Beri Makan Semua','feedAll','','')}${B('Kutip Hasil','collectAll','','g')}</div>
    <div class="list">${S.farm.animals.map(a=>{const A=ANIMAL[a.t];const fed=a.fed>S.time;return`<div class="li"><span class="emo">${A.e}</span><div class="t"><b>${A.name}</b><span>${a.ready?`${A.pname} sedia dikutip!`:fed?`Kenyang · ${Math.round(pct(a.prog,A.hrs*60))}%`:'Lapar — beri makan'}</span></div></div>`}).join('')||'<div class="note">Belum ada haiwan ternakan.</div>'}</div>
    <div class="sec">Beli Haiwan</div><div class="grid">${ANIMALS.map(a=>`<div class="card"><span class="emo" style="width:100%">${a.e}</span><h4>${a.name}</h4><p>Hasil: ${a.pname} (${fmt(a.pprice)})</p><div class="row"><span class="price">${fmt(a.price)}</span><span class="sp"></span>${B('Beli','buyAnimal',a.id,'y',S.farm.animals.length>=cap)}</div></div>`).join('')}</div>`}
  if(t==='hasil'){const items=Object.keys(S.inv).filter(k=>CROP[k]||['telur','telurItik','susu','susukambing','ikanternak','baja','bulu'].includes(k));
    return`<div class="row" style="margin-bottom:10px"><b>Jual di Pasar Tani</b><span class="sp"></span>${B('Jual Semua Hasil','sellAllProduce','','y',!items.length)}</div><div class="list">${items.map(k=>`<div class="li"><span class="emo">${ITEMS[k][1]}</span><div class="t"><b>${esc(ITEMS[k][0])}</b><span>Ada ${S.inv[k]} · ${fmt(ITEMS[k][2])} seunit</span></div>${B('Jual 1','sellItem',k,'y')}</div>`).join('')||'<div class="note">Belum ada hasil tuaian.</div>'}</div>`}
  const nx=[12,18,24].find(n=>n>S.farm.size);const cost={12:1500,18:4000,24:9000}[nx];
  return`<div class="grid w"><div class="card"><h4>Tambah Petak Tanaman</h4><p>Sekarang: ${S.farm.size} petak.</p>${nx?B(`Besarkan ke ${nx} petak · ${fmt(cost)}`,'expandFarm','','y'):'<span class="tagx u">Maksimum</span>'}</div>
    <div class="card"><h4>Naik Taraf Kandang</h4><p>Kapasiti: ${S.farm.barn*4} haiwan.</p>${S.farm.barn<4?B(`Naik taraf · ${fmt(2000*S.farm.barn)}`,'expandBarn','','y'):'<span class="tagx u">Maksimum</span>'}</div></div>`;
}};
const farmGo=fn=>atLoc('ladang')?fn():needAt('ladang',fn,'Pergi ke');
ACT.plot=v=>farmGo(()=>{const i=+v,p=S.farm.plots[i],st=plotState(p);
  if(st==='empty'){showDlg({title:'Tanam benih',body:`<div class="list">${CROPS.map(c=>`<div class="li"><span class="emo">${c.e}</span><div class="t"><b>${c.name}</b><span>${c.grow} jam · jual ${fmt(c.sell)}</span></div>${B(fmt(c.seed),'plant',i+':'+c.id,'g')}</div>`).join('')}</div>`,buttons:[{label:'Batal',cls:'w',a:'closeDlg'}]});return}
  if(st==='ready'){harvest(i);rerender();return}
  if(p.wet<=S.time){if(!useEnergy(1))return;p.wet=S.time+1440;advance(5);toast('Disiram!','g');rerender()}else toast(`${CROP[p.c].name}: ${Math.round(pct(p.g,CROP[p.c].grow*60))}% — sudah disiram`)});
ACT.plant=v=>{const [i,c]=v.split(':');if(!spend(CROP[c].seed))return;if(!useEnergy(2))return;S.farm.plots[+i]={c,g:0,wet:S.time+1440};advance(10);addXP(3);closeDlg();toast(CROP[c].name+' ditanam & disiram','g')};
function harvest(i){const p=S.farm.plots[i];if(plotState(p)!=='ready')return false;inv(p.c,p.f?2:1+(Math.random()<.3?1:0));S.farm.plots[i]=null;S.cnt.harvest++;addXP(6);return true}
ACT.waterAll=()=>farmGo(()=>{let n=0;for(const p of S.farm.plots)if(p&&p.wet<=S.time&&plotState(p)!=='ready'){if(S.energy<1)break;S.energy-=1;p.wet=S.time+1440;n++}advance(n*3);toast(n?`${n} petak disiram`:'Tiada petak perlu disiram','g');rerender()});
ACT.harvestAll=()=>farmGo(()=>{let n=0;S.farm.plots.forEach((p,i)=>{if(harvest(i))n++});if(n){advance(n*5);if(!useEnergy(Math.min(n,10))){}}toast(n?`${n} hasil dituai!`:'Belum ada yang matang','g');checkAch();rerender()});
ACT.fertAll=()=>farmGo(()=>{let n=0;for(const p of S.farm.plots)if(p&&!p.f&&S.inv.baja){p.f=1;p.g+=CROP[p.c].grow*15;inv('baja',-1);n++}toast(n?`Baja digunakan pada ${n} petak (+25% pertumbuhan)`:'Tiada petak sesuai','g');rerender()});
ACT.buyAnimal=v=>farmGo(()=>{const A=ANIMAL[v];if(S.farm.animals.length>=S.farm.barn*4)return;if(!spend(A.price,A.name))return;S.farm.animals.push({t:v,prog:0,fed:0,ready:false});addXP(10);rerender()});
ACT.feedAll=()=>farmGo(()=>{let n=0;for(const a of S.farm.animals){if(a.fed>S.time||a.ready)continue;if(!S.inv.feed){toast('Makanan haiwan habis. Beli di Pasar Raya / Pasar Tani.','r');break}inv('feed',-1);a.fed=S.time+1440;n++}if(n){advance(n*3);addXP(n);toast(`${n} haiwan diberi makan`,'g')}rerender()});
ACT.collectAll=()=>farmGo(()=>{let n=0;for(const a of S.farm.animals)if(a.ready){const A=ANIMAL[a.t];inv(A.pid,a.t==='kolam'?2:1);a.ready=false;a.prog=0;n++}toast(n?`${n} hasil dikutip!`:'Belum ada hasil','g');if(n)addXP(n*2);rerender()});
const pasarGo=fn=>atLoc('pasar')||atLoc('jeti')?fn():needAt('pasar',fn,'Pergi jual di');
ACT.sellItem=v=>pasarGo(()=>{if(!S.inv[v])return;inv(v,-1);S.money+=ITEMS[v][2];toast(`+${fmt(ITEMS[v][2])}`,'g');rerender()});
ACT.sellAllProduce=()=>pasarGo(()=>{let t=0;for(const k of Object.keys(S.inv))if(CROP[k]||['telur','telurItik','susu','susukambing','ikanternak','baja','bulu'].includes(k)){t+=ITEMS[k][2]*S.inv[k];delete S.inv[k]}S.money+=t;addXP(Math.round(t/25));toast(`+${fmt(t)} · Hasil ladang dijual`,'g');rerender()});
ACT.expandFarm=()=>{const nx=[12,18,24].find(n=>n>S.farm.size);const cost={12:1500,18:4000,24:9000}[nx];if(!spend(cost,'Besarkan ladang'))return;while(S.farm.plots.length<nx)S.farm.plots.push(null);S.farm.size=nx;addXP(40);rerender()};
ACT.expandBarn=()=>{if(!spend(2000*S.farm.barn,'Naik taraf kandang'))return;S.farm.barn++;addXP(30);rerender()};

// ---------- MASAK
const FGRP={'f:ikan':['ikan','keli','marlin'],'f:udang':['udang'],'f:sotong':['sotong','kurita'],'f:ketam':['ketam','belangkas'],'f:kerang':['kerang','siput']};
const INGN={'f:ikan':'Ikan (apa-apa)','f:udang':'Udang','f:sotong':'Sotong','f:ketam':'Ketam','f:kerang':'Kerang / Siput'};
function haveIng(k){if(k.startsWith('f:'))return S.fishInv.filter(f=>FGRP[k].includes(f.g)).length+(k==='f:ikan'?(S.inv.ikanternak||0):0);return S.inv[k]||0}
function useIng(k,n){for(let i=0;i<n;i++){if(k.startsWith('f:')){if(k==='f:ikan'&&S.inv.ikanternak){inv('ikanternak',-1);continue}const list=S.fishInv.map((f,j)=>[f,j]).filter(x=>FGRP[k].includes(x[0].g)).sort((a,b)=>a[0].price-b[0].price);if(list.length)S.fishInv.splice(list[0][1],1)}else inv(k,-1)}}
PANELS.masak={title:'Dapur & Masakan',tabs:[['resepi','Resepi'],['hidangan','Hidangan Saya'],['bahan','Bahan']],
render(t){
  if(t==='resepi'){const kit=Object.values(S.home.rooms).some(r=>r.items.includes('dapurgas'));return`${kit?'':'<div class="note r" style="margin-bottom:10px">Letak <b>Dapur Gas</b> di dapur rumah anda untuk memasak (Rumah → Kedai Perabot).</div>'}<div class="grid w">${RECIPES.map(r=>{const ok=Object.entries(r[3]).every(([k,n])=>haveIng(k)>=n);return`<div class="card ${ok?'':'dim'}"><div class="row"><span class="emo">${r[2]}</span><div><h4>${r[1]}${(r[7]||0)>skillLv('cook')?` <span class="tagx p">Tahap ${r[7]}</span>`:''}</h4><p>Tenaga +${r[4]} · Gembira +${r[5]} · Jual ${fmt(r[6])}</p></div></div><div class="row">${Object.entries(r[3]).map(([k,n])=>`<span class="tagx ${haveIng(k)>=n?'u':'p'}">${k.startsWith('f:')?INGN[k]:ITEMS[k][0]} ${haveIng(k)}/${n}</span>`).join('')}</div>${B('Masak (30 min)','cook',r[0],'g',!ok||!kit)}</div>`}).join('')}</div>`}
  if(t==='hidangan'){const ks=Object.keys(S.inv).filter(k=>k.startsWith('d_')||(ITEMS[k]&&ITEMS[k][3]));return`<div class="list">${ks.map(k=>`<div class="li"><span class="emo">${ITEMS[k][1]}</span><div class="t"><b>${esc(ITEMS[k][0])} ×${S.inv[k]}</b><span>Tenaga +${ITEMS[k][3]} · Gembira +${ITEMS[k][4]}</span></div>${B('Makan','eatItem',k,'g')}${ITEMS[k][2]?B('Jual '+fmt(ITEMS[k][2]),'sellDish',k,'y'):''}</div>`).join('')||'<div class="note">Belum ada hidangan. Masak sesuatu!</div>'}</div>`}
  const keys=['f:ikan','f:udang','f:sotong','f:ketam','f:kerang'];return`<div class="sec">Hasil laut (dari tangkapan)</div><div class="row">${keys.map(k=>`<span class="tagx">${INGN[k]}: ${haveIng(k)}</span>`).join('')}</div><div class="sec">Bahan dapur</div><div class="list">${Object.keys(S.inv).filter(k=>!k.startsWith('d_')&&ITEMS[k]&&!ITEMS[k][3]).map(k=>`<div class="li"><span class="emo">${ITEMS[k][1]}</span><div class="t"><b>${esc(ITEMS[k][0])}</b><span>${S.inv[k]} unit</span></div></div>`).join('')}</div><div class="note" style="margin-top:8px">Beli bahan di Pasar Raya (Asia Mall) atau tanam sendiri di ladang.</div>`;
}};
ACT.cook=v=>needAt(homeLoc(),()=>{const r=RECIPES.find(x=>x[0]===v);if(!Object.entries(r[3]).every(([k,n])=>haveIng(k)>=n))return;if(!useEnergy(4))return;for(const [k,n] of Object.entries(r[3]))useIng(k,n);inv('d_'+v,1);advance(30);S.cnt.cook++;addXP(15);toast(`${r[1]} siap dimasak!`,'g');checkAch();rerender()},'Balik ke');
ACT.eatItem=v=>{if(!S.inv[v])return;const it=ITEMS[v];inv(v,-1);advance(15);gainEnergy(it[3]);stat('gembira',it[4]||0);toast(`${it[0]}: Tenaga +${it[3]}`,'g');rerender()};
ACT.sellDish=v=>pasarGo(()=>{if(!S.inv[v])return;inv(v,-1);S.money+=ITEMS[v][2];toast(`+${fmt(ITEMS[v][2])}`,'g');rerender()});

// ---------- SOSIAL
PANELS.sosial={title:'Komuniti & Sosial',tabs:[['kawan','Kawan'],['keluarga','Keluarga'],['acara','Acara & Perayaan'],['mesej','Mesej'],['notis','Notifikasi']],
render(t){
  if(t==='kawan')return`<div class="grid w">${NPCS.map(n=>{const id=n[0],f=S.friends[id]||0,np=RT.npcs.find(x=>x.id===id);return`<div class="card"><div class="row"><img src="${headImg(np.C)}" style="width:56px;height:56px;border-radius:50%;background:var(--lil)" alt=""><div style="flex:1"><h4>${esc(n[1])}</h4><p>${esc(n[8])} · ${friendLvl(f)}</p></div></div><div class="bar" style="background:#ffe1f0"><i style="width:${f}%;background:linear-gradient(90deg,#ff9ec4,#ff5ea8)"></i></div>
    <div class="row">${B('Mesej','msgNpc',id,'w',S.msgd[id])}${B('Hadiah','giftPick',id,'y',S.gifted[id])}${B('Cari','findNpc',id,'')}${f>=30?B('Jemput','inviteNpc',id,'g',S.invited[id]):''}</div></div>`}).join('')}</div>`;
  if(t==='keluarga'){const fam=FAMILY.map((f,i)=>({n:f[0],C:{g:f[1]==='u'?S.look.g:f[1],skin:S.look.skin,face:i,eye:i,eyeCol:S.look.eyeCol,brow:0,nose:0,mouth:i,hair:f[3],hairCol:f[4],hijab:f[5],hijabSt:0,hijabCol:4,glasses:i===1?1:0,hat:0,acc:0,outfit:f[1]==='u'?(S.look.g==='f'?'s2':'s1'):f[6],shoes:'sh1'}}));
    return`<div class="grid">${fam.map(f=>`<div class="card"><img class="im" src="${charImg(f.C,140,150,1.04,4)}" alt=""><h4>${f.n}</h4></div>`).join('')}</div><div class="sec">Masa bersama keluarga</div><div class="grid w">
    <div class="card"><h4>Makan bersama</h4><p>Tenaga +30, gembira +6 (di rumah keluarga).</p>${B('Makan','fam','makan','g',S.daily.fmakan)}</div>
    <div class="card"><h4>Borak dengan Mak & Ayah</h4><p>Gembira +6, nasihat berguna.</p>${B('Borak','fam','borak','',S.daily.fborak)}</div>
    <div class="card"><h4>Bantu kerja rumah</h4><p>Tenaga −10, karisma +1, duit poket RM20.</p>${B('Bantu','fam','bantu','y',S.daily.fbantu)}</div></div>`}
  if(t==='acara'){const d=dayIdx(),t2=dateOf(d),f=festToday(),w=S.events.wedding&&S.events.wedding.day===d?S.events.wedding:null;
    const ev=[];if(f)ev.push(`<div class="li"><span class="emo">🎉</span><div class="t"><b>${esc(f.name)}</b><span>${esc(f.desc)}</span></div>${B(S.festDone[f.id+d]?'Sudah disertai':'Sertai','joinFest','','g',S.festDone[f.id+d])}</div>`);
    if(w)ev.push(`<div class="li"><span class="emo">💐</span><div class="t"><b>Majlis Kahwin ${esc(w.names)}</b><span>Pusat Bandar · pakai baju tradisional/formal</span></div>${B(S.daily.wed?'Sudah hadir':'Hadir','wedding','','g',S.daily.wed)}</div>`);
    if(t2.w===5)ev.push(`<div class="li"><span class="emo">🧹</span><div class="t"><b>Gotong-royong Kampung</b><span>Kampung Tradisional · +XP, karisma</span></div>${B(S.daily.gotong?'Selesai':'Sertai','gotong','','g',S.daily.gotong)}</div>`);
    ev.push(`<div class="li"><span class="emo">🏮</span><div class="t"><b>Pasar Malam</b><span>Setiap malam · 6 ptg – 11 mlm</span></div>${B('Pergi','pasarMalam','','g')}</div>`);
    if(t2.w===6)ev.push(`<div class="li"><span class="emo">🎣</span><div class="t"><b>Pertandingan Memancing</b><span>Jeti Kota Kita</span></div>${B('Sertai','tourJoin','','g',S.daily.tour)}</div>`);
    if(t2.m===12&&t2.d===1&&S.spm!=null)ev.push(`<div class="li"><span class="emo">🏫</span><div class="t"><b>Reunion Sekolah</b><span>Sekolah Menengah</span></div>${B('Hadir','reunion','','g',S.daily.reunion)}</div>`);
    if(S.edu)ev.push(`<div class="li"><span class="emo">🎓</span><div class="t"><b>Aktiviti Kampus</b><span>Kelab & persatuan</span></div>${B('Lihat','goPanel','pendidikan:kampus','')}</div>`);
    const first=d-(t2.d-1),fw=dateOf(first).w;let cal='';for(let i=0;i<fw;i++)cal+='<div class="h"></div>';for(let i=1;i<=MDAYS[t2.m-1];i++){const fd=festToday(first+i-1);cal+=`<div class="${i===t2.d?'t':''} ${fd?'ev':''}" title="${fd?esc(fd.name):''}">${i}${fd?'<br><b style="font-size:9px">'+esc(fd.name.split(' ')[0])+'</b>':''}</div>`}
    const up=FESTS.filter((x,i,a)=>a.findIndex(y=>y[2]===x[2])===i);
    return`<div class="sec">Hari ini — ${dateStr()}</div><div class="list">${ev.join('')||'<div class="note">Tiada acara khas hari ini. Sabtu: gotong-royong · Rabu: pasar malam · Ahad: pertandingan memancing.</div>'}</div>
    <div class="sec">${MONTHS[t2.m-1]}</div><div class="cal">${WEEK.map(w=>`<div class="h">${w.slice(0,3)}</div>`).join('')}${cal}</div>
    <div class="sec">Perayaan Malaysia</div><div class="grid">${up.map(f=>`<div class="card ${S.festDone[f[2]]?'on':''}"><h4>${esc(f[3].replace(/ \(.*\)/,''))}</h4><p>${f[1]} ${MONTHS[f[0]-1]} · ${esc(f[4])}</p>${S.festDone[f[2]]?'<span class="tagx u">Pernah disambut</span>':''}</div>`).join('')}</div>`}
  if(t==='mesej')return`<div class="list">${S.msgs.map((m,i)=>`<button class="li" data-a="readMsg" data-v="${i}" style="text-align:left;${m.read?'':'border-color:var(--pur)'}"><span class="emo">${m.read?'📭':'📩'}</span><div class="t"><b>${esc(m.title)}</b><span>${esc(m.from)} · ${dateStr(m.d)}</span></div></button>`).join('')||'<div class="note">Peti mesej kosong.</div>'}</div>`;
  S.notifs.forEach(n=>n.seen=1);
  return`<div class="list">${S.notifs.map(n=>`<div class="li"><div class="t"><b style="font-family:Nunito;font-weight:800">${esc(n.t)}</b><span>${dateStr(n.d)} · ${n.tm}</span></div></div>`).join('')||'<div class="note">Tiada notifikasi.</div>'}</div>`;
}};
ACT.readMsg=v=>{const m=S.msgs[+v];m.read=true;showDlg({title:m.title,body:`<p style="color:var(--mut);margin-top:0">Daripada: ${esc(m.from)} · ${dateStr(m.d)}</p><p>${esc(m.body)}</p>`,buttons:[{label:'Tutup',cls:'w',a:'closeDlg'}]});hud()};
ACT.msgNpc=v=>{if(S.msgd[v])return;S.msgd[v]=1;addFriend(v,1);addXP(2);toast('Mesej dihantar 💬','g');rerender()};
ACT.findNpc=v=>{const n=RT.npcs.find(x=>x.id===v);closeSheet();RT.target={x:n.x,y:n.y+10};toast('Berjalan ke arah '+n.name+'…')};
ACT.giftPick=v=>{const ks=Object.keys(S.inv).filter(k=>ITEMS[k]&&k!=='feed'&&!['phone','laptop','camera','console'].includes(k));const fish=S.fishInv.length;
  showDlg({title:'Beri hadiah',body:`<div class="list">${ks.map(k=>`<div class="li"><span class="emo">${ITEMS[k][1]}</span><div class="t"><b>${esc(ITEMS[k][0])}</b><span>Ada ${S.inv[k]}</span></div>${B('Beri','gift',v+':'+k,'g')}</div>`).join('')}${fish?`<div class="li"><span class="emo">🐟</span><div class="t"><b>Ikan segar</b><span>${fish} dalam tong</span></div>${B('Beri','gift',v+':f:ikan','g')}</div>`:''}</div>${ks.length||fish?'':'<div class="note">Tiada barang untuk dihadiahkan. Beli bunga atau coklat di Pasar Raya!</div>'}`,buttons:[{label:'Batal',cls:'w',a:'closeDlg'}]})};
ACT.gift=v=>{const [id,...r]=v.split(':');const k=r.join(':');const n=NPCS.find(x=>x[0]===id);if(S.gifted[id])return;
  if(k==='f:ikan'){if(!S.fishInv.length)return;S.fishInv.pop()}else{if(!S.inv[k])return;inv(k,-1)}
  const liked=n[10].includes(k);S.gifted[id]=1;addFriend(id,liked?12:5);addXP(liked?15:6);closeDlg();toast(liked?`${n[1]} sangat suka hadiah ini! ❤️`:`${n[1]} berterima kasih.`,'g');checkAch();rerender()};
ACT.fam=v=>{const go=()=>{if(v==='makan'){S.daily.fmakan=1;advance(45);gainEnergy(30);stat('gembira',6);toast('Masakan Mak memang terbaik! Tenaga +30','g')}
  else if(v==='borak'){S.daily.fborak=1;advance(30);stat('gembira',6);toast(pick(['Ayah: "Simpan duit sikit-sikit, nanti senang."','Mak: "Jangan lupa makan ya."','Adik: "Belanja aiskrim boleh?"','Mak: "Belajar rajin-rajin, nanti kerja bagus."']),'g')}
  else{if(!useEnergy(10))return;S.daily.fbantu=1;advance(60);stat('karisma',1);S.money+=20;toast('Mak bagi duit poket RM20. Terima kasih!','g')}rerender()};
  S.home.type==='keluarga'?needAt('perumahan',go,'Balik ke'):needAt('perumahan',go,'Lawat keluarga di')};

// ---------- PENCAPAIAN
PANELS.pencapaian={title:'Pencapaian & Statistik',tabs:[['capaian','Pencapaian'],['statistik','Statistik'],['kewangan','Kewangan & Bank']],
render(t){
  if(t==='capaian'){const n=Object.keys(S.ach).length;return`<div class="row" style="margin-bottom:10px"><b>${n}/${ACH.length} dibuka</b><div class="bar y" style="flex:1"><i style="width:${pct(n,ACH.length)}%"></i></div></div><div class="grid">${ACH.map(a=>`<div class="card ${S.ach[a[0]]?'on':'dim'}"><span class="emo" style="width:100%">${S.ach[a[0]]?'🏆':'🔒'}</span><h4>${esc(a[1])}</h4><p>${esc(a[2])}</p></div>`).join('')}</div>`}
  if(t==='statistik'){const st=[['akademik','Akademik'],['karisma','Karisma'],['cergas','Kecergasan'],['gembira','Kebahagiaan']];return`<div class="grid w"><div class="card"><div class="row"><img src="${headImg(S.look)}" style="width:70px;border-radius:50%;background:var(--lil)" alt=""><div><h4>${esc(S.name)}</h4><p>Tahap ${S.lvl} · ${{sekolah:'Pelajar Sekolah',lepasan:'Lepasan SPM',universiti:'Pelajar IPT',graduan:'Graduan'}[S.stage]}${S.job?' · '+FT_JOBS.find(j=>j[0]===S.job.id)[8][S.job.lvl]:''}</p></div></div><div class="stat">XP ${S.xp}/${xpNeed(S.lvl)}<div class="bar g"><i style="width:${pct(S.xp,xpNeed(S.lvl))}%"></i></div></div>${st.map(s=>`<div class="stat">${s[1]} ${S.stats[s[0]]}<div class="bar"><i style="width:${S.stats[s[0]]}%"></i></div></div>`).join('')}</div>
    <div class="card"><h4>Rekod</h4><div class="kv"><span>Syif kerja</span><b>${S.cnt.shifts}</b><span>Ikan ditangkap</span><b>${S.cnt.fish}</b><span>Spesies</span><b>${Object.keys(S.fishdex).length}/56</b><span>Haiwan dilindungi dilepaskan</span><b>${S.cnt.prot}</b><span>Hasil dituai</span><b>${S.cnt.harvest}</b><span>Hidangan dimasak</span><b>${S.cnt.cook}</b><span>Perayaan disertai</span><b>${S.cnt.fest}</b><span>Lokasi dilawati</span><b>${Object.keys(S.visited).length}/24</b><span>Pakaian dimiliki</span><b>${S.owned.length}</b><span>Hari di Kota Kita</span><b>${dayIdx()-START_DAY+1}</b></div></div></div>`}
  return`<div class="grid w"><div class="card"><h4>Ringkasan Kewangan</h4><div class="kv"><span>Dompet</span><b>${fmt2(S.money)}</b><span>Akaun bank</span><b>${fmt2(S.bank)}</b><span>Pinjaman pendidikan</span><b>${fmt(S.debt)}</b><span>Pinjaman perumahan</span><b>${S.mortgage?fmt(S.mortgage.left):'—'}</b><span>Nilai bersih</span><b>${fmt(netWorth())}</b></div><p style="font-size:12px">Faedah simpanan 3.65% setahun dikreditkan setiap hari.</p></div>
    <div class="card"><h4>Perbankan dalam talian</h4><div class="row">${B('Simpan RM100','bank','dep:100','')}${B('Simpan semua','bank','dep:all','')}</div><div class="row">${B('Keluar RM100','bank','wd:100','w')}${B('Keluar RM500','bank','wd:500','w')}</div>${S.debt>0?`<div class="row">${B('Bayar pinjaman RM500','bank','debt:500','y')}</div>`:''}</div></div>`;
}};
ACT.bank=v=>{const [k,a]=v.split(':');let n=a==='all'?S.money:+a;
  if(k==='dep'){n=Math.min(n,S.money);S.money-=n;S.bank+=n}else if(k==='wd'){n=Math.min(n,S.bank);S.bank-=n;S.money+=n}else{n=Math.min(n,S.debt);if(!spend(n,'Bayar pinjaman'))return;S.debt-=n}rerender()};
