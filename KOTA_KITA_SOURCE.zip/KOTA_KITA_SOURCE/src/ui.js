// ===================== UI CORE =====================
const ICON={
peta:'<svg viewBox="0 0 24 24"><path d="M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2z" fill="#c9f0d0" stroke="#2a8a4a" stroke-width="1.6" stroke-linejoin="round"/><path d="M9 4v14M15 6v14" stroke="#2a8a4a" stroke-width="1.4"/><path d="M12 7.5a2.6 2.6 0 0 1 2.6 2.6c0 2-2.6 4.6-2.6 4.6s-2.6-2.6-2.6-4.6A2.6 2.6 0 0 1 12 7.5z" fill="#e5484d"/></svg>',
rumah:'<svg viewBox="0 0 24 24"><path d="M3 11l9-7 9 7" fill="none" stroke="#c8503a" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M5.5 10v10h13V10" fill="#ffe7c2" stroke="#8a5a33" stroke-width="1.6"/><rect x="10" y="14" width="4" height="6" fill="#8c5cf2"/></svg>',
kerjaya:'<svg viewBox="0 0 24 24"><rect x="3" y="7" width="18" height="13" rx="3" fill="#ffc531" stroke="#b57400" stroke-width="1.6"/><path d="M9 7V5h6v2" fill="none" stroke="#b57400" stroke-width="1.6"/><path d="M3 12h18" stroke="#b57400" stroke-width="1.4"/><rect x="10.5" y="11" width="3" height="3" rx="1" fill="#fff"/></svg>',
pendidikan:'<svg viewBox="0 0 24 24"><path d="M2 9l10-5 10 5-10 5z" fill="#6a3fd0" stroke="#3b1f8f" stroke-width="1.4" stroke-linejoin="round"/><path d="M6 11v5c3 2.5 9 2.5 12 0v-5" fill="#8c5cf2" stroke="#3b1f8f" stroke-width="1.4"/><path d="M21 9v6" stroke="#ffc531" stroke-width="1.8"/></svg>',
almari:'<svg viewBox="0 0 24 24"><path d="M8 3l-5 3 2 5 2-1v11h10V10l2 1 2-5-5-3c-1 2-2.5 2.5-4 2.5S9 5 8 3z" fill="#ff7ab6" stroke="#b42a6a" stroke-width="1.5" stroke-linejoin="round"/></svg>',
kedai:'<svg viewBox="0 0 24 24"><path d="M5 8h14l-1 12H6z" fill="#8c5cf2" stroke="#3b1f8f" stroke-width="1.6" stroke-linejoin="round"/><path d="M9 10V7a3 3 0 0 1 6 0v3" fill="none" stroke="#3b1f8f" stroke-width="1.6"/><circle cx="12" cy="14" r="2" fill="#ffc531"/></svg>',
memancing:'<svg viewBox="0 0 24 24"><path d="M3 12c4-6 11-6 15 0-4 6-11 6-15 0z" fill="#5ab8f0" stroke="#1f5fa0" stroke-width="1.6"/><path d="M18 12l3-3v6z" fill="#5ab8f0" stroke="#1f5fa0" stroke-width="1.4" stroke-linejoin="round"/><circle cx="8" cy="11" r="1.2" fill="#1f2a44"/></svg>',
ladang:'<svg viewBox="0 0 24 24"><path d="M12 21v-9" stroke="#2a8a3a" stroke-width="2"/><path d="M12 13c-5 0-7-3-7-7 4 0 7 2 7 7zM12 11c0-4 3-6 7-6 0 4-2 7-7 6z" fill="#5ed36b" stroke="#2a8a3a" stroke-width="1.4"/><path d="M5 21h14" stroke="#8a5a33" stroke-width="2"/></svg>',
masak:'<svg viewBox="0 0 24 24"><path d="M4 11h16v4a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5z" fill="#ff8c42" stroke="#a84a10" stroke-width="1.6"/><path d="M2 12h2M20 12h2" stroke="#a84a10" stroke-width="2"/><path d="M9 8c0-2 2-2 2-4M13 8c0-2 2-2 2-4" fill="none" stroke="#8a9aa8" stroke-width="1.5" stroke-linecap="round"/></svg>',
sosial:'<svg viewBox="0 0 24 24"><circle cx="8.5" cy="8" r="3.2" fill="#3a86ff" stroke="#1f4fb0" stroke-width="1.4"/><circle cx="16" cy="9" r="2.8" fill="#ff5ea8" stroke="#b42a6a" stroke-width="1.4"/><path d="M2.5 19c.5-4 3-5.5 6-5.5s5.5 1.5 6 5.5z" fill="#3a86ff" stroke="#1f4fb0" stroke-width="1.4"/><path d="M13 14.5c1-1 2-1.4 3-1.4 2.6 0 4.5 1.4 5 5h-6" fill="#ff5ea8" stroke="#b42a6a" stroke-width="1.4"/></svg>',
pencapaian:'<svg viewBox="0 0 24 24"><path d="M7 4h10v5a5 5 0 0 1-10 0z" fill="#ffc531" stroke="#b57400" stroke-width="1.6"/><path d="M7 6H4c0 3 1.5 4.5 3.4 4.8M17 6h3c0 3-1.5 4.5-3.4 4.8" fill="none" stroke="#b57400" stroke-width="1.5"/><path d="M12 14v3M8 20h8l-1-3H9z" fill="#ffc531" stroke="#b57400" stroke-width="1.5"/></svg>',
mesej:'<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="3" fill="#fff" stroke="#6a3fd0" stroke-width="1.8"/><path d="M4 7l8 6 8-6" fill="none" stroke="#6a3fd0" stroke-width="1.8"/></svg>',
notis:'<svg viewBox="0 0 24 24"><path d="M6 17V11a6 6 0 0 1 12 0v6l2 2H4z" fill="#ffc531" stroke="#b57400" stroke-width="1.6" stroke-linejoin="round"/><circle cx="12" cy="20.5" r="1.8" fill="#b57400"/></svg>',
event:'<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="3" fill="#fff" stroke="#e5484d" stroke-width="1.8"/><path d="M3 10h18" stroke="#e5484d" stroke-width="1.8"/><path d="M8 3v4M16 3v4" stroke="#e5484d" stroke-width="1.8" stroke-linecap="round"/><circle cx="12" cy="15" r="2.2" fill="#ff5ea8"/></svg>',
tetapan:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.4" fill="#fff" stroke="#4b2a9e" stroke-width="1.8"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1" stroke="#4b2a9e" stroke-width="2.2" stroke-linecap="round"/></svg>',
};
ICON.inventori='<svg viewBox="0 0 24 24"><path d="M7 8V6a5 5 0 0 1 10 0v2" fill="none" stroke="#8a5a33" stroke-width="1.8"/><rect x="4" y="8" width="16" height="13" rx="4" fill="#ff9f43" stroke="#a84a10" stroke-width="1.6"/><rect x="8" y="13" width="8" height="5" rx="1.5" fill="#ffd8a8" stroke="#a84a10" stroke-width="1.2"/></svg>';
ICON.lagi='<svg viewBox="0 0 24 24">'+[[6,6],[12,6],[18,6],[6,12],[12,12],[18,12],[6,18],[12,18],[18,18]].map(([x,y],i)=>`<circle cx="${x}" cy="${y}" r="2.4" fill="${['#6a3fd0','#ff5ea8','#3a86ff','#38b84a','#ffc531','#ff8c42','#2ec4b6','#e5484d','#8c5cf2'][i]}"/>`).join('')+'</svg>';
ICON.fs='<svg viewBox="0 0 24 24"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" fill="none" stroke="#4b2a9e" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
ICON.run='<svg viewBox="0 0 24 24"><circle cx="15" cy="4.5" r="2.4" fill="currentColor"/><path d="M8 21l3-6 3 2v5M6 11l4-3 4 1 2 4 3 1M11 15l1-6" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
ICON.act='<svg viewBox="0 0 24 24"><path d="M8 12V5.5a1.5 1.5 0 0 1 3 0V11M11 11V4a1.5 1.5 0 0 1 3 0v7M14 11V5.5a1.5 1.5 0 0 1 3 0V13M8 12V9.5a1.5 1.5 0 0 0-3 0V14c0 4 3 7 7 7s6-3 6-7v-1" fill="none" stroke="#fff" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const NAV=[['peta','Peta'],['rumah','Rumah'],['kerjaya','Kerjaya'],['pendidikan','Belajar'],['almari','Almari'],['inventori','Inventori'],['memancing','Pancing'],['lagi','Lagi']];
const MORE=[['kedai','Kedai / Mall'],['ladang','Ladang'],['masak','Masak'],['sosial','Sosial'],['misi','Misi'],['pencapaian','Capaian']];
ICON.misi=ICON.pencapaian;
// ---------- STAGE (16:9 landscape)
const STG={s:1,w:854,h:480};
const pxr=()=>Math.min(3,(devicePixelRatio||1)*STG.s);
function layoutStage(){
  const vw=innerWidth,vh=innerHeight,por=vh>vw;
  document.body.classList.toggle('portrait',por);RT.blocked=por;
  if(por){rotAnim();return}
  const sw=Math.min(vw,vh*16/9),sh=sw*9/16;const dh=480,s=sh/dh,dw=dh*16/9;
  STG.s=s;STG.w=dw;STG.h=dh;const st=$('#stage');st.style.width=dw+'px';st.style.height=dh+'px';
  st.style.transform=`translate(${Math.round((vw-sw)/2)}px,${Math.round((vh-sh)/2)}px) scale(${s})`;
  document.documentElement.style.setProperty('--sh',dh+'px');st.classList.toggle('stg-s',dw<1000);
}
let rotOn=false;
function rotAnim(){if(rotOn)return;rotOn=true;const f=t=>{if(!document.body.classList.contains('portrait')){rotOn=false;return}
  const c=$('#rotCv'),W=c.clientWidth,H=c.clientHeight,d=Math.min(3,devicePixelRatio||1);if(c.width!==Math.round(W*d)){c.width=Math.round(W*d);c.height=Math.round(H*d)}
  const x=c.getContext('2d');x.setTransform(d,0,0,d,0,0);x.clearRect(0,0,W,H);
  x.fillStyle='rgba(255,255,255,.14)';x.beginPath();x.ellipse(W/2,H-10,W*.32,14,0,0,TAU);x.fill();
  const C=S?S.look:{g:'f',skin:0,face:2,eye:3,eyeCol:2,brow:1,nose:0,mouth:2,hair:0,hairCol:0,hijab:1,hijabSt:0,hijabCol:0,glasses:0,hat:0,acc:1,outfit:'h3',shoes:'sh1'};
  const sc=Math.min((H-20)/140,W/70),bob=Math.sin(t/300)*3,fx=W/2,fy=H-10+bob;drawChibi(x,fx,fy,sc,C,0,Math.floor(t/400)%2?0:2);
  const a=(Math.sin(t/700)*.5+.5)*Math.PI/2;x.save();x.translate(fx+13.5*sc,fy-52*sc);x.rotate(-a);const pw=13*sc,ph=22*sc;
  x.fillStyle='#2a1f47';const p=new Path2D();rrp(p,-pw/2,-ph,pw,ph,3*sc);x.fill(p);x.fillStyle='#ffd23f';x.fillRect(-pw/2+2*sc,-ph+2.5*sc,pw-4*sc,ph-6*sc);x.restore();
  x.fillStyle='#fff';x.beginPath();x.arc(fx+13.5*sc,fy-52*sc,2.6*sc,0,TAU);x.fill();
  requestAnimationFrame(f)};requestAnimationFrame(f)}
function doFs(){const d=document,el=d.documentElement;if(d.fullscreenElement||d.webkitFullscreenElement){(d.exitFullscreen||d.webkitExitFullscreen).call(d);return}
  const rq=el.requestFullscreen||el.webkitRequestFullscreen;if(!rq){toast('Skrin penuh tidak disokong pada pelayar ini.','y');return}
  try{Promise.resolve(rq.call(el,{navigationUI:'hide'})).then(()=>{try{screen.orientation.lock('landscape').catch(()=>{})}catch(e){}}).catch(()=>toast('Skrin penuh disekat di sini — buka permainan dalam tab sendiri.','y'))}catch(e){toast('Skrin penuh disekat di sini.','y')}}
function doLagi(){showDlg({title:'Menu Lain',body:`<div class="grid s">${MORE.map(m=>`<button class="card" data-a="nav" data-v="${m[0]}" style="justify-items:center;text-align:center"><span style="width:44px;height:44px">${ICON[m[0]]||''}</span><h4>${m[1]}</h4></button>`).join('')}</div>`,buttons:[{label:'Tutup',cls:'w',a:'closeDlg'}]})}

function toast(t,c){const el=document.createElement('div');el.className='toast '+(c||'');el.textContent=t;$('#toasts').appendChild(el);setTimeout(()=>el.remove(),2600);while($('#toasts').children.length>3)$('#toasts').firstChild.remove()}

// ---------- HUD
let hudT=0;const COARSE=matchMedia('(pointer:coarse)').matches;
function hud(){
  if(!S)return;
  $('#hName').textContent=S.name;$('#hLv').textContent='Tahap '+S.lvl;
  $('#hXp').style.width=Math.min(100,S.xp/xpNeed(S.lvl)*100)+'%';$('#hXpt').textContent=`XP ${S.xp} / ${xpNeed(S.lvl)}`;$('#hGem').textContent=S.gems||0;
  $('#hMoney').textContent=fmt(S.money);$('#hBank').textContent=fmt(S.bank);
  $('#hEn').textContent=Math.round(S.energy)+'/'+maxEnergy();
  {const t=dateOf(dayIdx());$('#hTime').textContent=`${WEEK[t.w].slice(0,3)}, ${t.d} ${MONTHS[t.m-1].slice(0,3)} · ${timeStr()}`}
  $('#hWeather').textContent=WNAME[S.weather]+' '+temp()+'°C';renderMis();locChip();
  const um=S.msgs.filter(m=>!m.read).length;const md=$('#dMsg');md.textContent=um;md.classList.toggle('hide',!um);
  const nn=S.notifs.filter(n=>!n.seen).length;const nd=$('#dNot');nd.textContent=nn;nd.classList.toggle('hide',!nn);
  const f=RT.fest;$('#banner').classList.toggle('hide',!f);if(f)$('#banner').textContent='Hari ini: '+f.name;
}
function hudTick(){
  if(!S||$('#game').classList.contains('hide'))return;
  hudT++;if(hudT%15===0)hud();
  const n=RT.near,pr=$('#prompt'),ab=$('#btnAct');
  if(n&&!RT.paused){pr.classList.remove('hide');const h=`${esc(n.label)} · <b>${COARSE?'Tekan Aksi':'Tekan E'}</b>`;if(pr.innerHTML!==h)pr.innerHTML=h;ab.classList.add('hot')}
  else{pr.classList.add('hide');ab.classList.remove('hot')}
}
function drawPortrait(){const c=$('#hPort');const x=c.getContext('2d');c.width=c.height=100;x.clearRect(0,0,100,100);const h=crHeadCentre(S.look,2),sc=1.45*.86/h.hs;drawChibi(x,50,54-h.cy*sc,sc,S.look,0,0)}
function updateActBtns(){$('#btnRide').textContent=RT.ride?'Turun':'Naik';$('#btnRide').classList.toggle('hide',!S||!S.vehicles.some(v=>VEH[v].kind!=='boat'))}

// ---------- Sheet
const SH={id:null,tab:null,arg:null};
function openPanel(id,tab,arg){
  if(!PANELS[id])return;
  closeDlg();
  RT.paused=true;RT.keys={};SH.id=id;SH.arg=arg;const p=PANELS[id];const tabs=typeof p.tabs==='function'?p.tabs():p.tabs;
  SH.tab=tab||(tabs&&tabs[0]&&tabs[0][0]);
  $('#sheet').classList.remove('hide');SH.fresh=true;renderSheet(true);SH.fresh=false;
}
function renderSheet(reset){
  const p=PANELS[SH.id];const tabs=typeof p.tabs==='function'?p.tabs():p.tabs;
  const main=$('#sMain'),st=reset?0:(main?main.scrollTop:0);
  const title=typeof p.title==='function'?p.title():p.title;
  $('#sheet').innerHTML=`<div class="sbox${reset&&SH.fresh?' in':''}"><div class="shead"><h2>${esc(title)}</h2><span class="chip"><span class="coin"></span>${fmt(S.money)}</span><button class="x" data-a="closeSheet" aria-label="Tutup">✕</button></div>
  <div class="sbody ${tabs?'':'nos'}">${tabs?`<nav class="side">${tabs.map(t=>`<button class="${t[0]===SH.tab?'on':''}" data-a="tab" data-v="${t[0]}">${esc(t[1])}</button>`).join('')}</nav>`:''}<div class="main" id="sMain">${p.render(SH.tab,SH.arg)}</div></div></div>`;
  $('#sMain').scrollTop=st;
  if(p.after)p.after(SH.tab,SH.arg);
}
function rerender(){if(SH.id&&!$('#sheet').classList.contains('hide'))renderSheet();hud()}
function closeSheet(){if(S)checkMissions();$('#sheet').classList.add('hide');$('#sheet').innerHTML='';SH.id=null;if($('#dlg').classList.contains('hide'))RT.paused=false;save();checkAch();hud()}

// ---------- Dialog
let DLG=null;
function showDlg(o){
  DLG=o;RT.paused=true;RT.keys={};
  $('#dlg').innerHTML=`<div class="dbox ${o.wide==='fish'?'fish':''}" style="${o.wide?'width:min(620px,100%)':''}">${o.title?`<h3>${esc(o.title)}</h3>`:''}<div>${o.body||''}</div>${o.buttons&&o.buttons.length?`<div class="row">${o.buttons.map(b=>`<button class="btn ${b.cls||''}" data-a="${b.a}" data-v="${b.v===undefined?'':esc(b.v)}" ${b.dis?'disabled':''}>${esc(b.label)}</button>`).join('')}</div>`:''}</div>`;
  $('#dlg').classList.remove('hide');
  if(o.after)o.after();
}
function closeDlg(){if($('#dlg').classList.contains('hide'))return;const o=DLG;DLG=null;$('#dlg').classList.add('hide');$('#dlg').innerHTML='';if(o&&o.onclose)o.onclose();if(!SH.id&&$('#dlg').classList.contains('hide'))RT.paused=false;rerender()}
function confirmDlg(title,body,yesLabel,fn,cls){showDlg({title,body,buttons:[{label:'Batal',cls:'w',a:'closeDlg'},{label:yesLabel,cls:cls||'g',a:'_cb'}]});DLG.cb=fn}

// ---------- actions registry
const ACT={
  closeSheet:()=>closeSheet(),closeDlg:()=>closeDlg(),
  tab:v=>{SH.tab=v;renderSheet(true)},
  nav:v=>{if(v==='lagi')return doLagi();openPanel(v)},fs:()=>doFs(),
  _cb:()=>{const f=DLG&&DLG.cb;closeDlg();if(f)f()},
};
document.addEventListener('click',e=>{const b=e.target.closest('[data-a]');if(!b||b.disabled)return;const f=ACT[b.dataset.a];if(f){e.preventDefault();f(b.dataset.v,b)}});

// ---------- portraits & icons cache
const imgCache=new Map();
function charImg(C,w,h,s,dy,key){const k=key||JSON.stringify(C)+w+h+s+dy;let u=imgCache.get(k);if(u)return u;const c=document.createElement('canvas');c.width=w;c.height=h;drawChibi(c.getContext('2d'),w/2,h-(dy||6),s,C,0,0);u=c.toDataURL();imgCache.set(k,u);if(imgCache.size>400)imgCache.delete(imgCache.keys().next().value);return u}
function headImg(C){return crHead(C,120,1.05,5)}

// ---------- TITLE
let titleAnim=0;
function drawTitle(t){
  const c=$('#titleCv');if(!c||$('#title').classList.contains('hide'))return;
  const W=c.clientWidth,H=c.clientHeight,d=pxr();if(c.width!==Math.round(W*d)){c.width=Math.round(W*d);c.height=Math.round(H*d)}
  const x=c.getContext('2d');x.setTransform(d,0,0,d,0,0);
  const g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,'#6fb7ff');g.addColorStop(.55,'#c8e4ff');g.addColorStop(1,'#ffe0f0');x.fillStyle=g;x.fillRect(0,0,W,H);
  // clouds
  x.fillStyle='rgba(255,255,255,.85)';for(let i=0;i<5;i++){const cx=((t*.012+i*260)%(W+300))-150,cy=40+i*28;x.beginPath();x.arc(cx,cy,26,0,TAU);x.arc(cx+30,cy-8,32,0,TAU);x.arc(cx+64,cy,24,0,TAU);x.fill()}
  // mountain
  const by=H*.62;x.fillStyle='#7a86c8';x.beginPath();x.moveTo(W*.02,by);x.lineTo(W*.18,by-H*.22);x.lineTo(W*.22,by-H*.26);x.lineTo(W*.26,by-H*.2);x.lineTo(W*.44,by);x.fill();
  x.fillStyle='#fff';x.beginPath();x.moveTo(W*.16,by-H*.19);x.lineTo(W*.22,by-H*.26);x.lineTo(W*.27,by-H*.19);x.lineTo(W*.24,by-H*.2);x.lineTo(W*.21,by-H*.17);x.fill();
  // skyline
  x.fillStyle='#9aa6e0';const bx=W*.55;for(let i=0;i<14;i++){const h=40+((i*37)%70);x.fillRect(bx+i*W*.03,by-h,W*.025,h)}
  x.fillStyle='#8592d6';const tx=W*.8;x.fillRect(tx,by-H*.3,W*.022,H*.3);x.fillRect(tx+W*.04,by-H*.3,W*.022,H*.3);x.fillRect(tx+W*.018,by-H*.18,W*.028,5);x.beginPath();x.moveTo(tx,by-H*.3);x.lineTo(tx+W*.011,by-H*.37);x.lineTo(tx+W*.022,by-H*.3);x.moveTo(tx+W*.04,by-H*.3);x.lineTo(tx+W*.051,by-H*.37);x.lineTo(tx+W*.062,by-H*.3);x.fill();
  x.fillRect(W*.7,by-H*.26,4,H*.26);x.beginPath();x.ellipse(W*.7+2,by-H*.24,10,6,0,0,TAU);x.fill();
  // ground
  x.fillStyle='#8fd46e';x.fillRect(0,by,W,H-by);x.fillStyle='#e8dac6';x.beginPath();x.moveTo(W*.3,H);x.lineTo(W*.42,by);x.lineTo(W*.58,by);x.lineTo(W*.7,H);x.fill();
  // palms
  for(const [px,s] of [[W*.06,1.2],[W*.94,1.3],[W*.14,.9],[W*.86,.95]]){x.strokeStyle='#8a6a42';x.lineWidth=8*s;x.lineCap='round';x.beginPath();x.moveTo(px,H);x.quadraticCurveTo(px+20*s,H-120*s,px+6*s,H-200*s);x.stroke();for(let i=0;i<7;i++){const a=i/7*TAU+t*.0005;x.fillStyle=i%2?'#3a9a3a':'#4fb84a';x.beginPath();x.moveTo(px+6*s,H-200*s);x.quadraticCurveTo(px+6*s+Math.cos(a)*60*s,H-200*s+Math.sin(a)*30*s-20,px+6*s+Math.cos(a)*90*s,H-200*s+Math.sin(a)*40*s+16);x.quadraticCurveTo(px+6*s+Math.cos(a)*50*s,H-200*s+Math.sin(a)*20*s,px+6*s,H-200*s);x.fill()}}
  // hibiscus
  for(let i=0;i<9;i++){const fx=(i*137)%W,fy=H-20-(i*53)%60;x.fillStyle=i%2?'#ff5ea8':'#e5484d';for(let k=0;k<5;k++){x.beginPath();x.ellipse(fx+Math.cos(k*1.256)*8,fy+Math.sin(k*1.256)*8,7,5,k*1.256,0,TAU);x.fill()}x.fillStyle='#ffd23f';x.beginPath();x.arc(fx,fy,3,0,TAU);x.fill()}
  // characters
  const s=Math.min(2,H/300,W/420),fr=Math.floor(t/400)%2;
  const cs=[CR_PRESETS.m[0],CR_PRESETS.f[1],CR_PRESETS.f[0]];
  cs.forEach((C,i)=>{drawChibi(x,W*.74+(i-1)*95*s/1.5,H-18-(i===1?8:0)+(fr&&i!==1?-2:0),s,C,0,0)});
}
function titleLoop(t){drawTitle(t);if(!$('#title').classList.contains('hide'))requestAnimationFrame(titleLoop)}
function showTitle(){
  ['#game','#creator'].forEach(q=>$(q).classList.add('hide'));$('#title').classList.remove('hide');
  $('#btnCont').disabled=!loadSave();
  requestAnimationFrame(titleLoop);
}
ACT.newGame=()=>{if(loadSave()){confirmDlg('Permainan Baharu?','<p>Permainan tersimpan anda akan diganti apabila anda mula bermain watak baharu.</p>','Teruskan',()=>startCreator())}else startCreator()};
ACT.cont=()=>{const s=loadSave();if(!s)return;S=s;migrate();startGame(false)};
ACT.reset=()=>confirmDlg('Set Semula Permainan?','<p>Semua kemajuan (wang, pakaian, rumah, ikan) akan dipadam. Tindakan ini tidak boleh dibatalkan.</p>','Padam',()=>{if(SH.id)closeSheet();RT.paused=true;wipeSave();S=null;toast('Permainan telah diset semula','g');showTitle()},'r');
function migrate(){if(S&&!S.ownedBags)S.ownedBags=[0,1];if(S.look&&S.look.acc>=3&&S.ear==null&&S.look.ear==null){const a=S.look.acc;if(a===3){S.look.neck=1;S.look.acc=0}else if(a===4){S.look.ear=1;S.look.acc=0}else if(a===5)S.look.acc=4;else if(a===6){S.look.neck=2;S.look.acc=0}}
  for(const r of ['belajar','balkoni'])if(S.home&&!S.home.rooms[r])S.home.rooms[r]={wall:0,floor:0,items:[]};
  const d={gems:20,sk:{},mq:0,aqua:[],certs:[],ownedEars:[0,1],ownedNecks:[0],festDone:{},daily:{},events:{},msgd:{},gifted:{},invited:{},talked:{},workLog:{},styles:[],clubs:[],journal:[],ownedHijab:[0,1],ownedGlasses:[0,1,2],ownedHats:[0,1],ownedAccs:[0,1]};for(const k in d)if(S[k]==null)S[k]=d[k];S.cnt=Object.assign({shifts:0,fish:0,prot:0,harvest:0,cook:0,fest:0,champ:0,classes:0,released:0},S.cnt||{})}

// ---------- CREATOR
const NAMES_M=['Aiman','Haziq','Danial','Arif','Hakim','Irfan','Wei Jie','Jun Hao','Arjun','Ravi','Darren','Jeffry','Ezra','Rizal','Syafiq','Nazrin','Kelvin','Ryan'];
const NAMES_F=['Aisyah','Nurul','Sofea','Mei Ling','Xin Yi','Priya','Kavitha','Joanna','Dayang','Alya','Hana','Melissa','Ain','Balqis','Chloe','Erna','Sharmila','Yasmin'];
const PRESETS=[
 {g:'m',skin:1,face:0,eye:1,eyeCol:0,brow:0,nose:0,mouth:4,hair:0,hairCol:0,hijab:0,hijabSt:0,hijabCol:0,glasses:0,hat:0,acc:1,outfit:'h1',shoes:'sh1'},
 {g:'m',skin:3,face:3,eye:0,eyeCol:1,brow:2,nose:2,mouth:0,hair:2,hairCol:0,hijab:0,hijabSt:0,hijabCol:0,glasses:0,hat:1,acc:0,outfit:'h8',shoes:'sh4'},
 {g:'f',skin:0,face:2,eye:3,eyeCol:2,brow:1,nose:0,mouth:2,hair:0,hairCol:0,hijab:1,hijabSt:0,hijabCol:7,glasses:0,hat:0,acc:0,outfit:'h3',shoes:'sh1'},
 {g:'f',skin:1,face:1,eye:0,eyeCol:0,brow:1,nose:1,mouth:0,hair:1,hairCol:2,hijab:0,hijabSt:0,hijabCol:0,glasses:0,hat:0,acc:0,outfit:'h4',shoes:'sh1'},
 {g:'m',skin:4,face:1,eye:1,eyeCol:1,brow:2,nose:2,mouth:3,hair:3,hairCol:0,hijab:0,hijabSt:0,hijabCol:0,glasses:1,hat:0,acc:0,outfit:'h2',shoes:'sh1'},
 {g:'m',skin:0,face:0,eye:2,eyeCol:3,brow:3,nose:1,mouth:0,hair:4,hairCol:6,hijab:0,hijabSt:0,hijabCol:0,glasses:0,hat:0,acc:0,outfit:'h1',shoes:'sh1'},
 {g:'f',skin:2,face:0,eye:3,eyeCol:5,brow:1,nose:0,mouth:2,hair:0,hairCol:0,hijab:1,hijabSt:1,hijabCol:1,glasses:2,hat:0,acc:1,outfit:'h3',shoes:'sh1'},
 {g:'f',skin:5,face:1,eye:2,eyeCol:0,brow:0,nose:1,mouth:1,hair:2,hairCol:0,hijab:0,hijabSt:0,hijabCol:0,glasses:0,hat:0,acc:0,outfit:'h4',shoes:'sh1'},
];
const CR={look:null,name:'',stage:'lepasan',tab:'asas',dir:0};
function startCreator(){
  CR.look=Object.assign({},PRESETS[0]);CR.name='';CR.stage='lepasan';CR.tab='profil';CR.dir=0;crInitProfile();
  ['#game','#title'].forEach(q=>$(q).classList.add('hide'));$('#creator').classList.remove('hide');
  renderCreator();
}
function optBtns(key,list,cur,price,owned){return`<div class="opts">${list.map((n,i)=>{const pr=price?price[i]:0;const lock=pr>0&&!(owned&&owned.includes(i));return`<button class="opt ${cur===i?'on':''}" data-a="crSet" data-v="${key}:${i}" ${lock?'disabled':''}>${esc(n)}${lock?`<span class="lk">${fmt(pr)}</span>`:''}</button>`}).join('')}</div>`}
function swatches(key,list,cur){return`<div class="opts">${list.map((c,i)=>`<button class="sw ${cur===i?'on':''}" style="background:${c}" data-a="crSet" data-v="${key}:${i}" aria-label="warna ${i+1}"></button>`).join('')}</div>`}
function lookEditor(L,tab,ctxName){
  const hairs=L.g==='m'?HAIR_M:HAIR_F;
  const ownedH=S?S.ownedHijab:[0,1],ownedG=S?S.ownedGlasses:[0,1,2],ownedHt=S?S.ownedHats:[0,1],ownedA=S?S.ownedAccs:[0,1];
  switch(tab){
  case 'asas':return`${ctxName==='creator'?`<div class="chead">Pilih Jantina</div><div class="gbtn"><button class="opt ${L.g==='m'?'on':''}" data-a="crSet" data-v="g:m">Lelaki</button><button class="opt ${L.g==='f'?'on':''}" data-a="crSet" data-v="g:f">Perempuan</button></div>
</div>`:''}
    <div class="chead">Warna Kulit</div>${swatches('skin',SKIN,L.skin)}<div class="chead">Bentuk Wajah</div>${optBtns('face',FACES,L.face)}<div class="chead">Bentuk Badan</div>${optBtns('body',BODIES.map(b=>b[0]),L.body||0)}`;
  case 'rambut':return`<div class="chead">Gaya Rambut</div>${optBtns('hair',hairs,L.hair)}<div class="chead">Warna Rambut</div>${swatches('hairCol',HAIRCOL,L.hairCol)}${L.hijab?'<div class="note">Rambut tersembunyi semasa memakai hijab.</div>':''}`;
  case 'mata':return`<div class="chead">Bentuk Mata</div>${optBtns('eye',EYES,L.eye)}<div class="chead">Warna Mata</div>${swatches('eyeCol',EYECOL,L.eyeCol)}<div class="chead">Kening</div>${optBtns('brow',BROWS,L.brow)}`;
  case 'muka':return`<div class="chead">Hidung</div>${optBtns('nose',NOSES,L.nose)}<div class="chead">Mulut</div>${optBtns('mouth',MOUTHS,L.mouth)}`;
  case 'hijab':return L.g!=='f'?'<div class="note">Pilihan hijab tersedia untuk watak perempuan.</div>':`<div class="chead">Hijab</div><div class="gbtn"><button class="opt ${!L.hijab?'on':''}" data-a="crSet" data-v="hijab:0">Tanpa Hijab</button><button class="opt ${L.hijab?'on':''}" data-a="crSet" data-v="hijab:1">Berhijab</button></div>
    <div class="chead">Gaya Hijab</div>${optBtns('hijabSt',HIJAB_ST.map(h=>h[0]),L.hijabSt,HIJAB_ST.map(h=>h[1]),ownedH)}<div class="chead">Warna Hijab</div>${swatches('hijabCol',HIJAB_COL,L.hijabCol)}`;
  case 'aksesori':return`<div class="chead">Cermin Mata</div>${optBtns('glasses',GLASSES.map(g=>g[0]),L.glasses,GLASSES.map(g=>g[1]),ownedG)}<div class="chead">Topi</div>${optBtns('hat',HATS.map(g=>g[0]),L.hat,HATS.map(g=>g[1]),ownedHt)}<div class="chead">Aksesori</div>${optBtns('acc',ACCS.map(g=>g[0]),L.acc,ACCS.map(g=>g[1]),ownedA)}${ctxName!=='creator'?'<div class="note">Item berkunci boleh dibeli di Almari → Kasut & Aksesori.</div>':''}`;
  case 'pakaian':{const ids=['h1','h2','h3','h4','s1','s2','s4'].filter(i=>OUT[i].g==='u'||OUT[i].g===L.g);return`<div class="chead">Pakaian Permulaan</div><div class="grid s">${ids.map(i=>`<button class="card ${L.outfit===i?'on':''}" data-a="crSet" data-v="outfit:${i}"><img class="im" src="${charImg(Object.assign({},L,{outfit:i}),140,150,1.04,4)}" alt=""><h4>${esc(OUT[i].name)}</h4></button>`).join('')}</div>
    <div class="chead">Kasut</div>${optBtns('shoesIdx',['Sukan Putih','Sekolah','Selipar'],['sh1','sh2','sh3'].indexOf(L.shoes))}<div class="note">Lebih 70 pakaian termasuk koleksi tradisional boleh dibeli dalam permainan.</div>`}
  case 'pratetap':return`<div class="presets">${PRESETS.map((p,i)=>`<canvas width="120" height="120" data-a="crPreset" data-v="${i}" data-pre="${i}"></canvas>`).join('')}</div>`;
  }
  return'';
}
const CR_TABS=[['profil','Profil'],['asas','Asas'],['rambut','Rambut'],['mata','Mata'],['muka','Muka'],['hijab','Hijab'],['aksesori','Aksesori'],['pakaian','Pakaian'],['pratetap','Pratetap']];
function renderCreator(){
  const L=CR.look;
  $('#cLeft').innerHTML=`<div class="chead">Pratetap Pantas</div><div class="presets">${PRESETS.map((p,i)=>`<canvas width="120" height="120" data-a="crPreset" data-v="${i}" data-pre="${i}"></canvas>`).join('')}</div>
   <div class="chead">Tips</div><div class="note">Watak lelaki & perempuan, berhijab atau tanpa hijab — semuanya boleh diubah kemudian di Almari. Pakaian tradisional dari semua kaum Malaysia tersedia di Butik Warisan, Asia Mall.</div>`;
  $('#cRight').innerHTML=`<div class="ctabs">${CR_TABS.map(t=>`<button class="ctab ${CR.tab===t[0]?'on':''}" data-a="crTab" data-v="${t[0]}">${t[1]}</button>`).join('')}</div>${lookEditor(L,CR.tab,'creator')}`;
  document.querySelectorAll('canvas[data-pre]').forEach(c=>{const x=c.getContext('2d');x.clearRect(0,0,120,120);drawChibi(x,60,178,1.7,PRESETS[+c.dataset.pre],0,0)});
  drawCreatorPrev();
  const ni=$('#cName');if(ni&&ni.value!==CR.name)ni.value=CR.name;
}
function drawCreatorPrev(){
  const c=$('#cvPrev');const W=c.clientWidth,H=c.clientHeight,d=pxr();c.width=W*d;c.height=H*d;const x=c.getContext('2d');x.setTransform(d,0,0,d,0,0);
  x.fillStyle='rgba(255,255,255,.55)';x.beginPath();x.ellipse(W/2,H-24,Math.min(W*.3,150),22,0,0,TAU);x.fill();x.strokeStyle='#c9b4ff';x.lineWidth=3;x.stroke();
  const s=Math.min((H-30)/112,W/90);drawChibi(x,W/2,H-24,s,CR.look,CR.dir,0);
}
ACT.crTab=v=>{CR.tab=v;renderCreator()};
ACT.crStage=v=>{CR.stage=v;renderCreator()};
ACT.crPreset=v=>{CR.look=Object.assign({},PRESETS[+v]);renderCreator()};
ACT.crSet=v=>{const [k,val]=v.split(':');const L=SH.id==='almari'?S.look:CR.look;
  if(k==='g'){L.g=val;L.hair=0;if(val==='m'){L.hijab=0;if(OUT[L.outfit].g==='f')L.outfit='h1'}else if(OUT[L.outfit].g==='m')L.outfit='h4'}
  else if(k==='outfit')L.outfit=val;else if(k==='shoesIdx')L.shoes=['sh1','sh2','sh3'][+val];
  else L[k]=+val;
  if(SH.id==='almari'){clearSprites('player');drawPortrait();rerender()}else renderCreator()};
ACT.crRot=v=>{CR.dir=(CR.dir+(+v)+4)%4;drawCreatorPrev()};
ACT.crDice=()=>{CR.name=pick(CR.look.g==='m'?NAMES_M:NAMES_F);$('#cName').value=CR.name};
ACT.crStart=()=>{const n=($('#cName').value||'').trim()||pick(CR.look.g==='m'?NAMES_M:NAMES_F);CR.name=n.slice(0,18);newSave(Object.assign({},CR.look),CR.name,CR.stage);startGame(true)};
ACT.crBack=()=>showTitle();

// ---------- START GAME
let ENGINE_READY=false;
function startGame(fresh){
  ['#title','#creator'].forEach(q=>$(q).classList.add('hide'));$('#game').classList.remove('hide');
  if(!ENGINE_READY){genWorld();IA=[];ENGINE_READY=true;setupInput();resize();initEntities();requestAnimationFrame(loop)}
  else{resize()}
  IA=interactables();
  spriteCache.clear();
  if(S.pos&&!fresh){P.x=S.pos[0];P.y=S.pos[1];if(isBlocked(P.x,P.y)){const f=findFree(Math.floor(P.x/TS),Math.floor(P.y/TS));P.x=f[0];P.y=f[1]}}else placePlayerAt(homeLoc());
  RT.fest=festToday();RT.ride=false;
  drawPortrait();hud();updateActBtns();RT.paused=false;
  if(fresh){save();setTimeout(()=>showDlg({title:`Selamat datang, ${S.name}!`,body:`<p>Ini <b>Kota Kita</b> — bandar Malaysia anda. Belajar, bekerja, memancing, bertani, membeli-belah dan raikan perayaan bersama jiran.</p>
    <div class="note"><b>Kawalan:</b> ${matchMedia('(pointer:coarse)').matches?'Guna joystick untuk bergerak, butang <b>Aksi</b> untuk masuk bangunan & berbual. Ketik peta untuk berjalan ke situ.':'WASD / anak panah untuk bergerak, <b>E</b> untuk aksi, <b>Shift</b> untuk lari, <b>M</b> untuk peta. Klik peta untuk berjalan ke situ.'}</div>
    <div class="note y" style="margin-top:8px">Mula dengan masuk ke <b>Rumah Anda</b> di depan, atau buka menu <b>Kerjaya</b> untuk kerja sambilan pertama.</div>`,buttons:[{label:'Jom Main!',cls:'g',a:'closeDlg'}]}),300)}
}
