// ===================== NEW PLAYER WELCOME BONUS + BALIK KE RUMAH =====================
const WELCOME_BONUS=1000, BONUS_KEY='kotakita_bonus_claims_v1';
const kkUid=()=>'KK-'+Date.now().toString(36).toUpperCase()+'-'+Math.random().toString(36).slice(2,8).toUpperCase();
function bonusClaims(){try{const a=JSON.parse(localStorage.getItem(BONUS_KEY)||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}}
function recordClaim(pid){try{const a=bonusClaims();if(!a.includes(pid))a.push(pid);localStorage.setItem(BONUS_KEY,JSON.stringify(a.slice(-100)))}catch(e){}}
// every brand-new profile gets a unique ID and an unclaimed bonus
{const ns=newSave;newSave=function(...a){const r=ns.apply(this,a);S.pid=kkUid();S.bonusClaimed=false;S.bonusAt=null;return r}}
// saves from before this update are existing players: give them an ID, mark the bonus as already settled (no credit)
{const mg=migrate;migrate=function(...a){const r=mg.apply(this,a);if(S&&!S.pid){S.pid=kkUid();S.bonusClaimed=true;S.bonusLegacy=true}return r}}
function grantWelcomeBonus(){
  if(!S||!S.pid||S.bonusClaimed)return false;
  if(bonusClaims().includes(S.pid)){S.bonusClaimed=true;save();return false}
  S.money+=WELCOME_BONUS;S.bonusClaimed=true;S.bonusAt=Date.now();S.bonusAmt=WELCOME_BONUS;
  recordClaim(S.pid);save();
  notify(`Bonus pemain baharu ${fmt(WELCOME_BONUS)} dikreditkan ke dompet.`);
  addMsg('Majlis Bandaraya Kota Kita','Selamat datang ke Kota Kita!',`Anda menerima ${fmt(WELCOME_BONUS)} sebagai modal permulaan kehidupan baharu anda. Gunakan untuk makanan, pakaian, pengangkutan dan keperluan harian.`);
  hud();showReward();return true}
function showReward(){
  const st=$('#stage');let el=$('#reward');if(el)el.remove();
  el=document.createElement('div');el.id='reward';el.setAttribute('role','dialog');el.setAttribute('aria-label','Bonus selamat datang');
  const coins=Array.from({length:18},(_,i)=>`<i class="rc" style="left:${4+i*5.4}%;animation-delay:${(i%6)*.22+(i>8?.5:0)}s;animation-duration:${1.8+(i%4)*.35}s"></i>`).join('');
  el.innerHTML=`<div class="rcoins">${coins}</div><div class="rbox"><div class="rrays"></div>
    <div class="rbag"><svg viewBox="0 0 120 120"><defs><linearGradient id="rbg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd76a"/><stop offset="1" stop-color="#e09a12"/></linearGradient></defs><path d="M38 34h44l-8 14H46z" fill="#c97f0e"/><path d="M46 48h28c22 10 30 30 26 46-3 12-16 18-40 18s-37-6-40-18c-4-16 4-36 26-46z" fill="url(#rbg)" stroke="#a8670a" stroke-width="3"/><text x="60" y="94" text-anchor="middle" font-size="30" font-weight="900" fill="#7a4a06" font-family="Fredoka,sans-serif">RM</text><circle cx="94" cy="40" r="5" fill="#fff"/><circle cx="24" cy="58" r="3" fill="#fff"/></svg></div>
    <h2>SELAMAT DATANG KE KOTA KITA!</h2>
    <p>Anda menerima <b>RM1,000</b> sebagai modal permulaan kehidupan baharu anda!</p>
    <div class="ramt">+RM <span id="rCount">0</span></div>
    <small>Gunakan untuk makanan & minuman, pakaian, pengangkutan dan keperluan harian.</small>
    <button class="btn g" data-a="rewardOk">Terima kasih!</button></div>`;
  st.appendChild(el);RT.paused=true;
  const t0=performance.now();const tick=t=>{const k=Math.min(1,(t-t0)/1400),v=Math.round(WELCOME_BONUS*(1-Math.pow(1-k,3)));const c=$('#rCount');if(!c)return;c.textContent=v.toLocaleString('en-MY');if(k<1)requestAnimationFrame(tick)};requestAnimationFrame(tick);
}
ACT.rewardOk=()=>{const el=$('#reward');if(el){el.classList.add('out');setTimeout(()=>el.remove(),260)}RT.paused=!!DLG;const m=$('#hMoney');if(m){const ch=m.closest('.chip');ch.classList.remove('bump');void ch.offsetWidth;ch.classList.add('bump')}};
{const sg=startGame;startGame=function(fresh){sg(fresh);setTimeout(()=>grantWelcomeBonus(),fresh?120:400)}}

// ---------------- Balik ke Rumah
function hasHome(){return!!(S&&S.home&&S.home.type&&HOUSE[S.home.type]&&LOC[HOUSE[S.home.type].loc])}
ACT.goHome=()=>{
  if(!S||$('#game').classList.contains('hide')||RT.homing)return;
  if(!hasHome()){showDlg({title:'Tiada Rumah',body:'<p>Anda belum mempunyai rumah. Sila dapatkan rumah terlebih dahulu.</p>',buttons:[{label:'Cari Rumah',cls:'g',a:'goPanel',v:'rumah:hartanah'},{label:'Tutup',cls:'w',a:'closeDlg'}]});return}
  if(DLG){toast('Tutup tetingkap semasa dahulu.','r');return}
  if(SH&&SH.id)closeSheet();
  const H=HOUSE[S.home.type],to=H.loc;
  S.lastPos=[Math.round(P.x),Math.round(P.y)];S.pos=S.lastPos.slice();save();
  RT.homing=true;RT.paused=true;RT.target=null;RT.joy.x=RT.joy.y=0;
  let f=$('#homeFade');if(!f){f=document.createElement('div');f.id='homeFade';f.innerHTML=`<div class="hfbox"><div class="hfhouse">${HOME_ICON}</div><b>Pulang ke rumah…</b><span id="hfName"></span><div class="hfbar"><i></i></div></div>`;$('#stage').appendChild(f)}
  $('#hfName').textContent=H.name;f.classList.remove('hide');void f.offsetWidth;f.classList.add('on');
  setTimeout(()=>{
    if(RT.ride){RT.ride=false;if(typeof updateActBtns==='function')updateActBtns()}
    placePlayerAt(to);P.dir=0;P.moving=false;S.pos=[Math.round(P.x),Math.round(P.y)];S.cnt.home=(S.cnt.home||0)+1;save();hud();
    setTimeout(()=>{f.classList.remove('on');setTimeout(()=>{f.classList.add('hide');RT.homing=false;RT.paused=!!(DLG||(SH&&SH.id));toast(`Selamat pulang ke ${H.name}! 🏠`,'g');setTimeout(()=>{if(!DLG&&!(SH&&SH.id)&&typeof openLoc==='function')openLoc(to)},350)},420)},650)
  },520);
};
const HOME_ICON='<svg viewBox="0 0 48 48"><defs><linearGradient id="hmR" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff8cc6"/><stop offset="1" stop-color="#9a5cf5"/></linearGradient></defs><path d="M6 23 24 8l18 15" fill="none" stroke="url(#hmR)" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/><path d="M11 21v18a3 3 0 0 0 3 3h20a3 3 0 0 0 3-3V21L24 11z" fill="#fff"/><path d="M20 42V31a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v11" fill="#ffb3d6"/><circle cx="26" cy="36" r="1" fill="#9a5cf5"/><path d="M24 22.5c-1.4-2.2-5-1.4-5 1.2 0 2.4 5 5.3 5 5.3s5-2.9 5-5.3c0-2.6-3.6-3.4-5-1.2z" fill="#ff5ea8"/><rect x="33" y="10" width="4" height="7" rx="1" fill="#9a5cf5"/></svg>';
// permanent HUD button
{const hr=$('#hudR');if(hr&&!$('#homeBtn')){const b=document.createElement('button');b.id='homeBtn';b.className='homebtn';b.dataset.a='goHome';b.setAttribute('aria-label','Balik ke Rumah');b.innerHTML=`<span class="hbi">${HOME_ICON}</span><span class="hbt">BALIK KE<br>RUMAH</span>`;hr.appendChild(b)}}
// keyboard: B = balik ke rumah
addEventListener('keydown',e=>{if(e.code==='KeyB'&&!e.repeat&&S&&!$('#game').classList.contains('hide')&&!(document.activeElement&&/INPUT|TEXTAREA/.test(document.activeElement.tagName))&&!DLG&&!(SH&&SH.id))ACT.goHome()});
