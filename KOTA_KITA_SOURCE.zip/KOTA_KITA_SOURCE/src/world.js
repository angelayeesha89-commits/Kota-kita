// ===================== WORLD =====================
const TS=32,MW=72,MH=72,CH=256;
const T=new Uint8Array(MW*MH),SOL=new Uint8Array(MW*MH);
const ti=(x,y)=>y*MW+x;
const tget=(x,y)=>x<0||y<0||x>=MW||y>=MH?3:T[ti(x,y)];
function rect(x,y,w,h,t){for(let j=y;j<y+h;j++)for(let i=x;i<x+w;i++)if(i>=0&&j>=0&&i<MW&&j<MH)T[ti(i,j)]=t}
function solidRect(x,y,w,h,v=1){for(let j=y;j<y+h;j++)for(let i=x;i<x+w;i++)if(i>=0&&j>=0&&i<MW&&j<MH)SOL[ti(i,j)]=v}
// tiles
const G=0,RD=1,PL=2,SEA=3,SAND=4,FW=5,FO=6,SOIL=7,DIRT=8,MUD=9,TAR=10,DOCK=11,BRG=12,PARK=13,WALK=14,RAIL=15;
const OBJS=[],LAMPS=[],BLDS=[],SPOTS=[],SPECIAL=[];
const coastX=y=>86+Math.round(Math.sin(y*.35));
const coastY=x=>69+Math.round(Math.sin(x*.3)*.8);
const riverX=y=>21+Math.round(Math.sin(y*.22)*1.2);

function genWorld(){
  T.fill(G);SOL.fill(0);OBJS.length=0;LAMPS.length=0;BLDS.length=0;SPOTS.length=0;SPECIAL.length=0;
  const R=seeded(42);
  rect(0,0,20,30,FO);
  // sea + beach
  for(let y=12;y<MH;y++){const cx=coastX(y);for(let x=cx-3;x<MW;x++)T[ti(x,y)]=x>=cx?SEA:SAND}
  for(let x=0;x<MW;x++){const cy=coastY(x);for(let y=cy-2;y<MH;y++)if(T[ti(x,y)]!==SEA)T[ti(x,y)]=y>=cy?SEA:SAND}
  for(let x=86;x<MW;x++){T[ti(x,11)]=SAND}
  // airport
  rect(66,0,34,10,TAR);
  // river
  for(let y=0;y<MH;y++){const rx=riverX(y),wd=y>58?5:3,x0=y>58?rx-1:rx;
    if(y>56)for(let x=x0-4;x<x0+wd+4;x++)if(tget(x,y)!==SEA&&x>=0)T[ti(x,y)]=MUD;
    for(let x=x0;x<x0+wd;x++)T[ti(x,y)]=y>=coastY(x)?SEA:FW}
  // park + lake
  rect(38,58,24,7,PARK);rect(47,59,9,4,FW);
  // plaza
  rect(48,32,15,15,PL);rect(49,47,13,0,WALK);
  // farm soil
  rect(1,49,8,6,SOIL);rect(13,49,7,6,SOIL);rect(13,56,7,6,SOIL);
  // roads
  const road=(x,y,w,h,t=RD)=>{for(let j=y;j<y+h;j++)for(let i=x;i<x+w;i++){if(i<0||j<0||i>=MW||j>=MH)continue;const c=T[ti(i,j)];T[ti(i,j)]=(c===FW||c===SEA)?BRG:t}};
  road(26,17,60,2);road(0,30,86,2);road(0,47,86,2);road(46,0,2,66);road(63,10,2,56);road(26,17,2,49);road(10,65,76,2);road(63,10,18,2);
  road(10,32,2,33,DIRT);road(15,9,2,21,DIRT);road(15,9,4,2,DIRT);road(11,22,5,1,DIRT);road(2,62,8,1,DIRT);
  road(26,57,60,1,RAIL);
  // docks
  for(let x=86;x<94;x++){T[ti(x,47)]=DOCK;T[ti(x,48)]=DOCK}
  for(let y=67;y<73;y++)for(let x=76;x<80;x++)T[ti(x,y)]=DOCK;
  // island
  for(let y=51;y<65;y++)for(let x=89;x<MW;x++){const d=((x-94.5)/5.5)**2+((y-57.5)/6.8)**2;if(d<1)T[ti(x,y)]=d<.55?G:SAND}
  rect(89,57,2,1,DOCK);
  // muara dock
  const mrx=riverX(63)-1;for(let x=mrx-4;x<mrx;x++)T[ti(x,63)]=DOCK;

  // ---- buildings: kind,x,y,w,h,loc,label
  const B=(kind,x,y,w,h,loc,label,o={})=>{const b=Object.assign({kind,x,y,w,h,loc,label},o);BLDS.push(b);solidRect(x,y,w,h);OBJS.push({type:'bld',b,x:x*TS-16,y:(y*TS)-(o.tall||0)-66,w:w*TS+32,h:h*TS+(o.tall||0)+80,base:(y+h)*TS,occ:1});if(loc&&!o.nodoor){LOC[loc].door=[x+Math.floor(w/2),y+h]}return b};
  B('hospital',49,1,12,9,'hospital','HOSPITAL KOTA KITA',{tall:14});
  B('faculty',26,3,5,7,null,'FAKULTI SAINS');
  B('uni',32,3,11,10,'uni','UNIVERSITI KOTA KITA',{tall:8});
  B('faculty',43,5,3,6,null,'');
  B('school',33,20,11,7,'sekolah','SMK KOTA KITA');
  B('gov',49,20,7,8,'pejabat','PEJABAT KERAJAAN',{tall:10});
  B('klinik',57,21,5,6,'klinik','KLINIK KESIHATAN');
  B('kerjaya',66,20,6,7,'kerjaya','PUSAT KERJAYA');
  B('polis',72,21,5,6,'polis','BALAI POLIS');
  B('bomba',78,21,5,6,'bomba','BALAI BOMBA');
  B('airport',67,2,10,7,'airport','LAPANGAN TERBANG',{tall:6});
  B('mall',66,32,14,13,'mall','ASIA MALL',{tall:16});
  B('shop',48,32,5,4,null,'BANK',{c:'#3a86ff'});B('shop',53,32,5,4,'bandar','KEDAI MAMAK',{c:'#f29b0c',nodoor:1});B('cinema',58,32,5,4,'pawagam','PAWAGAM');
  B('beachhut',81,33,3,3,'pantai','PONDOK PANTAI');
  // housing
  const hc=['#c8503a','#3a6ab0','#7a5ac8','#2a9a6a','#d08a2a'];
  for(let r=0;r<2;r++)for(let i=0;i<4;i++)B('house',29+i*4,33+r*5,4,4,null,'',{c:hc[(i+r*2)%5],wall:['#fff4e6','#f0f6ff','#fdf0ff','#effbf0'][(i+r)%4]});
  B('myhome',35,42,5,4,'perumahan','RUMAH ANDA',{c:'#6a3fd0'});
  B('house',29,42,5,4,null,'',{c:'#d08a2a',wall:'#fff4e6'});B('house',41,42,4,4,null,'',{c:'#3a6ab0',wall:'#f0f6ff'});
  B('apartment',38,50,8,6,null,'APARTMEN SERI',{tall:18});
  B('pasar',29,50,8,5,'pasar','PASAR TANI');
  B('lrt',49,50,6,5,'lrt','LRT / MRT');
  B('bas',56,50,6,5,'bas','TERMINAL BAS');
  B('keretapi',66,50,8,5,'keretapi','STESEN KERETA API',{tall:6});
  B('jetihut',77,50,5,4,'jeti','JETI MEMANCING');
  B('port',69,59,8,5,'pelabuhan','PELABUHAN');
  B('pavilion',42,59,4,3,'taman','TAMAN REKREASI');
  B('library',57,12,5,4,'perpustakaan','PERPUSTAKAAN');
  rect(28,58,10,7,G);B('stadium',29,58,9,6,'stadium','STADIUM KOTA KITA');
  B('medan',48,41,4,4,'medan','MEDAN SELERA');
  B('nightmarket',59,41,4,4,'pasarmalam','PASAR MALAM');
  // kampung
  for(const [x,y] of [[1,33],[1,38],[1,43],[5,34],[5,41],[13,33],[17,35],[17,43]])B('kampung',x,y,4,4,null,'');
  B('balai',12,38,5,4,'kampung','BALAI RAYA');
  B('barn',2,57,6,5,'ladang','LADANG KOTA KITA');
  B('ranger',10,18,5,4,'hutan','PONDOK RENJER');
  B('resort',92,54,5,4,'pulau','RESORT PULAU');
  // fishing spots
  const spot=(id,x,y)=>{SPOTS.push({id,x,y})};
  spot('jeti',93,47);spot('teluk',coastX(40)-1,40);spot('manukan',96,61);spot('muara',mrx-4,63);spot('tasik',50,58);spot('sungai',19,10);
  SPECIAL.push({id:'feri',x:90,y:57,label:'Feri ke Pelabuhan'});
  SPECIAL.push({id:'fountain',x:55,y:42,label:'Pancutan Dataran'});
  // fountain + plaza decor
  solidRect(54,38,3,3);OBJS.push({type:'fountain',x:53*TS,y:37*TS,w:5*TS,h:5*TS,base:41*TS});
  // trees
  const doorSet=new Set(LOCS.map(l=>{const d=LOC[l[0]].door;return d[0]+','+d[1]}));
  const tree=(x,y,kind)=>{if(doorSet.has(x+','+y)||doorSet.has(x+','+(y-1))||SOL[ti(x,y)]||[RD,PL,SEA,FW,DOCK,BRG,RAIL,TAR,DIRT].includes(tget(x,y)))return;SOL[ti(x,y)]=1;OBJS.push({type:'tree',kind,tx:x,ty:y,x:x*TS-30,y:y*TS-60,w:TS+60,h:TS+64,base:(y+1)*TS,occ:1,s:R()})};
  for(let i=0;i<260;i++){const x=Math.floor(R()*20),y=Math.floor(R()*30);if(Math.abs(x-12)<4&&Math.abs(y-20)<4)continue;tree(x,y,'forest')}
  for(let y=33;y<62;y+=2)for(const x of [0,9,12,20])if(R()<.6)tree(x,y,'palm');
  for(let y=14;y<66;y+=3){const cx=coastX(y)-3;if(R()<.6&&!(y>45&&y<50))tree(cx,y,'palm')}
  for(let y=52;y<64;y+=2)for(let x=90;x<99;x+=2)if(T[ti(x,y)]===SAND&&R()<.5)tree(x,y,'palm');
  for(let x=28;x<86;x+=3){if(R()<.7)tree(x,16,'round');if(R()<.6)tree(x,29,'round');if(R()<.5)tree(x,46,'round');if(R()<.5)tree(x,64,'round')}
  for(let y=19;y<64;y+=3){tree(45,y,'round');tree(62,y,'round');tree(28,y,'round')}
  for(let i=0;i<30;i++){const x=38+Math.floor(R()*24),y=58+Math.floor(R()*7);if(T[ti(x,y)]===PARK)tree(x,y,R()<.5?'round':'flower')}
  for(let i=0;i<30;i++){const x=Math.floor(R()*30)+12,y=57+Math.floor(R()*10);if(T[ti(x,y)]===MUD)tree(x,y,'mangrove')}
  for(let i=0;i<18;i++){const x=27+Math.floor(R()*19),y=19+Math.floor(R()*10);if(x<33)tree(x,y,'round')}
  for(let x=1;x<20;x+=3)tree(x,63,'palm');
  // lamps & benches on plaza edges and roads
  for(let x=49;x<62;x+=4){LAMPS.push([x,47]);LAMPS.push([x,31])}
  for(let y=33;y<46;y+=4){LAMPS.push([48,y]);LAMPS.push([62,y])}
  for(let x=30;x<84;x+=8){LAMPS.push([x,19]);LAMPS.push([x,49])}
  for(const [x,y] of LAMPS){OBJS.push({type:'lamp',x:x*TS,y:y*TS-40,w:TS,h:TS+40,base:(y+1)*TS-2})}
  for(const [x,y] of [[50,40],[60,40],[50,36],[60,36],[44,61],[52,63],[58,60]])OBJS.push({type:'bench',x:x*TS,y:y*TS,w:TS*2,h:TS,base:(y+1)*TS});
  for(let y=30;y<62;y+=5){const cx=coastX(y)-2;OBJS.push({type:'umbrella',x:cx*TS-10,y:y*TS-30,w:TS+20,h:TS+40,base:(y+1)*TS,c:['#e5484d','#3a86ff','#f2c230','#38b84a'][y%4]})}
  for(const [x,y,c] of [[78,61,'#e5484d'],[80,61,'#3a86ff'],[82,61,'#f2c230'],[78,63,'#38b84a'],[80,63,'#6a3fd0'],[82,63,'#e85d75']]){solidRect(x,y,2,1);OBJS.push({type:'container',x:x*TS,y:y*TS-14,w:TS*2,h:TS+14,base:(y+1)*TS,c})}
  OBJS.push({type:'crane',x:76*TS,y:64*TS,w:TS*4,h:TS*4,base:72*TS});
  OBJS.push({type:'boat',x:88*TS,y:49*TS,w:TS*3,h:TS*2,base:51*TS});OBJS.push({type:'ferry',x:80*TS,y:68*TS,w:TS*4,h:TS*3,base:71*TS});
  for(const [x,y,k] of [[3,51,'cow'],[6,53,'chicken'],[15,51,'goat'],[17,53,'chicken']])OBJS.push({type:'animal',k,x:x*TS,y:y*TS,w:TS,h:TS,base:(y+1)*TS});
  OBJS.push({type:'plane',x:84*TS,y:3*TS,w:TS*6,h:TS*4,base:7*TS});
  OBJS.push({type:'field',x:28*TS,y:20*TS,w:5*TS,h:9*TS,base:20*TS,flat:1});
  OBJS.push({type:'waterfall',x:19*TS,y:0,w:TS*5,h:TS*3,base:2*TS});
  OBJS.sort((a,b)=>a.base-b.base);
  // walls of island water so player can't walk off: solid sea/freshwater handled by isSolid
}
const isSolidTile=(x,y)=>{const t=tget(x,y);return t===SEA||t===FW||SOL[ti(x,y)]===1||x<0||y<0||x>=MW||y>=MH};

// ---------- tile drawing ----------
const TCOL={[G]:'#7cc95a',[RD]:'#5b5e6b',[PL]:'#e8dac6',[SEA]:'#3aa6de',[SAND]:'#f3dda2',[FW]:'#4bb2c9',[FO]:'#5aa548',[SOIL]:'#8a5a33',[DIRT]:'#c9a06e',[MUD]:'#76845a',[TAR]:'#4d505a',[DOCK]:'#b47b4a',[BRG]:'#a8927a',[PARK]:'#88d26c',[WALK]:'#d8d0c8',[RAIL]:'#8c867a'};
function drawTile(c,x,y){
  const t=T[ti(x,y)],X=x*TS,Y=y*TS,r=seeded(x*131+y*17);
  c.fillStyle=TCOL[t];c.fillRect(X,Y,TS,TS);
  switch(t){
  case G:case FO:case PARK:{const nv=(a,b)=>(Math.sin(a*.62+b*.27)+Math.sin(a*.21-b*.55)+Math.sin((a+b)*.13))/3;
    const v0=nv(x,y),v1=nv(x+1,y+1),gg=c.createLinearGradient(X,Y,X+TS,Y+TS);gg.addColorStop(0,v0>0?`rgba(255,250,170,${v0*.16})`:`rgba(10,70,30,${-v0*.16})`);gg.addColorStop(1,v1>0?`rgba(255,250,170,${v1*.16})`:`rgba(10,70,30,${-v1*.16})`);c.fillStyle=gg;c.fillRect(X,Y,TS,TS);
    const dk=t===FO?'#43853a':'#5aa840',lt=t===FO?'#6db85a':'#9be07a';c.lineCap='round';
    for(let i=0;i<9;i++){const a=r()*TS,b=r()*(TS-4)+4;c.strokeStyle=r()<.55?dk:lt;c.lineWidth=1.3;c.beginPath();c.moveTo(X+a,Y+b);c.quadraticCurveTo(X+a+1,Y+b-2,X+a+(r()-.5)*3,Y+b-4.5);c.stroke()}
    if(r()<.18){const a=r()*24+4,b=r()*24+4;c.fillStyle='rgba(60,140,50,.5)';for(let k=0;k<3;k++){c.beginPath();c.arc(X+a+Math.cos(k*2.1)*2.2,Y+b+Math.sin(k*2.1)*2.2,2,0,TAU);c.fill()}}
    if((t===PARK&&r()<.4)||(t===G&&r()<.1)){const a=r()*24+4,b=r()*24+4,fc=['#ff7ab8','#ffffff','#ffd23f','#ff8a5c','#c79bff'][Math.floor(r()*5)];c.fillStyle=fc;for(let k=0;k<5;k++){c.beginPath();c.arc(X+a+Math.cos(k*1.26)*2.2,Y+b+Math.sin(k*1.26)*2.2,1.6,0,TAU);c.fill()}c.fillStyle='#ffe066';c.beginPath();c.arc(X+a,Y+b,1,0,TAU);c.fill()}break}
  case RD:{const up=tget(x,y-1)===RD||tget(x,y-1)===BRG,dn=tget(x,y+1)===RD||tget(x,y+1)===BRG,lf=tget(x-1,y)===RD||tget(x-1,y)===BRG,rt=tget(x+1,y)===RD||tget(x+1,y)===BRG;
    {const ag=c.createLinearGradient(X,Y,X,Y+TS);ag.addColorStop(0,'#5d6172');ag.addColorStop(1,'#565a6a');c.fillStyle=ag;c.fillRect(X,Y,TS,TS)}
    for(let i=0;i<7;i++){c.fillStyle=r()<.5?'rgba(255,255,255,.07)':'rgba(0,0,0,.08)';c.fillRect(X+r()*30,Y+r()*30,1.6,1.6)}if(r()<.08){c.strokeStyle='rgba(0,0,0,.12)';c.lineWidth=.8;c.beginPath();c.moveTo(X+r()*TS,Y+r()*TS);c.lineTo(X+r()*TS,Y+r()*TS);c.stroke()}
    c.fillStyle='#f2f2f2';if(!up&&dn&&x%2===0&&!(lf&&rt&&tget(x,y+2)===RD))c.fillRect(X+4,Y+TS-1,TS-8,2);
    if(!lf&&rt&&y%2===0)c.fillRect(X+TS-1,Y+4,2,TS-8);
    const kerb=(x0,y0,w,h,hor,far)=>{c.fillStyle='rgba(0,0,0,.22)';if(hor)c.fillRect(x0,far?y0-2:y0+h,w,2);else c.fillRect(far?x0-2:x0+w,y0,2,h);c.fillStyle='#dcd6cd';c.fillRect(x0,y0,w,h);c.fillStyle='#f6f2ea';if(hor)c.fillRect(x0,y0,w,1.4);else c.fillRect(x0,y0,1.4,h);c.fillStyle='rgba(120,110,100,.35)';if(hor)for(let i=0;i<w;i+=8)c.fillRect(x0+i,y0,1,h);else for(let i=0;i<h;i+=8)c.fillRect(x0,y0+i,w,1)};
    if(!up)kerb(X,Y,TS,5,1,0);if(!dn)kerb(X,Y+TS-5,TS,5,1,1);if(!lf)kerb(X,Y,5,TS,0,0);if(!rt)kerb(X+TS-5,Y,5,TS,0,1);break}
  case PL:{c.fillStyle='#cdbda6';c.fillRect(X,Y,TS,TS);for(let j=0;j<4;j++)for(let i=-1;i<3;i++){const px=X+i*16+(j%2?8:0),py=Y+j*8;if(px+15<X||px>X+TS)continue;const pg=c.createLinearGradient(0,py,0,py+8);const base=((x*7+y*3+i+j)%3)?'#eadcc6':'#e2d0b6';pg.addColorStop(0,shade(base,.08));pg.addColorStop(1,shade(base,-.05));c.fillStyle=pg;c.fillRect(Math.max(px+1,X),py+1,Math.min(px+15,X+TS)-Math.max(px+1,X),6.4)}
    if((x+y)%5===0){c.fillStyle='rgba(200,160,110,.5)';c.beginPath();c.arc(X+16,Y+16,7,0,TAU);c.fill();c.fillStyle='rgba(255,255,255,.35)';c.beginPath();c.arc(X+16,Y+16,3.4,0,TAU);c.fill()}break}
  case SEA:{const sh=Math.min(1,(x-coastX(y)+ (y-coastY(x)))/10);{const sg=c.createLinearGradient(X,Y,X+TS,Y+TS);sg.addColorStop(0,'#4cc0ec');sg.addColorStop(1,'#2f9ad6');c.fillStyle=sg;c.fillRect(X,Y,TS,TS)}c.fillStyle=`rgba(20,70,150,${.06+Math.max(0,sh)*.24})`;c.fillRect(X,Y,TS,TS);for(let i=0;i<3;i++)if(r()<.5){c.fillStyle='rgba(255,255,255,.75)';const sx=X+r()*30,sy=Y+r()*30;c.fillRect(sx,sy,2.4,1);c.fillRect(sx+.7,sy-.7,1,2.4)}c.strokeStyle='rgba(255,255,255,.35)';c.lineWidth=1.5;c.beginPath();const a=r()*20,b=r()*26+3;c.moveTo(X+a,Y+b);c.quadraticCurveTo(X+a+4,Y+b-3,X+a+8,Y+b);c.stroke();
    for(const [dx,dy] of [[-1,0],[1,0],[0,-1],[0,1]]){const n=tget(x+dx,y+dy);if(n===SAND||n===G||n===MUD){c.fillStyle='rgba(255,255,255,.65)';if(dx===-1)c.fillRect(X,Y,4,TS);if(dx===1)c.fillRect(X+TS-4,Y,4,TS);if(dy===-1)c.fillRect(X,Y,TS,4);if(dy===1)c.fillRect(X,Y+TS-4,TS,4)}}break}
  case FW:{{const fg=c.createLinearGradient(X,Y,X+TS,Y);fg.addColorStop(0,'#5cc4d8');fg.addColorStop(1,'#3fa6c4');c.fillStyle=fg;c.fillRect(X,Y,TS,TS)}if(r()<.4){c.fillStyle='rgba(255,255,255,.7)';c.fillRect(X+r()*28,Y+r()*28,2,1)}c.strokeStyle='rgba(255,255,255,.3)';c.lineWidth=1.5;c.beginPath();const a=r()*20,b=r()*26+3;c.moveTo(X+a,Y+b);c.quadraticCurveTo(X+a+4,Y+b-3,X+a+8,Y+b);c.stroke();
    for(const [dx,dy] of [[-1,0],[1,0],[0,-1],[0,1]]){const n=tget(x+dx,y+dy);if(n!==FW&&n!==SEA&&n!==BRG){c.fillStyle='rgba(60,110,60,.45)';if(dx===-1)c.fillRect(X,Y,3,TS);if(dx===1)c.fillRect(X+TS-3,Y,3,TS);if(dy===-1)c.fillRect(X,Y,TS,3);if(dy===1)c.fillRect(X,Y+TS-3,TS,3)}}break}
  case SAND:{c.strokeStyle='rgba(200,160,90,.35)';c.lineWidth=1;for(let j=0;j<2;j++){const yy=Y+8+j*14+r()*4;c.beginPath();c.moveTo(X,yy);c.quadraticCurveTo(X+8,yy-2,X+16,yy);c.quadraticCurveTo(X+24,yy+2,X+TS,yy);c.stroke()}c.fillStyle='#e6cb88';for(let i=0;i<5;i++)c.fillRect(X+r()*30,Y+r()*30,1.6,1.6);if(r()<.06){c.fillStyle='#fff0f4';c.beginPath();c.arc(X+r()*26+3,Y+r()*26+3,2.2,Math.PI,TAU);c.fill()}break}
  case SOIL:{c.fillStyle='#6f4526';for(let j=4;j<TS;j+=8)c.fillRect(X,Y+j,TS,3);c.fillStyle='#5cb85c';if(r()<.7)for(let j=2;j<TS;j+=8)for(let i=4;i<TS;i+=10){c.fillRect(X+i,Y+j,3,4);c.fillRect(X+i+3,Y+j+1,2,3)}break}
  case DIRT:{c.fillStyle='#b88e5c';for(let i=0;i<4;i++)c.fillRect(X+r()*30,Y+r()*30,3,2);break}
  case MUD:{c.fillStyle='#62704a';for(let i=0;i<4;i++)c.fillRect(X+r()*28,Y+r()*28,4,2);break}
  case TAR:{if(y===5){c.fillStyle='#f4f4f4';if(x%3===0)c.fillRect(X+2,Y+14,TS-4,4)}if(y===0||y===9){c.fillStyle='#e8c23a';c.fillRect(X,Y+(y?TS-3:0),TS,3)}break}
  case DOCK:case BRG:{c.fillStyle=t===DOCK?'#9a653a':'#8f7a63';for(let j=0;j<TS;j+=8)c.fillRect(X,Y+j,TS,1.5);if(t===BRG){c.fillStyle='#6b5a48';if(!(tget(x,y-1)===BRG||tget(x,y-1)===RD))c.fillRect(X,Y,TS,4);if(!(tget(x,y+1)===BRG||tget(x,y+1)===RD))c.fillRect(X,Y+TS-4,TS,4)}break}
  case RAIL:{c.fillStyle='#6b5a48';for(let i=2;i<TS;i+=8)c.fillRect(X+i,Y+4,4,TS-8);c.fillStyle='#b8bcc4';c.fillRect(X,Y+9,TS,2.5);c.fillRect(X,Y+21,TS,2.5);break}
  }
}

// ---------- object drawing ----------
function drawFlag(c,x,y,w){w=w||26;const h=w*.5,st=h/14;for(let i=0;i<14;i++){c.fillStyle=i%2?'#ffffff':'#cc0001';c.fillRect(x,y+i*st,w,st+.3)}c.fillStyle='#010066';c.fillRect(x,y,w*.5,st*8);c.fillStyle='#ffcc00';c.beginPath();c.arc(x+w*.18,y+st*4,st*2.6,0,TAU);c.fill();c.fillStyle='#010066';c.beginPath();c.arc(x+w*.21,y+st*4,st*2.2,0,TAU);c.fill();c.fillStyle='#ffcc00';c.beginPath();for(let k=0;k<14;k++){const a=k/14*TAU,r=k%2?st*.8:st*2;c.lineTo(x+w*.36+Math.cos(a)*r,y+st*4+Math.sin(a)*r)}c.fill()}
function signPlate(c,cx,y,text,bg,fg,size){c.font=`800 ${size||11}px Nunito,sans-serif`;const w=c.measureText(text).width+12;c.fillStyle=bg;const p=new Path2D();rrp(p,cx-w/2,y,w,(size||11)+8,5);c.fill(p);c.strokeStyle=shade(bg,-.35);c.lineWidth=1;c.stroke(p);c.fillStyle=fg;c.textAlign='center';c.textBaseline='middle';c.fillText(text,cx,y+((size||11)+8)/2+.5)}
function windows(c,X,Y,W,H,cols,rows,col,frame){const gw=W/cols,gh=H/rows,cur=['#ffd1e3','#ffe9a8','#d9ccff','#c8f0e0'];for(let j=0;j<rows;j++)for(let i=0;i<cols;i++){const x=X+i*gw+gw*.18,y=Y+j*gh+gh*.2,w=gw*.64,h=gh*.6;const g=c.createLinearGradient(x,y,x,y+h);g.addColorStop(0,shade(col||'#bfe3ff',.15));g.addColorStop(1,shade(col||'#bfe3ff',-.32));
  c.fillStyle='rgba(30,20,50,.18)';c.fillRect(x-1,y+h+2,w+5,2.5);c.fillStyle=frame||'#ffffff';c.fillRect(x-2,y-2,w+4,h+4);c.fillStyle=g;c.fillRect(x,y,w,h);
  if(w>9&&h>9&&!frame){c.fillStyle=cur[(i+j*3)%4];c.beginPath();c.moveTo(x,y);c.lineTo(x+w*.32,y);c.lineTo(x,y+h*.7);c.fill();c.beginPath();c.moveTo(x+w,y);c.lineTo(x+w*.68,y);c.lineTo(x+w,y+h*.7);c.fill()}
  c.fillStyle='rgba(255,255,255,.55)';c.beginPath();c.moveTo(x+w*.25,y);c.lineTo(x+w*.45,y);c.lineTo(x+w*.15,y+h);c.lineTo(x,y+h);c.lineTo(x,y+h*.6);c.fill();
  if(w>8){c.fillStyle=frame||'#ffffff';c.fillRect(x+w/2-.7,y,1.4,h)}c.fillStyle=shade(frame||'#ffffff',-.12);c.fillRect(x-3,y+h+1.5,w+6,2.4)}}
function drawBuilding(c,b){
  const X=b.x*TS,Y=b.y*TS,W=b.w*TS,H=b.h*TS,tall=b.tall||0;
  const top=Y-tall, roofH=Math.round((H+tall)*.42), wallY=top+roofH, wallH=Y+H-wallY;
  c.save();c.shadowColor='rgba(40,20,70,.38)';c.shadowBlur=16;c.shadowOffsetX=7;c.shadowOffsetY=7;c.fillStyle='rgba(40,20,70,.25)';c.fillRect(X+2,top+8,W-4,Y+H-top-6);c.restore();
  c.fillStyle='rgba(30,20,60,.18)';c.beginPath();c.ellipse(X+W/2+6,Y+H+3,W/2+6,7,0,0,TAU);c.fill();
  const roof=(col,style)=>{const p=new Path2D();
    if(style==='gable'){p.moveTo(X-5,wallY+2);p.lineTo(X+10,top);p.lineTo(X+W-10,top);p.lineTo(X+W+5,wallY+2);p.closePath();const rg=c.createLinearGradient(0,top,0,wallY);rg.addColorStop(0,shade(col,.22));rg.addColorStop(1,shade(col,-.12));c.fillStyle=rg;c.fill(p);
      c.save();c.clip(p);for(let yy=top+5,row=0;yy<wallY+2;yy+=6,row++){c.fillStyle=shade(col,-.2);c.fillRect(X-6,yy+4,W+12,1.2);c.fillStyle='rgba(255,255,255,.12)';for(let xx=X-6+(row%2?5:0);xx<X+W+6;xx+=10){c.beginPath();c.arc(xx+5,yy+4,5,Math.PI,TAU);c.fill()}}c.restore();
      c.strokeStyle=shade(col,-.4);c.lineWidth=1.5;c.stroke(p);c.fillStyle=shade(col,.35);c.fillRect(X+10,top,W-20,3);c.fillStyle='rgba(30,10,40,.25)';c.fillRect(X-5,wallY+1,W+10,2.5)}
    else if(style==='malay'){p.moveTo(X-6,wallY);p.lineTo(X+W*.2,top-8);p.lineTo(X+W*.8,top-8);p.lineTo(X+W+6,wallY);p.closePath();c.fillStyle=col;c.fill(p);c.strokeStyle=shade(col,-.4);c.lineWidth=1.5;c.stroke(p);c.strokeStyle=shade(col,-.2);c.lineWidth=1;for(let xx=X;xx<X+W;xx+=6){c.beginPath();c.moveTo(xx,wallY);c.lineTo(xx+(X+W/2-xx)*.25,top-6);c.stroke()}
      c.strokeStyle='#5a2f18';c.lineWidth=2.5;for(const ex of [X+W*.2,X+W*.8]){c.beginPath();c.moveTo(ex-6,top-14);c.lineTo(ex+6,top-2);c.moveTo(ex+6,top-14);c.lineTo(ex-6,top-2);c.stroke()}}
    else if(style==='thatch'){p.moveTo(X-6,wallY);p.lineTo(X+W/2,top-6);p.lineTo(X+W+6,wallY);p.closePath();c.fillStyle=col;c.fill(p);c.strokeStyle=shade(col,-.3);c.lineWidth=1;for(let xx=X;xx<X+W;xx+=4){c.beginPath();c.moveTo(xx,wallY);c.lineTo(X+W/2,top-4);c.stroke()}}
    else {rrp(p,X,top,W,roofH,6);const rg=c.createLinearGradient(0,top,0,top+roofH);rg.addColorStop(0,shade(col,.18));rg.addColorStop(1,shade(col,-.1));c.fillStyle=rg;c.fill(p);c.strokeStyle=shade(col,-.3);c.lineWidth=1.5;c.stroke(p);c.fillStyle=shade(col,.32);c.fillRect(X+4,top+3,W-8,3);c.fillStyle='rgba(0,0,0,.12)';c.fillRect(X+4,top+roofH-5,W-8,3);
      for(let i=0;i<Math.floor(W/60);i++){const ax=X+14+i*60;c.fillStyle='#e8ecf2';c.fillRect(ax,top+12,18,11);c.fillStyle='#b8c0cc';c.fillRect(ax,top+21,18,2);c.strokeStyle='#9aa4b2';c.lineWidth=.8;c.beginPath();c.arc(ax+9,top+16.5,3.5,0,TAU);c.stroke()}}
  };
  const wall=(col)=>{const wg=c.createLinearGradient(X,0,X+W,0);wg.addColorStop(0,shade(col,.04));wg.addColorStop(.7,col);wg.addColorStop(1,shade(col,-.1));c.fillStyle=wg;c.fillRect(X,wallY,W,wallH);
    const eg=c.createLinearGradient(0,wallY,0,wallY+12);eg.addColorStop(0,'rgba(40,20,60,.28)');eg.addColorStop(1,'rgba(40,20,60,0)');c.fillStyle=eg;c.fillRect(X,wallY,W,12);
    c.fillStyle=shade(col,-.22);c.fillRect(X,Y+H-6,W,6);c.fillStyle=shade(col,-.08);c.fillRect(X,Y+H-7,W,1.2);c.strokeStyle=shade(col,-.3);c.lineWidth=1;c.strokeRect(X+.5,wallY,W-1,wallH-.5)};
  const door=(col,w)=>{w=w||22;col=col||'#8a5a33';const dx=X+W/2-w/2,dh=Math.min(26,wallH*.55);
    c.fillStyle='#f4efe6';c.fillRect(dx-4,Y+H-dh-4,w+8,dh+4);c.fillStyle=shade(col,-.25);c.fillRect(dx-1,Y+H-dh-1,w+2,dh+1);
    const dg=c.createLinearGradient(dx,0,dx+w,0);dg.addColorStop(0,shade(col,.12));dg.addColorStop(1,shade(col,-.12));c.fillStyle=dg;c.fillRect(dx,Y+H-dh,w,dh);
    c.strokeStyle=shade(col,-.3);c.lineWidth=.8;c.strokeRect(dx+3,Y+H-dh+3,w/2-4.5,dh/2-4);c.strokeRect(dx+w/2+1.5,Y+H-dh+3,w/2-4.5,dh/2-4);
    c.fillStyle='rgba(255,255,255,.3)';c.fillRect(dx+3,Y+H-dh+3,w/2-4.5,dh/2-4);c.fillStyle='#f2c230';c.beginPath();c.arc(dx+w-5,Y+H-dh/2,1.8,0,TAU);c.fill();
    c.fillStyle='#cfc8bc';c.fillRect(dx-6,Y+H-1,w+12,4);c.fillStyle='#e8e2d8';c.fillRect(dx-6,Y+H-1,w+12,1.2);
    c.fillStyle='#fff6c0';c.shadowColor='#ffe680';c.shadowBlur=8;c.beginPath();c.arc(dx-7,Y+H-dh+4,2.4,0,TAU);c.fill();c.shadowBlur=0;c.fillStyle='#3a3a4a';c.fillRect(dx-8.2,Y+H-dh+.5,2.4,1.4);
    if(W>=TS*2){for(const px of [dx-14,dx+w+6]){c.fillStyle='#c8643a';c.beginPath();c.moveTo(px,Y+H-7);c.lineTo(px+8,Y+H-7);c.lineTo(px+7,Y+H);c.lineTo(px+1,Y+H);c.fill();c.fillStyle='#3f9a3f';c.beginPath();c.arc(px+4,Y+H-10,5,0,TAU);c.fill();c.fillStyle='#5ab84a';c.beginPath();c.arc(px+2.6,Y+H-11.5,2.6,0,TAU);c.fill();c.fillStyle='#ff7ab8';c.beginPath();c.arc(px+6,Y+H-12,1.4,0,TAU);c.fill()}}};
  const k=b.kind;
  switch(k){
  case 'mall':{roof('#e2d4ff');const dg=c.createRadialGradient(X+W/2,top+roofH*.5,4,X+W/2,top+roofH*.5,W*.25);dg.addColorStop(0,'#e8f6ff');dg.addColorStop(1,'#7a9ae8');c.fillStyle=dg;c.beginPath();c.ellipse(X+W/2,top+roofH*.62,W*.24,roofH*.5,0,Math.PI,TAU);c.fill();c.strokeStyle='#5a6ac8';c.lineWidth=1;for(let i=-3;i<=3;i++){c.beginPath();c.moveTo(X+W/2,top+roofH*.12);c.lineTo(X+W/2+i*W*.07,top+roofH*.62);c.stroke()}
    wall('#f6efff');windows(c,X+8,wallY+30,W-16,wallH-62,10,2,'#a8c8ff','#d8c8f8');c.fillStyle='#8c5cf2';c.fillRect(X,wallY+6,W,22);signPlate(c,X+W/2,wallY+4,'ASIA MALL','#6a3fd0','#ffffff',18);
    const gl=c.createLinearGradient(0,Y+H-34,0,Y+H);gl.addColorStop(0,'#d0e8ff');gl.addColorStop(1,'#7aa8e8');c.fillStyle=gl;c.fillRect(X+W/2-60,Y+H-34,120,34);c.strokeStyle='#fff';c.lineWidth=2;c.strokeRect(X+W/2-60,Y+H-34,120,34);c.beginPath();c.moveTo(X+W/2,Y+H-34);c.lineTo(X+W/2,Y+H);c.stroke();
    for(const fx of [X+20,X+W-30]){c.fillStyle='#888';c.fillRect(fx,top-30,2,40);c.fillStyle=fx<X+50?'#ff5ea8':'#ffd23f';c.beginPath();c.moveTo(fx+2,top-30);c.lineTo(fx+22,top-24);c.lineTo(fx+2,top-18);c.fill()}break}
  case 'hospital':roof('#dfe8f0');c.fillStyle='#c8d4e0';c.beginPath();c.arc(X+W*.75,top+roofH*.5,22,0,TAU);c.fill();c.fillStyle='#fff';c.font='900 20px Nunito';c.textAlign='center';c.textBaseline='middle';c.fillText('H',X+W*.75,top+roofH*.5+1);
    wall('#f7fbff');windows(c,X+8,wallY+30,W-16,wallH-60,12,2,'#9fd0ff');signPlate(c,X+W/2,wallY+6,'HOSPITAL KOTA KITA','#ffffff','#c8102e',13);c.fillStyle='#e5484d';c.fillRect(X+22,wallY+6,8,22);c.fillRect(X+15,wallY+13,22,8);door('#9fd0ff',40);break;
  case 'klinik':roof('#4aa3d8','gable');wall('#ffffff');windows(c,X+6,wallY+26,W-12,wallH-50,4,1);signPlate(c,X+W/2,wallY+4,'KLINIK','#ffffff','#c8102e',11);c.fillStyle='#e5484d';c.fillRect(X+10,wallY+6,5,15);c.fillRect(X+5,wallY+11,15,5);door('#9fd0ff');break;
  case 'uni':roof('#d8c8a0');c.fillStyle=b.c||'#3a6ab0';c.beginPath();c.ellipse(X+W/2,top+roofH*.75,W*.16,roofH*.65,0,Math.PI,TAU);c.fill();c.fillStyle='#f2c230';c.fillRect(X+W/2-2,top-10,4,14);
    wall('#f4ead6');for(let i=0;i<8;i++){c.fillStyle='#fffaf0';c.fillRect(X+20+i*(W-40)/7-5,wallY+28,10,wallH-34);c.fillStyle='#d8c8a0';c.fillRect(X+20+i*(W-40)/7-7,wallY+26,14,4)}
    signPlate(c,X+W/2,wallY+4,b.label||'UNIVERSITI KOTA KITA',b.c||'#1f3a6b','#ffffff',13);door('#6b4a2b',30);break;
  case 'faculty':roof('#d06a4a','gable');wall('#e8eef8');windows(c,X+6,wallY+10,W-12,wallH-20,Math.max(2,b.w),2);if(b.label)signPlate(c,X+W/2,Y+H-22,b.label,'#fff','#1f3a6b',9);break;
  case 'school':roof(b.c||'#3a6ab0','gable');wall('#fdf3d8');windows(c,X+6,wallY+24,W-12,wallH-30,10,2,'#bfe3ff',b.c||'#3a6ab0');signPlate(c,X+W/2,wallY+3,b.label||'SMK KOTA KITA',b.c||'#3a6ab0','#ffffff',12);door('#3a6ab0',26);
    c.fillStyle='#888';c.fillRect(X-12,top-20,2,60);drawFlag(c,X-10,top-20);break;
  case 'gov':roof('#f0f4ff');c.fillStyle=b.c||'#3a86ff';c.beginPath();c.ellipse(X+W/2,top+roofH*.8,W*.22,roofH*.75,0,Math.PI,TAU);c.fill();c.fillStyle='#f2c230';c.fillRect(X+W/2-1.5,top-14,3,12);
    wall('#ffffff');for(let i=0;i<5;i++){c.fillStyle='#e8eef8';c.fillRect(X+16+i*(W-32)/4-5,wallY+24,10,wallH-28)}signPlate(c,X+W/2,wallY+3,b.label||'PEJABAT KERAJAAN',b.c||'#1f6f8b','#fff',11);door('#6b4a2b',26);if(b.loc){c.fillStyle='#888';c.fillRect(X+W-14,top-34,2,50);drawFlag(c,X+W-12,top-34,30)}break;
  case 'kerjaya':roof('#f2a20c');wall('#fff4e0');windows(c,X+6,wallY+26,W-12,wallH-50,5,1,'#ffe3a0');signPlate(c,X+W/2,wallY+4,'PUSAT KERJAYA','#f29b0c','#fff',11);door('#9fd0ff',28);break;
  case 'polis':roof('#1d2d55');c.fillStyle='#3a86ff';c.fillRect(X+W/2-6,top+6,12,6);c.fillStyle='#e5484d';c.fillRect(X+W/2-6,top+12,12,4);wall('#eef3ff');windows(c,X+6,wallY+24,W-12,wallH-46,4,1);signPlate(c,X+W/2,wallY+3,'POLIS','#1d2d55','#fff',12);door('#1d2d55');c.fillStyle='#888';c.fillRect(X+6,top-30,2,40);drawFlag(c,X+8,top-30);break;
  case 'bomba':roof('#c8102e');wall('#fff0f0');for(let i=0;i<2;i++){c.fillStyle='#e5484d';c.fillRect(X+12+i*(W/2-6),Y+H-40,W/2-24,40);c.fillStyle='rgba(255,255,255,.3)';for(let j=0;j<5;j++)c.fillRect(X+12+i*(W/2-6),Y+H-38+j*8,W/2-24,2)}signPlate(c,X+W/2,wallY+3,'BOMBA','#c8102e','#fff',12);break;
  case 'airport':roof('#d8e4f0');wall('#eaf4ff');windows(c,X+6,wallY+24,W-12,wallH-30,10,2,'#8fc0f0');signPlate(c,X+W/2,wallY+3,'LAPANGAN TERBANG','#3a86ff','#fff',11);
    c.fillStyle='#d8e4f0';c.fillRect(X+W-30,top-50,18,60);c.fillStyle='#8fc0f0';c.fillRect(X+W-36,top-60,30,14);c.strokeStyle='#7a8a9a';c.strokeRect(X+W-36,top-60,30,14);break;
  case 'shop':{const cc=b.c||'#e85d75';roof(shade(cc,.3),'gable');wall('#fff8ee');c.fillStyle=cc;c.fillRect(X,wallY+4,W,16);for(let i=0;i<b.w;i++){c.fillStyle=i%2?cc:'#fff';c.beginPath();c.moveTo(X+i*TS,wallY+20);c.lineTo(X+i*TS+TS,wallY+20);c.lineTo(X+i*TS+TS-4,wallY+30);c.lineTo(X+i*TS+4,wallY+30);c.fill()}
    signPlate(c,X+W/2,wallY+3,b.label,'#fff',cc,10);windows(c,X+6,wallY+34,W-12,wallH-40,3,1,'#ffe8c0');break}
  case 'house':case 'myhome':roof(b.c,'gable');wall(b.wall||'#fff8ee');windows(c,X+6,wallY+8,W-12,wallH-14,2,1,'#bfe3ff');door(k==='myhome'?'#6a3fd0':'#8a5a33',18);if(k==='myhome'){signPlate(c,X+W/2,top-6,'RUMAH ANDA','#6a3fd0','#fff',10);c.fillStyle='#ff5ea8';for(let i=0;i<5;i++){c.beginPath();c.arc(X+8+i*8,Y+H+4,3,0,TAU);c.fill()}}break;
  case 'apartment':roof('#c8b8a8');wall('#f4ece0');windows(c,X+6,wallY+6,W-12,wallH-30,8,3,'#bfe3ff');for(let j=0;j<3;j++){c.fillStyle='#d8c8b8';c.fillRect(X+4,wallY+6+j*((wallH-30)/3)+((wallH-30)/3)*.82,W-8,3)}signPlate(c,X+W/2,Y+H-22,b.label,'#fff','#6a3fd0',9);break;
  case 'pasar':{const cols=['#e5484d','#f29b0c','#38b84a','#3a86ff'];for(let i=0;i<4;i++){const x=X+i*W/4;c.fillStyle='#8a5a33';c.fillRect(x+4,Y+H*.4,3,H*.6);c.fillRect(x+W/4-7,Y+H*.4,3,H*.6);c.fillStyle='#c8925a';c.fillRect(x+6,Y+H-24,W/4-12,14);
    for(let s=0;s<4;s++){c.fillStyle=s%2?'#fff':cols[i];c.fillRect(x+2+s*(W/4-4)/4,Y+6,(W/4-4)/4,H*.42)}c.fillStyle=['#e5484d','#f2c230','#38b84a','#ff8c42'][i];for(let k2=0;k2<5;k2++){c.beginPath();c.arc(x+10+k2*9,Y+H-24,4,0,TAU);c.fill()}}
    signPlate(c,X+W/2,Y-6,'PASAR TANI','#f29b0c','#fff',12);break}
  case 'lrt':roof('#6a3fd0');c.fillStyle='rgba(255,255,255,.35)';c.fillRect(X+8,top+8,W-16,8);wall('#ece6fb');windows(c,X+6,wallY+24,W-12,wallH-34,6,1,'#b8a8ff');signPlate(c,X+W/2,wallY+3,'LRT / MRT','#6a3fd0','#fff',11);door('#b8a8ff',26);break;
  case 'bas':roof('#f29b0c');wall('#fff6e6');signPlate(c,X+W/2,wallY+3,'TERMINAL BAS','#f29b0c','#fff',11);for(let i=0;i<2;i++){const bx=X+12+i*(W/2-6);c.fillStyle=i?'#3a86ff':'#38b84a';const p=new Path2D();rrp(p,bx,Y+H-34,W/2-24,28,5);c.fill(p);c.fillStyle='#bfe3ff';c.fillRect(bx+4,Y+H-30,W/2-32,10)}break;
  case 'keretapi':roof('#f4ece0');for(const dx of [.2,.5,.8]){c.fillStyle='#f4ece0';c.beginPath();c.arc(X+W*dx,top+4,10,Math.PI,TAU);c.fill();c.fillStyle='#e2b44a';c.fillRect(X+W*dx-1,top-12,2,8)}wall('#fffaf0');for(let i=0;i<6;i++){c.fillStyle='#bfe3ff';c.beginPath();const ax=X+12+i*(W-24)/6;c.moveTo(ax,Y+H-6);c.lineTo(ax,wallY+34);c.arc(ax+(W-24)/12-2,wallY+34,(W-24)/12-2,Math.PI,TAU);c.lineTo(ax+(W-24)/6-4,Y+H-6);c.fill()}signPlate(c,X+W/2,wallY+3,'STESEN KERETA API','#1f3a6b','#fff',10);break;
  case 'jetihut':roof('#3a86ff','gable');wall('#d8a878');c.strokeStyle='#a87848';for(let yy=wallY+6;yy<Y+H;yy+=6){c.beginPath();c.moveTo(X,yy);c.lineTo(X+W,yy);c.stroke()}signPlate(c,X+W/2,wallY+3,'JETI MEMANCING','#3a86ff','#fff',10);door('#6b4a2b');c.fillStyle='#888';c.fillRect(X+W-6,top-30,2,40);drawFlag(c,X+W-4,top-30);break;
  case 'port':roof('#4a7ab0');c.fillStyle='#5a8ac0';for(let xx=X+6;xx<X+W-6;xx+=10)c.fillRect(xx,top+4,5,roofH-8);wall('#e0e8f0');c.fillStyle='#7a8a9a';c.fillRect(X+20,Y+H-40,W-40,40);signPlate(c,X+W/2,wallY+3,'PELABUHAN','#1f6f8b','#fff',11);break;
  case 'pavilion':roof('#c8503a','gable');c.fillStyle='#8a5a33';for(const px of [X+6,X+W-10])c.fillRect(px,wallY,4,wallH);c.fillStyle='#c8925a';c.fillRect(X+4,Y+H-8,W-8,6);signPlate(c,X+W/2,top-12,'TAMAN','#38b84a','#fff',10);break;
  case 'kampung':case 'balai':case 'ranger':{const rc=k==='ranger'?'#3a7a3a':'#8b4a2b';roof(rc,'malay');c.fillStyle='#c8925a';c.fillRect(X+4,wallY,W-8,wallH-12);c.strokeStyle='#a8723a';c.lineWidth=1;for(let xx=X+8;xx<X+W-6;xx+=5){c.beginPath();c.moveTo(xx,wallY);c.lineTo(xx,Y+H-12);c.stroke()}
    c.fillStyle='#5a3a20';for(let i=0;i<5;i++)c.fillRect(X+6+i*(W-16)/4,Y+H-12,4,12);c.fillStyle='rgba(30,20,10,.3)';c.fillRect(X+4,Y+H-12,W-8,12);
    windows(c,X+10,wallY+6,W-20,wallH-24,k==='balai'?4:2,1,'#4a3020','#e8c890');
    c.fillStyle='#8a5a33';for(let s=0;s<3;s++)c.fillRect(X+W/2-8,Y+H-10+s*3,16,2);
    if(b.label)signPlate(c,X+W/2,top-20,b.label,k==='ranger'?'#2a6a3a':'#8b4a2b','#fff',10);break}
  case 'barn':roof('#8a2a2a','gable');wall('#b8323a');c.strokeStyle='#fff';c.lineWidth=3;const dx=X+W/2-18,dy=Y+H-34;c.strokeRect(dx,dy,36,34);c.beginPath();c.moveTo(dx,dy);c.lineTo(dx+36,dy+34);c.moveTo(dx+36,dy);c.lineTo(dx,dy+34);c.stroke();signPlate(c,X+W/2,top-14,'LADANG','#2a9a3a','#fff',10);break;
  case 'beachhut':roof('#d8b070','thatch');wall('#e8c890');signPlate(c,X+W/2,wallY+2,'PANTAI','#2ec4b6','#fff',9);door('#8a5a33',16);break;
  case 'resort':roof('#c8a060','thatch');wall('#e8d0a0');windows(c,X+6,wallY+8,W-12,wallH-20,3,1,'#bfe3ff');signPlate(c,X+W/2,top-14,'RESORT PULAU','#2ec4b6','#fff',10);door('#8a5a33');break;
  case 'library':roof('#7a5ac8','gable');wall('#f6efe2');for(let i=0;i<5;i++){c.fillStyle='#fffaf0';c.fillRect(X+14+i*(W-28)/4-4,wallY+26,8,wallH-30)}signPlate(c,X+W/2,wallY+3,'PERPUSTAKAAN','#7a5ac8','#fff',11);door('#6b4a2b',22);break;
  case 'cinema':roof('#3a1f2b');wall('#2b1d24');c.fillStyle='#c8102e';c.fillRect(X,wallY+4,W,20);for(let i=0;i<14;i++){c.fillStyle=i%2?'#ffd23f':'#fff6c0';c.beginPath();c.arc(X+6+i*(W-12)/13,wallY+6,2.2,0,TAU);c.fill();c.beginPath();c.arc(X+6+i*(W-12)/13,wallY+22,2.2,0,TAU);c.fill()}
    signPlate(c,X+W/2,wallY+6,'PAWAGAM','#c8102e','#ffd23f',11);for(let i=0;i<2;i++){c.fillStyle=['#3a86ff','#ff5ea8'][i];c.fillRect(X+10+i*(W/2),wallY+32,W/2-20,wallH-46);c.fillStyle='rgba(255,255,255,.6)';c.fillRect(X+14+i*(W/2),wallY+36,W/2-28,6)}door('#5a1a24',26);break;
  case 'medan':{c.fillStyle='#8a5a33';for(const px of [X+4,X+W-8])c.fillRect(px,Y+10,4,H-12);for(let i=0;i<8;i++){c.fillStyle=i%2?'#fff':'#f29b0c';c.fillRect(X+i*W/8,Y,W/8,H*.32)}
    for(let i=0;i<3;i++){const tx=X+18+i*(W-36)/2,ty=Y+H*.62;c.fillStyle='#c8925a';c.beginPath();c.ellipse(tx,ty,12,6,0,0,TAU);c.fill();c.fillStyle='#e5484d';c.fillRect(tx-14,ty+6,6,6);c.fillRect(tx+8,ty+6,6,6)}signPlate(c,X+W/2,Y-8,'MEDAN SELERA','#f29b0c','#fff',10);break}
  case 'nightmarket':{const cl=['#e5484d','#3a86ff','#38b84a','#ff8c42'];for(let i=0;i<2;i++){const sx=X+i*W/2;c.fillStyle='#6b4426';c.fillRect(sx+4,Y+12,3,H-14);c.fillRect(sx+W/2-7,Y+12,3,H-14);for(let k=0;k<4;k++){c.fillStyle=k%2?'#fff':cl[i*2];c.fillRect(sx+2+k*(W/2-4)/4,Y+4,(W/2-4)/4,H*.3)}
    c.fillStyle='#c8925a';c.fillRect(sx+6,Y+H-26,W/2-12,12);for(let k=0;k<4;k++){c.fillStyle=cl[(k+i)%4];c.beginPath();c.arc(sx+12+k*12,Y+H-27,4,0,TAU);c.fill()}}
    c.strokeStyle='#444';c.lineWidth=1;c.beginPath();c.moveTo(X,Y+2);c.quadraticCurveTo(X+W/2,Y+12,X+W,Y+2);c.stroke();for(let i=0;i<6;i++){const lx=X+8+i*(W-16)/5;c.fillStyle='#ffd23f';c.beginPath();c.arc(lx,Y+4+Math.sin(i/5*Math.PI)*9,3.4,0,TAU);c.fill()}
    signPlate(c,X+W/2,Y-14,'PASAR MALAM','#ff8c42','#fff',10);break}
  case 'stadium':{c.fillStyle='rgba(30,20,60,.2)';c.beginPath();c.ellipse(X+W/2+6,Y+H/2+8,W/2,H/2,0,0,TAU);c.fill();c.fillStyle='#d8d4e8';c.beginPath();c.ellipse(X+W/2,Y+H/2,W/2,H/2,0,0,TAU);c.fill();
    for(let r=0;r<4;r++){c.fillStyle=['#e5484d','#3a86ff','#f2c230','#38b84a'][r];c.beginPath();c.ellipse(X+W/2,Y+H/2,W/2-6-r*7,H/2-5-r*6,0,0,TAU);c.fill()}
    c.fillStyle='#c8643a';c.beginPath();c.ellipse(X+W/2,Y+H/2,W/2-36,H/2-30,0,0,TAU);c.fill();c.fillStyle='#4fb84a';c.fillRect(X+W/2-W*.26,Y+H/2-H*.17,W*.52,H*.34);c.strokeStyle='#fff';c.lineWidth=1.5;c.strokeRect(X+W/2-W*.26,Y+H/2-H*.17,W*.52,H*.34);c.beginPath();c.moveTo(X+W/2,Y+H/2-H*.17);c.lineTo(X+W/2,Y+H/2+H*.17);c.stroke();c.beginPath();c.arc(X+W/2,Y+H/2,8,0,TAU);c.stroke();
    signPlate(c,X+W/2,Y+H-18,'STADIUM KOTA KITA','#e5484d','#fff',10);for(const fx of [X+20,X+W-24]){c.fillStyle='#888';c.fillRect(fx,Y-24,2,30);drawFlag(c,fx+2,Y-24)}break}
  default:roof('#ccc');wall('#eee');
  }
}
function drawTree(c,o){
  const X=o.tx*TS+TS/2,Y=(o.ty+1)*TS-4,s=.85+o.s*.35;
  c.fillStyle='rgba(30,40,20,.28)';c.beginPath();c.ellipse(X+6,Y+1,18*s,6.5*s,0,0,TAU);c.fill();
  if(o.kind==='palm'){c.strokeStyle='#8a6a42';c.lineWidth=6;c.lineCap='round';c.beginPath();c.moveTo(X,Y);c.quadraticCurveTo(X+10*s,Y-26*s,X+4*s,Y-50*s);c.stroke();
    const tx=X+4*s,ty=Y-50*s;for(let i=0;i<7;i++){const a=i/7*TAU+o.s;c.fillStyle=i%2?'#3a9a3a':'#4fb84a';c.beginPath();c.moveTo(tx,ty);c.quadraticCurveTo(tx+Math.cos(a)*22*s,ty+Math.sin(a)*12*s-10,tx+Math.cos(a)*32*s,ty+Math.sin(a)*16*s+6);c.quadraticCurveTo(tx+Math.cos(a)*18*s,ty+Math.sin(a)*10*s,tx,ty);c.fill()}
    c.fillStyle='#7a5a2a';for(const [dx,dy] of [[-3,3],[3,3],[0,6]]){c.beginPath();c.arc(tx+dx,ty+dy,3,0,TAU);c.fill()}return}
  if(o.kind==='mangrove'){c.strokeStyle='#5a4a2a';c.lineWidth=2;for(let i=-2;i<=2;i++){c.beginPath();c.moveTo(X,Y-10);c.quadraticCurveTo(X+i*6,Y-6,X+i*8,Y);c.stroke()}c.fillStyle='#3f7a3a';c.beginPath();c.arc(X,Y-20*s,13*s,0,TAU);c.fill();c.fillStyle='#4f8f45';c.beginPath();c.arc(X-4,Y-24*s,8*s,0,TAU);c.fill();return}
  if(o.kind==='flower'){c.fillStyle='#3a8a3a';c.beginPath();c.arc(X,Y-10,13,0,TAU);c.fill();for(let i=0;i<6;i++){c.fillStyle=i%2?'#e5484d':'#ff5ea8';c.beginPath();c.arc(X+Math.cos(i)*8,Y-12+Math.sin(i)*6,3.4,0,TAU);c.fill()}return}
  {const tg=c.createLinearGradient(X-3,0,X+3,0);tg.addColorStop(0,'#9a6a40');tg.addColorStop(1,'#5e3e22');c.fillStyle=tg;c.beginPath();c.moveTo(X-4,Y);c.lineTo(X-2.6,Y-22*s);c.lineTo(X+2.6,Y-22*s);c.lineTo(X+4,Y);c.fill()}
  const dark=o.kind==='forest';const c1=dark?'#2a6e30':'#348a38',c2=dark?'#3f8f3a':'#4fae46',c3=dark?'#6cbc58':'#86d86a';
  const blobs=[[-11,-25,13],[11,-25,13],[0,-38,15],[-7,-33,11],[8,-35,11]];
  c.fillStyle='rgba(20,50,20,.35)';c.beginPath();for(const [bx,by,br] of blobs){c.moveTo(X+bx*s+br*s+1.5,Y+by*s);c.arc(X+bx*s,Y+by*s,br*s+1.5,0,TAU)}c.fill();
  for(const [bx,by,br] of blobs){const cg=c.createRadialGradient(X+(bx-br*.4)*s,Y+(by-br*.45)*s,1,X+bx*s,Y+by*s,br*s);cg.addColorStop(0,c3);cg.addColorStop(.45,c2);cg.addColorStop(1,c1);c.fillStyle=cg;c.beginPath();c.arc(X+bx*s,Y+by*s,br*s,0,TAU);c.fill()}
  c.fillStyle='rgba(255,255,220,.35)';for(const [bx,by] of [[-12,-30],[-3,-44],[6,-40]]){c.beginPath();c.arc(X+bx*s,Y+by*s,2.2*s,0,TAU);c.fill()}
  if(!dark&&o.s>.55){c.fillStyle='#ff8ab8';for(const [bx,by] of [[-8,-24],[9,-30],[2,-36],[-2,-28]]){c.beginPath();c.arc(X+bx*s,Y+by*s,1.6,0,TAU);c.fill()}}
}
function drawObj(c,o){
  switch(o.type){
  case 'bld':drawBuilding(c,o.b);break;
  case 'tree':drawTree(c,o);break;
  case 'lamp':{const X=o.x+16,Y=o.base;c.fillStyle='rgba(30,20,60,.2)';c.beginPath();c.ellipse(X+3,Y,7,2.4,0,0,TAU);c.fill();const lg=c.createLinearGradient(X-2,0,X+2,0);lg.addColorStop(0,'#5a5a72');lg.addColorStop(1,'#2a2a3a');c.fillStyle=lg;c.fillRect(X-1.6,Y-38,3.2,38);c.fillStyle='#3a3a4a';c.beginPath();c.moveTo(X-6,Y);c.lineTo(X+6,Y);c.lineTo(X+3,Y-5);c.lineTo(X-3,Y-5);c.fill();
    c.strokeStyle='#3a3a4a';c.lineWidth=1.4;c.beginPath();c.moveTo(X,Y-38);c.quadraticCurveTo(X,Y-44,X+5,Y-44);c.stroke();c.fillStyle='#2a2a3a';c.beginPath();c.moveTo(X+1,Y-44);c.lineTo(X+9,Y-44);c.lineTo(X+7.5,Y-40.5);c.lineTo(X+2.5,Y-40.5);c.fill();c.fillStyle='#fff3b0';c.shadowColor='#ffe680';c.shadowBlur=10;c.fillRect(X+3,Y-41,4,1.8);c.shadowBlur=0;break}
  case 'bench':{c.fillStyle='rgba(30,20,60,.2)';c.fillRect(o.x+9,o.y+24,52,4);c.fillStyle='#3a3a4a';c.fillRect(o.x+8,o.y+16,3,10);c.fillRect(o.x+53,o.y+16,3,10);c.fillRect(o.x+8,o.y+2,3,12);c.fillRect(o.x+53,o.y+2,3,12);
    for(const [yy,hh] of [[3,3.4],[8,3.4],[13,3.4],[17,3.4]]){const bg2=c.createLinearGradient(0,o.y+yy,0,o.y+yy+hh);bg2.addColorStop(0,'#c8925a');bg2.addColorStop(1,'#8a5a33');c.fillStyle=bg2;c.fillRect(o.x+5,o.y+yy,54,hh)}break}
  case 'umbrella':{const X=o.x+26,Y=o.base-4;c.fillStyle='rgba(0,0,0,.15)';c.beginPath();c.ellipse(X+6,Y,20,6,0,0,TAU);c.fill();c.fillStyle='#ddd';c.fillRect(X-1,Y-30,2,30);for(let i=0;i<6;i++){c.fillStyle=i%2?'#fff':o.c;c.beginPath();c.moveTo(X,Y-36);c.arc(X,Y-30,22,Math.PI+i/6*Math.PI,Math.PI+(i+1)/6*Math.PI);c.fill()}c.fillStyle='#f4f4f4';c.fillRect(X+10,Y-6,18,6);break}
  case 'container':{const p=new Path2D();rrp(p,o.x+2,o.y+4,60,o.h-6,3);c.fillStyle=o.c;c.fill(p);c.strokeStyle=shade(o.c,-.3);c.stroke(p);c.fillStyle=shade(o.c,-.15);for(let i=0;i<8;i++)c.fillRect(o.x+6+i*7,o.y+8,2,o.h-14);break}
  case 'crane':c.strokeStyle='#f2a20c';c.lineWidth=4;c.beginPath();c.moveTo(o.x+20,o.y+o.h);c.lineTo(o.x+20,o.y);c.lineTo(o.x+o.w,o.y);c.moveTo(o.x+20,o.y+20);c.lineTo(o.x+50,o.y);c.stroke();c.lineWidth=1.5;c.strokeStyle='#555';c.beginPath();c.moveTo(o.x+o.w-10,o.y);c.lineTo(o.x+o.w-10,o.y+60);c.stroke();break;
  case 'boat':{c.fillStyle='#fff';c.beginPath();c.moveTo(o.x,o.y+20);c.lineTo(o.x+80,o.y+20);c.lineTo(o.x+70,o.y+40);c.lineTo(o.x+10,o.y+40);c.fill();c.fillStyle='#e5484d';c.fillRect(o.x+8,o.y+30,66,4);c.fillStyle='#3a86ff';c.fillRect(o.x+30,o.y+4,24,16);break}
  case 'ferry':{c.fillStyle='#fff';c.beginPath();c.moveTo(o.x,o.y+30);c.lineTo(o.x+120,o.y+30);c.lineTo(o.x+108,o.y+70);c.lineTo(o.x+12,o.y+70);c.fill();c.fillStyle='#2ec4b6';c.fillRect(o.x+10,o.y+52,100,6);c.fillStyle='#f4f8ff';c.fillRect(o.x+24,o.y+8,72,24);c.fillStyle='#8fc0f0';for(let i=0;i<5;i++)c.fillRect(o.x+28+i*14,o.y+14,10,8);signPlate(c,o.x+60,o.y-12,'FERI','#2ec4b6','#fff',9);break}
  case 'plane':{c.save();c.translate(o.x+90,o.y+60);c.fillStyle='#f4f8ff';c.strokeStyle='#8a9ab0';c.lineWidth=1.5;const p=new Path2D();p.ellipse(0,0,80,12,0,0,TAU);c.fill(p);c.stroke(p);c.beginPath();c.moveTo(-10,0);c.lineTo(-30,-50);c.lineTo(-14,-50);c.lineTo(20,0);c.lineTo(-14,50);c.lineTo(-30,50);c.closePath();c.fill();c.stroke();c.fillStyle='#6a3fd0';c.beginPath();c.moveTo(-70,0);c.lineTo(-84,-24);c.lineTo(-72,-24);c.lineTo(-56,0);c.fill();c.fillStyle='#8fc0f0';for(let i=0;i<8;i++)c.fillRect(-40+i*12,-4,6,4);c.restore();break}
  case 'fountain':{const X=o.x+o.w/2,Y=o.y+o.h/2+6;c.fillStyle='#c9b89c';c.beginPath();c.ellipse(X,Y,62,40,0,0,TAU);c.fill();c.fillStyle='#5cc8e8';c.beginPath();c.ellipse(X,Y,54,34,0,0,TAU);c.fill();c.fillStyle='#e8dcc8';c.beginPath();c.ellipse(X,Y-6,16,10,0,0,TAU);c.fill();c.fillStyle='#bfefff';c.beginPath();c.moveTo(X-4,Y-8);c.quadraticCurveTo(X-20,Y-40,X,Y-46);c.quadraticCurveTo(X+20,Y-40,X+4,Y-8);c.fill();c.fillStyle='rgba(255,255,255,.7)';for(let i=0;i<8;i++){c.beginPath();c.arc(X+Math.cos(i)*30,Y+Math.sin(i)*18,2,0,TAU);c.fill()}
    for(let i=0;i<10;i++){const a=i/10*TAU;c.fillStyle=i%2?'#e5484d':'#ff5ea8';c.beginPath();c.arc(X+Math.cos(a)*70,Y+Math.sin(a)*46,4,0,TAU);c.fill()}break}
  case 'animal':{const X=o.x+16,Y=o.y+22;if(o.k==='cow'){c.fillStyle='#fff';c.beginPath();c.ellipse(X,Y,14,8,0,0,TAU);c.fill();c.fillStyle='#333';c.beginPath();c.arc(X-4,Y-2,3,0,TAU);c.arc(X+5,Y+2,2.5,0,TAU);c.fill();c.fillStyle='#f4c8b0';c.beginPath();c.ellipse(X+14,Y-3,5,4,0,0,TAU);c.fill()}
    else if(o.k==='goat'){c.fillStyle='#e8e0d0';c.beginPath();c.ellipse(X,Y,11,6,0,0,TAU);c.fill();c.beginPath();c.arc(X+11,Y-5,4,0,TAU);c.fill()}
    else{c.fillStyle='#fff';c.beginPath();c.arc(X,Y,6,0,TAU);c.fill();c.fillStyle='#e5484d';c.fillRect(X+3,Y-8,3,3);c.fillStyle='#f2a20c';c.fillRect(X+6,Y-3,3,2)}break}
  case 'field':{c.strokeStyle='rgba(255,255,255,.7)';c.lineWidth=2;c.strokeRect(o.x+8,o.y+8,o.w-16,o.h-16);c.beginPath();c.moveTo(o.x+8,o.y+o.h/2);c.lineTo(o.x+o.w-8,o.y+o.h/2);c.stroke();c.beginPath();c.arc(o.x+o.w/2,o.y+o.h/2,18,0,TAU);c.stroke();break}
  case 'waterfall':{c.fillStyle='#8a8478';for(const [dx,dy,r] of [[10,40,14],[130,44,16],[30,70,10],[120,76,9]]){c.beginPath();c.arc(o.x+dx,o.y+dy,r,0,TAU);c.fill()}const g=c.createLinearGradient(0,o.y,0,o.y+80);g.addColorStop(0,'#e8fbff');g.addColorStop(1,'rgba(160,220,240,.3)');c.fillStyle=g;c.fillRect(o.x+40,o.y,64,80);break}
  }
}

// ---------- chunk cache ----------
const chunks=new Map();let chunkK=1;
function chunkCanvas(cx,cy,k){
  const key=cx+','+cy;let ch=chunks.get(key);if(ch)return ch;
  const size=Math.ceil(CH*k)+1;const cv=document.createElement('canvas');cv.width=size;cv.height=size;const c=cv.getContext('2d');
  c.setTransform(k,0,0,k,-cx*CH*k,-cy*CH*k);
  const x0=Math.floor(cx*CH/TS),y0=Math.floor(cy*CH/TS),n=CH/TS;
  for(let y=y0;y<y0+n&&y<MH;y++)for(let x=x0;x<x0+n&&x<MW;x++)drawTile(c,x,y);
  const X0=cx*CH,Y0=cy*CH;
  for(const o of OBJS){if(o.x<X0+CH&&o.x+o.w>X0&&o.y<Y0+CH&&o.y+o.h+20>Y0)drawObj(c,o)}
  chunks.set(key,cv);
  if(chunks.size>(RT.chunkLimit||32)){const it=chunks.keys().next().value;chunks.delete(it)}
  return cv;
}
function clearChunks(){chunks.clear()}
