// ===================== LIFE EXPANSION: BASE HOOKS + SURAU =====================
const XDEF={},XMIG=[],XHOUR=[],XDAY=[],XMIN=[],XLOC=[];
function xDefaults(){if(!S)return;for(const k in XDEF){if(S[k]==null)S[k]=XDEF[k]()}}
{const ns=newSave;newSave=function(){const r=ns.apply(this,arguments);xDefaults();for(const f of XMIG)try{f(true)}catch(e){console.warn(e)}return r}}
{const mg=migrate;migrate=function(){mg();xDefaults();for(const f of XMIG)try{f(false)}catch(e){console.warn(e)}}}
{const nd=newDay;newDay=function(){nd();for(const f of XDAY)try{f()}catch(e){console.warn(e)}}}
{const ad=advance;advance=function(min){const t0=S.time;ad(min);const h0=Math.floor(t0/60),h1=Math.floor(S.time/60);if(h1>h0)for(let h=Math.max(h0+1,h1-72);h<=h1;h++)for(const f of XHOUR)try{f(h*60)}catch(e){console.warn(e)}for(const f of XMIN)try{f(t0,S.time)}catch(e){console.warn(e)}}}
{const ia=interactables;interactables=function(){const l=ia();for(const x of XENTS)if(x.ia&&!x.hide)l.push({kind:'x',id:x.id,x:x.x,y:x.y-4,label:x.ia,fn:x.fn,xe:x});return l}}
{const di=doInteract;doInteract=function(){const n=RT.near;if(n&&n.kind==='x'){if(RT.paused)return;if(n.fn)n.fn(n.xe);return}di()}}
setInterval(()=>{if(S&&typeof ENGINE_READY!=='undefined'&&ENGINE_READY&&!$('#game').classList.contains('hide'))IA=interactables()},900);
const hhmm=m=>{m=((m%1440)+1440)%1440;const h=Math.floor(m/60),mm=m%60;return`${h%12||12}:${String(mm).padStart(2,'0')} ${h<12?'pg':h<19?'ptg':'mlm'}`};
const minOfDay=()=>S.time%1440;
const once=(k)=>{S.daily=S.daily||{};if(S.daily[k])return false;S.daily[k]=1;return true};
const xrand=a=>a[Math.floor(Math.random()*a.length)];
// ---------- new map locations
LOCS.push(['surau','Surau Al-Hidayah','Surau',[-99,-99],'#1f8a5a'],['surau2','Surau Ar-Rahman (Kampung)','Surau Kg',[-99,-99],'#1f8a5a'],['haiwan','Klinik Haiwan & Pusat Adopsi','Klinik Haiwan',[-99,-99],'#ff6eb4']);
for(const l of LOCS.slice(-3))LOC[l[0]]={id:l[0],name:l[1],short:l[2],door:l[3],col:l[4]};
MAP_HOOKS.push(B=>{B('surau',.27,.07,3,3,'surau','SURAU AL-HIDAYAH');B('surau',-.1,.31,3,3,'surau2','SURAU AR-RAHMAN');B('petclinic',.92,.73,3,3,'haiwan','KLINIK HAIWAN')});
BART.surau=(c,b)=>{const {x,y,w,h}=b;box(c,x-.15,y-.15,0,w+.3,h+.3,8,'#d8d0c0');box(c,x,y,8,w,h,40,'#fbfaf4');
  box(c,x,y+h,8,w,.03,5,'#1f8a5a',{notop:1});box(c,x+w,y,8,.03,h,5,'#17704a',{notop:1});
  for(let i=0;i<3;i++){const xc=x+.55+i*(w-1.1)/2;ipoly(c,[IP(xc-.22,y+h,18),IP(xc+.22,y+h,18),IP(xc+.22,y+h,36),IP(xc,y+h,42),IP(xc-.22,y+h,36)],'#9fd8c0','#1f8a5a',.8)}
  for(let i=0;i<2;i++){const yc=y+.8+i*(h-1.6);ipoly(c,[IP(x+w,yc-.22,18),IP(x+w,yc+.22,18),IP(x+w,yc+.22,36),IP(x+w,yc,42),IP(x+w,yc-.22,36)],'#7ab8a0','#17704a',.8)}
  doorY(c,x+w*.5,y+h,.5,28,'#6b4426');for(let s=0;s<2;s++)box(c,x+w*.3,y+h+.1+s*.22,8-s*4,w*.4,.24,3,'#e8dcc4');
  hipRoof(c,x,y,48,w,h,22,.35,'#2a9a6a');box(c,x+.6,y+.6,62,w-1.2,h-1.2,10,'#fbfaf4');hipRoof(c,x+.6,y+.6,72,w-1.2,h-1.2,20,.25,'#2a9a6a');
  const t=IP(x+w/2,y+h/2,92);dome(c,x+w/2,y+h/2,.32,92,16,'#f2c230');c.strokeStyle='#c88a1a';c.lineWidth=1.6;c.beginPath();c.moveTo(t[0],t[1]-16);c.lineTo(t[0],t[1]-28);c.stroke();c.fillStyle='#f2c230';c.beginPath();c.arc(t[0],t[1]-31,4,0,TAU);c.fill();c.fillStyle='#fbfaf4';c.beginPath();c.arc(t[0]+1.6,t[1]-31.6,3.2,0,TAU);c.fill();
  // small minaret
  cyl(c,x+w+.5,y+.4,.26,0,92,'#fbfaf4',{stripes:[[60,64,'#2a9a6a']]});cyl(c,x+w+.5,y+.4,.34,92,96,'#2a9a6a');dome(c,x+w+.5,y+.4,.26,96,14,'#2a9a6a');
  signY(c,x+w*.5,y+h,46,b.loc==='surau2'?'SURAU AR-RAHMAN':'SURAU AL-HIDAYAH','#1f8a5a','#fff',7)};
BART.petclinic=(c,b)=>{const {x,y,w,h}=b;box(c,x,y,0,w,h,50,'#fff4fa');box(c,x,y+h,40,w,.04,10,'#ff6eb4',{notop:1});winRowY(c,x+.2,x+w-.2,y+h,12,32,3,{frame:'#ffd6ea'});winRowX(c,x+w,y,y+h,12,32,2,{});doorY(c,x+w*.5,y+h,.6,26,'#bfe3ff',{glass:1});flatRoof(c,x,y,50,w,h,'#ffd0e6','#ff8cc6');
  onFace(c,'y',x+w*.5,y+h,45,()=>{c.fillStyle='#fff';c.font='900 8px Nunito';c.textAlign='center';c.textBaseline='middle';c.fillText('KLINIK HAIWAN',0,0)});
  const p=IP(x+w*.5,y+h*.5,58);c.fillStyle='#ff6eb4';c.beginPath();c.ellipse(p[0],p[1]-6,9,7,0,0,TAU);c.fill();for(const [dx,dy] of [[-9,-16],[-3,-20],[3,-20],[9,-16]]){c.beginPath();c.arc(p[0]+dx,p[1]+dy,3.2,0,TAU);c.fill()}};
// ---------- RELIGION (optional profile choice) + PRAYER TIMES
const AGAMA=[['','Tidak dinyatakan'],['islam','Islam'],['kristian','Kristian'],['buddha','Buddha'],['hindu','Hindu'],['lain','Lain-lain']];
XDEF.agama=()=>'';XDEF.solat=()=>({});XDEF.prayNotif=()=>true;
const PRAYERS=[['subuh','Subuh',5*60+50,7*60+10],['zohor','Zohor',13*60+15,16*60+34],['asar','Asar',16*60+35,19*60+19],['maghrib','Maghrib',19*60+20,20*60+34],['isyak','Isyak',20*60+35,23*60+59]];
const isMuslim=()=>S&&S.agama==='islam';
function prayerNow(){const m=minOfDay();return PRAYERS.find(p=>m>=p[2]&&m<=p[3])}
XMIN.push((t0,t1)=>{if(!isMuslim()||S.prayNotif===false)return;for(const p of PRAYERS){const at=Math.floor(t0/1440)*1440+p[2];for(const tt of [at,at+1440])if(tt>t0&&tt<=t1){notify(`Waktu solat ${p[1]} (${hhmm(p[2])})`);toast(`🕌 Masuk waktu ${p[1]}`,'y');try{sfx('notify')}catch(e){}}}});
ACT.setAgama=v=>{S.agama=v;save();toast(v?`Profil: ${AGAMA.find(a=>a[0]===v)[1]}`:'Agama tidak dinyatakan','g');rerender();if(DLG&&DLG.agama)ACT.settings()};
ACT.prayNotifT=()=>{S.prayNotif=S.prayNotif===false;save();toast(S.prayNotif?'Notifikasi waktu solat dihidupkan':'Notifikasi waktu solat dimatikan');if(DLG)ACT.settings()};
{const st=ACT.settings;ACT.settings=function(){st.apply(this,arguments);const b=$('#dlg .dbox>div');if(!b||!S)return;const d=document.createElement('div');d.className='sec';d.textContent='Profil Agama (pilihan)';const o=document.createElement('div');o.innerHTML=`<div class="opts">${AGAMA.map(a=>`<button class="opt ${S.agama===a[0]?'on':''}" data-a="setAgama" data-v="${a[0]}">${a[1]}</button>`).join('')}</div><p style="font-size:12px;color:var(--mut)">Ciri solat & notifikasi waktu solat hanya untuk profil Islam. Aktiviti komuniti surau terbuka kepada semua.</p>${isMuslim()?B(S.prayNotif===false?'🔕 Hidupkan notifikasi solat':'🔔 Matikan notifikasi solat','prayNotifT','','w'):''}`;b.appendChild(d);b.appendChild(o);if(DLG)DLG.agama=1}}
ACT.solat=v=>{if(!isMuslim()){toast('Ciri solat untuk profil Islam. Tetapkan dalam Tetapan → Profil Agama.','y');return}const p=prayerNow();if(!p){toast('Belum masuk waktu solat. Lihat jadual waktu solat.','y');return}
  const d=dayIdx();S.solat[d]=S.solat[d]||{};if(S.solat[d][p[0]]){toast(`Solat ${p[1]} sudah ditunaikan hari ini.`);return}
  const at=v==='surau';showDlg({title:`Solat ${p[1]}${at?' berjemaah':''}`,body:`<canvas id="solCv" width="320" height="150" style="width:100%;max-width:320px;display:block;margin:auto;border-radius:12px"></canvas><p style="text-align:center">Bersuci (wuduk) → bentang sejadah → tunaikan solat ${p[1]}.</p>`,buttons:[],after:()=>{const c=$('#solCv');if(!c)return;const x=c.getContext('2d');let f=0;const steps=['Ambil wuduk','Bentang sejadah','Berdiri (qiyam)','Rukuk','Sujud','Salam'];
    const iv=setInterval(()=>{if(!$('#solCv')){clearInterval(iv);return}x.clearRect(0,0,320,150);const g=x.createLinearGradient(0,0,0,150);g.addColorStop(0,at?'#e8f6ee':'#fff7ec');g.addColorStop(1,at?'#c8ecd8':'#f4e2c8');x.fillStyle=g;x.fillRect(0,0,320,150);
      x.fillStyle='#1f8a5a';x.beginPath();x.moveTo(120,120);x.lineTo(200,120);x.lineTo(210,140);x.lineTo(110,140);x.fill();x.fillStyle='#f2c230';x.fillRect(150,124,20,10);drawChibi(x,160,124,.62,S.look,f%6>=4?3:0,0);
      x.fillStyle='#2a1f47';x.font='800 13px Nunito';x.textAlign='center';x.fillText(steps[Math.min(5,Math.floor(f/2))],160,22);f++;if(f>12){clearInterval(iv);S.solat[d][p[0]]=1;stat('gembira',2);if(at){stat('karisma',1);addXP(6)}else addXP(4);advance(at?15:10);closeDlg();toast(`Solat ${p[1]} ditunaikan${at?' berjemaah di surau':''} 🤲`,'g');save()}},380)}})};
const SURAU_ACTS=[['kuliah','📖 Kuliah Agama','Kuliah maghrib bersama ustaz (Isnin & Khamis, 8–10 mlm).',1,(w,m)=>(w===0||w===3)&&m>=20*60&&m<22*60,()=>{advance(90);stat('akademik',2);stat('gembira',3);addXP(10)}],
  ['quran','📗 Bacaan Al-Quran','Tadarus bersama jemaah di rak Al-Quran.',1,()=>true,()=>{advance(45);stat('gembira',3);stat('karisma',1);addXP(6)}],
  ['kelas','🕌 Kelas Fardu Ain','Kelas agama hujung minggu (Sabtu & Ahad, 9–12 tgh).',1,(w,m)=>(w===5||w===6)&&m>=9*60&&m<12*60,()=>{advance(120);stat('akademik',3);addXP(12)}],
  ['derma','💚 Derma & Kebajikan','Sumbangan RM20 ke tabung kebajikan surau.',0,()=>true,()=>{if(!spend(20,'Derma surau'))return false;stat('karisma',3);stat('gembira',4);addXP(8);S.cnt.derma=(S.cnt.derma||0)+1}],
  ['gotong','🧹 Gotong-royong Surau','Bersihkan kawasan surau (Sabtu pagi, 7–11 pg).',0,(w,m)=>w===5&&m>=7*60&&m<11*60,()=>{if(!useEnergy(10))return false;advance(120);stat('karisma',3);addXP(15)}],
  ['komuniti','🤝 Program Komuniti','Majlis komuniti mingguan (Ahad, 5–7 ptg).',0,(w,m)=>w===6&&m>=17*60&&m<19*60,()=>{advance(90);stat('gembira',6);stat('karisma',2);addXP(10);const n=xrand(RT.npcs.filter(n=>n.named));S.friends[n.id]=(S.friends[n.id]||0)+4}]];
ACT.surauAct=v=>{const a=SURAU_ACTS.find(x=>x[0]===v);if(!a)return;if(a[3]&&!isMuslim()){toast('Aktiviti ini untuk profil Islam.','y');return}const t=dateOf(dayIdx());if(!a[4](t.w,minOfDay())){toast('Belum waktunya: '+a[2],'y');return}if(S.daily['surau_'+v]){toast('Sudah disertai hari ini.');return}
  const go=()=>{if(a[5]()===false)return;S.daily['surau_'+v]=1;toast(a[1].slice(2)+' selesai!','g');rerender()};if(atLoc('surau')||atLoc('surau2'))go();else needAt('surau',go,'Pergi ke')};
XLOC.push((id,c)=>{if(id!=='surau'&&id!=='surau2')return;const t=dateOf(dayIdx()),m=minOfDay(),p=prayerNow();
  c.unshift(card('🕌 '+esc(LOC[id].name),'Dewan solat berkarpet, sejadah, ruang wuduk, rak kasut, rak Al-Quran & hiasan khat. Terbuka kepada semua untuk program komuniti.',`<div class="kv" style="margin:6px 0">${PRAYERS.map(q=>`<span>${q[1]}</span><b ${p&&p[0]===q[0]?'style="color:#1f8a5a"':''}>${hhmm(q[2])}${p&&p[0]===q[0]?' · SEKARANG':''}</b>`).join('')}</div>`+(isMuslim()?B(p?`Solat ${p[1]} Berjemaah`:'Belum waktu solat','solat','surau','g',!p||((S.solat[dayIdx()]||{})[p&&p[0]])):B('Tetapkan Profil Agama','settings','','w')),'on'));
  c.push(card('📅 Aktiviti Surau','Kuliah, tadarus, kelas, derma, gotong-royong & program komuniti.',SURAU_ACTS.map(a=>B(a[1]+(S.daily['surau_'+a[0]]?' ✓':''),'surauAct',a[0],a[3]?'':'w',(a[3]&&!isMuslim())||!a[4](t.w,m)||S.daily['surau_'+a[0]])).join('')));
  const mus=RT.npcs.filter(n=>['hafiz','nurul','siti','aiman','faridah','danial'].includes(n.id));c.push(card('👥 Jemaah Surau','Berbual dengan jemaah.',mus.map(n=>B(n.name.split(' ')[0],'surauTalk',n.id,'w')).join('')))});
ACT.surauTalk=v=>{const n=RT.npcs.find(x=>x.id===v);if(!n)return;if(once('st_'+v)){S.friends[v]=(S.friends[v]||0)+3;stat('gembira',2)}showDlg({title:n.name,body:`<p>“${esc(xrand(['Assalamualaikum! Jom sertai kuliah malam Khamis nanti.','Gotong-royong surau hari Sabtu, datang ramai-ramai ya.','Tabung kebajikan surau bantu keluarga asnaf di Kota Kita.','Bulan Ramadan nanti ada majlis berbuka di surau setiap hari.','Semua dialu-alukan ke program komuniti hujung minggu.']))}”</p>`,buttons:[{label:'Terima kasih',cls:'g',a:'closeDlg'}]})};
// home prayer card
XLOC.push((id,c)=>{if(id!==homeLoc()||!isMuslim())return;const p=prayerNow();c.push(card('🤲 Solat di Rumah',p?`Waktu ${p[1]} sekarang.`:'Belum masuk waktu solat.',B(p?`Solat ${p[1]}`:'Belum waktu','solat','rumah','w',!p||((S.solat[dayIdx()]||{})[p&&p[0]]))))});
XDAY.push(()=>{const d=dayIdx();for(const k in S.solat)if(+k<d-7)delete S.solat[k]});
