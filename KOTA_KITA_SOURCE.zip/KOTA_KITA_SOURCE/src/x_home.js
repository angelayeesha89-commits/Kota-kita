// ===================== FREE HOME DESIGN MODE =====================
ROOMS.splice(1,0,['bilik2','Bilik Tidur Tambahan']);ROOMS.splice(4,0,['makan','Ruang Makan']);ROOMS.push(['luar','Kawasan Luar']);
const ROOMN={bilik:'Bilik Tidur Utama',bilik2:'Bilik Tidur Tambahan',tamu:'Ruang Tamu',dapur:'Dapur',makan:'Ruang Makan',mandi:'Bilik Air',belajar:'Bilik Belajar',balkoni:'Balkoni',laman:'Taman',luar:'Kawasan Luar'};
ROOMS.forEach(r=>r[1]=ROOMN[r[0]]||r[1]);
const OUTDOOR=r=>r==='laman'||r==='luar';
const HOUSE_ROOMS={apartmen:['bilik','bilik2','tamu','dapur','makan','mandi','belajar','balkoni'],kondo:['bilik','bilik2','tamu','dapur','makan','mandi','belajar','balkoni']};
const roomsFor=()=>HOUSE_ROOMS[S.home.type]||ROOMS.map(r=>r[0]);
// all wall / floor styles are free
WALLS.forEach(w=>w[2]=0);FLOORS.forEach(f=>f[2]=0);
WALLS.push(['pat:floral','Kertas Dinding Bunga',0],['pat:check','Kertas Dinding Petak',0],['pat:cloud','Kertas Dinding Awan',0],['pat:motif','Kertas Dinding Motif',0]);
FLOORS.push(['#f4d8c0','Jubin Terakota',0],['#d8e8f0','Vinil Biru Pastel',0],['#3a3a44','Jubin Hitam Moden',0]);
const CURT=['#ffb3d6','#c9a7ff','#ffd27a','#9fd8c8','#ffffff','#e5484d','#3a86ff','#38b84a','#8a5a33'];
const FCOL=[null,'#e5484d','#ff8cc6','#ffd23f','#38b84a','#3a86ff','#8c5cf2','#8a5a33','#2b2b33','#f4f4f4'];
// free basic collection (unlimited, no money)
const BASIC=[['b_sofa','Sofa Asas','sofa','#8aa8d8'],['b_bed','Katil Asas','bed','#a8c0e8'],['b_chair','Kerusi','chair','#c8925a'],['b_table','Meja Asas','table','#c8a070'],['b_rug','Permaidani Asas','rug','#d8a8c8'],['b_lamp','Lampu Lantai','lamp','#ffd56b'],['b_plant','Pokok Dalam Pasu','plant','#3a9a4a'],
 ['b_shelf','Rak Asas','shelf','#b08050'],['b_wardrobe','Almari Asas','wardrobe','#c8a070'],['b_desk','Meja Tulis','desk','#d8b080'],['b_bench','Bangku Luar','bench','#a87040'],['b_frame','Hiasan Dinding','frame','#e2b44a'],['b_mirror','Cermin','mirror','#c0e0f0'],['b_dresser','Meja Solek','dresser','#f4c8d8'],
 ['b_cabinet','Kabinet Dapur','cabinet','#e8dcc8'],['b_outdoor','Set Meja Luar','outdoorset','#3a86ff'],['b_flower','Pasu Bunga','flower','#ff5ea8'],['b_curtain','Langsir Hiasan','curtainp','#c9a7ff']];
for(const b of BASIC){const f={id:b[0],name:b[1],room:'*',price:0,shape:b[2],c:b[3],comfort:1,free:1};FURN.push(f);FURNI[f.id]=f}
FURN.push(...[['sofa3','Sofa Kulit Mewah','tamu',2800,'sofa','#6b3a2a',6],['katil4','Katil King Kayu Jati','bilik',3600,'bed','#c8a070',6],['solek','Meja Solek Diraja','bilik',1100,'dresser','#ffd6e8',3],['kabinet','Kabinet Dapur Moden','dapur',1500,'cabinet','#3a3a44',3],['meja4','Meja Makan 6 Kerusi','makan',1900,'table','#8a5a33',4],['kerusi2','Kerusi Makan Rotan','makan',260,'chair','#c8925a',1],['luarset','Set Payung Laman','luar',900,'outdoorset','#e5484d',3],['katilhaiwan','Katil Haiwan Peliharaan','tamu',120,'petbed','#ff8cc6',1]].map(f=>({id:f[0],name:f[1],room:f[2],price:f[3],shape:f[4],c:f[5],comfort:f[6]})));
FURN.slice(-8).forEach(f=>FURNI[f.id]=f);
{const df=drawFurn;drawFurn=function(c,f,x,y,s){const P2=()=>new Path2D();const bx=(x0,y0,w,h,cc,r)=>{const p=P2();rrp(p,x0,y0,w,h,r||4);fillP(c,p,cc,1.4)};const col=f.c;
  const custom={chair:()=>{bx(-18,-34,36,8,col);bx(-16,-70,6,38,shade(col,-.2));bx(10,-70,6,38,shade(col,-.2));bx(-16,-70,32,8,col);bx(-16,-26,5,26,shade(col,-.3));bx(11,-26,5,26,shade(col,-.3))},
    dresser:()=>{bx(-36,-46,72,46,col);bx(-30,-40,28,14,shade(col,.2));bx(2,-40,28,14,shade(col,.2));bx(-22,-110,44,60,'#e2b44a',20);bx(-17,-105,34,50,'#c0e0f0',16)},
    cabinet:()=>{bx(-46,-50,92,50,col);bx(-46,-56,92,8,'#d8d0c0');for(let i=0;i<3;i++)bx(-42+i*30,-44,26,40,shade(col,.1));bx(-46,-130,92,40,col)},
    outdoorset:()=>{bx(-26,-34,52,6,'#f4f4f4');bx(-2,-30,4,30,'#aaa');c.fillStyle='#ddd';c.fillRect(-1,-100,2,66);for(let i=0;i<6;i++){c.fillStyle=i%2?'#fff':col;c.beginPath();c.moveTo(0,-104);c.arc(0,-92,40,Math.PI+i/6*Math.PI,Math.PI+(i+1)/6*Math.PI);c.fill()}bx(-46,-26,14,26,'#c8925a');bx(32,-26,14,26,'#c8925a')},
    curtainp:()=>{bx(-40,-150,80,4,'#8a6a42');for(const sd of [-1,1]){c.fillStyle=col;c.beginPath();c.moveTo(sd*38,-148);c.lineTo(sd*8,-148);c.quadraticCurveTo(sd*20,-90,sd*14,-30);c.lineTo(sd*38,-30);c.closePath();c.fill();c.strokeStyle=shade(col,-.3);c.stroke()}},
    petbed:()=>{c.fillStyle=col;c.beginPath();c.ellipse(0,-10,34,14,0,0,TAU);c.fill();c.fillStyle=shade(col,.35);c.beginPath();c.ellipse(0,-12,24,9,0,0,TAU);c.fill();c.fillStyle='#fff';c.font='12px sans-serif';c.textAlign='center';c.fillText('🐾',0,-8)}};
  if(custom[f.shape]){c.save();c.translate(x,y);c.scale(s,s);custom[f.shape]();c.restore();return}return df(c,f,x,y,s)}}
// layout model
XDEF.homeSaved=()=>[];
XMIG.push(()=>{for(const r of ROOMS){if(!S.home.rooms[r[0]])S.home.rooms[r[0]]={wall:0,floor:0,items:[]};const R=S.home.rooms[r[0]];if(!R.lay){R.lay=R.items.filter(id=>FURNI[id]).map((id,i,a)=>({id,x:a.length>1?.12+i*(.76/(a.length-1)):.5,y:(i%2)*.45+.25,r:0,s:1,c:null}))}}
  for(const m in (S.mkDefs||{}))if(!FURNI[m]){FURNI[m]=S.mkDefs[m];FURN.push(S.mkDefs[m])}homeSync()});
function homeSync(){const av=new Set(roomsFor());for(const r of ROOMS){const R=S.home.rooms[r[0]];if(!R)continue;if(!av.has(r[0])&&R.lay.length){for(const l of R.lay)if(!FURNI[l.id].free)S.furn.push(l.id);R.lay=[];notify(`${ROOMN[r[0]]} tiada di rumah ini — perabot disimpan ke stor.`)}R.items=R.lay.map(l=>l.id)}}
// comfort counts placed items (free ones = 1)
// ---------- design canvas
const HD={sel:null,drag:null,room:'tamu',anim:0};
const FSZ={bed:[100,62],sofa:[124,66],wardrobe:[64,100],desk:[80,64],pc:[80,76],lamp:[36,76],ac:[76,24],tv:[96,100],shelf:[64,100],rug:[120,26],plant:[40,70],frame:[64,50],deco:[30,60],stove:[76,52],fridge:[60,112],table:[104,50],sink:[76,66],oven:[64,52],bath:[116,40],shower:[40,140],washer:[64,66],mirror:[48,66],swing:[84,124],flower:[32,44],bbq:[56,52],pond:[124,32],aquarium:[96,90],trophy:[76,100],bench:[92,52],chair:[40,72],dresser:[76,112],cabinet:[96,132],outdoorset:[96,106],curtainp:[84,124],petbed:[72,30],ricecooker:[50,44],microwave:[68,42],blender:[30,62],utensils:[64,50]};
const WALLY=new Set(['frame','deco','ac','mirror','curtainp']);
function hdPos(l,W,H){const fy=H*.62;const yy=fy+(H-fy)*(.12+l.y*.82);return{x:W*.06+l.x*W*.88,y:WALLY.has(FURNI[l.id].shape)?fy-(1-l.y)*4:yy,sc:(.62+.5*l.y)*l.s*Math.min(1.2,H/250)}}
function drawDesign(cv,room,tm){const R=S.home.rooms[room];const saved=R.items;R.items=Array(Math.max(8,HOUSE[S.home.type].slots)).fill('__none');try{drawRoom(cv,room)}finally{R.items=saved}const c=cv.getContext('2d'),W=cv.clientWidth,H=cv.clientHeight;
  // cover player drawn by drawRoom (redrawn after furniture)
  const lay=R.lay.map((l,i)=>({l,i,p:hdPos(l,W,H)})).sort((a,b)=>(WALLY.has(FURNI[a.l.id].shape)?-1:a.p.y)-(WALLY.has(FURNI[b.l.id].shape)?-1:b.p.y));
  for(const o of lay){const f=FURNI[o.l.id];if(!f)continue;const ff=o.l.c?Object.assign({},f,{c:o.l.c}):f;c.save();c.translate(o.p.x,o.p.y);if(o.l.r)c.scale(-1,1);drawFurn(c,ff,0,0,o.p.sc);c.restore();
    if(HD.sel===o.i){const sz=FSZ[f.shape]||[80,80];c.strokeStyle='#ffd23f';c.lineWidth=2.5;c.setLineDash([6,4]);c.strokeRect(o.p.x-sz[0]*o.p.sc/2-4,o.p.y-sz[1]*o.p.sc-4,sz[0]*o.p.sc+8,sz[1]*o.p.sc+8);c.setLineDash([])}}
  // pets roaming
  for(const p of (S.pets||[]).filter(p=>p.home&&(p.room||'tamu')===room)){const ph=(tm||0)/1000+p.seed*7;const px=W*(.15+.7*(.5+.5*Math.sin(ph*.35))),py=H*.62+(H*.38)*(.55+.3*Math.sin(ph*.21));drawPet(c,px,py,Math.min(1.1,H/230),p,ph,Math.cos(ph*.35)<0)}}
function hdHit(cv,ex,ey){const room=HD.room,R=S.home.rooms[room],W=cv.clientWidth,H=cv.clientHeight;let best=null;R.lay.forEach((l,i)=>{const p=hdPos(l,W,H),sz=FSZ[FURNI[l.id].shape]||[80,80];if(ex>p.x-sz[0]*p.sc/2&&ex<p.x+sz[0]*p.sc/2&&ey>p.y-sz[1]*p.sc&&ey<p.y+6){if(!best||p.y>best.y)best={i,y:p.y}}});return best?best.i:null}
function hdBind(){const cv=$('#rkCv');if(!cv)return;const loop=t=>{if(!$('#rkCv')||SH.id!=='rumah')return;drawDesign(cv,HD.room,t);HD.anim=requestAnimationFrame(loop)};cancelAnimationFrame(HD.anim);HD.anim=requestAnimationFrame(loop);
  const rel=e=>{const r=cv.getBoundingClientRect();return[(e.clientX-r.left)*cv.clientWidth/r.width,(e.clientY-r.top)*cv.clientHeight/r.height]};
  cv.onpointerdown=e=>{const [x,y]=rel(e);const i=hdHit(cv,x,y);const prev=HD.sel;HD.sel=i;if(i!=null){const l=S.home.rooms[HD.room].lay[i];HD.drag={x,y,lx:l.x,ly:l.y,moved:false};cv.setPointerCapture(e.pointerId)}if(prev!==HD.sel)hdTools()};
  cv.onpointermove=e=>{if(!HD.drag||HD.sel==null)return;const [x,y]=rel(e);const W=cv.clientWidth,H=cv.clientHeight,l=S.home.rooms[HD.room].lay[HD.sel];l.x=clamp(HD.drag.lx+(x-HD.drag.x)/(W*.88),0,1);l.y=clamp(HD.drag.ly+(y-HD.drag.y)/((H*.38)*.82),0,1);HD.drag.moved=true};
  cv.onpointerup=()=>{if(HD.drag&&HD.drag.moved){save()}HD.drag=null}}
function hdTools(){const el=$('#rkTools');if(!el)return;const l=HD.sel!=null&&S.home.rooms[HD.room].lay[HD.sel];el.innerHTML=l?`<b class="rksel">✋ ${esc(FURNI[l.id].name)}</b>${B('⟲ Putar','hdRot','','w')}${B('＋ Besar','hdSize','1','w')}${B('－ Kecil','hdSize','-1','w')}${B('🎨 Warna','hdColor','','w')}${B('🚚 Pindah Bilik','hdMove','','w')}${B('🗑 Simpan ke Stor','hdRemove','','r')}`:'<span class="rkhint">Ketik perabot untuk pilih · seret untuk alih · semua reka bentuk PERCUMA</span>'}
const hdL=()=>S.home.rooms[HD.room].lay[HD.sel];
ACT.hdRot=()=>{const l=hdL();if(!l)return;l.r=l.r?0:1;save()};
ACT.hdSize=v=>{const l=hdL();if(!l)return;l.s=clamp(Math.round((l.s+(+v)*.1)*10)/10,.6,1.6);toast(`Saiz ${Math.round(l.s*100)}%`);save()};
ACT.hdColor=()=>{const l=hdL();if(!l)return;showDlg({title:'Warna perabot (percuma)',body:`<div class="opts">${FCOL.map((c,i)=>`<button class="opt ${l.c===c?'on':''}" data-a="hdSetCol" data-v="${i}" style="${c?`background:${c};color:${['#2b2b33','#8a5a33','#3a86ff','#8c5cf2','#e5484d','#38b84a'].includes(c)?'#fff':'#2a1f47'}`:''}">${c?'●':'Asal'}</button>`).join('')}</div>`,buttons:[{label:'Siap',cls:'g',a:'closeDlg'}]})};
ACT.hdSetCol=v=>{const l=hdL();if(!l)return;l.c=FCOL[+v];save();closeDlg()};
ACT.hdRemove=()=>{const R=S.home.rooms[HD.room];const l=R.lay[HD.sel];if(!l)return;R.lay.splice(HD.sel,1);if(!FURNI[l.id].free)S.furn.push(l.id);HD.sel=null;homeSync();save();rerender();toast(FURNI[l.id].free?'Perabot asas dibuang (boleh tambah semula bila-bila masa)':'Disimpan ke stor — tiada yang hilang','g')};
ACT.hdMove=()=>{const l=hdL();if(!l)return;showDlg({title:`Pindah ${FURNI[l.id].name} ke…`,body:`<div class="opts">${roomsFor().filter(r=>r!==HD.room).map(r=>`<button class="opt" data-a="hdMoveTo" data-v="${r}">${ROOMN[r]}</button>`).join('')}</div>`,buttons:[{label:'Batal',cls:'w',a:'closeDlg'}]})};
ACT.hdMoveTo=v=>{const R=S.home.rooms[HD.room];const l=R.lay[HD.sel];if(!l)return;if(S.home.rooms[v].lay.length>=16){toast('Bilik itu sudah penuh (16 perabot).','r');return}R.lay.splice(HD.sel,1);l.x=.5;l.y=.5;S.home.rooms[v].lay.push(l);HD.sel=null;homeSync();save();closeDlg();HD.room=v;rerender();toast('Dipindahkan ke '+ROOMN[v],'g')};
ACT.hdRoom=v=>{HD.room=v;ROOMSEL=v;HD.sel=null;renderSheet()};
ACT.hdAdd=t=>{t=t||'asas';const tabs=[['asas','🆓 Asas (Percuma)'],['stor','📦 Stor Saya ('+S.furn.length+')'],['premium','⭐ Beli Premium']];const ids=t==='asas'?BASIC.map(b=>b[0]):t==='stor'?S.furn.map((id,i)=>i):FURN.filter(f=>!f.free&&f.price>0&&!String(f.id).startsWith('m_')).map(f=>f.id);
  showDlg({title:'Tambah ke '+ROOMN[HD.room],wide:1,body:`<div class="opts" style="margin-bottom:6px">${tabs.map(x=>`<button class="opt ${x[0]===t?'on':''}" data-a="hdAdd" data-v="${x[0]}">${x[1]}</button>`).join('')}</div><div class="grid s rkpick">${ids.map(v=>{const f=t==='stor'?FURNI[S.furn[v]]:FURNI[v];if(!f)return'';return`<button class="card" data-a="${t==='premium'?'hdBuy':'hdPut'}" data-v="${t}:${v}"><canvas class="rkth" data-f="${f.id}" width="90" height="70"></canvas><h4>${esc(f.name)}</h4><p>${t==='premium'?fmt(f.price):t==='stor'?'Dari stor':'Percuma'}</p></button>`}).join('')||'<div class="note">Kosong. Beli di BorongKu / KedaiKlik atau tab Premium.</div>'}</div>`,buttons:[{label:'Tutup',cls:'w',a:'closeDlg'}],after:()=>document.querySelectorAll('canvas.rkth').forEach(c=>{const x=c.getContext('2d');drawFurn(x,FURNI[c.dataset.f],45,66,.42)})})};
ACT.hdPut=v=>{const [t,k]=v.split(':');const R=S.home.rooms[HD.room];if(R.lay.length>=16){toast('Bilik penuh (16 perabot). Simpan sebahagian ke stor dahulu.','r');return}let id;if(t==='stor'){id=S.furn[+k];if(!id)return;S.furn.splice(+k,1)}else id=k;R.lay.push({id,x:.5,y:.55,r:0,s:1,c:null});HD.sel=R.lay.length-1;homeSync();addXP(1);save();closeDlg();rerender();toast(FURNI[id].name+' diletak — seret untuk susun','g')};
ACT.hdBuy=v=>{const id=v.split(':')[1];const f=FURNI[id];if(!f)return;confirmDlg('Beli perabot premium',`${esc(f.name)} · ${fmt(f.price)}. Disimpan ke stor & terus diletak.`,'Beli',()=>{if(!spend(f.price,f.name))return;S.furn.push(id);const i=S.furn.length-1;ACT.hdPut('stor:'+i)})};
ACT.hdWall=v=>{S.home.rooms[HD.room].wall=+v;save();rerender()};ACT.hdFloor=v=>{S.home.rooms[HD.room].floor=+v;save();rerender()};ACT.hdCur=v=>{S.home.rooms[HD.room].cur=CURT[+v];save();rerender()};
ACT.hdSaveLay=()=>{showDlg({title:'Simpan reka letak',body:`<input id="hdName" class="tgq" maxlength="24" placeholder="Nama reka letak (cth: Ruang Tamu Raya)">`,buttons:[{label:'Batal',cls:'w',a:'closeDlg'},{label:'Simpan',cls:'g',a:'hdSaveGo'}]});setTimeout(()=>{const i=$('#hdName');if(i)i.focus()},50)};
ACT.hdSaveGo=()=>{const nm=(($('#hdName')||{}).value||'').trim()||('Reka letak '+(S.homeSaved.length+1));const R=S.home.rooms[HD.room];S.homeSaved.unshift({name:nm,room:HD.room,lay:JSON.parse(JSON.stringify(R.lay)),wall:R.wall,floor:R.floor,cur:R.cur||null});if(S.homeSaved.length>20)S.homeSaved.length=20;save();closeDlg();toast('Reka letak "'+nm+'" disimpan','g');rerender()};
ACT.hdLoadLay=v=>{const L=S.homeSaved[+v];if(!L)return;const R=S.home.rooms[L.room];const have=new Map();for(const r of ROOMS)for(const l of S.home.rooms[r[0]].lay)have.set(l.id,(have.get(l.id)||0)+1);for(const id of S.furn)have.set(id,(have.get(id)||0)+1);
  // return current items to storage, then place saved items that are still owned
  for(const l of R.lay)if(!FURNI[l.id].free)S.furn.push(l.id);const nl=[];let miss=0;for(const l of L.lay){if(FURNI[l.id]&&FURNI[l.id].free){nl.push(Object.assign({},l));continue}const i=S.furn.indexOf(l.id);if(i>=0){S.furn.splice(i,1);nl.push(Object.assign({},l))}else miss++}
  R.lay=nl;R.wall=L.wall;R.floor=L.floor;R.cur=L.cur;HD.room=L.room;HD.sel=null;homeSync();save();rerender();toast(miss?`Dimuat — ${miss} perabot tiada dalam stor (mungkin di bilik lain)`:'Reka letak dimuat','g')};
ACT.hdDelLay=v=>{S.homeSaved.splice(+v,1);save();rerender()};
// panel: replace "Rumah Saya" with design mode
PANELS.rumah.tabs[0]=['rumah','🏠 Reka Rumah (Percuma)'];
{const r0=PANELS.rumah.render;PANELS.rumah.render=t=>{if(t==='reka')t='rumah';if(t!=='rumah')return r0(t);homeSync();const av=roomsFor();if(!av.includes(HD.room))HD.room=av.includes(ROOMSEL)?ROOMSEL:av[0];const R=S.home.rooms[HD.room],H2=HOUSE[S.home.type];
  return`<div class="row" style="margin-bottom:6px"><span class="tagx">${S.home.owned?'Milik sendiri':H2.rent?'Sewa '+fmt(H2.rent)+'/bulan':'Rumah keluarga'}</span><span class="tagx u">Keselesaan: ${comfort()}</span><span class="tagx g">Reka bentuk 100% percuma</span></div>
  <div class="tabs rktabs">${av.map(r=>`<button class="${HD.room===r?'on':''}" data-a="hdRoom" data-v="${r}">${ROOMN[r]}</button>`).join('')}</div>
  <canvas class="room rkcv" id="rkCv"></canvas><div class="rktools" id="rkTools"></div>
  <div class="row" style="margin:6px 0">${B('＋ Tambah Perabot','hdAdd','asas','g')}${B('💾 Simpan Reka Letak','hdSaveLay','','w')}<span class="tagx">${R.lay.length}/16 perabot</span><span class="tagx">Stor: ${S.furn.length}</span></div>
  ${OUTDOOR(HD.room)?'':`<div class="sec">Dinding & Kertas Dinding</div><div class="opts">${WALLS.map((w,i)=>`<button class="opt ${R.wall===i?'on':''}" data-a="hdWall" data-v="${i}" ${w[0][0]==='#'?`style="background:${w[0]}"`:''}>${esc(w[1])}</button>`).join('')}</div>
  <div class="sec">Lantai</div><div class="opts">${FLOORS.map((w,i)=>`<button class="opt ${R.floor===i?'on':''}" data-a="hdFloor" data-v="${i}" style="background:${w[0]};color:${['#8b5a33','#3a3a44','#9a7ab0'].includes(w[0])?'#fff':'#2a1f47'}">${esc(w[1])}</button>`).join('')}</div>
  <div class="sec">Langsir</div><div class="opts">${CURT.map((c,i)=>`<button class="opt ${(R.cur||'')===c?'on':''}" data-a="hdCur" data-v="${i}" style="background:${c};min-width:34px">&nbsp;</button>`).join('')}</div>`}
  ${S.homeSaved.length?`<div class="sec">Reka Letak Disimpan</div><div class="list">${S.homeSaved.map((L,i)=>`<div class="li"><div class="t"><b>${esc(L.name)}</b><span>${ROOMN[L.room]} · ${L.lay.length} perabot</span></div>${B('Muat','hdLoadLay',i,'g')}${B('Padam','hdDelLay',i,'w')}</div>`).join('')}</div>`:''}
  ${HOUSE_ROOMS[S.home.type]?'<div class="note" style="margin-top:8px">Jenis rumah ini tiada taman/kawasan luar — guna balkoni.</div>':''}`}}
{const a0=PANELS.rumah.after;PANELS.rumah.after=t=>{if(t==='rumah'||t==='reka'){hdBind();hdTools();return}if(a0)a0(t)}}
// curtains + wallpapers in the shared room renderer
const WALLBASE={batik:'#2a6a8a',songket:'#6a1f2b',floral:'#ffe8f0',check:'#efe6ff',cloud:'#dfeeff',motif:'#fbe7d0'};
{const dr=drawRoom;drawRoom=function(cv,room){const R=S.home.rooms[room];if(OUTDOOR(room)&&room==='luar'){const sv=S.home.rooms.laman;S.home.rooms.laman=R;try{dr(cv,'laman')}finally{S.home.rooms.laman=sv}}else dr(cv,room);
  if(!OUTDOOR(room)){const W=cv.clientWidth,H=cv.clientHeight,c=cv.getContext('2d');const w=WALLS[R.wall]||WALLS[0];const fy=H*.62,top=H*.05,bx0=W*.07,bx1=W*.93;
    if(w[0].startsWith('pat:')&&!['pat:batik','pat:songket'].includes(w[0])){const p=w[0].slice(4);c.save();c.beginPath();c.rect(bx0,top,bx1-bx0,fy-top-7);c.clip();c.fillStyle=WALLBASE[p];c.fillRect(bx0,top,bx1-bx0,fy-top);drawPattern(c,p,WALLBASE[p],shade(WALLBASE[p],-.25),bx0,top,bx1,fy);c.restore();
      const wx=W*.4,ww=W*.2,wy=top+(fy-top)*.12,wh=(fy-top)*.5;c.fillStyle='#ffffff';c.fillRect(wx-7,wy-7,ww+14,wh+14);c.fillStyle='#8fd0ff';c.fillRect(wx,wy,ww,wh);c.fillStyle='#fff';c.fillRect(wx+ww/2-2,wy,4,wh);c.fillRect(wx,wy+wh/2-2,ww,4)}
    if(R.cur){const wx=W*.4,ww=W*.2,wy=top+(fy-top)*.12,wh=(fy-top)*.5;for(const sd of [-1,1]){const cx0=sd<0?wx-16:wx+ww+16;c.fillStyle=R.cur;c.beginPath();c.moveTo(cx0,wy-10);c.lineTo(cx0+sd*-16,wy-10);c.quadraticCurveTo(cx0+sd*-8,wy+wh*.5,cx0+sd*-12,wy+wh+4);c.lineTo(cx0,wy+wh+4);c.closePath();c.fill();c.strokeStyle=shade(R.cur,-.3);c.stroke()}}}}}
// comfort uses free items as 1 point each (already via FURNI.comfort); keep items in sync after any old-style edits
{const fi=ACT.furnIn;ACT.furnIn=v=>{const id=S.furn[+v];fi(v);const R=S.home.rooms[ROOMSEL];if(R.lay&&R.items.includes(id)&&R.lay.length<R.items.length)R.lay.push({id,x:.5,y:.5,r:0,s:1,c:null})}}
{const fo=ACT.furnOut;ACT.furnOut=v=>{const R=S.home.rooms[ROOMSEL];const id=R.items[+v];fo(v);const i=R.lay?R.lay.findIndex(l=>l.id===id):-1;if(i>=0)R.lay.splice(i,1)}}
{const mh=ACT.moveHouse;ACT.moveHouse=v=>{mh(v);setTimeout(()=>{if(S)homeSync()},60)}}
