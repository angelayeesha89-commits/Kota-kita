#!/usr/bin/env python3
"""
KOTA KITA – Dunia Malaysia : build script
------------------------------------------
Combines the source files in ../src into runnable game files.

Outputs (paths relative to the project root):
  index.html               Single self-contained file (CSS + JS + fonts embedded).
                           Works fully offline. This is the file to use for an APK.
  web/index.html           Same game, with fonts loaded from ../fonts/fonts.css instead
  web/fonts/...            of embedded (multi-file version, for hosting or editing).
  android/app/src/main/assets/index.html   copy of index.html for the Android project.

  --online                 Also writes original_artifact/rebuilt.html using the
                           Google Fonts link, identical to the published Artifact.

Usage:  python3 tools/build.py            (run from the project root or anywhere)

The JavaScript is wrapped in the same order as the published game. Do not change
the order of JS_ORDER: later files override functions from earlier files.
"""
import base64, os, sys, shutil

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'src')
FONTS = os.path.join(ROOT, 'fonts')

JS_ORDER = ['data.js', 'assets.js', 'chibi.js', 'anime.js', 'world.js', 'engine.js',
            'core.js', 'ui.js', 'games.js', 'panels1.js', 'panels2.js', 'loc.js',
            'features.js', 'life.js', 'creator.js', 'update.js', 'iso_gen.js',
            'iso_art.js', 'iso_render.js', 'iso_hud.js', 'career2.js', 'x_base.js',
            'x_cook.js', 'x_tapau.js', 'x_fest.js', 'x_home.js', 'x_shop.js',
            'x_pet.js', 'x_farm.js']

GOOGLE_FONTS = ('<link rel="preconnect" href="https://fonts.googleapis.com">'
                '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n'
                '<link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@500;600;700'
                '&family=Nunito:wght@600;700;800;900&display=swap" rel="stylesheet">')

RANGES = {
    'latin': 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,'
             'U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD',
    'latin-ext': 'U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,'
                 'U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,'
                 'U+2113,U+2C60-2C7F,U+A720-A7FF',
}
FACES = [('Fredoka', 'fredoka', w) for w in (500, 600, 700)] + \
        [('Nunito', 'nunito', w) for w in (600, 700, 800, 900)]


def font_css(embed, prefix='fonts/'):
    out = []
    for fam, key, w in FACES:
        for sub in ('latin-ext', 'latin'):   # latin last, same order Google uses
            fn = f'{key}-{sub}-{w}-normal.woff2'
            if embed:
                data = base64.b64encode(open(os.path.join(FONTS, fn), 'rb').read()).decode()
                url = f'data:font/woff2;base64,{data}'
            else:
                url = prefix + fn
            out.append("@font-face{font-family:'%s';font-style:normal;font-weight:%d;"
                       "font-display:swap;src:url(%s) format('woff2');unicode-range:%s}"
                       % (fam, w, url, RANGES[sub]))
    return '\n'.join(out)


def assemble():
    css = open(os.path.join(SRC, 'style.css'), encoding='utf-8').read()
    js = '\n'.join(open(os.path.join(SRC, f), encoding='utf-8').read() for f in JS_ORDER)
    shell = open(os.path.join(SRC, 'shell.html'), encoding='utf-8').read()
    return shell.replace('/*CSS*/', css).replace('/*JS*/', js)


def main():
    html = assemble()
    if GOOGLE_FONTS not in html:
        sys.exit('ERROR: font link block not found in src/shell.html')

    # 1) single-file offline build (use this for the APK)
    single = html.replace(GOOGLE_FONTS, '<style>\n' + font_css(True) + '\n</style>')
    open(os.path.join(ROOT, 'index.html'), 'w', encoding='utf-8').write(single)

    # 2) multi-file web build
    web = os.path.join(ROOT, 'web')
    os.makedirs(os.path.join(web, 'fonts'), exist_ok=True)
    for _, key, w in FACES:
        for sub in ('latin', 'latin-ext'):
            fn = f'{key}-{sub}-{w}-normal.woff2'
            shutil.copy(os.path.join(FONTS, fn), os.path.join(web, 'fonts', fn))
    open(os.path.join(web, 'fonts', 'fonts.css'), 'w').write(font_css(False, prefix=''))
    multi = html.replace(GOOGLE_FONTS, '<link rel="stylesheet" href="fonts/fonts.css">')
    open(os.path.join(web, 'index.html'), 'w', encoding='utf-8').write(multi)

    # 3) copy the single-file build into the Android WebView project
    adir = os.path.join(ROOT, 'android', 'app', 'src', 'main', 'assets')
    if os.path.isdir(os.path.dirname(adir)):
        os.makedirs(adir, exist_ok=True)
        shutil.copy(os.path.join(ROOT, 'index.html'), os.path.join(adir, 'index.html'))

    # 4) optional: rebuild exactly like the published Artifact (needs internet for fonts)
    if '--online' in sys.argv:
        open(os.path.join(ROOT, 'original_artifact', 'rebuilt.html'), 'w',
             encoding='utf-8').write(html)

    print('index.html      %8d bytes (offline, single file)' % len(single.encode()))
    print('web/index.html  %8d bytes (+ web/fonts/)' % len(multi.encode()))


if __name__ == '__main__':
    main()
